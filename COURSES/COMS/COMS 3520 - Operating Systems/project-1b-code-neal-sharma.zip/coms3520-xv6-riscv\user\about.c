// Name: Neal Sharma
// Description: Prints course information, student name, and an optional command-line argument.

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]) {
    printf("COM S 3520 Project 1A\n");
    printf("Student: Neal Sharma\n");
    
    if(argc == 2) {
        printf("Argument: %s\n", argv[1]);
    }
    
    exit(0);
}