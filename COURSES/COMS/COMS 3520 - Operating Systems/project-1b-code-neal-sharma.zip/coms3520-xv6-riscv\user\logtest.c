#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void do_heavy_work() {
  volatile int calc = 0;
  for (int i = 0; i < 100000; i++) {
    for (int j = 0; j < 10000; j++) {
      calc += i;
    }
  }
}

int main(int argc, char *argv[]) {
  if (argc > 1 && strcmp(argv[1], "priority") == 0) {
    nice(getpid(), -20);
    
    int pid1 = fork();
    if (pid1 == 0) {
      int my_nice = nice(getpid(), 0);
      printf("Child %d with nice %d starting work\n", getpid(), my_nice);
      do_heavy_work();
      printf("Child %d finished\n", getpid());
      exit(0);
    }
    
    int pid2 = fork();
    if (pid2 == 0) {
      int my_nice = nice(getpid(), 0);
      printf("Child %d with nice %d starting work\n", getpid(), my_nice);
      do_heavy_work();
      printf("Child %d finished\n", getpid());
      exit(0);
    }
    
    nice(pid1, 10);
    nice(pid2, 5);
    
    wait(0);
    wait(0);
    exit(0);
  }

  // Default mode
  startLogging();
  
  int pid = fork();
  if (pid == 0) {
    nice(getpid(), 10);
    do_heavy_work();
    exit(0);
  } else {
    wait(0);
    stopLogging();
    exit(0);
  }
}
