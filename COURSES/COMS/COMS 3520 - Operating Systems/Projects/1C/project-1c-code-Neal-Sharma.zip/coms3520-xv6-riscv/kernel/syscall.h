// System call numbers
#define SYS_fork   1
#define SYS_exit   2
#define SYS_wait   3
#define SYS_pipe   4
#define SYS_read   5
#define SYS_kill   6
#define SYS_exec   7
#define SYS_fstat  8
#define SYS_chdir  9
#define SYS_dup    10
#define SYS_getpid 11
#define SYS_sbrk   12
#define SYS_pause  13
#define SYS_uptime 14
#define SYS_open   15
#define SYS_write  16
#define SYS_mknod  17
#define SYS_unlink 18
#define SYS_link   19
#define SYS_mkdir  20
#define SYS_close  21
#define SYS_sync   22

// Project 1B
#define SYS_startLogging 23
#define SYS_stopLogging  24
#define SYS_nice         25

// Project 1C
#define SYS_workload_load          26
#define SYS_workload_process_count 27
#define SYS_workload_attach        28
#define SYS_workload_start         29
#define SYS_workload_checkpoint    30
#define SYS_workload_stop          31
#define SYS_workload_stats         32
#define SYS_set_scheduler          33
