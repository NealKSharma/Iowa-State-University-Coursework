kernel/policy.o: kernel/policy.c kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/spinlock.h kernel/proc.h \
 kernel/defs.h
