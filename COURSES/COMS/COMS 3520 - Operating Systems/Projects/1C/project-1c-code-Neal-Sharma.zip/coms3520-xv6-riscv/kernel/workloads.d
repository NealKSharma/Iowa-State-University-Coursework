kernel/workloads.o: kernel/workloads.c kernel/types.h kernel/workload.h
