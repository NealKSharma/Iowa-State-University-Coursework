// Project 1C: scheduling policies.
//
// This is the file you modify. The scheduler framework in proc.c
// calls the functions below; it already handles locking and the
// context switch, so a policy only decides which process runs next
// and when the running process should be preempted.
//
// Each policy has an ID. Select one at run time with the
// set_scheduler(id) system call (for example: wl 2 1). To try a
// different setting, such as another quantum, give it its own ID.
//
// Scheduler IDs:
//   0: round robin, 10-tick quantum (starter).
//   1: round robin, 1-tick quantum (starter).
//   2: strict priority by nice, 10-tick quantum (starter).
//   3: MLFQ, nice-based starts Q2/Q1/Q0 (-20..-10/-9..10/11..19);
//      quanta 2/10/15 ticks, allotments 2/10 ticks before demotion;
//      usage survives sleeps; every 60 ticks boost to max(start, Q1);
//      cross-band nice changes reset level/usage; higher queues preempt.
//   4: stride, nice-weighted tickets, per-tick pass accounting;
//      minimum pass wins, rotating ties, upward-only wakeup placement.
//   5: five-tick stride with longest-runnable-wait override at 20 ticks;
//      waiting clears on dispatch/wakeup; aging service charges normal pass.
//   6: round robin, 5-tick quantum (50 ms); ignores nice.
//  10: ID 4 stride with a 5-tick quantum; pass still advances every tick.
//  11: ID 4 stride with effective tickets floored at 335; 1-tick quantum.
//  12: ID 3 MLFQ with a 30-tick boost interval.
//  13: ID 3 MLFQ with a 30-tick Q0 quantum.
//
// Rules for policy code (Section 2.2 of the project document):
//  1. The system has one CPU. These functions run with interrupts off
//     and must not sleep or acquire p->lock (the framework holds the
//     locks it needs).
//  2. policy_pick_next_proc() must only return a RUNNABLE process, or
//     0 if there is none.
//  3. A scheduler meant to be fair must not starve a job: every ready
//     job eventually runs. (Strict priority, ID 2, is the one
//     deliberate exception.)
//  4. A scheduler must not recognize a workload: do not read
//     p->wl_slot, workload IDs, process names, or pids to decide how
//     to treat a process.
//  5. policy_init(id) may be called more than once for the same ID,
//     including at the start of every workload run. Each call must
//     reset all of the scheduler's global state.
//  6. Do not modify the protected files (kernel/workload.c,
//     kernel/workload.h, user/wl.c).

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

#define SCHED_RR     0 // round robin, 10-tick (100 ms) quantum: stock xv6
#define SCHED_RR1    1 // round robin, 1-tick (10 ms) quantum
#define SCHED_PRIO   2 // strict priority by nice (Project 1B), 10-tick quantum
#define SCHED_MLFQ   3 // multi-level feedback queues, Q2 highest
#define SCHED_STRIDE 4 // deterministic nice-weighted proportional share
#define SCHED_STRIDE_AGING 5 // stride with bounded-wait service opportunities
#define SCHED_RR5    6 // round robin, 5-tick (50 ms) quantum
#define SCHED_STRIDE5       10
#define SCHED_STRIDE_FLOOR  11
#define SCHED_MLFQ_BOOST30  12
#define SCHED_MLFQ_Q030     13

// Linux CFS weights for nice -20 .. 19, indexed by nice + 20
// (nice 0 has weight 1024). This is the same table user/wl.c uses
// for the fairness metric. For example, a fair-share scheduler can
// advance a process's vrt by (1 << 24) / nice_weight[p->nice + 20]
// for each tick it runs.
const int nice_weight[40] = {
  88761, 71755, 56483, 46273, 36291, 29154, 23254, 18705, 14949, 11916,
  9548,  7620,  6100,  4904,  3906,  3121,  2501,  1991,  1586,  1277,
  1024,  820,   655,   526,   423,   335,   272,   215,   172,   137,
  110,   87,    70,    56,    45,    36,    29,    23,    18,    15,
};

static int quantum = 10; // ticks a process may run before preemption
static int last = -1;    // index in proc[] of the last process chosen

static int mlfq_quantum[3] = {15, 10, 2};
static const int mlfq_allotment[3] = {0, 10, 2}; // Q0 never demotes
static int mlfq_last[3];
static uint last_boost;
static uint mlfq_boost_interval = 60;

#define STRIDE_SCALE (1ULL << 24)
static int stride_quantum = 1;
static int stride_ticket_floor = 0;
static uint64 aging_threshold = 20;
static int stride_last = -1;
static int stride_reset_left; // per-process initializations remaining in sched_reset

static int
is_stride(int id)
{
  return id == SCHED_STRIDE || id == SCHED_STRIDE_AGING ||
         id == SCHED_STRIDE5 || id == SCHED_STRIDE_FLOOR;
}

static int
is_mlfq(int id)
{
  return id == SCHED_MLFQ || id == SCHED_MLFQ_BOOST30 || id == SCHED_MLFQ_Q030;
}

// Exclude p itself, including when wakeup has already made it RUNNABLE.
static int
stride_min_other(struct proc *p, uint64 *minimum)
{
  int found = 0;

  for (struct proc *q = proc; q < &proc[NPROC]; q++) {
    if (q == p || (q->state != RUNNING && q->state != RUNNABLE))
      continue;
    if (!found || q->vrt < *minimum) {
      *minimum = q->vrt;
      found = 1;
    }
  }
  return found;
}

static void
stride_place(struct proc *p)
{
  uint64 minimum = 0;

  uint64 before = p->vrt;
  int peers = stride_min_other(p, &minimum);
  if (peers && p->vrt < minimum)
    p->vrt = minimum;
  if (logging)
    printk("stride place pid %d before %lu peers %d minimum %lu after %lu at %d\n",
           p->pid, before, peers, minimum, p->vrt, ticks);
}

// Subtract a common offset well before overflow. Active ordering is unchanged;
// obsolete sleeper credit is discarded and wakeup will clamp it to active work.
static void
stride_normalize(void)
{
  uint64 minimum = 0;

  if (!stride_min_other(0, &minimum) || minimum < (1ULL << 60))
    return;
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    if (p->state != UNUSED)
      p->vrt = p->vrt >= minimum ? p->vrt - minimum : 0;
  }
}

static int
starting_queue(int nice)
{
  if (nice <= -10)
    return 2;
  if (nice <= 10)
    return 1;
  return 0;
}

static void
change_queue(struct proc *p, int level)
{
  int old = p->level;

  p->level = level;
  if (logging && old != level)
    printk("mlfq pid %d Q%d -> Q%d at %d\n", p->pid, old, level, ticks);
}

// Called with interrupts off, including from selection after an idle interval.
static void
mlfq_boost(void)
{
  uint now = ticks;

  if (now - last_boost < mlfq_boost_interval)
    return;
  last_boost = now;
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    if (p->state == UNUSED || p->state == ZOMBIE)
      continue;
    int old_level = p->level;
    int old_used = p->used;
    change_queue(p, p->start_level > 1 ? p->start_level : 1);
    p->used = 0; // refresh the allotment even if the queue did not change
    if (logging)
      printk("mlfq boostcheck pid %d level %d->%d used %d->%d at %d\n",
             p->pid, old_level, p->level, old_used, p->used, ticks);
  }
}

// Called by set_scheduler(id), and again when a workload starts.
// Set up global state for policy id.
// Return 0 if id is a known policy, -1 otherwise.
int
policy_init(int id)
{
  // Select into locals first: an invalid ID must not alter the active policy.
  int next_quantum = 10;
  int next_stride_quantum = 1;
  int next_ticket_floor = 0;
  uint next_boost_interval = 60;
  int next_q0_quantum = 15;

  switch (id) {
  case SCHED_RR:
  case SCHED_PRIO:
  case SCHED_MLFQ:
  case SCHED_STRIDE:
    break;
  case SCHED_RR1:
    next_quantum = 1;
    break;
  case SCHED_RR5:
    next_quantum = 5;
    break;
  case SCHED_STRIDE_AGING:
  case SCHED_STRIDE5:
    next_stride_quantum = 5;
    break;
  case SCHED_STRIDE_FLOOR:
    next_ticket_floor = 335;
    break;
  case SCHED_MLFQ_BOOST30:
    next_boost_interval = 30;
    break;
  case SCHED_MLFQ_Q030:
    next_q0_quantum = 30;
    break;
  default:
    return -1;
  }
  // Reset every configurable parameter on each successful selection.
  quantum = next_quantum;
  stride_quantum = next_stride_quantum;
  stride_ticket_floor = next_ticket_floor;
  aging_threshold = 20;
  mlfq_boost_interval = next_boost_interval;
  mlfq_quantum[0] = next_q0_quantum;
  mlfq_quantum[1] = 10;
  mlfq_quantum[2] = 2;
  last = -1;
  for (int level = 0; level < 3; level++)
    mlfq_last[level] = -1;
  last_boost = ticks;
  stride_last = -1;
  stride_reset_left = 0;
  // sched_reset calls policy_proc_init once per allocated process with
  // interrupts off. Suppress placement until all old passes are cleared.
  if (is_stride(id))
    for (struct proc *p = proc; p < &proc[NPROC]; p++)
      if (p->state != UNUSED)
        stride_reset_left++;
  return 0;
}

// Called when a process is created, and for every process when the
// policy changes or a workload starts. Initialize any per-process
// policy fields.
void
policy_proc_init(struct proc *p)
{
  p->qticks = 0;
  // Level 0 is the lowest queue (Q0); Q2 is the highest. An MLFQ must
  // set the starting level from p->nice here: workload_start() calls
  // this for every process after the jobs' nice values are set.
  p->start_level = starting_queue(p->nice);
  p->level = is_mlfq(sched_current) ? p->start_level : 0;
  p->used = 0;
  p->vrt = 0;
  p->wait_ticks = 0;
  if (is_stride(sched_current)) {
    if (stride_reset_left > 0)
      stride_reset_left--;
    else
      stride_place(p); // new process joins at the other active minimum
  }
}

// Round robin: the next RUNNABLE process after the last one chosen,
// scanning proc[] in a circle so no process is starved.
static struct proc *
pick_rr(void)
{
  for (int i = 1; i <= NPROC; i++) {
    struct proc *p = &proc[(last + i) % NPROC];
    if (p->state == RUNNABLE) {
      last = p - proc;
      return p;
    }
  }
  return 0;
}

// Strict priority: a RUNNABLE process with the lowest nice value;
// processes with equal nice take turns in round-robin order.
static struct proc *
pick_prio(void)
{
  int best = 100;

  for (struct proc *p = proc; p < &proc[NPROC]; p++)
    if (p->state == RUNNABLE && p->nice < best)
      best = p->nice;
  for (int i = 1; i <= NPROC; i++) {
    struct proc *p = &proc[(last + i) % NPROC];
    if (p->state == RUNNABLE && p->nice == best) {
      last = p - proc;
      return p;
    }
  }
  return 0;
}

static struct proc *
pick_mlfq(void)
{
  mlfq_boost();
  for (int level = 2; level >= 0; level--) {
    for (int i = 1; i <= NPROC; i++) {
      struct proc *p = &proc[(mlfq_last[level] + i) % NPROC];
      if (p->state == RUNNABLE && p->level == level) {
        mlfq_last[level] = p - proc;
        return p;
      }
    }
  }
  return 0;
}

static struct proc *
pick_stride(void)
{
  struct proc *best = 0;
  struct proc *aged = 0;

  for (int i = 1; i <= NPROC; i++) {
    struct proc *p = &proc[(stride_last + i) % NPROC];
    if (p->state != RUNNABLE)
      continue;
    // Strict comparisons retain circular order for both kinds of ties.
    if (!best || p->vrt < best->vrt)
      best = p;
    if (sched_current == SCHED_STRIDE_AGING && p->wait_ticks >= aging_threshold &&
        (!aged || p->wait_ticks > aged->wait_ticks))
      aged = p;
  }
  if (aged) {
    if (logging && aged != best)
      printk("aging override pid %d wait %lu pass %lu over pid %d pass %lu at %d\n",
             aged->pid, aged->wait_ticks, aged->vrt, best->pid, best->vrt, ticks);
    best = aged;
  }
  if (best)
    stride_last = best - proc;
  return best;
}

// Choose the next process to run, or return 0 if none is RUNNABLE.
struct proc *
policy_pick_next_proc(void)
{
  switch (sched_current) {
  case SCHED_STRIDE:
  case SCHED_STRIDE_AGING:
  case SCHED_STRIDE5:
  case SCHED_STRIDE_FLOOR:
    return pick_stride();
  case SCHED_MLFQ:
  case SCHED_MLFQ_BOOST30:
  case SCHED_MLFQ_Q030:
    return pick_mlfq();
  case SCHED_PRIO:
    return pick_prio();
  default:
    return pick_rr();
  }
}

// Called just before the framework switches to p.
void
policy_dispatch(struct proc *p)
{
  p->wait_ticks = 0;
  p->qticks = 0; // a new quantum starts
  if (logging && is_stride(sched_current))
    printk("stride dispatch pid %d nice %d pass %lu at %d\n",
           p->pid, p->nice, p->vrt, ticks);
}

// Called on every timer tick while p is running.
// Return 1 to preempt p, or 0 to let it keep running.
// A process is charged only for ticks that arrive while it is running.
// A loop of pause(1) wakes at a tick, runs briefly, and sleeps again
// before the next one, so it is never charged and cannot test a rule
// such as an allotment kept across sleeps. A test that is charged must
// keep the CPU across a tick, for example by spinning until uptime()
// changes before each pause(1); workload jobs are charged correctly.
int
policy_tick(struct proc *p)
{
  // Sample runnable waiting once per timer tick, even inside a quantum.
  // Reaching the threshold changes the next selection, not preemption timing.
  if (sched_current == SCHED_STRIDE_AGING)
    for (struct proc *q = proc; q < &proc[NPROC]; q++)
      if (q->state == RUNNABLE && q->wait_ticks != ~0ULL)
        q->wait_ticks++;
  if (is_stride(sched_current)) {
    p->qticks++;
    uint64 before = p->vrt;
    int tickets = nice_weight[p->nice + 20];
    if (tickets < stride_ticket_floor)
      tickets = stride_ticket_floor;
    uint64 stride = STRIDE_SCALE / tickets;
    p->vrt += stride;
    if (logging)
      printk("stride charge pid %d nice %d before %lu step %lu after %lu at %d\n",
             p->pid, p->nice, before, stride, p->vrt, ticks);
    stride_normalize();
    return p->qticks >= stride_quantum;
  }
  if (!is_mlfq(sched_current)) {
    p->qticks++;
    return p->qticks >= quantum;
  }

  // Charge first, then boost, then check allotment/quantum and higher queues.
  p->used++;
  p->qticks++;
  mlfq_boost();

  int preempt = 0;
  if (p->level > 0 && p->used >= mlfq_allotment[p->level]) {
    change_queue(p, p->level - 1);
    p->used = 0;
    preempt = 1;
  }
  if (p->qticks >= mlfq_quantum[p->level])
    preempt = 1;
  for (struct proc *q = proc; q < &proc[NPROC]; q++)
    if (q->state == RUNNABLE && q->level > p->level)
      preempt = 1;
  return preempt;
}

// Called when p wakes from sleep (for example, when its simulated I/O
// or a pause() ends) and becomes RUNNABLE again. Use it to decide how
// a waking process re-enters the policy; for example, a fair-share or
// stride policy may move a process that slept a long time up to the
// current minimum, so it cannot claim the CPU for the time it slept.
void
policy_wakeup(struct proc *p)
{
  p->wait_ticks = 0;
  if (is_stride(sched_current))
    stride_place(p);
  // MLFQ retains level and used across sleeps; dispatch resets only qticks.
}

// Called whenever p's nice value changes.
void
policy_nice(struct proc *p)
{
  // Stride derives its increment from the current nice; preserve its pass.
  if (!is_mlfq(sched_current))
    return;
  int old_start = p->start_level;
  int old_level = p->level;
  int old_used = p->used;
  int old_qticks = p->qticks;
  int start = starting_queue(p->nice);
  if (start != p->start_level) {
    p->start_level = start;
    change_queue(p, start);
    p->used = 0;
  }
  // Diagnostics observe Rule 6 without changing scheduling decisions.
  if (logging)
    printk("mlfq nicecheck pid %d nice %d start %d->%d level %d->%d used %d->%d qticks %d->%d at %d\n",
           p->pid, p->nice, old_start, p->start_level, old_level, p->level,
           old_used, p->used, old_qticks, p->qticks, ticks);
}
