
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000d117          	auipc	sp,0xd
    80000004:	5d013103          	ld	sp,1488(sp) # 8000d5d0 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	03c000ef          	jal	80000052 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000022:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000026:	577d                	li	a4,-1
    80000028:	177e                	slli	a4,a4,0x3f
    8000002a:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002c:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000030:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000034:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    80000038:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003c:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + TICK_INTERVAL);
    80000040:	6761                	lui	a4,0x18
    80000042:	6a070713          	addi	a4,a4,1696 # 186a0 <_entry-0x7ffe7960>
    80000046:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    80000048:	14d79073          	csrw	stimecmp,a5
}
    8000004c:	6422                	ld	s0,8(sp)
    8000004e:	0141                	addi	sp,sp,16
    80000050:	8082                	ret

0000000080000052 <start>:
{
    80000052:	1141                	addi	sp,sp,-16
    80000054:	e406                	sd	ra,8(sp)
    80000056:	e022                	sd	s0,0(sp)
    80000058:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    8000005a:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000005e:	7779                	lui	a4,0xffffe
    80000060:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd6847>
    80000064:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000066:	6705                	lui	a4,0x1
    80000068:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000006c:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    8000006e:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000072:	00001797          	auipc	a5,0x1
    80000076:	d7a78793          	addi	a5,a5,-646 # 80000dec <main>
    8000007a:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    8000007e:	4781                	li	a5,0
    80000080:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    80000084:	67c1                	lui	a5,0x10
    80000086:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80000088:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    8000008c:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000090:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    80000094:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    80000098:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    8000009c:	57fd                	li	a5,-1
    8000009e:	83a9                	srli	a5,a5,0xa
    800000a0:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000a4:	47bd                	li	a5,15
    800000a6:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000aa:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000ae:	4705                	li	a4,1
    800000b0:	1776                	slli	a4,a4,0x3d
    800000b2:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000b4:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	7119                	addi	sp,sp,-128
    800000d2:	fc86                	sd	ra,120(sp)
    800000d4:	f8a2                	sd	s0,112(sp)
    800000d6:	f4a6                	sd	s1,104(sp)
    800000d8:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000da:	06c05a63          	blez	a2,8000014e <consolewrite+0x7e>
    800000de:	f0ca                	sd	s2,96(sp)
    800000e0:	ecce                	sd	s3,88(sp)
    800000e2:	e8d2                	sd	s4,80(sp)
    800000e4:	e4d6                	sd	s5,72(sp)
    800000e6:	e0da                	sd	s6,64(sp)
    800000e8:	fc5e                	sd	s7,56(sp)
    800000ea:	f862                	sd	s8,48(sp)
    800000ec:	f466                	sd	s9,40(sp)
    800000ee:	8aaa                	mv	s5,a0
    800000f0:	8b2e                	mv	s6,a1
    800000f2:	8a32                	mv	s4,a2
  int i = 0;
    800000f4:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000f6:	02000c13          	li	s8,32
    800000fa:	02000c93          	li	s9,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    800000fe:	5bfd                	li	s7,-1
    80000100:	a035                	j	8000012c <consolewrite+0x5c>
    if (nn > n - i)
    80000102:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	86ce                	mv	a3,s3
    80000108:	01648633          	add	a2,s1,s6
    8000010c:	85d6                	mv	a1,s5
    8000010e:	f8040513          	addi	a0,s0,-128
    80000112:	210020ef          	jal	80002322 <either_copyin>
    80000116:	03750e63          	beq	a0,s7,80000152 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011a:	85ce                	mv	a1,s3
    8000011c:	f8040513          	addi	a0,s0,-128
    80000120:	786000ef          	jal	800008a6 <uartwrite>
    i += nn;
    80000124:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000128:	0144da63          	bge	s1,s4,8000013c <consolewrite+0x6c>
    if (nn > n - i)
    8000012c:	409a093b          	subw	s2,s4,s1
    80000130:	0009079b          	sext.w	a5,s2
    80000134:	fcfc57e3          	bge	s8,a5,80000102 <consolewrite+0x32>
    80000138:	8966                	mv	s2,s9
    8000013a:	b7e1                	j	80000102 <consolewrite+0x32>
    8000013c:	7906                	ld	s2,96(sp)
    8000013e:	69e6                	ld	s3,88(sp)
    80000140:	6a46                	ld	s4,80(sp)
    80000142:	6aa6                	ld	s5,72(sp)
    80000144:	6b06                	ld	s6,64(sp)
    80000146:	7be2                	ld	s7,56(sp)
    80000148:	7c42                	ld	s8,48(sp)
    8000014a:	7ca2                	ld	s9,40(sp)
    8000014c:	a819                	j	80000162 <consolewrite+0x92>
  int i = 0;
    8000014e:	4481                	li	s1,0
    80000150:	a809                	j	80000162 <consolewrite+0x92>
    80000152:	7906                	ld	s2,96(sp)
    80000154:	69e6                	ld	s3,88(sp)
    80000156:	6a46                	ld	s4,80(sp)
    80000158:	6aa6                	ld	s5,72(sp)
    8000015a:	6b06                	ld	s6,64(sp)
    8000015c:	7be2                	ld	s7,56(sp)
    8000015e:	7c42                	ld	s8,48(sp)
    80000160:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000162:	8526                	mv	a0,s1
    80000164:	70e6                	ld	ra,120(sp)
    80000166:	7446                	ld	s0,112(sp)
    80000168:	74a6                	ld	s1,104(sp)
    8000016a:	6109                	addi	sp,sp,128
    8000016c:	8082                	ret

000000008000016e <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000016e:	711d                	addi	sp,sp,-96
    80000170:	ec86                	sd	ra,88(sp)
    80000172:	e8a2                	sd	s0,80(sp)
    80000174:	e4a6                	sd	s1,72(sp)
    80000176:	e0ca                	sd	s2,64(sp)
    80000178:	fc4e                	sd	s3,56(sp)
    8000017a:	f852                	sd	s4,48(sp)
    8000017c:	f456                	sd	s5,40(sp)
    8000017e:	f05a                	sd	s6,32(sp)
    80000180:	1080                	addi	s0,sp,96
    80000182:	8aaa                	mv	s5,a0
    80000184:	8a2e                	mv	s4,a1
    80000186:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000188:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018c:	00015517          	auipc	a0,0x15
    80000190:	4e450513          	addi	a0,a0,1252 # 80015670 <cons>
    80000194:	1fb000ef          	jal	80000b8e <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    80000198:	00015497          	auipc	s1,0x15
    8000019c:	4d848493          	addi	s1,s1,1240 # 80015670 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a0:	00015917          	auipc	s2,0x15
    800001a4:	56890913          	addi	s2,s2,1384 # 80015708 <cons+0x98>
  while (n > 0) {
    800001a8:	0d305463          	blez	s3,80000270 <consoleread+0x102>
    while (cons.r == cons.w) {
    800001ac:	0984a783          	lw	a5,152(s1)
    800001b0:	09c4a703          	lw	a4,156(s1)
    800001b4:	0af71963          	bne	a4,a5,80000266 <consoleread+0xf8>
      if (killed(myproc())) {
    800001b8:	6e0010ef          	jal	80001898 <myproc>
    800001bc:	7e1010ef          	jal	8000219c <killed>
    800001c0:	e925                	bnez	a0,80000230 <consoleread+0xc2>
      sleep_prepare(&cons.r);
    800001c2:	854a                	mv	a0,s2
    800001c4:	56d010ef          	jal	80001f30 <sleep_prepare>
      release(&cons.lock);
    800001c8:	8526                	mv	a0,s1
    800001ca:	251000ef          	jal	80000c1a <release>
      sleep();
    800001ce:	59f010ef          	jal	80001f6c <sleep>
      acquire(&cons.lock);
    800001d2:	8526                	mv	a0,s1
    800001d4:	1bb000ef          	jal	80000b8e <acquire>
    while (cons.r == cons.w) {
    800001d8:	0984a783          	lw	a5,152(s1)
    800001dc:	09c4a703          	lw	a4,156(s1)
    800001e0:	fcf70ce3          	beq	a4,a5,800001b8 <consoleread+0x4a>
    800001e4:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e6:	00015717          	auipc	a4,0x15
    800001ea:	48a70713          	addi	a4,a4,1162 # 80015670 <cons>
    800001ee:	0017869b          	addiw	a3,a5,1
    800001f2:	08d72c23          	sw	a3,152(a4)
    800001f6:	07f7f693          	andi	a3,a5,127
    800001fa:	9736                	add	a4,a4,a3
    800001fc:	01874703          	lbu	a4,24(a4)
    80000200:	00070b9b          	sext.w	s7,a4

    if (c == C('D')) { // end-of-file
    80000204:	4691                	li	a3,4
    80000206:	04db8663          	beq	s7,a3,80000252 <consoleread+0xe4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020a:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000020e:	4685                	li	a3,1
    80000210:	faf40613          	addi	a2,s0,-81
    80000214:	85d2                	mv	a1,s4
    80000216:	8556                	mv	a0,s5
    80000218:	0be020ef          	jal	800022d6 <either_copyout>
    8000021c:	57fd                	li	a5,-1
    8000021e:	04f50863          	beq	a0,a5,8000026e <consoleread+0x100>
      break;

    dst++;
    80000222:	0a05                	addi	s4,s4,1
    --n;
    80000224:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    80000226:	47a9                	li	a5,10
    80000228:	04fb8d63          	beq	s7,a5,80000282 <consoleread+0x114>
    8000022c:	6be2                	ld	s7,24(sp)
    8000022e:	bfad                	j	800001a8 <consoleread+0x3a>
        release(&cons.lock);
    80000230:	00015517          	auipc	a0,0x15
    80000234:	44050513          	addi	a0,a0,1088 # 80015670 <cons>
    80000238:	1e3000ef          	jal	80000c1a <release>
        return -1;
    8000023c:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    8000023e:	60e6                	ld	ra,88(sp)
    80000240:	6446                	ld	s0,80(sp)
    80000242:	64a6                	ld	s1,72(sp)
    80000244:	6906                	ld	s2,64(sp)
    80000246:	79e2                	ld	s3,56(sp)
    80000248:	7a42                	ld	s4,48(sp)
    8000024a:	7aa2                	ld	s5,40(sp)
    8000024c:	7b02                	ld	s6,32(sp)
    8000024e:	6125                	addi	sp,sp,96
    80000250:	8082                	ret
      if (n < target) {
    80000252:	0009871b          	sext.w	a4,s3
    80000256:	01677a63          	bgeu	a4,s6,8000026a <consoleread+0xfc>
        cons.r--;
    8000025a:	00015717          	auipc	a4,0x15
    8000025e:	4af72723          	sw	a5,1198(a4) # 80015708 <cons+0x98>
    80000262:	6be2                	ld	s7,24(sp)
    80000264:	a031                	j	80000270 <consoleread+0x102>
    80000266:	ec5e                	sd	s7,24(sp)
    80000268:	bfbd                	j	800001e6 <consoleread+0x78>
    8000026a:	6be2                	ld	s7,24(sp)
    8000026c:	a011                	j	80000270 <consoleread+0x102>
    8000026e:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000270:	00015517          	auipc	a0,0x15
    80000274:	40050513          	addi	a0,a0,1024 # 80015670 <cons>
    80000278:	1a3000ef          	jal	80000c1a <release>
  return target - n;
    8000027c:	413b053b          	subw	a0,s6,s3
    80000280:	bf7d                	j	8000023e <consoleread+0xd0>
    80000282:	6be2                	ld	s7,24(sp)
    80000284:	b7f5                	j	80000270 <consoleread+0x102>

0000000080000286 <consputc>:
{
    80000286:	1141                	addi	sp,sp,-16
    80000288:	e406                	sd	ra,8(sp)
    8000028a:	e022                	sd	s0,0(sp)
    8000028c:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    8000028e:	10000793          	li	a5,256
    80000292:	00f50863          	beq	a0,a5,800002a2 <consputc+0x1c>
    uartputc_sync(c);
    80000296:	696000ef          	jal	8000092c <uartputc_sync>
}
    8000029a:	60a2                	ld	ra,8(sp)
    8000029c:	6402                	ld	s0,0(sp)
    8000029e:	0141                	addi	sp,sp,16
    800002a0:	8082                	ret
    uartputc_sync('\b');
    800002a2:	4521                	li	a0,8
    800002a4:	688000ef          	jal	8000092c <uartputc_sync>
    uartputc_sync(' ');
    800002a8:	02000513          	li	a0,32
    800002ac:	680000ef          	jal	8000092c <uartputc_sync>
    uartputc_sync('\b');
    800002b0:	4521                	li	a0,8
    800002b2:	67a000ef          	jal	8000092c <uartputc_sync>
    800002b6:	b7d5                	j	8000029a <consputc+0x14>

00000000800002b8 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002b8:	1101                	addi	sp,sp,-32
    800002ba:	ec06                	sd	ra,24(sp)
    800002bc:	e822                	sd	s0,16(sp)
    800002be:	e426                	sd	s1,8(sp)
    800002c0:	1000                	addi	s0,sp,32
    800002c2:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c4:	00015517          	auipc	a0,0x15
    800002c8:	3ac50513          	addi	a0,a0,940 # 80015670 <cons>
    800002cc:	0c3000ef          	jal	80000b8e <acquire>

  switch (c) {
    800002d0:	47d5                	li	a5,21
    800002d2:	08f48f63          	beq	s1,a5,80000370 <consoleintr+0xb8>
    800002d6:	0297c563          	blt	a5,s1,80000300 <consoleintr+0x48>
    800002da:	47a1                	li	a5,8
    800002dc:	0ef48463          	beq	s1,a5,800003c4 <consoleintr+0x10c>
    800002e0:	47c1                	li	a5,16
    800002e2:	10f49563          	bne	s1,a5,800003ec <consoleintr+0x134>
  case C('P'): // Print process list.
    procdump();
    800002e6:	088020ef          	jal	8000236e <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ea:	00015517          	auipc	a0,0x15
    800002ee:	38650513          	addi	a0,a0,902 # 80015670 <cons>
    800002f2:	129000ef          	jal	80000c1a <release>
}
    800002f6:	60e2                	ld	ra,24(sp)
    800002f8:	6442                	ld	s0,16(sp)
    800002fa:	64a2                	ld	s1,8(sp)
    800002fc:	6105                	addi	sp,sp,32
    800002fe:	8082                	ret
  switch (c) {
    80000300:	07f00793          	li	a5,127
    80000304:	0cf48063          	beq	s1,a5,800003c4 <consoleintr+0x10c>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    80000308:	00015717          	auipc	a4,0x15
    8000030c:	36870713          	addi	a4,a4,872 # 80015670 <cons>
    80000310:	0a072783          	lw	a5,160(a4)
    80000314:	09872703          	lw	a4,152(a4)
    80000318:	9f99                	subw	a5,a5,a4
    8000031a:	07f00713          	li	a4,127
    8000031e:	fcf766e3          	bltu	a4,a5,800002ea <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000322:	47b5                	li	a5,13
    80000324:	0cf48763          	beq	s1,a5,800003f2 <consoleintr+0x13a>
      consputc(c);
    80000328:	8526                	mv	a0,s1
    8000032a:	f5dff0ef          	jal	80000286 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    8000032e:	00015797          	auipc	a5,0x15
    80000332:	34278793          	addi	a5,a5,834 # 80015670 <cons>
    80000336:	0a07a683          	lw	a3,160(a5)
    8000033a:	0016871b          	addiw	a4,a3,1
    8000033e:	0007061b          	sext.w	a2,a4
    80000342:	0ae7a023          	sw	a4,160(a5)
    80000346:	07f6f693          	andi	a3,a3,127
    8000034a:	97b6                	add	a5,a5,a3
    8000034c:	00978c23          	sb	s1,24(a5)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000350:	47a9                	li	a5,10
    80000352:	0cf48563          	beq	s1,a5,8000041c <consoleintr+0x164>
    80000356:	4791                	li	a5,4
    80000358:	0cf48263          	beq	s1,a5,8000041c <consoleintr+0x164>
    8000035c:	00015797          	auipc	a5,0x15
    80000360:	3ac7a783          	lw	a5,940(a5) # 80015708 <cons+0x98>
    80000364:	9f1d                	subw	a4,a4,a5
    80000366:	08000793          	li	a5,128
    8000036a:	f8f710e3          	bne	a4,a5,800002ea <consoleintr+0x32>
    8000036e:	a07d                	j	8000041c <consoleintr+0x164>
    80000370:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000372:	00015717          	auipc	a4,0x15
    80000376:	2fe70713          	addi	a4,a4,766 # 80015670 <cons>
    8000037a:	0a072783          	lw	a5,160(a4)
    8000037e:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000382:	00015497          	auipc	s1,0x15
    80000386:	2ee48493          	addi	s1,s1,750 # 80015670 <cons>
    while (cons.e != cons.w &&
    8000038a:	4929                	li	s2,10
    8000038c:	02f70863          	beq	a4,a5,800003bc <consoleintr+0x104>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000390:	37fd                	addiw	a5,a5,-1
    80000392:	07f7f713          	andi	a4,a5,127
    80000396:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    80000398:	01874703          	lbu	a4,24(a4)
    8000039c:	03270263          	beq	a4,s2,800003c0 <consoleintr+0x108>
      cons.e--;
    800003a0:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a4:	10000513          	li	a0,256
    800003a8:	edfff0ef          	jal	80000286 <consputc>
    while (cons.e != cons.w &&
    800003ac:	0a04a783          	lw	a5,160(s1)
    800003b0:	09c4a703          	lw	a4,156(s1)
    800003b4:	fcf71ee3          	bne	a4,a5,80000390 <consoleintr+0xd8>
    800003b8:	6902                	ld	s2,0(sp)
    800003ba:	bf05                	j	800002ea <consoleintr+0x32>
    800003bc:	6902                	ld	s2,0(sp)
    800003be:	b735                	j	800002ea <consoleintr+0x32>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b725                	j	800002ea <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c4:	00015717          	auipc	a4,0x15
    800003c8:	2ac70713          	addi	a4,a4,684 # 80015670 <cons>
    800003cc:	0a072783          	lw	a5,160(a4)
    800003d0:	09c72703          	lw	a4,156(a4)
    800003d4:	f0f70be3          	beq	a4,a5,800002ea <consoleintr+0x32>
      cons.e--;
    800003d8:	37fd                	addiw	a5,a5,-1
    800003da:	00015717          	auipc	a4,0x15
    800003de:	32f72b23          	sw	a5,822(a4) # 80015710 <cons+0xa0>
      consputc(BACKSPACE);
    800003e2:	10000513          	li	a0,256
    800003e6:	ea1ff0ef          	jal	80000286 <consputc>
    800003ea:	b701                	j	800002ea <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ec:	ee048fe3          	beqz	s1,800002ea <consoleintr+0x32>
    800003f0:	bf21                	j	80000308 <consoleintr+0x50>
      consputc(c);
    800003f2:	4529                	li	a0,10
    800003f4:	e93ff0ef          	jal	80000286 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003f8:	00015797          	auipc	a5,0x15
    800003fc:	27878793          	addi	a5,a5,632 # 80015670 <cons>
    80000400:	0a07a703          	lw	a4,160(a5)
    80000404:	0017069b          	addiw	a3,a4,1
    80000408:	0006861b          	sext.w	a2,a3
    8000040c:	0ad7a023          	sw	a3,160(a5)
    80000410:	07f77713          	andi	a4,a4,127
    80000414:	97ba                	add	a5,a5,a4
    80000416:	4729                	li	a4,10
    80000418:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041c:	00015797          	auipc	a5,0x15
    80000420:	2ec7a823          	sw	a2,752(a5) # 8001570c <cons+0x9c>
        wakeup(&cons.r);
    80000424:	00015517          	auipc	a0,0x15
    80000428:	2e450513          	addi	a0,a0,740 # 80015708 <cons+0x98>
    8000042c:	371010ef          	jal	80001f9c <wakeup>
    80000430:	bd6d                	j	800002ea <consoleintr+0x32>

0000000080000432 <consoleinit>:

void
consoleinit(void)
{
    80000432:	1141                	addi	sp,sp,-16
    80000434:	e406                	sd	ra,8(sp)
    80000436:	e022                	sd	s0,0(sp)
    80000438:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000043a:	00009597          	auipc	a1,0x9
    8000043e:	bc658593          	addi	a1,a1,-1082 # 80009000 <etext>
    80000442:	00015517          	auipc	a0,0x15
    80000446:	22e50513          	addi	a0,a0,558 # 80015670 <cons>
    8000044a:	6ce000ef          	jal	80000b18 <initlock>

  uartinit();
    8000044e:	400000ef          	jal	8000084e <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000452:	00026797          	auipc	a5,0x26
    80000456:	fa678793          	addi	a5,a5,-90 # 800263f8 <devsw>
    8000045a:	00000717          	auipc	a4,0x0
    8000045e:	d1470713          	addi	a4,a4,-748 # 8000016e <consoleread>
    80000462:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000464:	00000717          	auipc	a4,0x0
    80000468:	c6c70713          	addi	a4,a4,-916 # 800000d0 <consolewrite>
    8000046c:	ef98                	sd	a4,24(a5)
}
    8000046e:	60a2                	ld	ra,8(sp)
    80000470:	6402                	ld	s0,0(sp)
    80000472:	0141                	addi	sp,sp,16
    80000474:	8082                	ret

0000000080000476 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000476:	7139                	addi	sp,sp,-64
    80000478:	fc06                	sd	ra,56(sp)
    8000047a:	f822                	sd	s0,48(sp)
    8000047c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    8000047e:	c219                	beqz	a2,80000484 <printint+0xe>
    80000480:	08054063          	bltz	a0,80000500 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000484:	4881                	li	a7,0
    80000486:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000048a:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000048c:	00009617          	auipc	a2,0x9
    80000490:	50460613          	addi	a2,a2,1284 # 80009990 <digits>
    80000494:	883e                	mv	a6,a5
    80000496:	2785                	addiw	a5,a5,1
    80000498:	02b57733          	remu	a4,a0,a1
    8000049c:	9732                	add	a4,a4,a2
    8000049e:	00074703          	lbu	a4,0(a4)
    800004a2:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    800004a6:	872a                	mv	a4,a0
    800004a8:	02b55533          	divu	a0,a0,a1
    800004ac:	0685                	addi	a3,a3,1
    800004ae:	feb773e3          	bgeu	a4,a1,80000494 <printint+0x1e>

  if (sign)
    800004b2:	00088a63          	beqz	a7,800004c6 <printint+0x50>
    buf[i++] = '-';
    800004b6:	1781                	addi	a5,a5,-32
    800004b8:	97a2                	add	a5,a5,s0
    800004ba:	02d00713          	li	a4,45
    800004be:	fee78423          	sb	a4,-24(a5)
    800004c2:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    800004c6:	02f05963          	blez	a5,800004f8 <printint+0x82>
    800004ca:	f426                	sd	s1,40(sp)
    800004cc:	f04a                	sd	s2,32(sp)
    800004ce:	fc840713          	addi	a4,s0,-56
    800004d2:	00f704b3          	add	s1,a4,a5
    800004d6:	fff70913          	addi	s2,a4,-1
    800004da:	993e                	add	s2,s2,a5
    800004dc:	37fd                	addiw	a5,a5,-1
    800004de:	1782                	slli	a5,a5,0x20
    800004e0:	9381                	srli	a5,a5,0x20
    800004e2:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004e6:	fff4c503          	lbu	a0,-1(s1)
    800004ea:	d9dff0ef          	jal	80000286 <consputc>
  while (--i >= 0)
    800004ee:	14fd                	addi	s1,s1,-1
    800004f0:	ff249be3          	bne	s1,s2,800004e6 <printint+0x70>
    800004f4:	74a2                	ld	s1,40(sp)
    800004f6:	7902                	ld	s2,32(sp)
}
    800004f8:	70e2                	ld	ra,56(sp)
    800004fa:	7442                	ld	s0,48(sp)
    800004fc:	6121                	addi	sp,sp,64
    800004fe:	8082                	ret
    x = -xx;
    80000500:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000504:	4885                	li	a7,1
    x = -xx;
    80000506:	b741                	j	80000486 <printint+0x10>

0000000080000508 <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    80000508:	7131                	addi	sp,sp,-192
    8000050a:	fc86                	sd	ra,120(sp)
    8000050c:	f8a2                	sd	s0,112(sp)
    8000050e:	e8d2                	sd	s4,80(sp)
    80000510:	0100                	addi	s0,sp,128
    80000512:	8a2a                	mv	s4,a0
    80000514:	e40c                	sd	a1,8(s0)
    80000516:	e810                	sd	a2,16(s0)
    80000518:	ec14                	sd	a3,24(s0)
    8000051a:	f018                	sd	a4,32(s0)
    8000051c:	f41c                	sd	a5,40(s0)
    8000051e:	03043823          	sd	a6,48(s0)
    80000522:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000526:	0000d797          	auipc	a5,0xd
    8000052a:	0ce7a783          	lw	a5,206(a5) # 8000d5f4 <panicking>
    8000052e:	c3a1                	beqz	a5,8000056e <printk+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000530:	00840793          	addi	a5,s0,8
    80000534:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000538:	000a4503          	lbu	a0,0(s4)
    8000053c:	28050763          	beqz	a0,800007ca <printk+0x2c2>
    80000540:	f4a6                	sd	s1,104(sp)
    80000542:	f0ca                	sd	s2,96(sp)
    80000544:	ecce                	sd	s3,88(sp)
    80000546:	e4d6                	sd	s5,72(sp)
    80000548:	e0da                	sd	s6,64(sp)
    8000054a:	f862                	sd	s8,48(sp)
    8000054c:	f466                	sd	s9,40(sp)
    8000054e:	f06a                	sd	s10,32(sp)
    80000550:	ec6e                	sd	s11,24(sp)
    80000552:	4981                	li	s3,0
    if (cx != '%') {
    80000554:	02500a93          	li	s5,37
    c1 = c2 = 0;
    if (c0)
      c1 = fmt[i + 1] & 0xff;
    if (c1)
      c2 = fmt[i + 2] & 0xff;
    if (c0 == 'd') {
    80000558:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if (c0 == 'l' && c1 == 'd') {
    8000055c:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000560:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000564:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000568:	07000d93          	li	s11,112
    8000056c:	a01d                	j	80000592 <printk+0x8a>
    acquire(&pr.lock);
    8000056e:	00015517          	auipc	a0,0x15
    80000572:	1aa50513          	addi	a0,a0,426 # 80015718 <pr>
    80000576:	618000ef          	jal	80000b8e <acquire>
    8000057a:	bf5d                	j	80000530 <printk+0x28>
      consputc(cx);
    8000057c:	d0bff0ef          	jal	80000286 <consputc>
      continue;
    80000580:	84ce                	mv	s1,s3
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000582:	0014899b          	addiw	s3,s1,1
    80000586:	013a07b3          	add	a5,s4,s3
    8000058a:	0007c503          	lbu	a0,0(a5)
    8000058e:	20050b63          	beqz	a0,800007a4 <printk+0x29c>
    if (cx != '%') {
    80000592:	ff5515e3          	bne	a0,s5,8000057c <printk+0x74>
    i++;
    80000596:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i + 0] & 0xff;
    8000059a:	009a07b3          	add	a5,s4,s1
    8000059e:	0007c903          	lbu	s2,0(a5)
    if (c0)
    800005a2:	20090b63          	beqz	s2,800007b8 <printk+0x2b0>
      c1 = fmt[i + 1] & 0xff;
    800005a6:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    800005aa:	86be                	mv	a3,a5
    if (c1)
    800005ac:	c789                	beqz	a5,800005b6 <printk+0xae>
      c2 = fmt[i + 2] & 0xff;
    800005ae:	009a0733          	add	a4,s4,s1
    800005b2:	00274683          	lbu	a3,2(a4)
    if (c0 == 'd') {
    800005b6:	03690963          	beq	s2,s6,800005e8 <printk+0xe0>
    } else if (c0 == 'l' && c1 == 'd') {
    800005ba:	05890363          	beq	s2,s8,80000600 <printk+0xf8>
    } else if (c0 == 'u') {
    800005be:	0d990663          	beq	s2,s9,8000068a <printk+0x182>
    } else if (c0 == 'x') {
    800005c2:	11a90d63          	beq	s2,s10,800006dc <printk+0x1d4>
    } else if (c0 == 'p') {
    800005c6:	15b90663          	beq	s2,s11,80000712 <printk+0x20a>
      printptr(va_arg(ap, uint64));
    } else if (c0 == 'c') {
    800005ca:	06300793          	li	a5,99
    800005ce:	18f90563          	beq	s2,a5,80000758 <printk+0x250>
      consputc(va_arg(ap, uint));
    } else if (c0 == 's') {
    800005d2:	07300793          	li	a5,115
    800005d6:	18f90b63          	beq	s2,a5,8000076c <printk+0x264>
      if ((s = va_arg(ap, char *)) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
    } else if (c0 == '%') {
    800005da:	03591b63          	bne	s2,s5,80000610 <printk+0x108>
      consputc('%');
    800005de:	02500513          	li	a0,37
    800005e2:	ca5ff0ef          	jal	80000286 <consputc>
    800005e6:	bf71                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005e8:	f8843783          	ld	a5,-120(s0)
    800005ec:	00878713          	addi	a4,a5,8
    800005f0:	f8e43423          	sd	a4,-120(s0)
    800005f4:	4605                	li	a2,1
    800005f6:	45a9                	li	a1,10
    800005f8:	4388                	lw	a0,0(a5)
    800005fa:	e7dff0ef          	jal	80000476 <printint>
    800005fe:	b751                	j	80000582 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'd') {
    80000600:	01678f63          	beq	a5,s6,8000061e <printk+0x116>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    80000604:	03878b63          	beq	a5,s8,8000063a <printk+0x132>
    } else if (c0 == 'l' && c1 == 'u') {
    80000608:	09978e63          	beq	a5,s9,800006a4 <printk+0x19c>
    } else if (c0 == 'l' && c1 == 'x') {
    8000060c:	0fa78563          	beq	a5,s10,800006f6 <printk+0x1ee>
    } else if (c0 == 0) {
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000610:	8556                	mv	a0,s5
    80000612:	c75ff0ef          	jal	80000286 <consputc>
      consputc(c0);
    80000616:	854a                	mv	a0,s2
    80000618:	c6fff0ef          	jal	80000286 <consputc>
    8000061c:	b79d                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    8000061e:	f8843783          	ld	a5,-120(s0)
    80000622:	00878713          	addi	a4,a5,8
    80000626:	f8e43423          	sd	a4,-120(s0)
    8000062a:	4605                	li	a2,1
    8000062c:	45a9                	li	a1,10
    8000062e:	6388                	ld	a0,0(a5)
    80000630:	e47ff0ef          	jal	80000476 <printint>
      i += 1;
    80000634:	0029849b          	addiw	s1,s3,2
    80000638:	b7a9                	j	80000582 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000063a:	06400793          	li	a5,100
    8000063e:	02f68863          	beq	a3,a5,8000066e <printk+0x166>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    80000642:	07500793          	li	a5,117
    80000646:	06f68d63          	beq	a3,a5,800006c0 <printk+0x1b8>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000064a:	07800793          	li	a5,120
    8000064e:	fcf691e3          	bne	a3,a5,80000610 <printk+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000652:	f8843783          	ld	a5,-120(s0)
    80000656:	00878713          	addi	a4,a5,8
    8000065a:	f8e43423          	sd	a4,-120(s0)
    8000065e:	4601                	li	a2,0
    80000660:	45c1                	li	a1,16
    80000662:	6388                	ld	a0,0(a5)
    80000664:	e13ff0ef          	jal	80000476 <printint>
      i += 2;
    80000668:	0039849b          	addiw	s1,s3,3
    8000066c:	bf19                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    8000066e:	f8843783          	ld	a5,-120(s0)
    80000672:	00878713          	addi	a4,a5,8
    80000676:	f8e43423          	sd	a4,-120(s0)
    8000067a:	4605                	li	a2,1
    8000067c:	45a9                	li	a1,10
    8000067e:	6388                	ld	a0,0(a5)
    80000680:	df7ff0ef          	jal	80000476 <printint>
      i += 2;
    80000684:	0039849b          	addiw	s1,s3,3
    80000688:	bded                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000068a:	f8843783          	ld	a5,-120(s0)
    8000068e:	00878713          	addi	a4,a5,8
    80000692:	f8e43423          	sd	a4,-120(s0)
    80000696:	4601                	li	a2,0
    80000698:	45a9                	li	a1,10
    8000069a:	0007e503          	lwu	a0,0(a5)
    8000069e:	dd9ff0ef          	jal	80000476 <printint>
    800006a2:	b5c5                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006a4:	f8843783          	ld	a5,-120(s0)
    800006a8:	00878713          	addi	a4,a5,8
    800006ac:	f8e43423          	sd	a4,-120(s0)
    800006b0:	4601                	li	a2,0
    800006b2:	45a9                	li	a1,10
    800006b4:	6388                	ld	a0,0(a5)
    800006b6:	dc1ff0ef          	jal	80000476 <printint>
      i += 1;
    800006ba:	0029849b          	addiw	s1,s3,2
    800006be:	b5d1                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	4601                	li	a2,0
    800006ce:	45a9                	li	a1,10
    800006d0:	6388                	ld	a0,0(a5)
    800006d2:	da5ff0ef          	jal	80000476 <printint>
      i += 2;
    800006d6:	0039849b          	addiw	s1,s3,3
    800006da:	b565                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006dc:	f8843783          	ld	a5,-120(s0)
    800006e0:	00878713          	addi	a4,a5,8
    800006e4:	f8e43423          	sd	a4,-120(s0)
    800006e8:	4601                	li	a2,0
    800006ea:	45c1                	li	a1,16
    800006ec:	0007e503          	lwu	a0,0(a5)
    800006f0:	d87ff0ef          	jal	80000476 <printint>
    800006f4:	b579                	j	80000582 <printk+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006f6:	f8843783          	ld	a5,-120(s0)
    800006fa:	00878713          	addi	a4,a5,8
    800006fe:	f8e43423          	sd	a4,-120(s0)
    80000702:	4601                	li	a2,0
    80000704:	45c1                	li	a1,16
    80000706:	6388                	ld	a0,0(a5)
    80000708:	d6fff0ef          	jal	80000476 <printint>
      i += 1;
    8000070c:	0029849b          	addiw	s1,s3,2
    80000710:	bd8d                	j	80000582 <printk+0x7a>
    80000712:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000714:	f8843783          	ld	a5,-120(s0)
    80000718:	00878713          	addi	a4,a5,8
    8000071c:	f8e43423          	sd	a4,-120(s0)
    80000720:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000724:	03000513          	li	a0,48
    80000728:	b5fff0ef          	jal	80000286 <consputc>
  consputc('x');
    8000072c:	07800513          	li	a0,120
    80000730:	b57ff0ef          	jal	80000286 <consputc>
    80000734:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000736:	00009b97          	auipc	s7,0x9
    8000073a:	25ab8b93          	addi	s7,s7,602 # 80009990 <digits>
    8000073e:	03c9d793          	srli	a5,s3,0x3c
    80000742:	97de                	add	a5,a5,s7
    80000744:	0007c503          	lbu	a0,0(a5)
    80000748:	b3fff0ef          	jal	80000286 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000074c:	0992                	slli	s3,s3,0x4
    8000074e:	397d                	addiw	s2,s2,-1
    80000750:	fe0917e3          	bnez	s2,8000073e <printk+0x236>
    80000754:	7be2                	ld	s7,56(sp)
    80000756:	b535                	j	80000582 <printk+0x7a>
      consputc(va_arg(ap, uint));
    80000758:	f8843783          	ld	a5,-120(s0)
    8000075c:	00878713          	addi	a4,a5,8
    80000760:	f8e43423          	sd	a4,-120(s0)
    80000764:	4388                	lw	a0,0(a5)
    80000766:	b21ff0ef          	jal	80000286 <consputc>
    8000076a:	bd21                	j	80000582 <printk+0x7a>
      if ((s = va_arg(ap, char *)) == 0)
    8000076c:	f8843783          	ld	a5,-120(s0)
    80000770:	00878713          	addi	a4,a5,8
    80000774:	f8e43423          	sd	a4,-120(s0)
    80000778:	0007b903          	ld	s2,0(a5)
    8000077c:	00090d63          	beqz	s2,80000796 <printk+0x28e>
      for (; *s; s++)
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	de050fe3          	beqz	a0,80000582 <printk+0x7a>
        consputc(*s);
    80000788:	affff0ef          	jal	80000286 <consputc>
      for (; *s; s++)
    8000078c:	0905                	addi	s2,s2,1
    8000078e:	00094503          	lbu	a0,0(s2)
    80000792:	f97d                	bnez	a0,80000788 <printk+0x280>
    80000794:	b3fd                	j	80000582 <printk+0x7a>
        s = "(null)";
    80000796:	00009917          	auipc	s2,0x9
    8000079a:	87290913          	addi	s2,s2,-1934 # 80009008 <etext+0x8>
      for (; *s; s++)
    8000079e:	02800513          	li	a0,40
    800007a2:	b7dd                	j	80000788 <printk+0x280>
    800007a4:	74a6                	ld	s1,104(sp)
    800007a6:	7906                	ld	s2,96(sp)
    800007a8:	69e6                	ld	s3,88(sp)
    800007aa:	6aa6                	ld	s5,72(sp)
    800007ac:	6b06                	ld	s6,64(sp)
    800007ae:	7c42                	ld	s8,48(sp)
    800007b0:	7ca2                	ld	s9,40(sp)
    800007b2:	7d02                	ld	s10,32(sp)
    800007b4:	6de2                	ld	s11,24(sp)
    800007b6:	a811                	j	800007ca <printk+0x2c2>
    800007b8:	74a6                	ld	s1,104(sp)
    800007ba:	7906                	ld	s2,96(sp)
    800007bc:	69e6                	ld	s3,88(sp)
    800007be:	6aa6                	ld	s5,72(sp)
    800007c0:	6b06                	ld	s6,64(sp)
    800007c2:	7c42                	ld	s8,48(sp)
    800007c4:	7ca2                	ld	s9,40(sp)
    800007c6:	7d02                	ld	s10,32(sp)
    800007c8:	6de2                	ld	s11,24(sp)
    }
  }
  va_end(ap);

  if (panicking == 0)
    800007ca:	0000d797          	auipc	a5,0xd
    800007ce:	e2a7a783          	lw	a5,-470(a5) # 8000d5f4 <panicking>
    800007d2:	c799                	beqz	a5,800007e0 <printk+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007d4:	4501                	li	a0,0
    800007d6:	70e6                	ld	ra,120(sp)
    800007d8:	7446                	ld	s0,112(sp)
    800007da:	6a46                	ld	s4,80(sp)
    800007dc:	6129                	addi	sp,sp,192
    800007de:	8082                	ret
    release(&pr.lock);
    800007e0:	00015517          	auipc	a0,0x15
    800007e4:	f3850513          	addi	a0,a0,-200 # 80015718 <pr>
    800007e8:	432000ef          	jal	80000c1a <release>
  return 0;
    800007ec:	b7e5                	j	800007d4 <printk+0x2cc>

00000000800007ee <panic>:

void
panic(char *s)
{
    800007ee:	1101                	addi	sp,sp,-32
    800007f0:	ec06                	sd	ra,24(sp)
    800007f2:	e822                	sd	s0,16(sp)
    800007f4:	e426                	sd	s1,8(sp)
    800007f6:	e04a                	sd	s2,0(sp)
    800007f8:	1000                	addi	s0,sp,32
    800007fa:	84aa                	mv	s1,a0
  panicking = 1;
    800007fc:	4905                	li	s2,1
    800007fe:	0000d797          	auipc	a5,0xd
    80000802:	df27ab23          	sw	s2,-522(a5) # 8000d5f4 <panicking>
  printk("panic: ");
    80000806:	00009517          	auipc	a0,0x9
    8000080a:	81250513          	addi	a0,a0,-2030 # 80009018 <etext+0x18>
    8000080e:	cfbff0ef          	jal	80000508 <printk>
  printk("%s\n", s);
    80000812:	85a6                	mv	a1,s1
    80000814:	00009517          	auipc	a0,0x9
    80000818:	80c50513          	addi	a0,a0,-2036 # 80009020 <etext+0x20>
    8000081c:	cedff0ef          	jal	80000508 <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000820:	0000d797          	auipc	a5,0xd
    80000824:	dd27a823          	sw	s2,-560(a5) # 8000d5f0 <panicked>
  for (;;)
    80000828:	a001                	j	80000828 <panic+0x3a>

000000008000082a <printkinit>:
    ;
}

void
printkinit(void)
{
    8000082a:	1141                	addi	sp,sp,-16
    8000082c:	e406                	sd	ra,8(sp)
    8000082e:	e022                	sd	s0,0(sp)
    80000830:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000832:	00008597          	auipc	a1,0x8
    80000836:	7f658593          	addi	a1,a1,2038 # 80009028 <etext+0x28>
    8000083a:	00015517          	auipc	a0,0x15
    8000083e:	ede50513          	addi	a0,a0,-290 # 80015718 <pr>
    80000842:	2d6000ef          	jal	80000b18 <initlock>
}
    80000846:	60a2                	ld	ra,8(sp)
    80000848:	6402                	ld	s0,0(sp)
    8000084a:	0141                	addi	sp,sp,16
    8000084c:	8082                	ret

000000008000084e <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    8000084e:	1141                	addi	sp,sp,-16
    80000850:	e406                	sd	ra,8(sp)
    80000852:	e022                	sd	s0,0(sp)
    80000854:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000856:	100007b7          	lui	a5,0x10000
    8000085a:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    8000085e:	10000737          	lui	a4,0x10000
    80000862:	f8000693          	li	a3,-128
    80000866:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000086a:	468d                	li	a3,3
    8000086c:	10000637          	lui	a2,0x10000
    80000870:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000874:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000878:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000087c:	10000737          	lui	a4,0x10000
    80000880:	461d                	li	a2,7
    80000882:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000886:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    8000088a:	00008597          	auipc	a1,0x8
    8000088e:	7a658593          	addi	a1,a1,1958 # 80009030 <etext+0x30>
    80000892:	00015517          	auipc	a0,0x15
    80000896:	e9e50513          	addi	a0,a0,-354 # 80015730 <tx_lock>
    8000089a:	1c1030ef          	jal	8000425a <initsleeplock>
}
    8000089e:	60a2                	ld	ra,8(sp)
    800008a0:	6402                	ld	s0,0(sp)
    800008a2:	0141                	addi	sp,sp,16
    800008a4:	8082                	ret

00000000800008a6 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008a6:	7139                	addi	sp,sp,-64
    800008a8:	fc06                	sd	ra,56(sp)
    800008aa:	f822                	sd	s0,48(sp)
    800008ac:	f04a                	sd	s2,32(sp)
    800008ae:	e456                	sd	s5,8(sp)
    800008b0:	0080                	addi	s0,sp,64
    800008b2:	8aaa                	mv	s5,a0
    800008b4:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    800008b6:	00015517          	auipc	a0,0x15
    800008ba:	e7a50513          	addi	a0,a0,-390 # 80015730 <tx_lock>
    800008be:	1d3030ef          	jal	80004290 <acquiresleep>

  int i = 0;
  while (i < n) {
    800008c2:	05205963          	blez	s2,80000914 <uartwrite+0x6e>
    800008c6:	f426                	sd	s1,40(sp)
    800008c8:	ec4e                	sd	s3,24(sp)
    800008ca:	e852                	sd	s4,16(sp)
    800008cc:	e05a                	sd	s6,0(sp)
  int i = 0;
    800008ce:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    800008d0:	0000da17          	auipc	s4,0xd
    800008d4:	d28a0a13          	addi	s4,s4,-728 # 8000d5f8 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008d8:	100009b7          	lui	s3,0x10000
    800008dc:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    800008de:	10000b37          	lui	s6,0x10000
    800008e2:	a811                	j	800008f6 <uartwrite+0x50>
    800008e4:	009a87b3          	add	a5,s5,s1
    800008e8:	0007c783          	lbu	a5,0(a5)
    800008ec:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    800008f0:	2485                	addiw	s1,s1,1
  while (i < n) {
    800008f2:	0124dd63          	bge	s1,s2,8000090c <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    800008f6:	8552                	mv	a0,s4
    800008f8:	638010ef          	jal	80001f30 <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008fc:	0009c783          	lbu	a5,0(s3)
    80000900:	0207f793          	andi	a5,a5,32
    80000904:	f3e5                	bnez	a5,800008e4 <uartwrite+0x3e>
    } else {
      sleep();
    80000906:	666010ef          	jal	80001f6c <sleep>
    8000090a:	b7e5                	j	800008f2 <uartwrite+0x4c>
    8000090c:	74a2                	ld	s1,40(sp)
    8000090e:	69e2                	ld	s3,24(sp)
    80000910:	6a42                	ld	s4,16(sp)
    80000912:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    80000914:	00015517          	auipc	a0,0x15
    80000918:	e1c50513          	addi	a0,a0,-484 # 80015730 <tx_lock>
    8000091c:	1c9030ef          	jal	800042e4 <releasesleep>
}
    80000920:	70e2                	ld	ra,56(sp)
    80000922:	7442                	ld	s0,48(sp)
    80000924:	7902                	ld	s2,32(sp)
    80000926:	6aa2                	ld	s5,8(sp)
    80000928:	6121                	addi	sp,sp,64
    8000092a:	8082                	ret

000000008000092c <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092c:	1101                	addi	sp,sp,-32
    8000092e:	ec06                	sd	ra,24(sp)
    80000930:	e822                	sd	s0,16(sp)
    80000932:	e426                	sd	s1,8(sp)
    80000934:	1000                	addi	s0,sp,32
    80000936:	84aa                	mv	s1,a0
  if (panicking == 0)
    80000938:	0000d797          	auipc	a5,0xd
    8000093c:	cbc7a783          	lw	a5,-836(a5) # 8000d5f4 <panicking>
    80000940:	cf95                	beqz	a5,8000097c <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000942:	0000d797          	auipc	a5,0xd
    80000946:	cae7a783          	lw	a5,-850(a5) # 8000d5f0 <panicked>
    8000094a:	ef85                	bnez	a5,80000982 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094c:	10000737          	lui	a4,0x10000
    80000950:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000952:	00074783          	lbu	a5,0(a4)
    80000956:	0207f793          	andi	a5,a5,32
    8000095a:	dfe5                	beqz	a5,80000952 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095c:	0ff4f513          	zext.b	a0,s1
    80000960:	100007b7          	lui	a5,0x10000
    80000964:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    80000968:	0000d797          	auipc	a5,0xd
    8000096c:	c8c7a783          	lw	a5,-884(a5) # 8000d5f4 <panicking>
    80000970:	cb91                	beqz	a5,80000984 <uartputc_sync+0x58>
    pop_off();
}
    80000972:	60e2                	ld	ra,24(sp)
    80000974:	6442                	ld	s0,16(sp)
    80000976:	64a2                	ld	s1,8(sp)
    80000978:	6105                	addi	sp,sp,32
    8000097a:	8082                	ret
    push_off();
    8000097c:	1dc000ef          	jal	80000b58 <push_off>
    80000980:	b7c9                	j	80000942 <uartputc_sync+0x16>
    for (;;)
    80000982:	a001                	j	80000982 <uartputc_sync+0x56>
    pop_off();
    80000984:	24a000ef          	jal	80000bce <pop_off>
}
    80000988:	b7ed                	j	80000972 <uartputc_sync+0x46>

000000008000098a <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000098a:	1101                	addi	sp,sp,-32
    8000098c:	ec06                	sd	ra,24(sp)
    8000098e:	e822                	sd	s0,16(sp)
    80000990:	e426                	sd	s1,8(sp)
    80000992:	e04a                	sd	s2,0(sp)
    80000994:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000996:	100007b7          	lui	a5,0x10000
    8000099a:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    8000099c:	0007c783          	lbu	a5,0(a5)

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009a0:	100007b7          	lui	a5,0x10000
    800009a4:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009a6:	0007c783          	lbu	a5,0(a5)
    800009aa:	0207f793          	andi	a5,a5,32
    800009ae:	ef99                	bnez	a5,800009cc <uartintr+0x42>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009b0:	100004b7          	lui	s1,0x10000
    800009b4:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009b6:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009ba:	0004c783          	lbu	a5,0(s1)
    800009be:	8b85                	andi	a5,a5,1
    800009c0:	cf89                	beqz	a5,800009da <uartintr+0x50>
    return ReadReg(RHR);
    800009c2:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    800009c6:	8f3ff0ef          	jal	800002b8 <consoleintr>
  while (1) {
    800009ca:	bfc5                	j	800009ba <uartintr+0x30>
    wakeup(&tx_chan);
    800009cc:	0000d517          	auipc	a0,0xd
    800009d0:	c2c50513          	addi	a0,a0,-980 # 8000d5f8 <tx_chan>
    800009d4:	5c8010ef          	jal	80001f9c <wakeup>
    800009d8:	bfe1                	j	800009b0 <uartintr+0x26>
  }
}
    800009da:	60e2                	ld	ra,24(sp)
    800009dc:	6442                	ld	s0,16(sp)
    800009de:	64a2                	ld	s1,8(sp)
    800009e0:	6902                	ld	s2,0(sp)
    800009e2:	6105                	addi	sp,sp,32
    800009e4:	8082                	ret

00000000800009e6 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009e6:	1101                	addi	sp,sp,-32
    800009e8:	ec06                	sd	ra,24(sp)
    800009ea:	e822                	sd	s0,16(sp)
    800009ec:	e426                	sd	s1,8(sp)
    800009ee:	e04a                	sd	s2,0(sp)
    800009f0:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    800009f2:	03451793          	slli	a5,a0,0x34
    800009f6:	e7a9                	bnez	a5,80000a40 <kfree+0x5a>
    800009f8:	84aa                	mv	s1,a0
    800009fa:	00027797          	auipc	a5,0x27
    800009fe:	5be78793          	addi	a5,a5,1470 # 80027fb8 <end>
    80000a02:	02f56f63          	bltu	a0,a5,80000a40 <kfree+0x5a>
    80000a06:	47c5                	li	a5,17
    80000a08:	07ee                	slli	a5,a5,0x1b
    80000a0a:	02f57b63          	bgeu	a0,a5,80000a40 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a0e:	6605                	lui	a2,0x1
    80000a10:	4585                	li	a1,1
    80000a12:	240000ef          	jal	80000c52 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a16:	00015917          	auipc	s2,0x15
    80000a1a:	d4a90913          	addi	s2,s2,-694 # 80015760 <kmem>
    80000a1e:	854a                	mv	a0,s2
    80000a20:	16e000ef          	jal	80000b8e <acquire>
  r->next = kmem.freelist;
    80000a24:	01893783          	ld	a5,24(s2)
    80000a28:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a2a:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a2e:	854a                	mv	a0,s2
    80000a30:	1ea000ef          	jal	80000c1a <release>
}
    80000a34:	60e2                	ld	ra,24(sp)
    80000a36:	6442                	ld	s0,16(sp)
    80000a38:	64a2                	ld	s1,8(sp)
    80000a3a:	6902                	ld	s2,0(sp)
    80000a3c:	6105                	addi	sp,sp,32
    80000a3e:	8082                	ret
    panic("kfree");
    80000a40:	00008517          	auipc	a0,0x8
    80000a44:	5f850513          	addi	a0,a0,1528 # 80009038 <etext+0x38>
    80000a48:	da7ff0ef          	jal	800007ee <panic>

0000000080000a4c <freerange>:
{
    80000a4c:	7179                	addi	sp,sp,-48
    80000a4e:	f406                	sd	ra,40(sp)
    80000a50:	f022                	sd	s0,32(sp)
    80000a52:	ec26                	sd	s1,24(sp)
    80000a54:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a56:	6785                	lui	a5,0x1
    80000a58:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a5c:	00e504b3          	add	s1,a0,a4
    80000a60:	777d                	lui	a4,0xfffff
    80000a62:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a64:	94be                	add	s1,s1,a5
    80000a66:	0295e263          	bltu	a1,s1,80000a8a <freerange+0x3e>
    80000a6a:	e84a                	sd	s2,16(sp)
    80000a6c:	e44e                	sd	s3,8(sp)
    80000a6e:	e052                	sd	s4,0(sp)
    80000a70:	892e                	mv	s2,a1
    kfree(p);
    80000a72:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a74:	6985                	lui	s3,0x1
    kfree(p);
    80000a76:	01448533          	add	a0,s1,s4
    80000a7a:	f6dff0ef          	jal	800009e6 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a7e:	94ce                	add	s1,s1,s3
    80000a80:	fe997be3          	bgeu	s2,s1,80000a76 <freerange+0x2a>
    80000a84:	6942                	ld	s2,16(sp)
    80000a86:	69a2                	ld	s3,8(sp)
    80000a88:	6a02                	ld	s4,0(sp)
}
    80000a8a:	70a2                	ld	ra,40(sp)
    80000a8c:	7402                	ld	s0,32(sp)
    80000a8e:	64e2                	ld	s1,24(sp)
    80000a90:	6145                	addi	sp,sp,48
    80000a92:	8082                	ret

0000000080000a94 <kinit>:
{
    80000a94:	1141                	addi	sp,sp,-16
    80000a96:	e406                	sd	ra,8(sp)
    80000a98:	e022                	sd	s0,0(sp)
    80000a9a:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000a9c:	00008597          	auipc	a1,0x8
    80000aa0:	5a458593          	addi	a1,a1,1444 # 80009040 <etext+0x40>
    80000aa4:	00015517          	auipc	a0,0x15
    80000aa8:	cbc50513          	addi	a0,a0,-836 # 80015760 <kmem>
    80000aac:	06c000ef          	jal	80000b18 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000ab0:	45c5                	li	a1,17
    80000ab2:	05ee                	slli	a1,a1,0x1b
    80000ab4:	00027517          	auipc	a0,0x27
    80000ab8:	50450513          	addi	a0,a0,1284 # 80027fb8 <end>
    80000abc:	f91ff0ef          	jal	80000a4c <freerange>
}
    80000ac0:	60a2                	ld	ra,8(sp)
    80000ac2:	6402                	ld	s0,0(sp)
    80000ac4:	0141                	addi	sp,sp,16
    80000ac6:	8082                	ret

0000000080000ac8 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000ac8:	1101                	addi	sp,sp,-32
    80000aca:	ec06                	sd	ra,24(sp)
    80000acc:	e822                	sd	s0,16(sp)
    80000ace:	e426                	sd	s1,8(sp)
    80000ad0:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000ad2:	00015497          	auipc	s1,0x15
    80000ad6:	c8e48493          	addi	s1,s1,-882 # 80015760 <kmem>
    80000ada:	8526                	mv	a0,s1
    80000adc:	0b2000ef          	jal	80000b8e <acquire>
  r = kmem.freelist;
    80000ae0:	6c84                	ld	s1,24(s1)
  if (r)
    80000ae2:	c485                	beqz	s1,80000b0a <kalloc+0x42>
    kmem.freelist = r->next;
    80000ae4:	609c                	ld	a5,0(s1)
    80000ae6:	00015517          	auipc	a0,0x15
    80000aea:	c7a50513          	addi	a0,a0,-902 # 80015760 <kmem>
    80000aee:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000af0:	12a000ef          	jal	80000c1a <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000af4:	6605                	lui	a2,0x1
    80000af6:	4595                	li	a1,5
    80000af8:	8526                	mv	a0,s1
    80000afa:	158000ef          	jal	80000c52 <memset>
  return (void *)r;
}
    80000afe:	8526                	mv	a0,s1
    80000b00:	60e2                	ld	ra,24(sp)
    80000b02:	6442                	ld	s0,16(sp)
    80000b04:	64a2                	ld	s1,8(sp)
    80000b06:	6105                	addi	sp,sp,32
    80000b08:	8082                	ret
  release(&kmem.lock);
    80000b0a:	00015517          	auipc	a0,0x15
    80000b0e:	c5650513          	addi	a0,a0,-938 # 80015760 <kmem>
    80000b12:	108000ef          	jal	80000c1a <release>
  if (r)
    80000b16:	b7e5                	j	80000afe <kalloc+0x36>

0000000080000b18 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b18:	1141                	addi	sp,sp,-16
    80000b1a:	e422                	sd	s0,8(sp)
    80000b1c:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b1e:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b20:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b24:	00053823          	sd	zero,16(a0)
}
    80000b28:	6422                	ld	s0,8(sp)
    80000b2a:	0141                	addi	sp,sp,16
    80000b2c:	8082                	ret

0000000080000b2e <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b2e:	411c                	lw	a5,0(a0)
    80000b30:	e399                	bnez	a5,80000b36 <holding+0x8>
    80000b32:	4501                	li	a0,0
  return r;
}
    80000b34:	8082                	ret
{
    80000b36:	1101                	addi	sp,sp,-32
    80000b38:	ec06                	sd	ra,24(sp)
    80000b3a:	e822                	sd	s0,16(sp)
    80000b3c:	e426                	sd	s1,8(sp)
    80000b3e:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b40:	6904                	ld	s1,16(a0)
    80000b42:	53b000ef          	jal	8000187c <mycpu>
    80000b46:	40a48533          	sub	a0,s1,a0
    80000b4a:	00153513          	seqz	a0,a0
}
    80000b4e:	60e2                	ld	ra,24(sp)
    80000b50:	6442                	ld	s0,16(sp)
    80000b52:	64a2                	ld	s1,8(sp)
    80000b54:	6105                	addi	sp,sp,32
    80000b56:	8082                	ret

0000000080000b58 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b58:	1101                	addi	sp,sp,-32
    80000b5a:	ec06                	sd	ra,24(sp)
    80000b5c:	e822                	sd	s0,16(sp)
    80000b5e:	e426                	sd	s1,8(sp)
    80000b60:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000b62:	100174f3          	csrrci	s1,sstatus,2
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000b66:	517000ef          	jal	8000187c <mycpu>
    80000b6a:	5d3c                	lw	a5,120(a0)
    80000b6c:	cb99                	beqz	a5,80000b82 <push_off+0x2a>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000b6e:	50f000ef          	jal	8000187c <mycpu>
    80000b72:	5d3c                	lw	a5,120(a0)
    80000b74:	2785                	addiw	a5,a5,1
    80000b76:	dd3c                	sw	a5,120(a0)
}
    80000b78:	60e2                	ld	ra,24(sp)
    80000b7a:	6442                	ld	s0,16(sp)
    80000b7c:	64a2                	ld	s1,8(sp)
    80000b7e:	6105                	addi	sp,sp,32
    80000b80:	8082                	ret
    mycpu()->intena = old;
    80000b82:	4fb000ef          	jal	8000187c <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000b86:	8085                	srli	s1,s1,0x1
    80000b88:	8885                	andi	s1,s1,1
    mycpu()->intena = old;
    80000b8a:	dd64                	sw	s1,124(a0)
    80000b8c:	b7cd                	j	80000b6e <push_off+0x16>

0000000080000b8e <acquire>:
{
    80000b8e:	1101                	addi	sp,sp,-32
    80000b90:	ec06                	sd	ra,24(sp)
    80000b92:	e822                	sd	s0,16(sp)
    80000b94:	e426                	sd	s1,8(sp)
    80000b96:	1000                	addi	s0,sp,32
    80000b98:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000b9a:	fbfff0ef          	jal	80000b58 <push_off>
  if (holding(lk))
    80000b9e:	8526                	mv	a0,s1
    80000ba0:	f8fff0ef          	jal	80000b2e <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000ba4:	4705                	li	a4,1
  if (holding(lk))
    80000ba6:	ed11                	bnez	a0,80000bc2 <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000ba8:	87ba                	mv	a5,a4
    80000baa:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bae:	2781                	sext.w	a5,a5
    80000bb0:	ffe5                	bnez	a5,80000ba8 <acquire+0x1a>
  lk->cpu = mycpu();
    80000bb2:	4cb000ef          	jal	8000187c <mycpu>
    80000bb6:	e888                	sd	a0,16(s1)
}
    80000bb8:	60e2                	ld	ra,24(sp)
    80000bba:	6442                	ld	s0,16(sp)
    80000bbc:	64a2                	ld	s1,8(sp)
    80000bbe:	6105                	addi	sp,sp,32
    80000bc0:	8082                	ret
    panic("acquire");
    80000bc2:	00008517          	auipc	a0,0x8
    80000bc6:	48650513          	addi	a0,a0,1158 # 80009048 <etext+0x48>
    80000bca:	c25ff0ef          	jal	800007ee <panic>

0000000080000bce <pop_off>:

void
pop_off(void)
{
    80000bce:	1141                	addi	sp,sp,-16
    80000bd0:	e406                	sd	ra,8(sp)
    80000bd2:	e022                	sd	s0,0(sp)
    80000bd4:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000bd6:	4a7000ef          	jal	8000187c <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000bda:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000bde:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000be0:	e38d                	bnez	a5,80000c02 <pop_off+0x34>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000be2:	5d3c                	lw	a5,120(a0)
    80000be4:	02f05563          	blez	a5,80000c0e <pop_off+0x40>
    panic("pop_off");
  c->noff -= 1;
    80000be8:	37fd                	addiw	a5,a5,-1
    80000bea:	0007871b          	sext.w	a4,a5
    80000bee:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000bf0:	e709                	bnez	a4,80000bfa <pop_off+0x2c>
    80000bf2:	5d7c                	lw	a5,124(a0)
    80000bf4:	c399                	beqz	a5,80000bfa <pop_off+0x2c>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000bf6:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000bfa:	60a2                	ld	ra,8(sp)
    80000bfc:	6402                	ld	s0,0(sp)
    80000bfe:	0141                	addi	sp,sp,16
    80000c00:	8082                	ret
    panic("pop_off - interruptible");
    80000c02:	00008517          	auipc	a0,0x8
    80000c06:	44e50513          	addi	a0,a0,1102 # 80009050 <etext+0x50>
    80000c0a:	be5ff0ef          	jal	800007ee <panic>
    panic("pop_off");
    80000c0e:	00008517          	auipc	a0,0x8
    80000c12:	45a50513          	addi	a0,a0,1114 # 80009068 <etext+0x68>
    80000c16:	bd9ff0ef          	jal	800007ee <panic>

0000000080000c1a <release>:
{
    80000c1a:	1101                	addi	sp,sp,-32
    80000c1c:	ec06                	sd	ra,24(sp)
    80000c1e:	e822                	sd	s0,16(sp)
    80000c20:	e426                	sd	s1,8(sp)
    80000c22:	1000                	addi	s0,sp,32
    80000c24:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c26:	f09ff0ef          	jal	80000b2e <holding>
    80000c2a:	cd11                	beqz	a0,80000c46 <release+0x2c>
  lk->cpu = 0;
    80000c2c:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c30:	0310000f          	fence	rw,w
    80000c34:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c38:	f97ff0ef          	jal	80000bce <pop_off>
}
    80000c3c:	60e2                	ld	ra,24(sp)
    80000c3e:	6442                	ld	s0,16(sp)
    80000c40:	64a2                	ld	s1,8(sp)
    80000c42:	6105                	addi	sp,sp,32
    80000c44:	8082                	ret
    panic("release");
    80000c46:	00008517          	auipc	a0,0x8
    80000c4a:	42a50513          	addi	a0,a0,1066 # 80009070 <etext+0x70>
    80000c4e:	ba1ff0ef          	jal	800007ee <panic>

0000000080000c52 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000c52:	1141                	addi	sp,sp,-16
    80000c54:	e422                	sd	s0,8(sp)
    80000c56:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000c58:	ca19                	beqz	a2,80000c6e <memset+0x1c>
    80000c5a:	87aa                	mv	a5,a0
    80000c5c:	1602                	slli	a2,a2,0x20
    80000c5e:	9201                	srli	a2,a2,0x20
    80000c60:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000c64:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000c68:	0785                	addi	a5,a5,1
    80000c6a:	fee79de3          	bne	a5,a4,80000c64 <memset+0x12>
  }
  return dst;
}
    80000c6e:	6422                	ld	s0,8(sp)
    80000c70:	0141                	addi	sp,sp,16
    80000c72:	8082                	ret

0000000080000c74 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000c74:	1141                	addi	sp,sp,-16
    80000c76:	e422                	sd	s0,8(sp)
    80000c78:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000c7a:	ca05                	beqz	a2,80000caa <memcmp+0x36>
    80000c7c:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000c80:	1682                	slli	a3,a3,0x20
    80000c82:	9281                	srli	a3,a3,0x20
    80000c84:	0685                	addi	a3,a3,1
    80000c86:	96aa                	add	a3,a3,a0
    if (*s1 != *s2)
    80000c88:	00054783          	lbu	a5,0(a0)
    80000c8c:	0005c703          	lbu	a4,0(a1)
    80000c90:	00e79863          	bne	a5,a4,80000ca0 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000c94:	0505                	addi	a0,a0,1
    80000c96:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000c98:	fed518e3          	bne	a0,a3,80000c88 <memcmp+0x14>
  }

  return 0;
    80000c9c:	4501                	li	a0,0
    80000c9e:	a019                	j	80000ca4 <memcmp+0x30>
      return *s1 - *s2;
    80000ca0:	40e7853b          	subw	a0,a5,a4
}
    80000ca4:	6422                	ld	s0,8(sp)
    80000ca6:	0141                	addi	sp,sp,16
    80000ca8:	8082                	ret
  return 0;
    80000caa:	4501                	li	a0,0
    80000cac:	bfe5                	j	80000ca4 <memcmp+0x30>

0000000080000cae <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000cae:	1141                	addi	sp,sp,-16
    80000cb0:	e422                	sd	s0,8(sp)
    80000cb2:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000cb4:	c205                	beqz	a2,80000cd4 <memmove+0x26>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000cb6:	02a5e263          	bltu	a1,a0,80000cda <memmove+0x2c>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000cba:	1602                	slli	a2,a2,0x20
    80000cbc:	9201                	srli	a2,a2,0x20
    80000cbe:	00c587b3          	add	a5,a1,a2
{
    80000cc2:	872a                	mv	a4,a0
      *d++ = *s++;
    80000cc4:	0585                	addi	a1,a1,1
    80000cc6:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffd7049>
    80000cc8:	fff5c683          	lbu	a3,-1(a1)
    80000ccc:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000cd0:	feb79ae3          	bne	a5,a1,80000cc4 <memmove+0x16>

  return dst;
}
    80000cd4:	6422                	ld	s0,8(sp)
    80000cd6:	0141                	addi	sp,sp,16
    80000cd8:	8082                	ret
  if (s < d && s + n > d) {
    80000cda:	02061693          	slli	a3,a2,0x20
    80000cde:	9281                	srli	a3,a3,0x20
    80000ce0:	00d58733          	add	a4,a1,a3
    80000ce4:	fce57be3          	bgeu	a0,a4,80000cba <memmove+0xc>
    d += n;
    80000ce8:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000cea:	fff6079b          	addiw	a5,a2,-1
    80000cee:	1782                	slli	a5,a5,0x20
    80000cf0:	9381                	srli	a5,a5,0x20
    80000cf2:	fff7c793          	not	a5,a5
    80000cf6:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000cf8:	177d                	addi	a4,a4,-1
    80000cfa:	16fd                	addi	a3,a3,-1
    80000cfc:	00074603          	lbu	a2,0(a4)
    80000d00:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d04:	fef71ae3          	bne	a4,a5,80000cf8 <memmove+0x4a>
    80000d08:	b7f1                	j	80000cd4 <memmove+0x26>

0000000080000d0a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d0a:	1141                	addi	sp,sp,-16
    80000d0c:	e406                	sd	ra,8(sp)
    80000d0e:	e022                	sd	s0,0(sp)
    80000d10:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d12:	f9dff0ef          	jal	80000cae <memmove>
}
    80000d16:	60a2                	ld	ra,8(sp)
    80000d18:	6402                	ld	s0,0(sp)
    80000d1a:	0141                	addi	sp,sp,16
    80000d1c:	8082                	ret

0000000080000d1e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e422                	sd	s0,8(sp)
    80000d22:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d24:	ce11                	beqz	a2,80000d40 <strncmp+0x22>
    80000d26:	00054783          	lbu	a5,0(a0)
    80000d2a:	cf89                	beqz	a5,80000d44 <strncmp+0x26>
    80000d2c:	0005c703          	lbu	a4,0(a1)
    80000d30:	00f71a63          	bne	a4,a5,80000d44 <strncmp+0x26>
    n--, p++, q++;
    80000d34:	367d                	addiw	a2,a2,-1
    80000d36:	0505                	addi	a0,a0,1
    80000d38:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d3a:	f675                	bnez	a2,80000d26 <strncmp+0x8>
  if (n == 0)
    return 0;
    80000d3c:	4501                	li	a0,0
    80000d3e:	a801                	j	80000d4e <strncmp+0x30>
    80000d40:	4501                	li	a0,0
    80000d42:	a031                	j	80000d4e <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000d44:	00054503          	lbu	a0,0(a0)
    80000d48:	0005c783          	lbu	a5,0(a1)
    80000d4c:	9d1d                	subw	a0,a0,a5
}
    80000d4e:	6422                	ld	s0,8(sp)
    80000d50:	0141                	addi	sp,sp,16
    80000d52:	8082                	ret

0000000080000d54 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000d54:	1141                	addi	sp,sp,-16
    80000d56:	e422                	sd	s0,8(sp)
    80000d58:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000d5a:	87aa                	mv	a5,a0
    80000d5c:	86b2                	mv	a3,a2
    80000d5e:	367d                	addiw	a2,a2,-1
    80000d60:	02d05563          	blez	a3,80000d8a <strncpy+0x36>
    80000d64:	0785                	addi	a5,a5,1
    80000d66:	0005c703          	lbu	a4,0(a1)
    80000d6a:	fee78fa3          	sb	a4,-1(a5)
    80000d6e:	0585                	addi	a1,a1,1
    80000d70:	f775                	bnez	a4,80000d5c <strncpy+0x8>
    ;
  while (n-- > 0)
    80000d72:	873e                	mv	a4,a5
    80000d74:	9fb5                	addw	a5,a5,a3
    80000d76:	37fd                	addiw	a5,a5,-1
    80000d78:	00c05963          	blez	a2,80000d8a <strncpy+0x36>
    *s++ = 0;
    80000d7c:	0705                	addi	a4,a4,1
    80000d7e:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000d82:	40e786bb          	subw	a3,a5,a4
    80000d86:	fed04be3          	bgtz	a3,80000d7c <strncpy+0x28>
  return os;
}
    80000d8a:	6422                	ld	s0,8(sp)
    80000d8c:	0141                	addi	sp,sp,16
    80000d8e:	8082                	ret

0000000080000d90 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000d90:	1141                	addi	sp,sp,-16
    80000d92:	e422                	sd	s0,8(sp)
    80000d94:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000d96:	02c05363          	blez	a2,80000dbc <safestrcpy+0x2c>
    80000d9a:	fff6069b          	addiw	a3,a2,-1
    80000d9e:	1682                	slli	a3,a3,0x20
    80000da0:	9281                	srli	a3,a3,0x20
    80000da2:	96ae                	add	a3,a3,a1
    80000da4:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000da6:	00d58963          	beq	a1,a3,80000db8 <safestrcpy+0x28>
    80000daa:	0585                	addi	a1,a1,1
    80000dac:	0785                	addi	a5,a5,1
    80000dae:	fff5c703          	lbu	a4,-1(a1)
    80000db2:	fee78fa3          	sb	a4,-1(a5)
    80000db6:	fb65                	bnez	a4,80000da6 <safestrcpy+0x16>
    ;
  *s = 0;
    80000db8:	00078023          	sb	zero,0(a5)
  return os;
}
    80000dbc:	6422                	ld	s0,8(sp)
    80000dbe:	0141                	addi	sp,sp,16
    80000dc0:	8082                	ret

0000000080000dc2 <strlen>:

int
strlen(const char *s)
{
    80000dc2:	1141                	addi	sp,sp,-16
    80000dc4:	e422                	sd	s0,8(sp)
    80000dc6:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000dc8:	00054783          	lbu	a5,0(a0)
    80000dcc:	cf91                	beqz	a5,80000de8 <strlen+0x26>
    80000dce:	0505                	addi	a0,a0,1
    80000dd0:	87aa                	mv	a5,a0
    80000dd2:	86be                	mv	a3,a5
    80000dd4:	0785                	addi	a5,a5,1
    80000dd6:	fff7c703          	lbu	a4,-1(a5)
    80000dda:	ff65                	bnez	a4,80000dd2 <strlen+0x10>
    80000ddc:	40a6853b          	subw	a0,a3,a0
    80000de0:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000de2:	6422                	ld	s0,8(sp)
    80000de4:	0141                	addi	sp,sp,16
    80000de6:	8082                	ret
  for (n = 0; s[n]; n++)
    80000de8:	4501                	li	a0,0
    80000dea:	bfe5                	j	80000de2 <strlen+0x20>

0000000080000dec <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000df4:	279000ef          	jal	8000186c <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000df8:	0000d717          	auipc	a4,0xd
    80000dfc:	80470713          	addi	a4,a4,-2044 # 8000d5fc <started>
  if (cpuid() == 0) {
    80000e00:	c51d                	beqz	a0,80000e2e <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e02:	431c                	lw	a5,0(a4)
    80000e04:	0230000f          	fence	r,rw
    80000e08:	2781                	sext.w	a5,a5
    80000e0a:	dfe5                	beqz	a5,80000e02 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e0c:	261000ef          	jal	8000186c <cpuid>
    80000e10:	85aa                	mv	a1,a0
    80000e12:	00008517          	auipc	a0,0x8
    80000e16:	28650513          	addi	a0,a0,646 # 80009098 <etext+0x98>
    80000e1a:	eeeff0ef          	jal	80000508 <printk>
    kvminithart();  // turn on paging
    80000e1e:	086000ef          	jal	80000ea4 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e22:	055010ef          	jal	80002676 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e26:	2c3040ef          	jal	800058e8 <plicinithart>
  }

  scheduler();
    80000e2a:	703000ef          	jal	80001d2c <scheduler>
    consoleinit();
    80000e2e:	e04ff0ef          	jal	80000432 <consoleinit>
    printkinit();
    80000e32:	9f9ff0ef          	jal	8000082a <printkinit>
    printk("\n");
    80000e36:	00008517          	auipc	a0,0x8
    80000e3a:	24250513          	addi	a0,a0,578 # 80009078 <etext+0x78>
    80000e3e:	ecaff0ef          	jal	80000508 <printk>
    printk("xv6 kernel is booting\n");
    80000e42:	00008517          	auipc	a0,0x8
    80000e46:	23e50513          	addi	a0,a0,574 # 80009080 <etext+0x80>
    80000e4a:	ebeff0ef          	jal	80000508 <printk>
    printk("\n");
    80000e4e:	00008517          	auipc	a0,0x8
    80000e52:	22a50513          	addi	a0,a0,554 # 80009078 <etext+0x78>
    80000e56:	eb2ff0ef          	jal	80000508 <printk>
    kinit();            // physical page allocator
    80000e5a:	c3bff0ef          	jal	80000a94 <kinit>
    kvminit();          // create kernel page table
    80000e5e:	2d0000ef          	jal	8000112e <kvminit>
    kvminithart();      // turn on paging
    80000e62:	042000ef          	jal	80000ea4 <kvminithart>
    procinit();         // process table
    80000e66:	157000ef          	jal	800017bc <procinit>
    wlinit();           // Project 1C workload harness
    80000e6a:	435050ef          	jal	80006a9e <wlinit>
    trapinit();         // trap vectors
    80000e6e:	7e4010ef          	jal	80002652 <trapinit>
    trapinithart();     // install kernel trap vector
    80000e72:	005010ef          	jal	80002676 <trapinithart>
    plicinit();         // set up interrupt controller
    80000e76:	259040ef          	jal	800058ce <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000e7a:	26f040ef          	jal	800058e8 <plicinithart>
    binit();            // buffer cache
    80000e7e:	76b010ef          	jal	80002de8 <binit>
    iinit();            // inode table
    80000e82:	4f0020ef          	jal	80003372 <iinit>
    fileinit();         // file table
    80000e86:	4e0030ef          	jal	80004366 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000e8a:	34f040ef          	jal	800059d8 <virtio_disk_init>
    userinit();         // first user process
    80000e8e:	4f3000ef          	jal	80001b80 <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000e92:	0000c797          	auipc	a5,0xc
    80000e96:	76a78793          	addi	a5,a5,1898 # 8000d5fc <started>
    80000e9a:	4705                	li	a4,1
    80000e9c:	0310000f          	fence	rw,w
    80000ea0:	c398                	sw	a4,0(a5)
    80000ea2:	b761                	j	80000e2a <main+0x3e>

0000000080000ea4 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000ea4:	1141                	addi	sp,sp,-16
    80000ea6:	e422                	sd	s0,8(sp)
    80000ea8:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000eaa:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000eae:	0000c797          	auipc	a5,0xc
    80000eb2:	7527b783          	ld	a5,1874(a5) # 8000d600 <kernel_pagetable>
    80000eb6:	83b1                	srli	a5,a5,0xc
    80000eb8:	577d                	li	a4,-1
    80000eba:	177e                	slli	a4,a4,0x3f
    80000ebc:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000ebe:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000ec2:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000ec6:	6422                	ld	s0,8(sp)
    80000ec8:	0141                	addi	sp,sp,16
    80000eca:	8082                	ret

0000000080000ecc <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000ecc:	7139                	addi	sp,sp,-64
    80000ece:	fc06                	sd	ra,56(sp)
    80000ed0:	f822                	sd	s0,48(sp)
    80000ed2:	f426                	sd	s1,40(sp)
    80000ed4:	f04a                	sd	s2,32(sp)
    80000ed6:	ec4e                	sd	s3,24(sp)
    80000ed8:	e852                	sd	s4,16(sp)
    80000eda:	e456                	sd	s5,8(sp)
    80000edc:	e05a                	sd	s6,0(sp)
    80000ede:	0080                	addi	s0,sp,64
    80000ee0:	84aa                	mv	s1,a0
    80000ee2:	89ae                	mv	s3,a1
    80000ee4:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    80000ee6:	57fd                	li	a5,-1
    80000ee8:	83e9                	srli	a5,a5,0x1a
    80000eea:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000eec:	4b31                	li	s6,12
  if (va >= MAXVA)
    80000eee:	02b7fc63          	bgeu	a5,a1,80000f26 <walk+0x5a>
    panic("walk");
    80000ef2:	00008517          	auipc	a0,0x8
    80000ef6:	1be50513          	addi	a0,a0,446 # 800090b0 <etext+0xb0>
    80000efa:	8f5ff0ef          	jal	800007ee <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000efe:	060a8263          	beqz	s5,80000f62 <walk+0x96>
    80000f02:	bc7ff0ef          	jal	80000ac8 <kalloc>
    80000f06:	84aa                	mv	s1,a0
    80000f08:	c139                	beqz	a0,80000f4e <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f0a:	6605                	lui	a2,0x1
    80000f0c:	4581                	li	a1,0
    80000f0e:	d45ff0ef          	jal	80000c52 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f12:	00c4d793          	srli	a5,s1,0xc
    80000f16:	07aa                	slli	a5,a5,0xa
    80000f18:	0017e793          	ori	a5,a5,1
    80000f1c:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000f20:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffd703f>
    80000f22:	036a0063          	beq	s4,s6,80000f42 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f26:	0149d933          	srl	s2,s3,s4
    80000f2a:	1ff97913          	andi	s2,s2,511
    80000f2e:	090e                	slli	s2,s2,0x3
    80000f30:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f32:	00093483          	ld	s1,0(s2)
    80000f36:	0014f793          	andi	a5,s1,1
    80000f3a:	d3f1                	beqz	a5,80000efe <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f3c:	80a9                	srli	s1,s1,0xa
    80000f3e:	04b2                	slli	s1,s1,0xc
    80000f40:	b7c5                	j	80000f20 <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f42:	00c9d513          	srli	a0,s3,0xc
    80000f46:	1ff57513          	andi	a0,a0,511
    80000f4a:	050e                	slli	a0,a0,0x3
    80000f4c:	9526                	add	a0,a0,s1
}
    80000f4e:	70e2                	ld	ra,56(sp)
    80000f50:	7442                	ld	s0,48(sp)
    80000f52:	74a2                	ld	s1,40(sp)
    80000f54:	7902                	ld	s2,32(sp)
    80000f56:	69e2                	ld	s3,24(sp)
    80000f58:	6a42                	ld	s4,16(sp)
    80000f5a:	6aa2                	ld	s5,8(sp)
    80000f5c:	6b02                	ld	s6,0(sp)
    80000f5e:	6121                	addi	sp,sp,64
    80000f60:	8082                	ret
        return 0;
    80000f62:	4501                	li	a0,0
    80000f64:	b7ed                	j	80000f4e <walk+0x82>

0000000080000f66 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000f66:	57fd                	li	a5,-1
    80000f68:	83e9                	srli	a5,a5,0x1a
    80000f6a:	00b7f463          	bgeu	a5,a1,80000f72 <walkaddr+0xc>
    return 0;
    80000f6e:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000f70:	8082                	ret
{
    80000f72:	1141                	addi	sp,sp,-16
    80000f74:	e406                	sd	ra,8(sp)
    80000f76:	e022                	sd	s0,0(sp)
    80000f78:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000f7a:	4601                	li	a2,0
    80000f7c:	f51ff0ef          	jal	80000ecc <walk>
  if (pte == 0)
    80000f80:	c105                	beqz	a0,80000fa0 <walkaddr+0x3a>
  if ((*pte & PTE_V) == 0)
    80000f82:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000f84:	0117f693          	andi	a3,a5,17
    80000f88:	4745                	li	a4,17
    return 0;
    80000f8a:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80000f8c:	00e68663          	beq	a3,a4,80000f98 <walkaddr+0x32>
}
    80000f90:	60a2                	ld	ra,8(sp)
    80000f92:	6402                	ld	s0,0(sp)
    80000f94:	0141                	addi	sp,sp,16
    80000f96:	8082                	ret
  pa = PTE2PA(*pte);
    80000f98:	83a9                	srli	a5,a5,0xa
    80000f9a:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000f9e:	bfcd                	j	80000f90 <walkaddr+0x2a>
    return 0;
    80000fa0:	4501                	li	a0,0
    80000fa2:	b7fd                	j	80000f90 <walkaddr+0x2a>

0000000080000fa4 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fa4:	715d                	addi	sp,sp,-80
    80000fa6:	e486                	sd	ra,72(sp)
    80000fa8:	e0a2                	sd	s0,64(sp)
    80000faa:	fc26                	sd	s1,56(sp)
    80000fac:	f84a                	sd	s2,48(sp)
    80000fae:	f44e                	sd	s3,40(sp)
    80000fb0:	f052                	sd	s4,32(sp)
    80000fb2:	ec56                	sd	s5,24(sp)
    80000fb4:	e85a                	sd	s6,16(sp)
    80000fb6:	e45e                	sd	s7,8(sp)
    80000fb8:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80000fba:	03459793          	slli	a5,a1,0x34
    80000fbe:	e7a9                	bnez	a5,80001008 <mappages+0x64>
    80000fc0:	8aaa                	mv	s5,a0
    80000fc2:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80000fc4:	03461793          	slli	a5,a2,0x34
    80000fc8:	e7b1                	bnez	a5,80001014 <mappages+0x70>
    panic("mappages: size not aligned");

  if (size == 0)
    80000fca:	ca39                	beqz	a2,80001020 <mappages+0x7c>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80000fcc:	77fd                	lui	a5,0xfffff
    80000fce:	963e                	add	a2,a2,a5
    80000fd0:	00b609b3          	add	s3,a2,a1
  a = va;
    80000fd4:	892e                	mv	s2,a1
    80000fd6:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80000fda:	6b85                	lui	s7,0x1
    80000fdc:	014904b3          	add	s1,s2,s4
    if ((pte = walk(pagetable, a, 1)) == 0)
    80000fe0:	4605                	li	a2,1
    80000fe2:	85ca                	mv	a1,s2
    80000fe4:	8556                	mv	a0,s5
    80000fe6:	ee7ff0ef          	jal	80000ecc <walk>
    80000fea:	c539                	beqz	a0,80001038 <mappages+0x94>
    if (*pte & PTE_V)
    80000fec:	611c                	ld	a5,0(a0)
    80000fee:	8b85                	andi	a5,a5,1
    80000ff0:	ef95                	bnez	a5,8000102c <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000ff2:	80b1                	srli	s1,s1,0xc
    80000ff4:	04aa                	slli	s1,s1,0xa
    80000ff6:	0164e4b3          	or	s1,s1,s6
    80000ffa:	0014e493          	ori	s1,s1,1
    80000ffe:	e104                	sd	s1,0(a0)
    if (a == last)
    80001000:	05390863          	beq	s2,s3,80001050 <mappages+0xac>
    a += PGSIZE;
    80001004:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001006:	bfd9                	j	80000fdc <mappages+0x38>
    panic("mappages: va not aligned");
    80001008:	00008517          	auipc	a0,0x8
    8000100c:	0b050513          	addi	a0,a0,176 # 800090b8 <etext+0xb8>
    80001010:	fdeff0ef          	jal	800007ee <panic>
    panic("mappages: size not aligned");
    80001014:	00008517          	auipc	a0,0x8
    80001018:	0c450513          	addi	a0,a0,196 # 800090d8 <etext+0xd8>
    8000101c:	fd2ff0ef          	jal	800007ee <panic>
    panic("mappages: size");
    80001020:	00008517          	auipc	a0,0x8
    80001024:	0d850513          	addi	a0,a0,216 # 800090f8 <etext+0xf8>
    80001028:	fc6ff0ef          	jal	800007ee <panic>
      panic("mappages: remap");
    8000102c:	00008517          	auipc	a0,0x8
    80001030:	0dc50513          	addi	a0,a0,220 # 80009108 <etext+0x108>
    80001034:	fbaff0ef          	jal	800007ee <panic>
      return -1;
    80001038:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000103a:	60a6                	ld	ra,72(sp)
    8000103c:	6406                	ld	s0,64(sp)
    8000103e:	74e2                	ld	s1,56(sp)
    80001040:	7942                	ld	s2,48(sp)
    80001042:	79a2                	ld	s3,40(sp)
    80001044:	7a02                	ld	s4,32(sp)
    80001046:	6ae2                	ld	s5,24(sp)
    80001048:	6b42                	ld	s6,16(sp)
    8000104a:	6ba2                	ld	s7,8(sp)
    8000104c:	6161                	addi	sp,sp,80
    8000104e:	8082                	ret
  return 0;
    80001050:	4501                	li	a0,0
    80001052:	b7e5                	j	8000103a <mappages+0x96>

0000000080001054 <kvmmap>:
{
    80001054:	1141                	addi	sp,sp,-16
    80001056:	e406                	sd	ra,8(sp)
    80001058:	e022                	sd	s0,0(sp)
    8000105a:	0800                	addi	s0,sp,16
    8000105c:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000105e:	86b2                	mv	a3,a2
    80001060:	863e                	mv	a2,a5
    80001062:	f43ff0ef          	jal	80000fa4 <mappages>
    80001066:	e509                	bnez	a0,80001070 <kvmmap+0x1c>
}
    80001068:	60a2                	ld	ra,8(sp)
    8000106a:	6402                	ld	s0,0(sp)
    8000106c:	0141                	addi	sp,sp,16
    8000106e:	8082                	ret
    panic("kvmmap");
    80001070:	00008517          	auipc	a0,0x8
    80001074:	0a850513          	addi	a0,a0,168 # 80009118 <etext+0x118>
    80001078:	f76ff0ef          	jal	800007ee <panic>

000000008000107c <kvmmake>:
{
    8000107c:	1101                	addi	sp,sp,-32
    8000107e:	ec06                	sd	ra,24(sp)
    80001080:	e822                	sd	s0,16(sp)
    80001082:	e426                	sd	s1,8(sp)
    80001084:	e04a                	sd	s2,0(sp)
    80001086:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    80001088:	a41ff0ef          	jal	80000ac8 <kalloc>
    8000108c:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000108e:	6605                	lui	a2,0x1
    80001090:	4581                	li	a1,0
    80001092:	bc1ff0ef          	jal	80000c52 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001096:	4719                	li	a4,6
    80001098:	6685                	lui	a3,0x1
    8000109a:	10000637          	lui	a2,0x10000
    8000109e:	100005b7          	lui	a1,0x10000
    800010a2:	8526                	mv	a0,s1
    800010a4:	fb1ff0ef          	jal	80001054 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010a8:	4719                	li	a4,6
    800010aa:	6685                	lui	a3,0x1
    800010ac:	10001637          	lui	a2,0x10001
    800010b0:	100015b7          	lui	a1,0x10001
    800010b4:	8526                	mv	a0,s1
    800010b6:	f9fff0ef          	jal	80001054 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800010ba:	4719                	li	a4,6
    800010bc:	040006b7          	lui	a3,0x4000
    800010c0:	0c000637          	lui	a2,0xc000
    800010c4:	0c0005b7          	lui	a1,0xc000
    800010c8:	8526                	mv	a0,s1
    800010ca:	f8bff0ef          	jal	80001054 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    800010ce:	00008917          	auipc	s2,0x8
    800010d2:	f3290913          	addi	s2,s2,-206 # 80009000 <etext>
    800010d6:	4729                	li	a4,10
    800010d8:	80008697          	auipc	a3,0x80008
    800010dc:	f2868693          	addi	a3,a3,-216 # 9000 <_entry-0x7fff7000>
    800010e0:	4605                	li	a2,1
    800010e2:	067e                	slli	a2,a2,0x1f
    800010e4:	85b2                	mv	a1,a2
    800010e6:	8526                	mv	a0,s1
    800010e8:	f6dff0ef          	jal	80001054 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    800010ec:	46c5                	li	a3,17
    800010ee:	06ee                	slli	a3,a3,0x1b
    800010f0:	4719                	li	a4,6
    800010f2:	412686b3          	sub	a3,a3,s2
    800010f6:	864a                	mv	a2,s2
    800010f8:	85ca                	mv	a1,s2
    800010fa:	8526                	mv	a0,s1
    800010fc:	f59ff0ef          	jal	80001054 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001100:	4729                	li	a4,10
    80001102:	6685                	lui	a3,0x1
    80001104:	00007617          	auipc	a2,0x7
    80001108:	efc60613          	addi	a2,a2,-260 # 80008000 <_trampoline>
    8000110c:	040005b7          	lui	a1,0x4000
    80001110:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001112:	05b2                	slli	a1,a1,0xc
    80001114:	8526                	mv	a0,s1
    80001116:	f3fff0ef          	jal	80001054 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000111a:	8526                	mv	a0,s1
    8000111c:	60e000ef          	jal	8000172a <proc_mapstacks>
}
    80001120:	8526                	mv	a0,s1
    80001122:	60e2                	ld	ra,24(sp)
    80001124:	6442                	ld	s0,16(sp)
    80001126:	64a2                	ld	s1,8(sp)
    80001128:	6902                	ld	s2,0(sp)
    8000112a:	6105                	addi	sp,sp,32
    8000112c:	8082                	ret

000000008000112e <kvminit>:
{
    8000112e:	1141                	addi	sp,sp,-16
    80001130:	e406                	sd	ra,8(sp)
    80001132:	e022                	sd	s0,0(sp)
    80001134:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001136:	f47ff0ef          	jal	8000107c <kvmmake>
    8000113a:	0000c797          	auipc	a5,0xc
    8000113e:	4ca7b323          	sd	a0,1222(a5) # 8000d600 <kernel_pagetable>
}
    80001142:	60a2                	ld	ra,8(sp)
    80001144:	6402                	ld	s0,0(sp)
    80001146:	0141                	addi	sp,sp,16
    80001148:	8082                	ret

000000008000114a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000114a:	1101                	addi	sp,sp,-32
    8000114c:	ec06                	sd	ra,24(sp)
    8000114e:	e822                	sd	s0,16(sp)
    80001150:	e426                	sd	s1,8(sp)
    80001152:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001154:	975ff0ef          	jal	80000ac8 <kalloc>
    80001158:	84aa                	mv	s1,a0
  if (pagetable == 0)
    8000115a:	c509                	beqz	a0,80001164 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000115c:	6605                	lui	a2,0x1
    8000115e:	4581                	li	a1,0
    80001160:	af3ff0ef          	jal	80000c52 <memset>
  return pagetable;
}
    80001164:	8526                	mv	a0,s1
    80001166:	60e2                	ld	ra,24(sp)
    80001168:	6442                	ld	s0,16(sp)
    8000116a:	64a2                	ld	s1,8(sp)
    8000116c:	6105                	addi	sp,sp,32
    8000116e:	8082                	ret

0000000080001170 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001170:	7139                	addi	sp,sp,-64
    80001172:	fc06                	sd	ra,56(sp)
    80001174:	f822                	sd	s0,48(sp)
    80001176:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001178:	03459793          	slli	a5,a1,0x34
    8000117c:	e38d                	bnez	a5,8000119e <uvmunmap+0x2e>
    8000117e:	f04a                	sd	s2,32(sp)
    80001180:	ec4e                	sd	s3,24(sp)
    80001182:	e852                	sd	s4,16(sp)
    80001184:	e456                	sd	s5,8(sp)
    80001186:	e05a                	sd	s6,0(sp)
    80001188:	8a2a                	mv	s4,a0
    8000118a:	892e                	mv	s2,a1
    8000118c:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000118e:	0632                	slli	a2,a2,0xc
    80001190:	00b609b3          	add	s3,a2,a1
    80001194:	6b05                	lui	s6,0x1
    80001196:	0535f963          	bgeu	a1,s3,800011e8 <uvmunmap+0x78>
    8000119a:	f426                	sd	s1,40(sp)
    8000119c:	a015                	j	800011c0 <uvmunmap+0x50>
    8000119e:	f426                	sd	s1,40(sp)
    800011a0:	f04a                	sd	s2,32(sp)
    800011a2:	ec4e                	sd	s3,24(sp)
    800011a4:	e852                	sd	s4,16(sp)
    800011a6:	e456                	sd	s5,8(sp)
    800011a8:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011aa:	00008517          	auipc	a0,0x8
    800011ae:	f7650513          	addi	a0,a0,-138 # 80009120 <etext+0x120>
    800011b2:	e3cff0ef          	jal	800007ee <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    800011b6:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011ba:	995a                	add	s2,s2,s6
    800011bc:	03397563          	bgeu	s2,s3,800011e6 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800011c0:	4601                	li	a2,0
    800011c2:	85ca                	mv	a1,s2
    800011c4:	8552                	mv	a0,s4
    800011c6:	d07ff0ef          	jal	80000ecc <walk>
    800011ca:	84aa                	mv	s1,a0
    800011cc:	d57d                	beqz	a0,800011ba <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    800011ce:	611c                	ld	a5,0(a0)
    800011d0:	0017f713          	andi	a4,a5,1
    800011d4:	d37d                	beqz	a4,800011ba <uvmunmap+0x4a>
    if (do_free) {
    800011d6:	fe0a80e3          	beqz	s5,800011b6 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800011da:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    800011dc:	00c79513          	slli	a0,a5,0xc
    800011e0:	807ff0ef          	jal	800009e6 <kfree>
    800011e4:	bfc9                	j	800011b6 <uvmunmap+0x46>
    800011e6:	74a2                	ld	s1,40(sp)
    800011e8:	7902                	ld	s2,32(sp)
    800011ea:	69e2                	ld	s3,24(sp)
    800011ec:	6a42                	ld	s4,16(sp)
    800011ee:	6aa2                	ld	s5,8(sp)
    800011f0:	6b02                	ld	s6,0(sp)
  }
}
    800011f2:	70e2                	ld	ra,56(sp)
    800011f4:	7442                	ld	s0,48(sp)
    800011f6:	6121                	addi	sp,sp,64
    800011f8:	8082                	ret

00000000800011fa <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800011fa:	1101                	addi	sp,sp,-32
    800011fc:	ec06                	sd	ra,24(sp)
    800011fe:	e822                	sd	s0,16(sp)
    80001200:	e426                	sd	s1,8(sp)
    80001202:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001204:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    80001206:	00b67d63          	bgeu	a2,a1,80001220 <uvmdealloc+0x26>
    8000120a:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    8000120c:	6785                	lui	a5,0x1
    8000120e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001210:	00f60733          	add	a4,a2,a5
    80001214:	76fd                	lui	a3,0xfffff
    80001216:	8f75                	and	a4,a4,a3
    80001218:	97ae                	add	a5,a5,a1
    8000121a:	8ff5                	and	a5,a5,a3
    8000121c:	00f76863          	bltu	a4,a5,8000122c <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001220:	8526                	mv	a0,s1
    80001222:	60e2                	ld	ra,24(sp)
    80001224:	6442                	ld	s0,16(sp)
    80001226:	64a2                	ld	s1,8(sp)
    80001228:	6105                	addi	sp,sp,32
    8000122a:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000122c:	8f99                	sub	a5,a5,a4
    8000122e:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001230:	4685                	li	a3,1
    80001232:	0007861b          	sext.w	a2,a5
    80001236:	85ba                	mv	a1,a4
    80001238:	f39ff0ef          	jal	80001170 <uvmunmap>
    8000123c:	b7d5                	j	80001220 <uvmdealloc+0x26>

000000008000123e <uvmalloc>:
  if (newsz < oldsz)
    8000123e:	08b66f63          	bltu	a2,a1,800012dc <uvmalloc+0x9e>
{
    80001242:	7139                	addi	sp,sp,-64
    80001244:	fc06                	sd	ra,56(sp)
    80001246:	f822                	sd	s0,48(sp)
    80001248:	ec4e                	sd	s3,24(sp)
    8000124a:	e852                	sd	s4,16(sp)
    8000124c:	e456                	sd	s5,8(sp)
    8000124e:	0080                	addi	s0,sp,64
    80001250:	8aaa                	mv	s5,a0
    80001252:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001254:	6785                	lui	a5,0x1
    80001256:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001258:	95be                	add	a1,a1,a5
    8000125a:	77fd                	lui	a5,0xfffff
    8000125c:	00f5f9b3          	and	s3,a1,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001260:	08c9f063          	bgeu	s3,a2,800012e0 <uvmalloc+0xa2>
    80001264:	f426                	sd	s1,40(sp)
    80001266:	f04a                	sd	s2,32(sp)
    80001268:	e05a                	sd	s6,0(sp)
    8000126a:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000126c:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001270:	859ff0ef          	jal	80000ac8 <kalloc>
    80001274:	84aa                	mv	s1,a0
    if (mem == 0) {
    80001276:	c515                	beqz	a0,800012a2 <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001278:	6605                	lui	a2,0x1
    8000127a:	4581                	li	a1,0
    8000127c:	9d7ff0ef          	jal	80000c52 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001280:	875a                	mv	a4,s6
    80001282:	86a6                	mv	a3,s1
    80001284:	6605                	lui	a2,0x1
    80001286:	85ca                	mv	a1,s2
    80001288:	8556                	mv	a0,s5
    8000128a:	d1bff0ef          	jal	80000fa4 <mappages>
    8000128e:	e915                	bnez	a0,800012c2 <uvmalloc+0x84>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001290:	6785                	lui	a5,0x1
    80001292:	993e                	add	s2,s2,a5
    80001294:	fd496ee3          	bltu	s2,s4,80001270 <uvmalloc+0x32>
  return newsz;
    80001298:	8552                	mv	a0,s4
    8000129a:	74a2                	ld	s1,40(sp)
    8000129c:	7902                	ld	s2,32(sp)
    8000129e:	6b02                	ld	s6,0(sp)
    800012a0:	a811                	j	800012b4 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012a2:	864e                	mv	a2,s3
    800012a4:	85ca                	mv	a1,s2
    800012a6:	8556                	mv	a0,s5
    800012a8:	f53ff0ef          	jal	800011fa <uvmdealloc>
      return 0;
    800012ac:	4501                	li	a0,0
    800012ae:	74a2                	ld	s1,40(sp)
    800012b0:	7902                	ld	s2,32(sp)
    800012b2:	6b02                	ld	s6,0(sp)
}
    800012b4:	70e2                	ld	ra,56(sp)
    800012b6:	7442                	ld	s0,48(sp)
    800012b8:	69e2                	ld	s3,24(sp)
    800012ba:	6a42                	ld	s4,16(sp)
    800012bc:	6aa2                	ld	s5,8(sp)
    800012be:	6121                	addi	sp,sp,64
    800012c0:	8082                	ret
      kfree(mem);
    800012c2:	8526                	mv	a0,s1
    800012c4:	f22ff0ef          	jal	800009e6 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800012c8:	864e                	mv	a2,s3
    800012ca:	85ca                	mv	a1,s2
    800012cc:	8556                	mv	a0,s5
    800012ce:	f2dff0ef          	jal	800011fa <uvmdealloc>
      return 0;
    800012d2:	4501                	li	a0,0
    800012d4:	74a2                	ld	s1,40(sp)
    800012d6:	7902                	ld	s2,32(sp)
    800012d8:	6b02                	ld	s6,0(sp)
    800012da:	bfe9                	j	800012b4 <uvmalloc+0x76>
    return oldsz;
    800012dc:	852e                	mv	a0,a1
}
    800012de:	8082                	ret
  return newsz;
    800012e0:	8532                	mv	a0,a2
    800012e2:	bfc9                	j	800012b4 <uvmalloc+0x76>

00000000800012e4 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800012e4:	7179                	addi	sp,sp,-48
    800012e6:	f406                	sd	ra,40(sp)
    800012e8:	f022                	sd	s0,32(sp)
    800012ea:	ec26                	sd	s1,24(sp)
    800012ec:	e84a                	sd	s2,16(sp)
    800012ee:	e44e                	sd	s3,8(sp)
    800012f0:	e052                	sd	s4,0(sp)
    800012f2:	1800                	addi	s0,sp,48
    800012f4:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    800012f6:	84aa                	mv	s1,a0
    800012f8:	6905                	lui	s2,0x1
    800012fa:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800012fc:	4985                	li	s3,1
    800012fe:	a819                	j	80001314 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001300:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001302:	00c79513          	slli	a0,a5,0xc
    80001306:	fdfff0ef          	jal	800012e4 <freewalk>
      pagetable[i] = 0;
    8000130a:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++) {
    8000130e:	04a1                	addi	s1,s1,8
    80001310:	01248f63          	beq	s1,s2,8000132e <freewalk+0x4a>
    pte_t pte = pagetable[i];
    80001314:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001316:	00f7f713          	andi	a4,a5,15
    8000131a:	ff3703e3          	beq	a4,s3,80001300 <freewalk+0x1c>
    } else if (pte & PTE_V) {
    8000131e:	8b85                	andi	a5,a5,1
    80001320:	d7fd                	beqz	a5,8000130e <freewalk+0x2a>
      panic("freewalk: leaf");
    80001322:	00008517          	auipc	a0,0x8
    80001326:	e1650513          	addi	a0,a0,-490 # 80009138 <etext+0x138>
    8000132a:	cc4ff0ef          	jal	800007ee <panic>
    }
  }
  kfree((void *)pagetable);
    8000132e:	8552                	mv	a0,s4
    80001330:	eb6ff0ef          	jal	800009e6 <kfree>
}
    80001334:	70a2                	ld	ra,40(sp)
    80001336:	7402                	ld	s0,32(sp)
    80001338:	64e2                	ld	s1,24(sp)
    8000133a:	6942                	ld	s2,16(sp)
    8000133c:	69a2                	ld	s3,8(sp)
    8000133e:	6a02                	ld	s4,0(sp)
    80001340:	6145                	addi	sp,sp,48
    80001342:	8082                	ret

0000000080001344 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001344:	1101                	addi	sp,sp,-32
    80001346:	ec06                	sd	ra,24(sp)
    80001348:	e822                	sd	s0,16(sp)
    8000134a:	e426                	sd	s1,8(sp)
    8000134c:	1000                	addi	s0,sp,32
    8000134e:	84aa                	mv	s1,a0
  if (sz > 0)
    80001350:	e989                	bnez	a1,80001362 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001352:	8526                	mv	a0,s1
    80001354:	f91ff0ef          	jal	800012e4 <freewalk>
}
    80001358:	60e2                	ld	ra,24(sp)
    8000135a:	6442                	ld	s0,16(sp)
    8000135c:	64a2                	ld	s1,8(sp)
    8000135e:	6105                	addi	sp,sp,32
    80001360:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001362:	6785                	lui	a5,0x1
    80001364:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001366:	95be                	add	a1,a1,a5
    80001368:	4685                	li	a3,1
    8000136a:	00c5d613          	srli	a2,a1,0xc
    8000136e:	4581                	li	a1,0
    80001370:	e01ff0ef          	jal	80001170 <uvmunmap>
    80001374:	bff9                	j	80001352 <uvmfree+0xe>

0000000080001376 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    80001376:	ce49                	beqz	a2,80001410 <uvmcopy+0x9a>
{
    80001378:	715d                	addi	sp,sp,-80
    8000137a:	e486                	sd	ra,72(sp)
    8000137c:	e0a2                	sd	s0,64(sp)
    8000137e:	fc26                	sd	s1,56(sp)
    80001380:	f84a                	sd	s2,48(sp)
    80001382:	f44e                	sd	s3,40(sp)
    80001384:	f052                	sd	s4,32(sp)
    80001386:	ec56                	sd	s5,24(sp)
    80001388:	e85a                	sd	s6,16(sp)
    8000138a:	e45e                	sd	s7,8(sp)
    8000138c:	0880                	addi	s0,sp,80
    8000138e:	8aaa                	mv	s5,a0
    80001390:	8b2e                	mv	s6,a1
    80001392:	8a32                	mv	s4,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001394:	4481                	li	s1,0
    80001396:	a029                	j	800013a0 <uvmcopy+0x2a>
    80001398:	6785                	lui	a5,0x1
    8000139a:	94be                	add	s1,s1,a5
    8000139c:	0544fe63          	bgeu	s1,s4,800013f8 <uvmcopy+0x82>
    if ((pte = walk(old, i, 0)) == 0)
    800013a0:	4601                	li	a2,0
    800013a2:	85a6                	mv	a1,s1
    800013a4:	8556                	mv	a0,s5
    800013a6:	b27ff0ef          	jal	80000ecc <walk>
    800013aa:	d57d                	beqz	a0,80001398 <uvmcopy+0x22>
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0)
    800013ac:	6118                	ld	a4,0(a0)
    800013ae:	00177793          	andi	a5,a4,1
    800013b2:	d3fd                	beqz	a5,80001398 <uvmcopy+0x22>
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013b4:	00a75593          	srli	a1,a4,0xa
    800013b8:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800013bc:	3ff77913          	andi	s2,a4,1023
    if ((mem = kalloc()) == 0)
    800013c0:	f08ff0ef          	jal	80000ac8 <kalloc>
    800013c4:	89aa                	mv	s3,a0
    800013c6:	c105                	beqz	a0,800013e6 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800013c8:	6605                	lui	a2,0x1
    800013ca:	85de                	mv	a1,s7
    800013cc:	8e3ff0ef          	jal	80000cae <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    800013d0:	874a                	mv	a4,s2
    800013d2:	86ce                	mv	a3,s3
    800013d4:	6605                	lui	a2,0x1
    800013d6:	85a6                	mv	a1,s1
    800013d8:	855a                	mv	a0,s6
    800013da:	bcbff0ef          	jal	80000fa4 <mappages>
    800013de:	dd4d                	beqz	a0,80001398 <uvmcopy+0x22>
      kfree(mem);
    800013e0:	854e                	mv	a0,s3
    800013e2:	e04ff0ef          	jal	800009e6 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800013e6:	4685                	li	a3,1
    800013e8:	00c4d613          	srli	a2,s1,0xc
    800013ec:	4581                	li	a1,0
    800013ee:	855a                	mv	a0,s6
    800013f0:	d81ff0ef          	jal	80001170 <uvmunmap>
  return -1;
    800013f4:	557d                	li	a0,-1
    800013f6:	a011                	j	800013fa <uvmcopy+0x84>
  return 0;
    800013f8:	4501                	li	a0,0
}
    800013fa:	60a6                	ld	ra,72(sp)
    800013fc:	6406                	ld	s0,64(sp)
    800013fe:	74e2                	ld	s1,56(sp)
    80001400:	7942                	ld	s2,48(sp)
    80001402:	79a2                	ld	s3,40(sp)
    80001404:	7a02                	ld	s4,32(sp)
    80001406:	6ae2                	ld	s5,24(sp)
    80001408:	6b42                	ld	s6,16(sp)
    8000140a:	6ba2                	ld	s7,8(sp)
    8000140c:	6161                	addi	sp,sp,80
    8000140e:	8082                	ret
  return 0;
    80001410:	4501                	li	a0,0
}
    80001412:	8082                	ret

0000000080001414 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001414:	1141                	addi	sp,sp,-16
    80001416:	e406                	sd	ra,8(sp)
    80001418:	e022                	sd	s0,0(sp)
    8000141a:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    8000141c:	4601                	li	a2,0
    8000141e:	aafff0ef          	jal	80000ecc <walk>
  if (pte == 0)
    80001422:	c901                	beqz	a0,80001432 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001424:	611c                	ld	a5,0(a0)
    80001426:	9bbd                	andi	a5,a5,-17
    80001428:	e11c                	sd	a5,0(a0)
}
    8000142a:	60a2                	ld	ra,8(sp)
    8000142c:	6402                	ld	s0,0(sp)
    8000142e:	0141                	addi	sp,sp,16
    80001430:	8082                	ret
    panic("uvmclear");
    80001432:	00008517          	auipc	a0,0x8
    80001436:	d1650513          	addi	a0,a0,-746 # 80009148 <etext+0x148>
    8000143a:	bb4ff0ef          	jal	800007ee <panic>

000000008000143e <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    8000143e:	1141                	addi	sp,sp,-16
    80001440:	e406                	sd	ra,8(sp)
    80001442:	e022                	sd	s0,0(sp)
    80001444:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001446:	4601                	li	a2,0
    80001448:	a85ff0ef          	jal	80000ecc <walk>
  if (pte == 0) {
    8000144c:	c519                	beqz	a0,8000145a <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V) {
    8000144e:	6108                	ld	a0,0(a0)
    80001450:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001452:	60a2                	ld	ra,8(sp)
    80001454:	6402                	ld	s0,0(sp)
    80001456:	0141                	addi	sp,sp,16
    80001458:	8082                	ret
    return 0;
    8000145a:	4501                	li	a0,0
    8000145c:	bfdd                	j	80001452 <ismapped+0x14>

000000008000145e <vmfault>:
{
    8000145e:	7179                	addi	sp,sp,-48
    80001460:	f406                	sd	ra,40(sp)
    80001462:	f022                	sd	s0,32(sp)
    80001464:	e44e                	sd	s3,8(sp)
    80001466:	1800                	addi	s0,sp,48
    return 0;
    80001468:	4981                	li	s3,0
  if (va >= psz)
    8000146a:	00b66863          	bltu	a2,a1,8000147a <vmfault+0x1c>
}
    8000146e:	854e                	mv	a0,s3
    80001470:	70a2                	ld	ra,40(sp)
    80001472:	7402                	ld	s0,32(sp)
    80001474:	69a2                	ld	s3,8(sp)
    80001476:	6145                	addi	sp,sp,48
    80001478:	8082                	ret
    8000147a:	ec26                	sd	s1,24(sp)
    8000147c:	e84a                	sd	s2,16(sp)
    8000147e:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    80001480:	77fd                	lui	a5,0xfffff
    80001482:	00f674b3          	and	s1,a2,a5
  if (ismapped(pagetable, va)) {
    80001486:	85a6                	mv	a1,s1
    80001488:	fb7ff0ef          	jal	8000143e <ismapped>
    return 0;
    8000148c:	4981                	li	s3,0
  if (ismapped(pagetable, va)) {
    8000148e:	c501                	beqz	a0,80001496 <vmfault+0x38>
    80001490:	64e2                	ld	s1,24(sp)
    80001492:	6942                	ld	s2,16(sp)
    80001494:	bfe9                	j	8000146e <vmfault+0x10>
    80001496:	e052                	sd	s4,0(sp)
  mem = (uint64)kalloc();
    80001498:	e30ff0ef          	jal	80000ac8 <kalloc>
    8000149c:	8a2a                	mv	s4,a0
  if (mem == 0)
    8000149e:	c915                	beqz	a0,800014d2 <vmfault+0x74>
  mem = (uint64)kalloc();
    800014a0:	89aa                	mv	s3,a0
  memset((void *)mem, 0, PGSIZE);
    800014a2:	6605                	lui	a2,0x1
    800014a4:	4581                	li	a1,0
    800014a6:	facff0ef          	jal	80000c52 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    800014aa:	4759                	li	a4,22
    800014ac:	86d2                	mv	a3,s4
    800014ae:	6605                	lui	a2,0x1
    800014b0:	85a6                	mv	a1,s1
    800014b2:	854a                	mv	a0,s2
    800014b4:	af1ff0ef          	jal	80000fa4 <mappages>
    800014b8:	e509                	bnez	a0,800014c2 <vmfault+0x64>
    800014ba:	64e2                	ld	s1,24(sp)
    800014bc:	6942                	ld	s2,16(sp)
    800014be:	6a02                	ld	s4,0(sp)
    800014c0:	b77d                	j	8000146e <vmfault+0x10>
    kfree((void *)mem);
    800014c2:	8552                	mv	a0,s4
    800014c4:	d22ff0ef          	jal	800009e6 <kfree>
    return 0;
    800014c8:	4981                	li	s3,0
    800014ca:	64e2                	ld	s1,24(sp)
    800014cc:	6942                	ld	s2,16(sp)
    800014ce:	6a02                	ld	s4,0(sp)
    800014d0:	bf79                	j	8000146e <vmfault+0x10>
    800014d2:	64e2                	ld	s1,24(sp)
    800014d4:	6942                	ld	s2,16(sp)
    800014d6:	6a02                	ld	s4,0(sp)
    800014d8:	bf59                	j	8000146e <vmfault+0x10>

00000000800014da <copyout>:
  while (len > 0) {
    800014da:	c745                	beqz	a4,80001582 <copyout+0xa8>
{
    800014dc:	7159                	addi	sp,sp,-112
    800014de:	f486                	sd	ra,104(sp)
    800014e0:	f0a2                	sd	s0,96(sp)
    800014e2:	eca6                	sd	s1,88(sp)
    800014e4:	e0d2                	sd	s4,64(sp)
    800014e6:	f85a                	sd	s6,48(sp)
    800014e8:	f45e                	sd	s7,40(sp)
    800014ea:	f062                	sd	s8,32(sp)
    800014ec:	e46e                	sd	s11,8(sp)
    800014ee:	1880                	addi	s0,sp,112
    800014f0:	8c2a                	mv	s8,a0
    800014f2:	8dae                	mv	s11,a1
    800014f4:	8b32                	mv	s6,a2
    800014f6:	8bb6                	mv	s7,a3
    800014f8:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(dstva);
    800014fa:	74fd                	lui	s1,0xfffff
    800014fc:	8cf1                	and	s1,s1,a2
    if (va0 >= MAXVA)
    800014fe:	57fd                	li	a5,-1
    80001500:	83e9                	srli	a5,a5,0x1a
    80001502:	0897e263          	bltu	a5,s1,80001586 <copyout+0xac>
    80001506:	e8ca                	sd	s2,80(sp)
    80001508:	e4ce                	sd	s3,72(sp)
    8000150a:	fc56                	sd	s5,56(sp)
    8000150c:	ec66                	sd	s9,24(sp)
    8000150e:	e86a                	sd	s10,16(sp)
    80001510:	6d05                	lui	s10,0x1
    80001512:	8cbe                	mv	s9,a5
    80001514:	a015                	j	80001538 <copyout+0x5e>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001516:	409b0533          	sub	a0,s6,s1
    8000151a:	0009861b          	sext.w	a2,s3
    8000151e:	85de                	mv	a1,s7
    80001520:	954a                	add	a0,a0,s2
    80001522:	f8cff0ef          	jal	80000cae <memmove>
    len -= n;
    80001526:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000152a:	9bce                	add	s7,s7,s3
  while (len > 0) {
    8000152c:	040a0463          	beqz	s4,80001574 <copyout+0x9a>
    if (va0 >= MAXVA)
    80001530:	055ced63          	bltu	s9,s5,8000158a <copyout+0xb0>
    80001534:	84d6                	mv	s1,s5
    80001536:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001538:	85a6                	mv	a1,s1
    8000153a:	8562                	mv	a0,s8
    8000153c:	a2bff0ef          	jal	80000f66 <walkaddr>
    80001540:	892a                	mv	s2,a0
    if (pa0 == 0) {
    80001542:	e909                	bnez	a0,80001554 <copyout+0x7a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    80001544:	4681                	li	a3,0
    80001546:	8626                	mv	a2,s1
    80001548:	85ee                	mv	a1,s11
    8000154a:	8562                	mv	a0,s8
    8000154c:	f13ff0ef          	jal	8000145e <vmfault>
    80001550:	892a                	mv	s2,a0
    80001552:	c139                	beqz	a0,80001598 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    80001554:	4601                	li	a2,0
    80001556:	85a6                	mv	a1,s1
    80001558:	8562                	mv	a0,s8
    8000155a:	973ff0ef          	jal	80000ecc <walk>
    if ((*pte & PTE_W) == 0)
    8000155e:	611c                	ld	a5,0(a0)
    80001560:	8b91                	andi	a5,a5,4
    80001562:	c3b1                	beqz	a5,800015a6 <copyout+0xcc>
    n = PGSIZE - (dstva - va0);
    80001564:	01a48ab3          	add	s5,s1,s10
    80001568:	416a89b3          	sub	s3,s5,s6
    if (n > len)
    8000156c:	fb3a75e3          	bgeu	s4,s3,80001516 <copyout+0x3c>
    80001570:	89d2                	mv	s3,s4
    80001572:	b755                	j	80001516 <copyout+0x3c>
  return 0;
    80001574:	4501                	li	a0,0
    80001576:	6946                	ld	s2,80(sp)
    80001578:	69a6                	ld	s3,72(sp)
    8000157a:	7ae2                	ld	s5,56(sp)
    8000157c:	6ce2                	ld	s9,24(sp)
    8000157e:	6d42                	ld	s10,16(sp)
    80001580:	a80d                	j	800015b2 <copyout+0xd8>
    80001582:	4501                	li	a0,0
}
    80001584:	8082                	ret
      return -1;
    80001586:	557d                	li	a0,-1
    80001588:	a02d                	j	800015b2 <copyout+0xd8>
    8000158a:	557d                	li	a0,-1
    8000158c:	6946                	ld	s2,80(sp)
    8000158e:	69a6                	ld	s3,72(sp)
    80001590:	7ae2                	ld	s5,56(sp)
    80001592:	6ce2                	ld	s9,24(sp)
    80001594:	6d42                	ld	s10,16(sp)
    80001596:	a831                	j	800015b2 <copyout+0xd8>
        return -1;
    80001598:	557d                	li	a0,-1
    8000159a:	6946                	ld	s2,80(sp)
    8000159c:	69a6                	ld	s3,72(sp)
    8000159e:	7ae2                	ld	s5,56(sp)
    800015a0:	6ce2                	ld	s9,24(sp)
    800015a2:	6d42                	ld	s10,16(sp)
    800015a4:	a039                	j	800015b2 <copyout+0xd8>
      return -1;
    800015a6:	557d                	li	a0,-1
    800015a8:	6946                	ld	s2,80(sp)
    800015aa:	69a6                	ld	s3,72(sp)
    800015ac:	7ae2                	ld	s5,56(sp)
    800015ae:	6ce2                	ld	s9,24(sp)
    800015b0:	6d42                	ld	s10,16(sp)
}
    800015b2:	70a6                	ld	ra,104(sp)
    800015b4:	7406                	ld	s0,96(sp)
    800015b6:	64e6                	ld	s1,88(sp)
    800015b8:	6a06                	ld	s4,64(sp)
    800015ba:	7b42                	ld	s6,48(sp)
    800015bc:	7ba2                	ld	s7,40(sp)
    800015be:	7c02                	ld	s8,32(sp)
    800015c0:	6da2                	ld	s11,8(sp)
    800015c2:	6165                	addi	sp,sp,112
    800015c4:	8082                	ret

00000000800015c6 <copyin>:
  while (len > 0) {
    800015c6:	cb49                	beqz	a4,80001658 <copyin+0x92>
{
    800015c8:	711d                	addi	sp,sp,-96
    800015ca:	ec86                	sd	ra,88(sp)
    800015cc:	e8a2                	sd	s0,80(sp)
    800015ce:	e4a6                	sd	s1,72(sp)
    800015d0:	e0ca                	sd	s2,64(sp)
    800015d2:	fc4e                	sd	s3,56(sp)
    800015d4:	f852                	sd	s4,48(sp)
    800015d6:	f456                	sd	s5,40(sp)
    800015d8:	f05a                	sd	s6,32(sp)
    800015da:	ec5e                	sd	s7,24(sp)
    800015dc:	e862                	sd	s8,16(sp)
    800015de:	e466                	sd	s9,8(sp)
    800015e0:	1080                	addi	s0,sp,96
    800015e2:	8baa                	mv	s7,a0
    800015e4:	8cae                	mv	s9,a1
    800015e6:	8ab2                	mv	s5,a2
    800015e8:	8936                	mv	s2,a3
    800015ea:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800015ec:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800015ee:	6b05                	lui	s6,0x1
    800015f0:	a035                	j	8000161c <copyin+0x56>
    800015f2:	412984b3          	sub	s1,s3,s2
    800015f6:	94da                	add	s1,s1,s6
    if (n > len)
    800015f8:	009a7363          	bgeu	s4,s1,800015fe <copyin+0x38>
    800015fc:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800015fe:	413905b3          	sub	a1,s2,s3
    80001602:	0004861b          	sext.w	a2,s1
    80001606:	95aa                	add	a1,a1,a0
    80001608:	8556                	mv	a0,s5
    8000160a:	ea4ff0ef          	jal	80000cae <memmove>
    len -= n;
    8000160e:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001612:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001614:	01698933          	add	s2,s3,s6
  while (len > 0) {
    80001618:	020a0263          	beqz	s4,8000163c <copyin+0x76>
    va0 = PGROUNDDOWN(srcva);
    8000161c:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001620:	85ce                	mv	a1,s3
    80001622:	855e                	mv	a0,s7
    80001624:	943ff0ef          	jal	80000f66 <walkaddr>
    if (pa0 == 0) {
    80001628:	f569                	bnez	a0,800015f2 <copyin+0x2c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000162a:	4685                	li	a3,1
    8000162c:	864e                	mv	a2,s3
    8000162e:	85e6                	mv	a1,s9
    80001630:	855e                	mv	a0,s7
    80001632:	e2dff0ef          	jal	8000145e <vmfault>
    80001636:	fd55                	bnez	a0,800015f2 <copyin+0x2c>
        return -1;
    80001638:	557d                	li	a0,-1
    8000163a:	a011                	j	8000163e <copyin+0x78>
  return 0;
    8000163c:	4501                	li	a0,0
}
    8000163e:	60e6                	ld	ra,88(sp)
    80001640:	6446                	ld	s0,80(sp)
    80001642:	64a6                	ld	s1,72(sp)
    80001644:	6906                	ld	s2,64(sp)
    80001646:	79e2                	ld	s3,56(sp)
    80001648:	7a42                	ld	s4,48(sp)
    8000164a:	7aa2                	ld	s5,40(sp)
    8000164c:	7b02                	ld	s6,32(sp)
    8000164e:	6be2                	ld	s7,24(sp)
    80001650:	6c42                	ld	s8,16(sp)
    80001652:	6ca2                	ld	s9,8(sp)
    80001654:	6125                	addi	sp,sp,96
    80001656:	8082                	ret
  return 0;
    80001658:	4501                	li	a0,0
}
    8000165a:	8082                	ret

000000008000165c <copyinstr>:
  while (got_null == 0 && max > 0) {
    8000165c:	c371                	beqz	a4,80001720 <copyinstr+0xc4>
{
    8000165e:	715d                	addi	sp,sp,-80
    80001660:	e486                	sd	ra,72(sp)
    80001662:	e0a2                	sd	s0,64(sp)
    80001664:	fc26                	sd	s1,56(sp)
    80001666:	f84a                	sd	s2,48(sp)
    80001668:	f44e                	sd	s3,40(sp)
    8000166a:	f052                	sd	s4,32(sp)
    8000166c:	ec56                	sd	s5,24(sp)
    8000166e:	e85a                	sd	s6,16(sp)
    80001670:	e45e                	sd	s7,8(sp)
    80001672:	e062                	sd	s8,0(sp)
    80001674:	0880                	addi	s0,sp,80
    80001676:	8a2a                	mv	s4,a0
    80001678:	8b2e                	mv	s6,a1
    8000167a:	8bb2                	mv	s7,a2
    8000167c:	8c36                	mv	s8,a3
    8000167e:	893a                	mv	s2,a4
    va0 = PGROUNDDOWN(srcva);
    80001680:	7afd                	lui	s5,0xfffff
    n = PGSIZE - (srcva - va0);
    80001682:	6985                	lui	s3,0x1
    80001684:	a0b1                	j	800016d0 <copyinstr+0x74>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001686:	4685                	li	a3,1
    80001688:	8626                	mv	a2,s1
    8000168a:	85da                	mv	a1,s6
    8000168c:	8552                	mv	a0,s4
    8000168e:	dd1ff0ef          	jal	8000145e <vmfault>
    80001692:	e531                	bnez	a0,800016de <copyinstr+0x82>
        return -1;
    80001694:	557d                	li	a0,-1
    80001696:	a039                	j	800016a4 <copyinstr+0x48>
        *dst = '\0';
    80001698:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffd7048>
    8000169c:	4785                	li	a5,1
  if (got_null) {
    8000169e:	37fd                	addiw	a5,a5,-1
    800016a0:	0007851b          	sext.w	a0,a5
}
    800016a4:	60a6                	ld	ra,72(sp)
    800016a6:	6406                	ld	s0,64(sp)
    800016a8:	74e2                	ld	s1,56(sp)
    800016aa:	7942                	ld	s2,48(sp)
    800016ac:	79a2                	ld	s3,40(sp)
    800016ae:	7a02                	ld	s4,32(sp)
    800016b0:	6ae2                	ld	s5,24(sp)
    800016b2:	6b42                	ld	s6,16(sp)
    800016b4:	6ba2                	ld	s7,8(sp)
    800016b6:	6c02                	ld	s8,0(sp)
    800016b8:	6161                	addi	sp,sp,80
    800016ba:	8082                	ret
    800016bc:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800016c0:	972a                	add	a4,a4,a0
      --max;
    800016c2:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800016c6:	01348c33          	add	s8,s1,s3
  while (got_null == 0 && max > 0) {
    800016ca:	04e58563          	beq	a1,a4,80001714 <copyinstr+0xb8>
{
    800016ce:	8bbe                	mv	s7,a5
    va0 = PGROUNDDOWN(srcva);
    800016d0:	015c74b3          	and	s1,s8,s5
    pa0 = walkaddr(pagetable, va0);
    800016d4:	85a6                	mv	a1,s1
    800016d6:	8552                	mv	a0,s4
    800016d8:	88fff0ef          	jal	80000f66 <walkaddr>
    if (pa0 == 0) {
    800016dc:	d54d                	beqz	a0,80001686 <copyinstr+0x2a>
    n = PGSIZE - (srcva - va0);
    800016de:	41848633          	sub	a2,s1,s8
    800016e2:	964e                	add	a2,a2,s3
    if (n > max)
    800016e4:	00c97363          	bgeu	s2,a2,800016ea <copyinstr+0x8e>
    800016e8:	864a                	mv	a2,s2
    char *p = (char *)(pa0 + (srcva - va0));
    800016ea:	409c0c33          	sub	s8,s8,s1
    800016ee:	9c2a                	add	s8,s8,a0
    while (n > 0) {
    800016f0:	c605                	beqz	a2,80001718 <copyinstr+0xbc>
    800016f2:	87de                	mv	a5,s7
    800016f4:	855e                	mv	a0,s7
      if (*p == '\0') {
    800016f6:	417c0733          	sub	a4,s8,s7
    while (n > 0) {
    800016fa:	965e                	add	a2,a2,s7
    800016fc:	85be                	mv	a1,a5
      if (*p == '\0') {
    800016fe:	00f706b3          	add	a3,a4,a5
    80001702:	0006c683          	lbu	a3,0(a3) # fffffffffffff000 <end+0xffffffff7ffd7048>
    80001706:	dac9                	beqz	a3,80001698 <copyinstr+0x3c>
        *dst = *p;
    80001708:	00d78023          	sb	a3,0(a5)
      dst++;
    8000170c:	0785                	addi	a5,a5,1
    while (n > 0) {
    8000170e:	fec797e3          	bne	a5,a2,800016fc <copyinstr+0xa0>
    80001712:	b76d                	j	800016bc <copyinstr+0x60>
    80001714:	4781                	li	a5,0
    80001716:	b761                	j	8000169e <copyinstr+0x42>
    srcva = va0 + PGSIZE;
    80001718:	6c05                	lui	s8,0x1
    8000171a:	9c26                	add	s8,s8,s1
    8000171c:	87de                	mv	a5,s7
    8000171e:	bf45                	j	800016ce <copyinstr+0x72>
  int got_null = 0;
    80001720:	4781                	li	a5,0
  if (got_null) {
    80001722:	37fd                	addiw	a5,a5,-1
    80001724:	0007851b          	sext.w	a0,a5
}
    80001728:	8082                	ret

000000008000172a <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    8000172a:	7139                	addi	sp,sp,-64
    8000172c:	fc06                	sd	ra,56(sp)
    8000172e:	f822                	sd	s0,48(sp)
    80001730:	f426                	sd	s1,40(sp)
    80001732:	f04a                	sd	s2,32(sp)
    80001734:	ec4e                	sd	s3,24(sp)
    80001736:	e852                	sd	s4,16(sp)
    80001738:	e456                	sd	s5,8(sp)
    8000173a:	e05a                	sd	s6,0(sp)
    8000173c:	0080                	addi	s0,sp,64
    8000173e:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001740:	00014497          	auipc	s1,0x14
    80001744:	47048493          	addi	s1,s1,1136 # 80015bb0 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    80001748:	8b26                	mv	s6,s1
    8000174a:	fafb0937          	lui	s2,0xfafb0
    8000174e:	afb90913          	addi	s2,s2,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    80001752:	0942                	slli	s2,s2,0x10
    80001754:	afb90913          	addi	s2,s2,-1285
    80001758:	0942                	slli	s2,s2,0x10
    8000175a:	afb90913          	addi	s2,s2,-1285
    8000175e:	040009b7          	lui	s3,0x4000
    80001762:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001764:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001766:	0001ba97          	auipc	s5,0x1b
    8000176a:	a4aa8a93          	addi	s5,s5,-1462 # 8001c1b0 <tickslock>
    char *pa = kalloc();
    8000176e:	b5aff0ef          	jal	80000ac8 <kalloc>
    80001772:	862a                	mv	a2,a0
    if (pa == 0)
    80001774:	cd15                	beqz	a0,800017b0 <proc_mapstacks+0x86>
    uint64 va = KSTACK((int)(p - proc));
    80001776:	416485b3          	sub	a1,s1,s6
    8000177a:	858d                	srai	a1,a1,0x3
    8000177c:	032585b3          	mul	a1,a1,s2
    80001780:	2585                	addiw	a1,a1,1
    80001782:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001786:	4719                	li	a4,6
    80001788:	6685                	lui	a3,0x1
    8000178a:	40b985b3          	sub	a1,s3,a1
    8000178e:	8552                	mv	a0,s4
    80001790:	8c5ff0ef          	jal	80001054 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001794:	19848493          	addi	s1,s1,408
    80001798:	fd549be3          	bne	s1,s5,8000176e <proc_mapstacks+0x44>
  }
}
    8000179c:	70e2                	ld	ra,56(sp)
    8000179e:	7442                	ld	s0,48(sp)
    800017a0:	74a2                	ld	s1,40(sp)
    800017a2:	7902                	ld	s2,32(sp)
    800017a4:	69e2                	ld	s3,24(sp)
    800017a6:	6a42                	ld	s4,16(sp)
    800017a8:	6aa2                	ld	s5,8(sp)
    800017aa:	6b02                	ld	s6,0(sp)
    800017ac:	6121                	addi	sp,sp,64
    800017ae:	8082                	ret
      panic("kalloc");
    800017b0:	00008517          	auipc	a0,0x8
    800017b4:	9a850513          	addi	a0,a0,-1624 # 80009158 <etext+0x158>
    800017b8:	836ff0ef          	jal	800007ee <panic>

00000000800017bc <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017bc:	7139                	addi	sp,sp,-64
    800017be:	fc06                	sd	ra,56(sp)
    800017c0:	f822                	sd	s0,48(sp)
    800017c2:	f426                	sd	s1,40(sp)
    800017c4:	f04a                	sd	s2,32(sp)
    800017c6:	ec4e                	sd	s3,24(sp)
    800017c8:	e852                	sd	s4,16(sp)
    800017ca:	e456                	sd	s5,8(sp)
    800017cc:	e05a                	sd	s6,0(sp)
    800017ce:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800017d0:	00008597          	auipc	a1,0x8
    800017d4:	99058593          	addi	a1,a1,-1648 # 80009160 <etext+0x160>
    800017d8:	00014517          	auipc	a0,0x14
    800017dc:	fa850513          	addi	a0,a0,-88 # 80015780 <pid_lock>
    800017e0:	b38ff0ef          	jal	80000b18 <initlock>
  initlock(&wait_lock, "wait_lock");
    800017e4:	00008597          	auipc	a1,0x8
    800017e8:	98458593          	addi	a1,a1,-1660 # 80009168 <etext+0x168>
    800017ec:	00014517          	auipc	a0,0x14
    800017f0:	fac50513          	addi	a0,a0,-84 # 80015798 <wait_lock>
    800017f4:	b24ff0ef          	jal	80000b18 <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017f8:	00014497          	auipc	s1,0x14
    800017fc:	3b848493          	addi	s1,s1,952 # 80015bb0 <proc>
    initlock(&p->lock, "proc");
    80001800:	00008b17          	auipc	s6,0x8
    80001804:	978b0b13          	addi	s6,s6,-1672 # 80009178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    80001808:	8aa6                	mv	s5,s1
    8000180a:	fafb0937          	lui	s2,0xfafb0
    8000180e:	afb90913          	addi	s2,s2,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    80001812:	0942                	slli	s2,s2,0x10
    80001814:	afb90913          	addi	s2,s2,-1285
    80001818:	0942                	slli	s2,s2,0x10
    8000181a:	afb90913          	addi	s2,s2,-1285
    8000181e:	040009b7          	lui	s3,0x4000
    80001822:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001824:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001826:	0001ba17          	auipc	s4,0x1b
    8000182a:	98aa0a13          	addi	s4,s4,-1654 # 8001c1b0 <tickslock>
    initlock(&p->lock, "proc");
    8000182e:	85da                	mv	a1,s6
    80001830:	8526                	mv	a0,s1
    80001832:	ae6ff0ef          	jal	80000b18 <initlock>
    p->state = UNUSED;
    80001836:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    8000183a:	415487b3          	sub	a5,s1,s5
    8000183e:	878d                	srai	a5,a5,0x3
    80001840:	032787b3          	mul	a5,a5,s2
    80001844:	2785                	addiw	a5,a5,1
    80001846:	00d7979b          	slliw	a5,a5,0xd
    8000184a:	40f987b3          	sub	a5,s3,a5
    8000184e:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    80001850:	19848493          	addi	s1,s1,408
    80001854:	fd449de3          	bne	s1,s4,8000182e <procinit+0x72>
  }
}
    80001858:	70e2                	ld	ra,56(sp)
    8000185a:	7442                	ld	s0,48(sp)
    8000185c:	74a2                	ld	s1,40(sp)
    8000185e:	7902                	ld	s2,32(sp)
    80001860:	69e2                	ld	s3,24(sp)
    80001862:	6a42                	ld	s4,16(sp)
    80001864:	6aa2                	ld	s5,8(sp)
    80001866:	6b02                	ld	s6,0(sp)
    80001868:	6121                	addi	sp,sp,64
    8000186a:	8082                	ret

000000008000186c <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000186c:	1141                	addi	sp,sp,-16
    8000186e:	e422                	sd	s0,8(sp)
    80001870:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    80001872:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001874:	2501                	sext.w	a0,a0
    80001876:	6422                	ld	s0,8(sp)
    80001878:	0141                	addi	sp,sp,16
    8000187a:	8082                	ret

000000008000187c <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    8000187c:	1141                	addi	sp,sp,-16
    8000187e:	e422                	sd	s0,8(sp)
    80001880:	0800                	addi	s0,sp,16
    80001882:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001884:	2781                	sext.w	a5,a5
    80001886:	079e                	slli	a5,a5,0x7
  return c;
}
    80001888:	00014517          	auipc	a0,0x14
    8000188c:	f2850513          	addi	a0,a0,-216 # 800157b0 <cpus>
    80001890:	953e                	add	a0,a0,a5
    80001892:	6422                	ld	s0,8(sp)
    80001894:	0141                	addi	sp,sp,16
    80001896:	8082                	ret

0000000080001898 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    80001898:	1101                	addi	sp,sp,-32
    8000189a:	ec06                	sd	ra,24(sp)
    8000189c:	e822                	sd	s0,16(sp)
    8000189e:	e426                	sd	s1,8(sp)
    800018a0:	1000                	addi	s0,sp,32
  push_off();
    800018a2:	ab6ff0ef          	jal	80000b58 <push_off>
    800018a6:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018a8:	2781                	sext.w	a5,a5
    800018aa:	079e                	slli	a5,a5,0x7
    800018ac:	00014717          	auipc	a4,0x14
    800018b0:	ed470713          	addi	a4,a4,-300 # 80015780 <pid_lock>
    800018b4:	97ba                	add	a5,a5,a4
    800018b6:	7b84                	ld	s1,48(a5)
  pop_off();
    800018b8:	b16ff0ef          	jal	80000bce <pop_off>
  return p;
}
    800018bc:	8526                	mv	a0,s1
    800018be:	60e2                	ld	ra,24(sp)
    800018c0:	6442                	ld	s0,16(sp)
    800018c2:	64a2                	ld	s1,8(sp)
    800018c4:	6105                	addi	sp,sp,32
    800018c6:	8082                	ret

00000000800018c8 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018c8:	7179                	addi	sp,sp,-48
    800018ca:	f406                	sd	ra,40(sp)
    800018cc:	f022                	sd	s0,32(sp)
    800018ce:	ec26                	sd	s1,24(sp)
    800018d0:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800018d2:	fc7ff0ef          	jal	80001898 <myproc>
    800018d6:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    800018d8:	b42ff0ef          	jal	80000c1a <release>

  if (__atomic_load_n(&first, __ATOMIC_ACQUIRE)) {
    800018dc:	0000b797          	auipc	a5,0xb
    800018e0:	5f478793          	addi	a5,a5,1524 # 8000ced0 <first.1>
    800018e4:	439c                	lw	a5,0(a5)
    800018e6:	0230000f          	fence	r,rw
    800018ea:	2781                	sext.w	a5,a5
    800018ec:	cf9d                	beqz	a5,8000192a <forkret+0x62>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800018ee:	4505                	li	a0,1
    800018f0:	787010ef          	jal	80003876 <fsinit>

    // ensure other cores see first=0.
    __atomic_store_n(&first, 0, __ATOMIC_RELEASE);
    800018f4:	0000b797          	auipc	a5,0xb
    800018f8:	5dc78793          	addi	a5,a5,1500 # 8000ced0 <first.1>
    800018fc:	0310000f          	fence	rw,w
    80001900:	0007a023          	sw	zero,0(a5)

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001904:	00008517          	auipc	a0,0x8
    80001908:	87c50513          	addi	a0,a0,-1924 # 80009180 <etext+0x180>
    8000190c:	fca43823          	sd	a0,-48(s0)
    80001910:	fc043c23          	sd	zero,-40(s0)
    80001914:	fd040593          	addi	a1,s0,-48
    80001918:	166030ef          	jal	80004a7e <kexec>
    8000191c:	6cbc                	ld	a5,88(s1)
    8000191e:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001920:	6cbc                	ld	a5,88(s1)
    80001922:	7bb8                	ld	a4,112(a5)
    80001924:	57fd                	li	a5,-1
    80001926:	02f70d63          	beq	a4,a5,80001960 <forkret+0x98>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000192a:	565000ef          	jal	8000268e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000192e:	68a8                	ld	a0,80(s1)
    80001930:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001932:	04000737          	lui	a4,0x4000
    80001936:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001938:	0732                	slli	a4,a4,0xc
    8000193a:	00006797          	auipc	a5,0x6
    8000193e:	76278793          	addi	a5,a5,1890 # 8000809c <userret>
    80001942:	00006697          	auipc	a3,0x6
    80001946:	6be68693          	addi	a3,a3,1726 # 80008000 <_trampoline>
    8000194a:	8f95                	sub	a5,a5,a3
    8000194c:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    8000194e:	577d                	li	a4,-1
    80001950:	177e                	slli	a4,a4,0x3f
    80001952:	8d59                	or	a0,a0,a4
    80001954:	9782                	jalr	a5
}
    80001956:	70a2                	ld	ra,40(sp)
    80001958:	7402                	ld	s0,32(sp)
    8000195a:	64e2                	ld	s1,24(sp)
    8000195c:	6145                	addi	sp,sp,48
    8000195e:	8082                	ret
      panic("exec");
    80001960:	00008517          	auipc	a0,0x8
    80001964:	82850513          	addi	a0,a0,-2008 # 80009188 <etext+0x188>
    80001968:	e87fe0ef          	jal	800007ee <panic>

000000008000196c <allocpid>:
{
    8000196c:	1101                	addi	sp,sp,-32
    8000196e:	ec06                	sd	ra,24(sp)
    80001970:	e822                	sd	s0,16(sp)
    80001972:	e426                	sd	s1,8(sp)
    80001974:	e04a                	sd	s2,0(sp)
    80001976:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001978:	00014917          	auipc	s2,0x14
    8000197c:	e0890913          	addi	s2,s2,-504 # 80015780 <pid_lock>
    80001980:	854a                	mv	a0,s2
    80001982:	a0cff0ef          	jal	80000b8e <acquire>
  pid = nextpid;
    80001986:	0000b797          	auipc	a5,0xb
    8000198a:	54e78793          	addi	a5,a5,1358 # 8000ced4 <nextpid>
    8000198e:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001990:	0014871b          	addiw	a4,s1,1
    80001994:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001996:	854a                	mv	a0,s2
    80001998:	a82ff0ef          	jal	80000c1a <release>
}
    8000199c:	8526                	mv	a0,s1
    8000199e:	60e2                	ld	ra,24(sp)
    800019a0:	6442                	ld	s0,16(sp)
    800019a2:	64a2                	ld	s1,8(sp)
    800019a4:	6902                	ld	s2,0(sp)
    800019a6:	6105                	addi	sp,sp,32
    800019a8:	8082                	ret

00000000800019aa <proc_pagetable>:
{
    800019aa:	1101                	addi	sp,sp,-32
    800019ac:	ec06                	sd	ra,24(sp)
    800019ae:	e822                	sd	s0,16(sp)
    800019b0:	e426                	sd	s1,8(sp)
    800019b2:	e04a                	sd	s2,0(sp)
    800019b4:	1000                	addi	s0,sp,32
    800019b6:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019b8:	f92ff0ef          	jal	8000114a <uvmcreate>
    800019bc:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800019be:	cd05                	beqz	a0,800019f6 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    800019c0:	4729                	li	a4,10
    800019c2:	00006697          	auipc	a3,0x6
    800019c6:	63e68693          	addi	a3,a3,1598 # 80008000 <_trampoline>
    800019ca:	6605                	lui	a2,0x1
    800019cc:	040005b7          	lui	a1,0x4000
    800019d0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019d2:	05b2                	slli	a1,a1,0xc
    800019d4:	dd0ff0ef          	jal	80000fa4 <mappages>
    800019d8:	02054663          	bltz	a0,80001a04 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    800019dc:	4719                	li	a4,6
    800019de:	05893683          	ld	a3,88(s2)
    800019e2:	6605                	lui	a2,0x1
    800019e4:	020005b7          	lui	a1,0x2000
    800019e8:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800019ea:	05b6                	slli	a1,a1,0xd
    800019ec:	8526                	mv	a0,s1
    800019ee:	db6ff0ef          	jal	80000fa4 <mappages>
    800019f2:	00054f63          	bltz	a0,80001a10 <proc_pagetable+0x66>
}
    800019f6:	8526                	mv	a0,s1
    800019f8:	60e2                	ld	ra,24(sp)
    800019fa:	6442                	ld	s0,16(sp)
    800019fc:	64a2                	ld	s1,8(sp)
    800019fe:	6902                	ld	s2,0(sp)
    80001a00:	6105                	addi	sp,sp,32
    80001a02:	8082                	ret
    uvmfree(pagetable, 0);
    80001a04:	4581                	li	a1,0
    80001a06:	8526                	mv	a0,s1
    80001a08:	93dff0ef          	jal	80001344 <uvmfree>
    return 0;
    80001a0c:	4481                	li	s1,0
    80001a0e:	b7e5                	j	800019f6 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a10:	4681                	li	a3,0
    80001a12:	4605                	li	a2,1
    80001a14:	040005b7          	lui	a1,0x4000
    80001a18:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a1a:	05b2                	slli	a1,a1,0xc
    80001a1c:	8526                	mv	a0,s1
    80001a1e:	f52ff0ef          	jal	80001170 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a22:	4581                	li	a1,0
    80001a24:	8526                	mv	a0,s1
    80001a26:	91fff0ef          	jal	80001344 <uvmfree>
    return 0;
    80001a2a:	4481                	li	s1,0
    80001a2c:	b7e9                	j	800019f6 <proc_pagetable+0x4c>

0000000080001a2e <proc_freepagetable>:
{
    80001a2e:	1101                	addi	sp,sp,-32
    80001a30:	ec06                	sd	ra,24(sp)
    80001a32:	e822                	sd	s0,16(sp)
    80001a34:	e426                	sd	s1,8(sp)
    80001a36:	e04a                	sd	s2,0(sp)
    80001a38:	1000                	addi	s0,sp,32
    80001a3a:	84aa                	mv	s1,a0
    80001a3c:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a3e:	4681                	li	a3,0
    80001a40:	4605                	li	a2,1
    80001a42:	040005b7          	lui	a1,0x4000
    80001a46:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a48:	05b2                	slli	a1,a1,0xc
    80001a4a:	f26ff0ef          	jal	80001170 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a4e:	4681                	li	a3,0
    80001a50:	4605                	li	a2,1
    80001a52:	020005b7          	lui	a1,0x2000
    80001a56:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a58:	05b6                	slli	a1,a1,0xd
    80001a5a:	8526                	mv	a0,s1
    80001a5c:	f14ff0ef          	jal	80001170 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a60:	85ca                	mv	a1,s2
    80001a62:	8526                	mv	a0,s1
    80001a64:	8e1ff0ef          	jal	80001344 <uvmfree>
}
    80001a68:	60e2                	ld	ra,24(sp)
    80001a6a:	6442                	ld	s0,16(sp)
    80001a6c:	64a2                	ld	s1,8(sp)
    80001a6e:	6902                	ld	s2,0(sp)
    80001a70:	6105                	addi	sp,sp,32
    80001a72:	8082                	ret

0000000080001a74 <freeproc>:
{
    80001a74:	1101                	addi	sp,sp,-32
    80001a76:	ec06                	sd	ra,24(sp)
    80001a78:	e822                	sd	s0,16(sp)
    80001a7a:	e426                	sd	s1,8(sp)
    80001a7c:	1000                	addi	s0,sp,32
    80001a7e:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001a80:	6d28                	ld	a0,88(a0)
    80001a82:	c119                	beqz	a0,80001a88 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001a84:	f63fe0ef          	jal	800009e6 <kfree>
  p->trapframe = 0;
    80001a88:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001a8c:	68a8                	ld	a0,80(s1)
    80001a8e:	c501                	beqz	a0,80001a96 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a90:	64ac                	ld	a1,72(s1)
    80001a92:	f9dff0ef          	jal	80001a2e <proc_freepagetable>
  p->pagetable = 0;
    80001a96:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a9a:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a9e:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001aa2:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001aa6:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001aaa:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001aae:	0204a623          	sw	zero,44(s1)
  p->nice = 0;
    80001ab2:	1604a423          	sw	zero,360(s1)
  p->wl_slot = -1;
    80001ab6:	57fd                	li	a5,-1
    80001ab8:	18f4a823          	sw	a5,400(s1)
  p->state = UNUSED;
    80001abc:	0004ac23          	sw	zero,24(s1)
}
    80001ac0:	60e2                	ld	ra,24(sp)
    80001ac2:	6442                	ld	s0,16(sp)
    80001ac4:	64a2                	ld	s1,8(sp)
    80001ac6:	6105                	addi	sp,sp,32
    80001ac8:	8082                	ret

0000000080001aca <allocproc>:
{
    80001aca:	1101                	addi	sp,sp,-32
    80001acc:	ec06                	sd	ra,24(sp)
    80001ace:	e822                	sd	s0,16(sp)
    80001ad0:	e426                	sd	s1,8(sp)
    80001ad2:	e04a                	sd	s2,0(sp)
    80001ad4:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ad6:	00014497          	auipc	s1,0x14
    80001ada:	0da48493          	addi	s1,s1,218 # 80015bb0 <proc>
    80001ade:	0001a917          	auipc	s2,0x1a
    80001ae2:	6d290913          	addi	s2,s2,1746 # 8001c1b0 <tickslock>
    acquire(&p->lock);
    80001ae6:	8526                	mv	a0,s1
    80001ae8:	8a6ff0ef          	jal	80000b8e <acquire>
    if (p->state == UNUSED) {
    80001aec:	4c9c                	lw	a5,24(s1)
    80001aee:	cb91                	beqz	a5,80001b02 <allocproc+0x38>
      release(&p->lock);
    80001af0:	8526                	mv	a0,s1
    80001af2:	928ff0ef          	jal	80000c1a <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001af6:	19848493          	addi	s1,s1,408
    80001afa:	ff2496e3          	bne	s1,s2,80001ae6 <allocproc+0x1c>
  return 0;
    80001afe:	4481                	li	s1,0
    80001b00:	a889                	j	80001b52 <allocproc+0x88>
  p->pid = allocpid();
    80001b02:	e6bff0ef          	jal	8000196c <allocpid>
    80001b06:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b08:	4785                	li	a5,1
    80001b0a:	cc9c                	sw	a5,24(s1)
  p->nice = 0;       // Project 1B: every new process starts at nice 0
    80001b0c:	1604a423          	sw	zero,360(s1)
  p->wl_slot = -1;   // Project 1C: not a workload worker
    80001b10:	57fd                	li	a5,-1
    80001b12:	18f4a823          	sw	a5,400(s1)
  policy_proc_init(p); // Project 1C: policy's per-process state
    80001b16:	8526                	mv	a0,s1
    80001b18:	6dc040ef          	jal	800061f4 <policy_proc_init>
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b1c:	fadfe0ef          	jal	80000ac8 <kalloc>
    80001b20:	892a                	mv	s2,a0
    80001b22:	eca8                	sd	a0,88(s1)
    80001b24:	cd15                	beqz	a0,80001b60 <allocproc+0x96>
  p->pagetable = proc_pagetable(p);
    80001b26:	8526                	mv	a0,s1
    80001b28:	e83ff0ef          	jal	800019aa <proc_pagetable>
    80001b2c:	892a                	mv	s2,a0
    80001b2e:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b30:	c121                	beqz	a0,80001b70 <allocproc+0xa6>
  memset(&p->context, 0, sizeof(p->context));
    80001b32:	07000613          	li	a2,112
    80001b36:	4581                	li	a1,0
    80001b38:	06048513          	addi	a0,s1,96
    80001b3c:	916ff0ef          	jal	80000c52 <memset>
  p->context.ra = (uint64)forkret;
    80001b40:	00000797          	auipc	a5,0x0
    80001b44:	d8878793          	addi	a5,a5,-632 # 800018c8 <forkret>
    80001b48:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b4a:	60bc                	ld	a5,64(s1)
    80001b4c:	6705                	lui	a4,0x1
    80001b4e:	97ba                	add	a5,a5,a4
    80001b50:	f4bc                	sd	a5,104(s1)
}
    80001b52:	8526                	mv	a0,s1
    80001b54:	60e2                	ld	ra,24(sp)
    80001b56:	6442                	ld	s0,16(sp)
    80001b58:	64a2                	ld	s1,8(sp)
    80001b5a:	6902                	ld	s2,0(sp)
    80001b5c:	6105                	addi	sp,sp,32
    80001b5e:	8082                	ret
    freeproc(p);
    80001b60:	8526                	mv	a0,s1
    80001b62:	f13ff0ef          	jal	80001a74 <freeproc>
    release(&p->lock);
    80001b66:	8526                	mv	a0,s1
    80001b68:	8b2ff0ef          	jal	80000c1a <release>
    return 0;
    80001b6c:	84ca                	mv	s1,s2
    80001b6e:	b7d5                	j	80001b52 <allocproc+0x88>
    freeproc(p);
    80001b70:	8526                	mv	a0,s1
    80001b72:	f03ff0ef          	jal	80001a74 <freeproc>
    release(&p->lock);
    80001b76:	8526                	mv	a0,s1
    80001b78:	8a2ff0ef          	jal	80000c1a <release>
    return 0;
    80001b7c:	84ca                	mv	s1,s2
    80001b7e:	bfd1                	j	80001b52 <allocproc+0x88>

0000000080001b80 <userinit>:
{
    80001b80:	1101                	addi	sp,sp,-32
    80001b82:	ec06                	sd	ra,24(sp)
    80001b84:	e822                	sd	s0,16(sp)
    80001b86:	e426                	sd	s1,8(sp)
    80001b88:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b8a:	f41ff0ef          	jal	80001aca <allocproc>
    80001b8e:	84aa                	mv	s1,a0
  initproc = p;
    80001b90:	0000c797          	auipc	a5,0xc
    80001b94:	a8a7b023          	sd	a0,-1408(a5) # 8000d610 <initproc>
  p->cwd = namei("/");
    80001b98:	00007517          	auipc	a0,0x7
    80001b9c:	5f850513          	addi	a0,a0,1528 # 80009190 <etext+0x190>
    80001ba0:	20e020ef          	jal	80003dae <namei>
    80001ba4:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001ba8:	478d                	li	a5,3
    80001baa:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bac:	8526                	mv	a0,s1
    80001bae:	86cff0ef          	jal	80000c1a <release>
}
    80001bb2:	60e2                	ld	ra,24(sp)
    80001bb4:	6442                	ld	s0,16(sp)
    80001bb6:	64a2                	ld	s1,8(sp)
    80001bb8:	6105                	addi	sp,sp,32
    80001bba:	8082                	ret

0000000080001bbc <growproc>:
{
    80001bbc:	1101                	addi	sp,sp,-32
    80001bbe:	ec06                	sd	ra,24(sp)
    80001bc0:	e822                	sd	s0,16(sp)
    80001bc2:	e426                	sd	s1,8(sp)
    80001bc4:	e04a                	sd	s2,0(sp)
    80001bc6:	1000                	addi	s0,sp,32
    80001bc8:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bca:	ccfff0ef          	jal	80001898 <myproc>
    80001bce:	892a                	mv	s2,a0
  sz = p->sz;
    80001bd0:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001bd2:	02905963          	blez	s1,80001c04 <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001bd6:	00b48633          	add	a2,s1,a1
    80001bda:	020007b7          	lui	a5,0x2000
    80001bde:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001be0:	07b6                	slli	a5,a5,0xd
    80001be2:	02c7ea63          	bltu	a5,a2,80001c16 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001be6:	4691                	li	a3,4
    80001be8:	6928                	ld	a0,80(a0)
    80001bea:	e54ff0ef          	jal	8000123e <uvmalloc>
    80001bee:	85aa                	mv	a1,a0
    80001bf0:	c50d                	beqz	a0,80001c1a <growproc+0x5e>
  p->sz = sz;
    80001bf2:	04b93423          	sd	a1,72(s2)
  return 0;
    80001bf6:	4501                	li	a0,0
}
    80001bf8:	60e2                	ld	ra,24(sp)
    80001bfa:	6442                	ld	s0,16(sp)
    80001bfc:	64a2                	ld	s1,8(sp)
    80001bfe:	6902                	ld	s2,0(sp)
    80001c00:	6105                	addi	sp,sp,32
    80001c02:	8082                	ret
  } else if (n < 0) {
    80001c04:	fe04d7e3          	bgez	s1,80001bf2 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c08:	00b48633          	add	a2,s1,a1
    80001c0c:	6928                	ld	a0,80(a0)
    80001c0e:	decff0ef          	jal	800011fa <uvmdealloc>
    80001c12:	85aa                	mv	a1,a0
    80001c14:	bff9                	j	80001bf2 <growproc+0x36>
      return -1;
    80001c16:	557d                	li	a0,-1
    80001c18:	b7c5                	j	80001bf8 <growproc+0x3c>
      return -1;
    80001c1a:	557d                	li	a0,-1
    80001c1c:	bff1                	j	80001bf8 <growproc+0x3c>

0000000080001c1e <kfork>:
{
    80001c1e:	7139                	addi	sp,sp,-64
    80001c20:	fc06                	sd	ra,56(sp)
    80001c22:	f822                	sd	s0,48(sp)
    80001c24:	f04a                	sd	s2,32(sp)
    80001c26:	e456                	sd	s5,8(sp)
    80001c28:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c2a:	c6fff0ef          	jal	80001898 <myproc>
    80001c2e:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c30:	e9bff0ef          	jal	80001aca <allocproc>
    80001c34:	0e050a63          	beqz	a0,80001d28 <kfork+0x10a>
    80001c38:	e852                	sd	s4,16(sp)
    80001c3a:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c3c:	048ab603          	ld	a2,72(s5)
    80001c40:	692c                	ld	a1,80(a0)
    80001c42:	050ab503          	ld	a0,80(s5)
    80001c46:	f30ff0ef          	jal	80001376 <uvmcopy>
    80001c4a:	04054a63          	bltz	a0,80001c9e <kfork+0x80>
    80001c4e:	f426                	sd	s1,40(sp)
    80001c50:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c52:	048ab783          	ld	a5,72(s5)
    80001c56:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c5a:	058ab683          	ld	a3,88(s5)
    80001c5e:	87b6                	mv	a5,a3
    80001c60:	058a3703          	ld	a4,88(s4)
    80001c64:	12068693          	addi	a3,a3,288
    80001c68:	0007b803          	ld	a6,0(a5)
    80001c6c:	6788                	ld	a0,8(a5)
    80001c6e:	6b8c                	ld	a1,16(a5)
    80001c70:	6f90                	ld	a2,24(a5)
    80001c72:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c76:	e708                	sd	a0,8(a4)
    80001c78:	eb0c                	sd	a1,16(a4)
    80001c7a:	ef10                	sd	a2,24(a4)
    80001c7c:	02078793          	addi	a5,a5,32
    80001c80:	02070713          	addi	a4,a4,32
    80001c84:	fed792e3          	bne	a5,a3,80001c68 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001c88:	058a3783          	ld	a5,88(s4)
    80001c8c:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001c90:	0d0a8493          	addi	s1,s5,208
    80001c94:	0d0a0913          	addi	s2,s4,208
    80001c98:	150a8993          	addi	s3,s5,336
    80001c9c:	a831                	j	80001cb8 <kfork+0x9a>
    freeproc(np);
    80001c9e:	8552                	mv	a0,s4
    80001ca0:	dd5ff0ef          	jal	80001a74 <freeproc>
    release(&np->lock);
    80001ca4:	8552                	mv	a0,s4
    80001ca6:	f75fe0ef          	jal	80000c1a <release>
    return -1;
    80001caa:	597d                	li	s2,-1
    80001cac:	6a42                	ld	s4,16(sp)
    80001cae:	a0b5                	j	80001d1a <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001cb0:	04a1                	addi	s1,s1,8
    80001cb2:	0921                	addi	s2,s2,8
    80001cb4:	01348963          	beq	s1,s3,80001cc6 <kfork+0xa8>
    if (p->ofile[i])
    80001cb8:	6088                	ld	a0,0(s1)
    80001cba:	d97d                	beqz	a0,80001cb0 <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cbc:	72c020ef          	jal	800043e8 <filedup>
    80001cc0:	00a93023          	sd	a0,0(s2)
    80001cc4:	b7f5                	j	80001cb0 <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001cc6:	150ab503          	ld	a0,336(s5)
    80001cca:	03b010ef          	jal	80003504 <idup>
    80001cce:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cd2:	4641                	li	a2,16
    80001cd4:	158a8593          	addi	a1,s5,344
    80001cd8:	158a0513          	addi	a0,s4,344
    80001cdc:	8b4ff0ef          	jal	80000d90 <safestrcpy>
  pid = np->pid;
    80001ce0:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001ce4:	8552                	mv	a0,s4
    80001ce6:	f35fe0ef          	jal	80000c1a <release>
  acquire(&wait_lock);
    80001cea:	00014497          	auipc	s1,0x14
    80001cee:	aae48493          	addi	s1,s1,-1362 # 80015798 <wait_lock>
    80001cf2:	8526                	mv	a0,s1
    80001cf4:	e9bfe0ef          	jal	80000b8e <acquire>
  np->parent = p;
    80001cf8:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001cfc:	8526                	mv	a0,s1
    80001cfe:	f1dfe0ef          	jal	80000c1a <release>
  acquire(&np->lock);
    80001d02:	8552                	mv	a0,s4
    80001d04:	e8bfe0ef          	jal	80000b8e <acquire>
  np->state = RUNNABLE;
    80001d08:	478d                	li	a5,3
    80001d0a:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d0e:	8552                	mv	a0,s4
    80001d10:	f0bfe0ef          	jal	80000c1a <release>
  return pid;
    80001d14:	74a2                	ld	s1,40(sp)
    80001d16:	69e2                	ld	s3,24(sp)
    80001d18:	6a42                	ld	s4,16(sp)
}
    80001d1a:	854a                	mv	a0,s2
    80001d1c:	70e2                	ld	ra,56(sp)
    80001d1e:	7442                	ld	s0,48(sp)
    80001d20:	7902                	ld	s2,32(sp)
    80001d22:	6aa2                	ld	s5,8(sp)
    80001d24:	6121                	addi	sp,sp,64
    80001d26:	8082                	ret
    return -1;
    80001d28:	597d                	li	s2,-1
    80001d2a:	bfc5                	j	80001d1a <kfork+0xfc>

0000000080001d2c <scheduler>:
{
    80001d2c:	711d                	addi	sp,sp,-96
    80001d2e:	ec86                	sd	ra,88(sp)
    80001d30:	e8a2                	sd	s0,80(sp)
    80001d32:	e4a6                	sd	s1,72(sp)
    80001d34:	e0ca                	sd	s2,64(sp)
    80001d36:	fc4e                	sd	s3,56(sp)
    80001d38:	f852                	sd	s4,48(sp)
    80001d3a:	f456                	sd	s5,40(sp)
    80001d3c:	f05a                	sd	s6,32(sp)
    80001d3e:	ec5e                	sd	s7,24(sp)
    80001d40:	e862                	sd	s8,16(sp)
    80001d42:	e466                	sd	s9,8(sp)
    80001d44:	1080                	addi	s0,sp,96
    80001d46:	8792                	mv	a5,tp
  int id = r_tp();
    80001d48:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d4a:	00779a13          	slli	s4,a5,0x7
    80001d4e:	00014717          	auipc	a4,0x14
    80001d52:	a3270713          	addi	a4,a4,-1486 # 80015780 <pid_lock>
    80001d56:	9752                	add	a4,a4,s4
    80001d58:	02073823          	sd	zero,48(a4)
      swtch(&c->context, &p->context);
    80001d5c:	00014717          	auipc	a4,0x14
    80001d60:	a5c70713          	addi	a4,a4,-1444 # 800157b8 <cpus+0x8>
    80001d64:	9a3a                	add	s4,s4,a4
    if (p->state == RUNNABLE) {
    80001d66:	490d                	li	s2,3
      p->state = RUNNING;
    80001d68:	4b91                	li	s7,4
      c->proc = p;
    80001d6a:	00014a97          	auipc	s5,0x14
    80001d6e:	a16a8a93          	addi	s5,s5,-1514 # 80015780 <pid_lock>
    80001d72:	079e                	slli	a5,a5,0x7
    80001d74:	00fa89b3          	add	s3,s5,a5
      if (logging && (!wl_loaded() || p->wl_slot >= 0))
    80001d78:	0000cb17          	auipc	s6,0xc
    80001d7c:	894b0b13          	addi	s6,s6,-1900 # 8000d60c <logging>
        printk("running %d at %d\n", p->pid, ticks);
    80001d80:	0000cc97          	auipc	s9,0xc
    80001d84:	898c8c93          	addi	s9,s9,-1896 # 8000d618 <ticks>
    80001d88:	00007c17          	auipc	s8,0x7
    80001d8c:	410c0c13          	addi	s8,s8,1040 # 80009198 <etext+0x198>
    80001d90:	a815                	j	80001dc4 <scheduler+0x98>
      asm volatile("wfi");
    80001d92:	10500073          	wfi
      continue;
    80001d96:	a03d                	j	80001dc4 <scheduler+0x98>
        printk("running %d at %d\n", p->pid, ticks);
    80001d98:	000ca603          	lw	a2,0(s9)
    80001d9c:	588c                	lw	a1,48(s1)
    80001d9e:	8562                	mv	a0,s8
    80001da0:	f68fe0ef          	jal	80000508 <printk>
      swtch(&c->context, &p->context);
    80001da4:	06048593          	addi	a1,s1,96
    80001da8:	8552                	mv	a0,s4
    80001daa:	03f000ef          	jal	800025e8 <swtch>
    80001dae:	8792                	mv	a5,tp
      mycpu()->intena = 0;
    80001db0:	2781                	sext.w	a5,a5
    80001db2:	079e                	slli	a5,a5,0x7
    80001db4:	97d6                	add	a5,a5,s5
    80001db6:	0a07a623          	sw	zero,172(a5)
      c->proc = 0;
    80001dba:	0209b823          	sd	zero,48(s3)
    release(&p->lock);
    80001dbe:	8526                	mv	a0,s1
    80001dc0:	e5bfe0ef          	jal	80000c1a <release>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001dc4:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001dc8:	10017073          	csrci	sstatus,2
    p = policy_pick_next_proc();
    80001dcc:	4a6040ef          	jal	80006272 <policy_pick_next_proc>
    80001dd0:	84aa                	mv	s1,a0
    if (p == 0) {
    80001dd2:	d161                	beqz	a0,80001d92 <scheduler+0x66>
    acquire(&p->lock);
    80001dd4:	dbbfe0ef          	jal	80000b8e <acquire>
    if (p->state == RUNNABLE) {
    80001dd8:	4c9c                	lw	a5,24(s1)
    80001dda:	ff2792e3          	bne	a5,s2,80001dbe <scheduler+0x92>
      p->state = RUNNING;
    80001dde:	0174ac23          	sw	s7,24(s1)
      c->proc = p;
    80001de2:	0299b823          	sd	s1,48(s3)
      policy_dispatch(p);
    80001de6:	8526                	mv	a0,s1
    80001de8:	7aa040ef          	jal	80006592 <policy_dispatch>
      wl_dispatch(p);
    80001dec:	8526                	mv	a0,s1
    80001dee:	689040ef          	jal	80006c76 <wl_dispatch>
      if (logging && (!wl_loaded() || p->wl_slot >= 0))
    80001df2:	000b2783          	lw	a5,0(s6)
    80001df6:	d7dd                	beqz	a5,80001da4 <scheduler+0x78>
    80001df8:	7db040ef          	jal	80006dd2 <wl_loaded>
    80001dfc:	dd51                	beqz	a0,80001d98 <scheduler+0x6c>
    80001dfe:	1904a783          	lw	a5,400(s1)
    80001e02:	f807dbe3          	bgez	a5,80001d98 <scheduler+0x6c>
    80001e06:	bf79                	j	80001da4 <scheduler+0x78>

0000000080001e08 <sched>:
{
    80001e08:	7179                	addi	sp,sp,-48
    80001e0a:	f406                	sd	ra,40(sp)
    80001e0c:	f022                	sd	s0,32(sp)
    80001e0e:	ec26                	sd	s1,24(sp)
    80001e10:	e84a                	sd	s2,16(sp)
    80001e12:	e44e                	sd	s3,8(sp)
    80001e14:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e16:	a83ff0ef          	jal	80001898 <myproc>
    80001e1a:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001e1c:	d13fe0ef          	jal	80000b2e <holding>
    80001e20:	c92d                	beqz	a0,80001e92 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e22:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001e24:	2781                	sext.w	a5,a5
    80001e26:	079e                	slli	a5,a5,0x7
    80001e28:	00014717          	auipc	a4,0x14
    80001e2c:	95870713          	addi	a4,a4,-1704 # 80015780 <pid_lock>
    80001e30:	97ba                	add	a5,a5,a4
    80001e32:	0a87a703          	lw	a4,168(a5)
    80001e36:	4785                	li	a5,1
    80001e38:	06f71363          	bne	a4,a5,80001e9e <sched+0x96>
  if (p->state == RUNNING)
    80001e3c:	4c98                	lw	a4,24(s1)
    80001e3e:	4791                	li	a5,4
    80001e40:	06f70563          	beq	a4,a5,80001eaa <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001e44:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e48:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e4a:	e7b5                	bnez	a5,80001eb6 <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e4c:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e4e:	00014917          	auipc	s2,0x14
    80001e52:	93290913          	addi	s2,s2,-1742 # 80015780 <pid_lock>
    80001e56:	2781                	sext.w	a5,a5
    80001e58:	079e                	slli	a5,a5,0x7
    80001e5a:	97ca                	add	a5,a5,s2
    80001e5c:	0ac7a983          	lw	s3,172(a5)
    80001e60:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e62:	2781                	sext.w	a5,a5
    80001e64:	079e                	slli	a5,a5,0x7
    80001e66:	00014597          	auipc	a1,0x14
    80001e6a:	95258593          	addi	a1,a1,-1710 # 800157b8 <cpus+0x8>
    80001e6e:	95be                	add	a1,a1,a5
    80001e70:	06048513          	addi	a0,s1,96
    80001e74:	774000ef          	jal	800025e8 <swtch>
    80001e78:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e7a:	2781                	sext.w	a5,a5
    80001e7c:	079e                	slli	a5,a5,0x7
    80001e7e:	993e                	add	s2,s2,a5
    80001e80:	0b392623          	sw	s3,172(s2)
}
    80001e84:	70a2                	ld	ra,40(sp)
    80001e86:	7402                	ld	s0,32(sp)
    80001e88:	64e2                	ld	s1,24(sp)
    80001e8a:	6942                	ld	s2,16(sp)
    80001e8c:	69a2                	ld	s3,8(sp)
    80001e8e:	6145                	addi	sp,sp,48
    80001e90:	8082                	ret
    panic("sched p->lock");
    80001e92:	00007517          	auipc	a0,0x7
    80001e96:	31e50513          	addi	a0,a0,798 # 800091b0 <etext+0x1b0>
    80001e9a:	955fe0ef          	jal	800007ee <panic>
    panic("sched locks");
    80001e9e:	00007517          	auipc	a0,0x7
    80001ea2:	32250513          	addi	a0,a0,802 # 800091c0 <etext+0x1c0>
    80001ea6:	949fe0ef          	jal	800007ee <panic>
    panic("sched RUNNING");
    80001eaa:	00007517          	auipc	a0,0x7
    80001eae:	32650513          	addi	a0,a0,806 # 800091d0 <etext+0x1d0>
    80001eb2:	93dfe0ef          	jal	800007ee <panic>
    panic("sched interruptible");
    80001eb6:	00007517          	auipc	a0,0x7
    80001eba:	32a50513          	addi	a0,a0,810 # 800091e0 <etext+0x1e0>
    80001ebe:	931fe0ef          	jal	800007ee <panic>

0000000080001ec2 <yield>:
{
    80001ec2:	1101                	addi	sp,sp,-32
    80001ec4:	ec06                	sd	ra,24(sp)
    80001ec6:	e822                	sd	s0,16(sp)
    80001ec8:	e426                	sd	s1,8(sp)
    80001eca:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ecc:	9cdff0ef          	jal	80001898 <myproc>
    80001ed0:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ed2:	cbdfe0ef          	jal	80000b8e <acquire>
  p->state = RUNNABLE;
    80001ed6:	478d                	li	a5,3
    80001ed8:	cc9c                	sw	a5,24(s1)
  sched();
    80001eda:	f2fff0ef          	jal	80001e08 <sched>
  release(&p->lock);
    80001ede:	8526                	mv	a0,s1
    80001ee0:	d3bfe0ef          	jal	80000c1a <release>
}
    80001ee4:	60e2                	ld	ra,24(sp)
    80001ee6:	6442                	ld	s0,16(sp)
    80001ee8:	64a2                	ld	s1,8(sp)
    80001eea:	6105                	addi	sp,sp,32
    80001eec:	8082                	ret

0000000080001eee <timer_tick>:
{
    80001eee:	7179                	addi	sp,sp,-48
    80001ef0:	f406                	sd	ra,40(sp)
    80001ef2:	f022                	sd	s0,32(sp)
    80001ef4:	ec26                	sd	s1,24(sp)
    80001ef6:	e84a                	sd	s2,16(sp)
    80001ef8:	e44e                	sd	s3,8(sp)
    80001efa:	1800                	addi	s0,sp,48
    80001efc:	84aa                	mv	s1,a0
    80001efe:	89ae                	mv	s3,a1
  int preempt = policy_tick(p);
    80001f00:	6ea040ef          	jal	800065ea <policy_tick>
    80001f04:	892a                	mv	s2,a0
  if (wl_burst_done(p)) {
    80001f06:	8526                	mv	a0,s1
    80001f08:	691040ef          	jal	80006d98 <wl_burst_done>
    80001f0c:	e911                	bnez	a0,80001f20 <timer_tick+0x32>
  if (preempt)
    80001f0e:	00091e63          	bnez	s2,80001f2a <timer_tick+0x3c>
}
    80001f12:	70a2                	ld	ra,40(sp)
    80001f14:	7402                	ld	s0,32(sp)
    80001f16:	64e2                	ld	s1,24(sp)
    80001f18:	6942                	ld	s2,16(sp)
    80001f1a:	69a2                	ld	s3,8(sp)
    80001f1c:	6145                	addi	sp,sp,48
    80001f1e:	8082                	ret
    if (user)
    80001f20:	fe0989e3          	beqz	s3,80001f12 <timer_tick+0x24>
      wl_checkpoint();
    80001f24:	2dc050ef          	jal	80007200 <wl_checkpoint>
    80001f28:	b7ed                	j	80001f12 <timer_tick+0x24>
    yield();
    80001f2a:	f99ff0ef          	jal	80001ec2 <yield>
    80001f2e:	b7d5                	j	80001f12 <timer_tick+0x24>

0000000080001f30 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001f30:	1101                	addi	sp,sp,-32
    80001f32:	ec06                	sd	ra,24(sp)
    80001f34:	e822                	sd	s0,16(sp)
    80001f36:	e426                	sd	s1,8(sp)
    80001f38:	e04a                	sd	s2,0(sp)
    80001f3a:	1000                	addi	s0,sp,32
    80001f3c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001f3e:	95bff0ef          	jal	80001898 <myproc>
    80001f42:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001f44:	c4bfe0ef          	jal	80000b8e <acquire>
  if (chan == 0)
    80001f48:	cc81                	beqz	s1,80001f60 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001f4a:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001f4e:	854a                	mv	a0,s2
    80001f50:	ccbfe0ef          	jal	80000c1a <release>
}
    80001f54:	60e2                	ld	ra,24(sp)
    80001f56:	6442                	ld	s0,16(sp)
    80001f58:	64a2                	ld	s1,8(sp)
    80001f5a:	6902                	ld	s2,0(sp)
    80001f5c:	6105                	addi	sp,sp,32
    80001f5e:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001f60:	00007517          	auipc	a0,0x7
    80001f64:	29850513          	addi	a0,a0,664 # 800091f8 <etext+0x1f8>
    80001f68:	887fe0ef          	jal	800007ee <panic>

0000000080001f6c <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001f6c:	1101                	addi	sp,sp,-32
    80001f6e:	ec06                	sd	ra,24(sp)
    80001f70:	e822                	sd	s0,16(sp)
    80001f72:	e426                	sd	s1,8(sp)
    80001f74:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f76:	923ff0ef          	jal	80001898 <myproc>
    80001f7a:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001f7c:	c13fe0ef          	jal	80000b8e <acquire>
  if (p->chan != 0) {
    80001f80:	709c                	ld	a5,32(s1)
    80001f82:	c789                	beqz	a5,80001f8c <sleep+0x20>
    p->state = SLEEPING;
    80001f84:	4789                	li	a5,2
    80001f86:	cc9c                	sw	a5,24(s1)
    sched();
    80001f88:	e81ff0ef          	jal	80001e08 <sched>
  }
  release(&p->lock);
    80001f8c:	8526                	mv	a0,s1
    80001f8e:	c8dfe0ef          	jal	80000c1a <release>
}
    80001f92:	60e2                	ld	ra,24(sp)
    80001f94:	6442                	ld	s0,16(sp)
    80001f96:	64a2                	ld	s1,8(sp)
    80001f98:	6105                	addi	sp,sp,32
    80001f9a:	8082                	ret

0000000080001f9c <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001f9c:	7139                	addi	sp,sp,-64
    80001f9e:	fc06                	sd	ra,56(sp)
    80001fa0:	f822                	sd	s0,48(sp)
    80001fa2:	f426                	sd	s1,40(sp)
    80001fa4:	f04a                	sd	s2,32(sp)
    80001fa6:	ec4e                	sd	s3,24(sp)
    80001fa8:	e852                	sd	s4,16(sp)
    80001faa:	e456                	sd	s5,8(sp)
    80001fac:	0080                	addi	s0,sp,64
    80001fae:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001fb0:	00014497          	auipc	s1,0x14
    80001fb4:	c0048493          	addi	s1,s1,-1024 # 80015bb0 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001fb8:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001fba:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001fbc:	0001a997          	auipc	s3,0x1a
    80001fc0:	1f498993          	addi	s3,s3,500 # 8001c1b0 <tickslock>
    80001fc4:	a801                	j	80001fd4 <wakeup+0x38>
        policy_wakeup(p); // Project 1C
      }
    }
    release(&p->lock);
    80001fc6:	8526                	mv	a0,s1
    80001fc8:	c53fe0ef          	jal	80000c1a <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001fcc:	19848493          	addi	s1,s1,408
    80001fd0:	03348363          	beq	s1,s3,80001ff6 <wakeup+0x5a>
    acquire(&p->lock);
    80001fd4:	8526                	mv	a0,s1
    80001fd6:	bb9fe0ef          	jal	80000b8e <acquire>
    if (p->chan == chan) {
    80001fda:	709c                	ld	a5,32(s1)
    80001fdc:	ff2795e3          	bne	a5,s2,80001fc6 <wakeup+0x2a>
      p->chan = 0;
    80001fe0:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    80001fe4:	4c9c                	lw	a5,24(s1)
    80001fe6:	ff4790e3          	bne	a5,s4,80001fc6 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001fea:	0154ac23          	sw	s5,24(s1)
        policy_wakeup(p); // Project 1C
    80001fee:	8526                	mv	a0,s1
    80001ff0:	7f6040ef          	jal	800067e6 <policy_wakeup>
    80001ff4:	bfc9                	j	80001fc6 <wakeup+0x2a>
  }
}
    80001ff6:	70e2                	ld	ra,56(sp)
    80001ff8:	7442                	ld	s0,48(sp)
    80001ffa:	74a2                	ld	s1,40(sp)
    80001ffc:	7902                	ld	s2,32(sp)
    80001ffe:	69e2                	ld	s3,24(sp)
    80002000:	6a42                	ld	s4,16(sp)
    80002002:	6aa2                	ld	s5,8(sp)
    80002004:	6121                	addi	sp,sp,64
    80002006:	8082                	ret

0000000080002008 <reparent>:
{
    80002008:	7179                	addi	sp,sp,-48
    8000200a:	f406                	sd	ra,40(sp)
    8000200c:	f022                	sd	s0,32(sp)
    8000200e:	ec26                	sd	s1,24(sp)
    80002010:	e84a                	sd	s2,16(sp)
    80002012:	e44e                	sd	s3,8(sp)
    80002014:	e052                	sd	s4,0(sp)
    80002016:	1800                	addi	s0,sp,48
    80002018:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000201a:	00014497          	auipc	s1,0x14
    8000201e:	b9648493          	addi	s1,s1,-1130 # 80015bb0 <proc>
      pp->parent = initproc;
    80002022:	0000ba17          	auipc	s4,0xb
    80002026:	5eea0a13          	addi	s4,s4,1518 # 8000d610 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000202a:	0001a997          	auipc	s3,0x1a
    8000202e:	18698993          	addi	s3,s3,390 # 8001c1b0 <tickslock>
    80002032:	a029                	j	8000203c <reparent+0x34>
    80002034:	19848493          	addi	s1,s1,408
    80002038:	01348b63          	beq	s1,s3,8000204e <reparent+0x46>
    if (pp->parent == p) {
    8000203c:	7c9c                	ld	a5,56(s1)
    8000203e:	ff279be3          	bne	a5,s2,80002034 <reparent+0x2c>
      pp->parent = initproc;
    80002042:	000a3503          	ld	a0,0(s4)
    80002046:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002048:	f55ff0ef          	jal	80001f9c <wakeup>
    8000204c:	b7e5                	j	80002034 <reparent+0x2c>
}
    8000204e:	70a2                	ld	ra,40(sp)
    80002050:	7402                	ld	s0,32(sp)
    80002052:	64e2                	ld	s1,24(sp)
    80002054:	6942                	ld	s2,16(sp)
    80002056:	69a2                	ld	s3,8(sp)
    80002058:	6a02                	ld	s4,0(sp)
    8000205a:	6145                	addi	sp,sp,48
    8000205c:	8082                	ret

000000008000205e <kexit>:
{
    8000205e:	7179                	addi	sp,sp,-48
    80002060:	f406                	sd	ra,40(sp)
    80002062:	f022                	sd	s0,32(sp)
    80002064:	e052                	sd	s4,0(sp)
    80002066:	1800                	addi	s0,sp,48
    80002068:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000206a:	82fff0ef          	jal	80001898 <myproc>
  if (p == initproc)
    8000206e:	0000b797          	auipc	a5,0xb
    80002072:	5a27b783          	ld	a5,1442(a5) # 8000d610 <initproc>
    80002076:	00a78d63          	beq	a5,a0,80002090 <kexit+0x32>
    8000207a:	ec26                	sd	s1,24(sp)
    8000207c:	e84a                	sd	s2,16(sp)
    8000207e:	e44e                	sd	s3,8(sp)
    80002080:	89aa                	mv	s3,a0
  wl_exit(p); // Project 1C: release any workload slot
    80002082:	528050ef          	jal	800075aa <wl_exit>
  for (int fd = 0; fd < NOFILE; fd++) {
    80002086:	0d098493          	addi	s1,s3,208
    8000208a:	15098913          	addi	s2,s3,336
    8000208e:	a00d                	j	800020b0 <kexit+0x52>
    80002090:	ec26                	sd	s1,24(sp)
    80002092:	e84a                	sd	s2,16(sp)
    80002094:	e44e                	sd	s3,8(sp)
    panic("init exiting");
    80002096:	00007517          	auipc	a0,0x7
    8000209a:	18250513          	addi	a0,a0,386 # 80009218 <etext+0x218>
    8000209e:	f50fe0ef          	jal	800007ee <panic>
      fileclose(f);
    800020a2:	38c020ef          	jal	8000442e <fileclose>
      p->ofile[fd] = 0;
    800020a6:	0004b023          	sd	zero,0(s1)
  for (int fd = 0; fd < NOFILE; fd++) {
    800020aa:	04a1                	addi	s1,s1,8
    800020ac:	01248563          	beq	s1,s2,800020b6 <kexit+0x58>
    if (p->ofile[fd]) {
    800020b0:	6088                	ld	a0,0(s1)
    800020b2:	f965                	bnez	a0,800020a2 <kexit+0x44>
    800020b4:	bfdd                	j	800020aa <kexit+0x4c>
  begin_op();
    800020b6:	6cd010ef          	jal	80003f82 <begin_op>
  iput(p->cwd);
    800020ba:	1509b503          	ld	a0,336(s3)
    800020be:	5fe010ef          	jal	800036bc <iput>
  end_op();
    800020c2:	747010ef          	jal	80004008 <end_op>
  p->cwd = 0;
    800020c6:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800020ca:	00013497          	auipc	s1,0x13
    800020ce:	6ce48493          	addi	s1,s1,1742 # 80015798 <wait_lock>
    800020d2:	8526                	mv	a0,s1
    800020d4:	abbfe0ef          	jal	80000b8e <acquire>
  reparent(p);
    800020d8:	854e                	mv	a0,s3
    800020da:	f2fff0ef          	jal	80002008 <reparent>
  wakeup(p->parent);
    800020de:	0389b503          	ld	a0,56(s3)
    800020e2:	ebbff0ef          	jal	80001f9c <wakeup>
  acquire(&p->lock);
    800020e6:	854e                	mv	a0,s3
    800020e8:	aa7fe0ef          	jal	80000b8e <acquire>
  p->xstate = status;
    800020ec:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020f0:	4795                	li	a5,5
    800020f2:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020f6:	8526                	mv	a0,s1
    800020f8:	b23fe0ef          	jal	80000c1a <release>
  sched();
    800020fc:	d0dff0ef          	jal	80001e08 <sched>
  panic("zombie exit");
    80002100:	00007517          	auipc	a0,0x7
    80002104:	12850513          	addi	a0,a0,296 # 80009228 <etext+0x228>
    80002108:	ee6fe0ef          	jal	800007ee <panic>

000000008000210c <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    8000210c:	7179                	addi	sp,sp,-48
    8000210e:	f406                	sd	ra,40(sp)
    80002110:	f022                	sd	s0,32(sp)
    80002112:	ec26                	sd	s1,24(sp)
    80002114:	e84a                	sd	s2,16(sp)
    80002116:	e44e                	sd	s3,8(sp)
    80002118:	1800                	addi	s0,sp,48
    8000211a:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000211c:	00014497          	auipc	s1,0x14
    80002120:	a9448493          	addi	s1,s1,-1388 # 80015bb0 <proc>
    80002124:	0001a997          	auipc	s3,0x1a
    80002128:	08c98993          	addi	s3,s3,140 # 8001c1b0 <tickslock>
    acquire(&p->lock);
    8000212c:	8526                	mv	a0,s1
    8000212e:	a61fe0ef          	jal	80000b8e <acquire>
    if (p->pid == pid) {
    80002132:	589c                	lw	a5,48(s1)
    80002134:	01278b63          	beq	a5,s2,8000214a <kkill+0x3e>
        policy_wakeup(p); // Project 1C
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002138:	8526                	mv	a0,s1
    8000213a:	ae1fe0ef          	jal	80000c1a <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000213e:	19848493          	addi	s1,s1,408
    80002142:	ff3495e3          	bne	s1,s3,8000212c <kkill+0x20>
  }
  return -1;
    80002146:	557d                	li	a0,-1
    80002148:	a819                	j	8000215e <kkill+0x52>
      p->killed = 1;
    8000214a:	4785                	li	a5,1
    8000214c:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    8000214e:	4c98                	lw	a4,24(s1)
    80002150:	4789                	li	a5,2
    80002152:	00f70d63          	beq	a4,a5,8000216c <kkill+0x60>
      release(&p->lock);
    80002156:	8526                	mv	a0,s1
    80002158:	ac3fe0ef          	jal	80000c1a <release>
      return 0;
    8000215c:	4501                	li	a0,0
}
    8000215e:	70a2                	ld	ra,40(sp)
    80002160:	7402                	ld	s0,32(sp)
    80002162:	64e2                	ld	s1,24(sp)
    80002164:	6942                	ld	s2,16(sp)
    80002166:	69a2                	ld	s3,8(sp)
    80002168:	6145                	addi	sp,sp,48
    8000216a:	8082                	ret
        p->state = RUNNABLE;
    8000216c:	478d                	li	a5,3
    8000216e:	cc9c                	sw	a5,24(s1)
        policy_wakeup(p); // Project 1C
    80002170:	8526                	mv	a0,s1
    80002172:	674040ef          	jal	800067e6 <policy_wakeup>
    80002176:	b7c5                	j	80002156 <kkill+0x4a>

0000000080002178 <setkilled>:

void
setkilled(struct proc *p)
{
    80002178:	1101                	addi	sp,sp,-32
    8000217a:	ec06                	sd	ra,24(sp)
    8000217c:	e822                	sd	s0,16(sp)
    8000217e:	e426                	sd	s1,8(sp)
    80002180:	1000                	addi	s0,sp,32
    80002182:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002184:	a0bfe0ef          	jal	80000b8e <acquire>
  p->killed = 1;
    80002188:	4785                	li	a5,1
    8000218a:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000218c:	8526                	mv	a0,s1
    8000218e:	a8dfe0ef          	jal	80000c1a <release>
}
    80002192:	60e2                	ld	ra,24(sp)
    80002194:	6442                	ld	s0,16(sp)
    80002196:	64a2                	ld	s1,8(sp)
    80002198:	6105                	addi	sp,sp,32
    8000219a:	8082                	ret

000000008000219c <killed>:

int
killed(struct proc *p)
{
    8000219c:	1101                	addi	sp,sp,-32
    8000219e:	ec06                	sd	ra,24(sp)
    800021a0:	e822                	sd	s0,16(sp)
    800021a2:	e426                	sd	s1,8(sp)
    800021a4:	e04a                	sd	s2,0(sp)
    800021a6:	1000                	addi	s0,sp,32
    800021a8:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    800021aa:	9e5fe0ef          	jal	80000b8e <acquire>
  k = p->killed;
    800021ae:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800021b2:	8526                	mv	a0,s1
    800021b4:	a67fe0ef          	jal	80000c1a <release>
  return k;
}
    800021b8:	854a                	mv	a0,s2
    800021ba:	60e2                	ld	ra,24(sp)
    800021bc:	6442                	ld	s0,16(sp)
    800021be:	64a2                	ld	s1,8(sp)
    800021c0:	6902                	ld	s2,0(sp)
    800021c2:	6105                	addi	sp,sp,32
    800021c4:	8082                	ret

00000000800021c6 <kwait>:
{
    800021c6:	715d                	addi	sp,sp,-80
    800021c8:	e486                	sd	ra,72(sp)
    800021ca:	e0a2                	sd	s0,64(sp)
    800021cc:	fc26                	sd	s1,56(sp)
    800021ce:	f84a                	sd	s2,48(sp)
    800021d0:	f44e                	sd	s3,40(sp)
    800021d2:	f052                	sd	s4,32(sp)
    800021d4:	ec56                	sd	s5,24(sp)
    800021d6:	e85a                	sd	s6,16(sp)
    800021d8:	e45e                	sd	s7,8(sp)
    800021da:	e062                	sd	s8,0(sp)
    800021dc:	0880                	addi	s0,sp,80
    800021de:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800021e0:	eb8ff0ef          	jal	80001898 <myproc>
    800021e4:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021e6:	00013517          	auipc	a0,0x13
    800021ea:	5b250513          	addi	a0,a0,1458 # 80015798 <wait_lock>
    800021ee:	9a1fe0ef          	jal	80000b8e <acquire>
    havekids = 0;
    800021f2:	4c01                	li	s8,0
        if (pp->state == ZOMBIE) {
    800021f4:	4a15                	li	s4,5
        havekids = 1;
    800021f6:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021f8:	0001a997          	auipc	s3,0x1a
    800021fc:	fb898993          	addi	s3,s3,-72 # 8001c1b0 <tickslock>
    release(&wait_lock);
    80002200:	00013b97          	auipc	s7,0x13
    80002204:	598b8b93          	addi	s7,s7,1432 # 80015798 <wait_lock>
    80002208:	a84d                	j	800022ba <kwait+0xf4>
          pid = pp->pid;
    8000220a:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    8000220e:	000b0e63          	beqz	s6,8000222a <kwait+0x64>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002212:	4711                	li	a4,4
    80002214:	02c48693          	addi	a3,s1,44
    80002218:	865a                	mv	a2,s6
    8000221a:	04893583          	ld	a1,72(s2)
    8000221e:	05093503          	ld	a0,80(s2)
    80002222:	ab8ff0ef          	jal	800014da <copyout>
          if (addr != 0 &&
    80002226:	02054d63          	bltz	a0,80002260 <kwait+0x9a>
          pp->parent = 0;
    8000222a:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    8000222e:	8526                	mv	a0,s1
    80002230:	845ff0ef          	jal	80001a74 <freeproc>
          release(&pp->lock);
    80002234:	8526                	mv	a0,s1
    80002236:	9e5fe0ef          	jal	80000c1a <release>
          release(&wait_lock);
    8000223a:	00013517          	auipc	a0,0x13
    8000223e:	55e50513          	addi	a0,a0,1374 # 80015798 <wait_lock>
    80002242:	9d9fe0ef          	jal	80000c1a <release>
}
    80002246:	854e                	mv	a0,s3
    80002248:	60a6                	ld	ra,72(sp)
    8000224a:	6406                	ld	s0,64(sp)
    8000224c:	74e2                	ld	s1,56(sp)
    8000224e:	7942                	ld	s2,48(sp)
    80002250:	79a2                	ld	s3,40(sp)
    80002252:	7a02                	ld	s4,32(sp)
    80002254:	6ae2                	ld	s5,24(sp)
    80002256:	6b42                	ld	s6,16(sp)
    80002258:	6ba2                	ld	s7,8(sp)
    8000225a:	6c02                	ld	s8,0(sp)
    8000225c:	6161                	addi	sp,sp,80
    8000225e:	8082                	ret
            release(&pp->lock);
    80002260:	8526                	mv	a0,s1
    80002262:	9b9fe0ef          	jal	80000c1a <release>
            release(&wait_lock);
    80002266:	00013517          	auipc	a0,0x13
    8000226a:	53250513          	addi	a0,a0,1330 # 80015798 <wait_lock>
    8000226e:	9adfe0ef          	jal	80000c1a <release>
            return -1;
    80002272:	59fd                	li	s3,-1
    80002274:	bfc9                	j	80002246 <kwait+0x80>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002276:	19848493          	addi	s1,s1,408
    8000227a:	03348063          	beq	s1,s3,8000229a <kwait+0xd4>
      if (pp->parent == p) {
    8000227e:	7c9c                	ld	a5,56(s1)
    80002280:	ff279be3          	bne	a5,s2,80002276 <kwait+0xb0>
        acquire(&pp->lock);
    80002284:	8526                	mv	a0,s1
    80002286:	909fe0ef          	jal	80000b8e <acquire>
        if (pp->state == ZOMBIE) {
    8000228a:	4c9c                	lw	a5,24(s1)
    8000228c:	f7478fe3          	beq	a5,s4,8000220a <kwait+0x44>
        release(&pp->lock);
    80002290:	8526                	mv	a0,s1
    80002292:	989fe0ef          	jal	80000c1a <release>
        havekids = 1;
    80002296:	8756                	mv	a4,s5
    80002298:	bff9                	j	80002276 <kwait+0xb0>
    if (!havekids || killed(p)) {
    8000229a:	c715                	beqz	a4,800022c6 <kwait+0x100>
    8000229c:	854a                	mv	a0,s2
    8000229e:	effff0ef          	jal	8000219c <killed>
    800022a2:	e115                	bnez	a0,800022c6 <kwait+0x100>
    sleep_prepare(p); //DOC: wait-sleep
    800022a4:	854a                	mv	a0,s2
    800022a6:	c8bff0ef          	jal	80001f30 <sleep_prepare>
    release(&wait_lock);
    800022aa:	855e                	mv	a0,s7
    800022ac:	96ffe0ef          	jal	80000c1a <release>
    sleep();
    800022b0:	cbdff0ef          	jal	80001f6c <sleep>
    acquire(&wait_lock);
    800022b4:	855e                	mv	a0,s7
    800022b6:	8d9fe0ef          	jal	80000b8e <acquire>
    havekids = 0;
    800022ba:	8762                	mv	a4,s8
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800022bc:	00014497          	auipc	s1,0x14
    800022c0:	8f448493          	addi	s1,s1,-1804 # 80015bb0 <proc>
    800022c4:	bf6d                	j	8000227e <kwait+0xb8>
      release(&wait_lock);
    800022c6:	00013517          	auipc	a0,0x13
    800022ca:	4d250513          	addi	a0,a0,1234 # 80015798 <wait_lock>
    800022ce:	94dfe0ef          	jal	80000c1a <release>
      return -1;
    800022d2:	59fd                	li	s3,-1
    800022d4:	bf8d                	j	80002246 <kwait+0x80>

00000000800022d6 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022d6:	7179                	addi	sp,sp,-48
    800022d8:	f406                	sd	ra,40(sp)
    800022da:	f022                	sd	s0,32(sp)
    800022dc:	ec26                	sd	s1,24(sp)
    800022de:	e84a                	sd	s2,16(sp)
    800022e0:	e44e                	sd	s3,8(sp)
    800022e2:	e052                	sd	s4,0(sp)
    800022e4:	1800                	addi	s0,sp,48
    800022e6:	84aa                	mv	s1,a0
    800022e8:	892e                	mv	s2,a1
    800022ea:	89b2                	mv	s3,a2
    800022ec:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800022ee:	daaff0ef          	jal	80001898 <myproc>
  if (user_dst) {
    800022f2:	c085                	beqz	s1,80002312 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    800022f4:	8752                	mv	a4,s4
    800022f6:	86ce                	mv	a3,s3
    800022f8:	864a                	mv	a2,s2
    800022fa:	652c                	ld	a1,72(a0)
    800022fc:	6928                	ld	a0,80(a0)
    800022fe:	9dcff0ef          	jal	800014da <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002302:	70a2                	ld	ra,40(sp)
    80002304:	7402                	ld	s0,32(sp)
    80002306:	64e2                	ld	s1,24(sp)
    80002308:	6942                	ld	s2,16(sp)
    8000230a:	69a2                	ld	s3,8(sp)
    8000230c:	6a02                	ld	s4,0(sp)
    8000230e:	6145                	addi	sp,sp,48
    80002310:	8082                	ret
    memmove((char *)dst, src, len);
    80002312:	000a061b          	sext.w	a2,s4
    80002316:	85ce                	mv	a1,s3
    80002318:	854a                	mv	a0,s2
    8000231a:	995fe0ef          	jal	80000cae <memmove>
    return 0;
    8000231e:	8526                	mv	a0,s1
    80002320:	b7cd                	j	80002302 <either_copyout+0x2c>

0000000080002322 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002322:	7179                	addi	sp,sp,-48
    80002324:	f406                	sd	ra,40(sp)
    80002326:	f022                	sd	s0,32(sp)
    80002328:	ec26                	sd	s1,24(sp)
    8000232a:	e84a                	sd	s2,16(sp)
    8000232c:	e44e                	sd	s3,8(sp)
    8000232e:	e052                	sd	s4,0(sp)
    80002330:	1800                	addi	s0,sp,48
    80002332:	892a                	mv	s2,a0
    80002334:	84ae                	mv	s1,a1
    80002336:	89b2                	mv	s3,a2
    80002338:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000233a:	d5eff0ef          	jal	80001898 <myproc>
  if (user_src) {
    8000233e:	c085                	beqz	s1,8000235e <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    80002340:	8752                	mv	a4,s4
    80002342:	86ce                	mv	a3,s3
    80002344:	864a                	mv	a2,s2
    80002346:	652c                	ld	a1,72(a0)
    80002348:	6928                	ld	a0,80(a0)
    8000234a:	a7cff0ef          	jal	800015c6 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    8000234e:	70a2                	ld	ra,40(sp)
    80002350:	7402                	ld	s0,32(sp)
    80002352:	64e2                	ld	s1,24(sp)
    80002354:	6942                	ld	s2,16(sp)
    80002356:	69a2                	ld	s3,8(sp)
    80002358:	6a02                	ld	s4,0(sp)
    8000235a:	6145                	addi	sp,sp,48
    8000235c:	8082                	ret
    memmove(dst, (char *)src, len);
    8000235e:	000a061b          	sext.w	a2,s4
    80002362:	85ce                	mv	a1,s3
    80002364:	854a                	mv	a0,s2
    80002366:	949fe0ef          	jal	80000cae <memmove>
    return 0;
    8000236a:	8526                	mv	a0,s1
    8000236c:	b7cd                	j	8000234e <either_copyin+0x2c>

000000008000236e <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000236e:	715d                	addi	sp,sp,-80
    80002370:	e486                	sd	ra,72(sp)
    80002372:	e0a2                	sd	s0,64(sp)
    80002374:	fc26                	sd	s1,56(sp)
    80002376:	f84a                	sd	s2,48(sp)
    80002378:	f44e                	sd	s3,40(sp)
    8000237a:	f052                	sd	s4,32(sp)
    8000237c:	ec56                	sd	s5,24(sp)
    8000237e:	e85a                	sd	s6,16(sp)
    80002380:	e45e                	sd	s7,8(sp)
    80002382:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002384:	00007517          	auipc	a0,0x7
    80002388:	cf450513          	addi	a0,a0,-780 # 80009078 <etext+0x78>
    8000238c:	97cfe0ef          	jal	80000508 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002390:	00014497          	auipc	s1,0x14
    80002394:	97848493          	addi	s1,s1,-1672 # 80015d08 <proc+0x158>
    80002398:	0001a917          	auipc	s2,0x1a
    8000239c:	f7090913          	addi	s2,s2,-144 # 8001c308 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023a0:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800023a2:	00007997          	auipc	s3,0x7
    800023a6:	e9698993          	addi	s3,s3,-362 # 80009238 <etext+0x238>
    printk("%d %s %s", p->pid, state, p->name);
    800023aa:	00007a97          	auipc	s5,0x7
    800023ae:	e96a8a93          	addi	s5,s5,-362 # 80009240 <etext+0x240>
    printk("\n");
    800023b2:	00007a17          	auipc	s4,0x7
    800023b6:	cc6a0a13          	addi	s4,s4,-826 # 80009078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023ba:	00007b97          	auipc	s7,0x7
    800023be:	5eeb8b93          	addi	s7,s7,1518 # 800099a8 <states.0>
    800023c2:	a829                	j	800023dc <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    800023c4:	ed86a583          	lw	a1,-296(a3)
    800023c8:	8556                	mv	a0,s5
    800023ca:	93efe0ef          	jal	80000508 <printk>
    printk("\n");
    800023ce:	8552                	mv	a0,s4
    800023d0:	938fe0ef          	jal	80000508 <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023d4:	19848493          	addi	s1,s1,408
    800023d8:	03248263          	beq	s1,s2,800023fc <procdump+0x8e>
    if (p->state == UNUSED)
    800023dc:	86a6                	mv	a3,s1
    800023de:	ec04a783          	lw	a5,-320(s1)
    800023e2:	dbed                	beqz	a5,800023d4 <procdump+0x66>
      state = "???";
    800023e4:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023e6:	fcfb6fe3          	bltu	s6,a5,800023c4 <procdump+0x56>
    800023ea:	02079713          	slli	a4,a5,0x20
    800023ee:	01d75793          	srli	a5,a4,0x1d
    800023f2:	97de                	add	a5,a5,s7
    800023f4:	6390                	ld	a2,0(a5)
    800023f6:	f679                	bnez	a2,800023c4 <procdump+0x56>
      state = "???";
    800023f8:	864e                	mv	a2,s3
    800023fa:	b7e9                	j	800023c4 <procdump+0x56>
  }
}
    800023fc:	60a6                	ld	ra,72(sp)
    800023fe:	6406                	ld	s0,64(sp)
    80002400:	74e2                	ld	s1,56(sp)
    80002402:	7942                	ld	s2,48(sp)
    80002404:	79a2                	ld	s3,40(sp)
    80002406:	7a02                	ld	s4,32(sp)
    80002408:	6ae2                	ld	s5,24(sp)
    8000240a:	6b42                	ld	s6,16(sp)
    8000240c:	6ba2                	ld	s7,8(sp)
    8000240e:	6161                	addi	sp,sp,80
    80002410:	8082                	ret

0000000080002412 <setnice>:

// Project 1B: set p's nice value, clamped to [-20, 19].
void
setnice(struct proc *p, int value)
{
    80002412:	7179                	addi	sp,sp,-48
    80002414:	f406                	sd	ra,40(sp)
    80002416:	f022                	sd	s0,32(sp)
    80002418:	ec26                	sd	s1,24(sp)
    8000241a:	e84a                	sd	s2,16(sp)
    8000241c:	e44e                	sd	s3,8(sp)
    8000241e:	1800                	addi	s0,sp,48
    80002420:	84aa                	mv	s1,a0
  if (value < -20)
    value = -20;
  if (value > 19)
    80002422:	892e                	mv	s2,a1
    80002424:	47cd                	li	a5,19
    80002426:	00b7d363          	bge	a5,a1,8000242c <setnice+0x1a>
    8000242a:	494d                	li	s2,19
    8000242c:	0009079b          	sext.w	a5,s2
    80002430:	5731                	li	a4,-20
    80002432:	00e7d363          	bge	a5,a4,80002438 <setnice+0x26>
    80002436:	5931                	li	s2,-20
    80002438:	0009099b          	sext.w	s3,s2
    value = 19;
  acquire(&p->lock);
    8000243c:	8526                	mv	a0,s1
    8000243e:	f50fe0ef          	jal	80000b8e <acquire>
  p->nice = value;
    80002442:	1724a423          	sw	s2,360(s1)
  policy_nice(p);
    80002446:	8526                	mv	a0,s1
    80002448:	3ce040ef          	jal	80006816 <policy_nice>
  release(&p->lock);
    8000244c:	8526                	mv	a0,s1
    8000244e:	fccfe0ef          	jal	80000c1a <release>
  if (logging)
    80002452:	0000b797          	auipc	a5,0xb
    80002456:	1ba7a783          	lw	a5,442(a5) # 8000d60c <logging>
    8000245a:	eb81                	bnez	a5,8000246a <setnice+0x58>
    printk("nice set to %d for %d\n", value, p->pid);
}
    8000245c:	70a2                	ld	ra,40(sp)
    8000245e:	7402                	ld	s0,32(sp)
    80002460:	64e2                	ld	s1,24(sp)
    80002462:	6942                	ld	s2,16(sp)
    80002464:	69a2                	ld	s3,8(sp)
    80002466:	6145                	addi	sp,sp,48
    80002468:	8082                	ret
    printk("nice set to %d for %d\n", value, p->pid);
    8000246a:	5890                	lw	a2,48(s1)
    8000246c:	85ce                	mv	a1,s3
    8000246e:	00007517          	auipc	a0,0x7
    80002472:	de250513          	addi	a0,a0,-542 # 80009250 <etext+0x250>
    80002476:	892fe0ef          	jal	80000508 <printk>
}
    8000247a:	b7cd                	j	8000245c <setnice+0x4a>

000000008000247c <sys_startLogging>:

// Project 1B: start printing log messages.
uint64
sys_startLogging(void)
{
    8000247c:	1141                	addi	sp,sp,-16
    8000247e:	e406                	sd	ra,8(sp)
    80002480:	e022                	sd	s0,0(sp)
    80002482:	0800                	addi	s0,sp,16
  printk("Logging Started\n");
    80002484:	00007517          	auipc	a0,0x7
    80002488:	de450513          	addi	a0,a0,-540 # 80009268 <etext+0x268>
    8000248c:	87cfe0ef          	jal	80000508 <printk>
  logging = 1;
    80002490:	4785                	li	a5,1
    80002492:	0000b717          	auipc	a4,0xb
    80002496:	16f72d23          	sw	a5,378(a4) # 8000d60c <logging>
  return 0;
}
    8000249a:	4501                	li	a0,0
    8000249c:	60a2                	ld	ra,8(sp)
    8000249e:	6402                	ld	s0,0(sp)
    800024a0:	0141                	addi	sp,sp,16
    800024a2:	8082                	ret

00000000800024a4 <sys_stopLogging>:

// Project 1B: stop printing log messages.
uint64
sys_stopLogging(void)
{
    800024a4:	1141                	addi	sp,sp,-16
    800024a6:	e406                	sd	ra,8(sp)
    800024a8:	e022                	sd	s0,0(sp)
    800024aa:	0800                	addi	s0,sp,16
  logging = 0;
    800024ac:	0000b797          	auipc	a5,0xb
    800024b0:	1607a023          	sw	zero,352(a5) # 8000d60c <logging>
  printk("Logging Stopped\n");
    800024b4:	00007517          	auipc	a0,0x7
    800024b8:	dcc50513          	addi	a0,a0,-564 # 80009280 <etext+0x280>
    800024bc:	84cfe0ef          	jal	80000508 <printk>
  return 0;
}
    800024c0:	4501                	li	a0,0
    800024c2:	60a2                	ld	ra,8(sp)
    800024c4:	6402                	ld	s0,0(sp)
    800024c6:	0141                	addi	sp,sp,16
    800024c8:	8082                	ret

00000000800024ca <sys_nice>:

// Project 1B: add inc to the nice value of process pid.
// Returns the new nice value, or 0 if pid is not a live process.
uint64
sys_nice(void)
{
    800024ca:	7179                	addi	sp,sp,-48
    800024cc:	f406                	sd	ra,40(sp)
    800024ce:	f022                	sd	s0,32(sp)
    800024d0:	ec26                	sd	s1,24(sp)
    800024d2:	e84a                	sd	s2,16(sp)
    800024d4:	1800                	addi	s0,sp,48
  int pid, inc;
  struct proc *p;

  argint(0, &pid);
    800024d6:	fdc40593          	addi	a1,s0,-36
    800024da:	4501                	li	a0,0
    800024dc:	582000ef          	jal	80002a5e <argint>
  argint(1, &inc);
    800024e0:	fd840593          	addi	a1,s0,-40
    800024e4:	4505                	li	a0,1
    800024e6:	578000ef          	jal	80002a5e <argint>
  for (p = proc; p < &proc[NPROC]; p++) {
    800024ea:	00013497          	auipc	s1,0x13
    800024ee:	6c648493          	addi	s1,s1,1734 # 80015bb0 <proc>
    800024f2:	0001a917          	auipc	s2,0x1a
    800024f6:	cbe90913          	addi	s2,s2,-834 # 8001c1b0 <tickslock>
    800024fa:	a801                	j	8000250a <sys_nice+0x40>
      int value = p->nice + inc;
      release(&p->lock);
      setnice(p, value);
      return p->nice;
    }
    release(&p->lock);
    800024fc:	8526                	mv	a0,s1
    800024fe:	f1cfe0ef          	jal	80000c1a <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002502:	19848493          	addi	s1,s1,408
    80002506:	05248163          	beq	s1,s2,80002548 <sys_nice+0x7e>
    acquire(&p->lock);
    8000250a:	8526                	mv	a0,s1
    8000250c:	e82fe0ef          	jal	80000b8e <acquire>
    if (p->pid == pid && p->state != UNUSED) {
    80002510:	5898                	lw	a4,48(s1)
    80002512:	fdc42783          	lw	a5,-36(s0)
    80002516:	fef713e3          	bne	a4,a5,800024fc <sys_nice+0x32>
    8000251a:	4c9c                	lw	a5,24(s1)
    8000251c:	d3e5                	beqz	a5,800024fc <sys_nice+0x32>
      int value = p->nice + inc;
    8000251e:	1684a783          	lw	a5,360(s1)
    80002522:	fd842903          	lw	s2,-40(s0)
    80002526:	00f9093b          	addw	s2,s2,a5
      release(&p->lock);
    8000252a:	8526                	mv	a0,s1
    8000252c:	eeefe0ef          	jal	80000c1a <release>
      setnice(p, value);
    80002530:	85ca                	mv	a1,s2
    80002532:	8526                	mv	a0,s1
    80002534:	edfff0ef          	jal	80002412 <setnice>
      return p->nice;
    80002538:	1684a503          	lw	a0,360(s1)
  }
  return 0;
}
    8000253c:	70a2                	ld	ra,40(sp)
    8000253e:	7402                	ld	s0,32(sp)
    80002540:	64e2                	ld	s1,24(sp)
    80002542:	6942                	ld	s2,16(sp)
    80002544:	6145                	addi	sp,sp,48
    80002546:	8082                	ret
  return 0;
    80002548:	4501                	li	a0,0
    8000254a:	bfcd                	j	8000253c <sys_nice+0x72>

000000008000254c <sched_reset>:
// process's policy state. Returns -1 if policy.c does not know id.
// Used by set_scheduler(), and by workload_start() so that a workload
// always starts from the same policy state.
int
sched_reset(int id)
{
    8000254c:	1101                	addi	sp,sp,-32
    8000254e:	ec06                	sd	ra,24(sp)
    80002550:	e822                	sd	s0,16(sp)
    80002552:	e426                	sd	s1,8(sp)
    80002554:	1000                	addi	s0,sp,32
    80002556:	84aa                	mv	s1,a0
  struct proc *p;

  push_off(); // no timer ticks while the policy changes
    80002558:	e00fe0ef          	jal	80000b58 <push_off>
  if (policy_init(id) < 0) {
    8000255c:	8526                	mv	a0,s1
    8000255e:	359030ef          	jal	800060b6 <policy_init>
    80002562:	02054063          	bltz	a0,80002582 <sched_reset+0x36>
    80002566:	e04a                	sd	s2,0(sp)
    pop_off();
    return -1;
  }
  sched_current = id;
    80002568:	0000b797          	auipc	a5,0xb
    8000256c:	0a97a023          	sw	s1,160(a5) # 8000d608 <sched_current>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002570:	00013497          	auipc	s1,0x13
    80002574:	64048493          	addi	s1,s1,1600 # 80015bb0 <proc>
    80002578:	0001a917          	auipc	s2,0x1a
    8000257c:	c3890913          	addi	s2,s2,-968 # 8001c1b0 <tickslock>
    80002580:	a821                	j	80002598 <sched_reset+0x4c>
    pop_off();
    80002582:	e4cfe0ef          	jal	80000bce <pop_off>
    return -1;
    80002586:	557d                	li	a0,-1
    80002588:	a02d                	j	800025b2 <sched_reset+0x66>
    acquire(&p->lock);
    if (p->state != UNUSED)
      policy_proc_init(p);
    release(&p->lock);
    8000258a:	8526                	mv	a0,s1
    8000258c:	e8efe0ef          	jal	80000c1a <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002590:	19848493          	addi	s1,s1,408
    80002594:	01248b63          	beq	s1,s2,800025aa <sched_reset+0x5e>
    acquire(&p->lock);
    80002598:	8526                	mv	a0,s1
    8000259a:	df4fe0ef          	jal	80000b8e <acquire>
    if (p->state != UNUSED)
    8000259e:	4c9c                	lw	a5,24(s1)
    800025a0:	d7ed                	beqz	a5,8000258a <sched_reset+0x3e>
      policy_proc_init(p);
    800025a2:	8526                	mv	a0,s1
    800025a4:	451030ef          	jal	800061f4 <policy_proc_init>
    800025a8:	b7cd                	j	8000258a <sched_reset+0x3e>
  }
  pop_off();
    800025aa:	e24fe0ef          	jal	80000bce <pop_off>
  return 0;
    800025ae:	4501                	li	a0,0
    800025b0:	6902                	ld	s2,0(sp)
}
    800025b2:	60e2                	ld	ra,24(sp)
    800025b4:	6442                	ld	s0,16(sp)
    800025b6:	64a2                	ld	s1,8(sp)
    800025b8:	6105                	addi	sp,sp,32
    800025ba:	8082                	ret

00000000800025bc <sys_set_scheduler>:

// Project 1C: switch to scheduling policy id. Refused (-1) while a
// workload is loaded, or if policy.c does not know id.
uint64
sys_set_scheduler(void)
{
    800025bc:	1101                	addi	sp,sp,-32
    800025be:	ec06                	sd	ra,24(sp)
    800025c0:	e822                	sd	s0,16(sp)
    800025c2:	1000                	addi	s0,sp,32
  int id;

  argint(0, &id);
    800025c4:	fec40593          	addi	a1,s0,-20
    800025c8:	4501                	li	a0,0
    800025ca:	494000ef          	jal	80002a5e <argint>
  if (wl_loaded())
    800025ce:	005040ef          	jal	80006dd2 <wl_loaded>
    800025d2:	87aa                	mv	a5,a0
    return -1;
    800025d4:	557d                	li	a0,-1
  if (wl_loaded())
    800025d6:	e789                	bnez	a5,800025e0 <sys_set_scheduler+0x24>
  return sched_reset(id);
    800025d8:	fec42503          	lw	a0,-20(s0)
    800025dc:	f71ff0ef          	jal	8000254c <sched_reset>
}
    800025e0:	60e2                	ld	ra,24(sp)
    800025e2:	6442                	ld	s0,16(sp)
    800025e4:	6105                	addi	sp,sp,32
    800025e6:	8082                	ret

00000000800025e8 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800025e8:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800025ec:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800025f0:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800025f2:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800025f4:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800025f8:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800025fc:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002600:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002604:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002608:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    8000260c:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002610:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002614:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002618:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000261c:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002620:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002624:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002626:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002628:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000262c:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002630:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002634:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002638:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000263c:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002640:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002644:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002648:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000264c:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002650:	8082                	ret

0000000080002652 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002652:	1141                	addi	sp,sp,-16
    80002654:	e406                	sd	ra,8(sp)
    80002656:	e022                	sd	s0,0(sp)
    80002658:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000265a:	00007597          	auipc	a1,0x7
    8000265e:	c6e58593          	addi	a1,a1,-914 # 800092c8 <etext+0x2c8>
    80002662:	0001a517          	auipc	a0,0x1a
    80002666:	b4e50513          	addi	a0,a0,-1202 # 8001c1b0 <tickslock>
    8000266a:	caefe0ef          	jal	80000b18 <initlock>
}
    8000266e:	60a2                	ld	ra,8(sp)
    80002670:	6402                	ld	s0,0(sp)
    80002672:	0141                	addi	sp,sp,16
    80002674:	8082                	ret

0000000080002676 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002676:	1141                	addi	sp,sp,-16
    80002678:	e422                	sd	s0,8(sp)
    8000267a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000267c:	00003797          	auipc	a5,0x3
    80002680:	1f478793          	addi	a5,a5,500 # 80005870 <kernelvec>
    80002684:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002688:	6422                	ld	s0,8(sp)
    8000268a:	0141                	addi	sp,sp,16
    8000268c:	8082                	ret

000000008000268e <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000268e:	1141                	addi	sp,sp,-16
    80002690:	e406                	sd	ra,8(sp)
    80002692:	e022                	sd	s0,0(sp)
    80002694:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002696:	a02ff0ef          	jal	80001898 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    8000269a:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000269e:	04000737          	lui	a4,0x4000
    800026a2:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800026a4:	0732                	slli	a4,a4,0xc
    800026a6:	00006797          	auipc	a5,0x6
    800026aa:	95a78793          	addi	a5,a5,-1702 # 80008000 <_trampoline>
    800026ae:	00006697          	auipc	a3,0x6
    800026b2:	95268693          	addi	a3,a3,-1710 # 80008000 <_trampoline>
    800026b6:	8f95                	sub	a5,a5,a3
    800026b8:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    800026ba:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800026be:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    800026c0:	18002773          	csrr	a4,satp
    800026c4:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800026c6:	6d38                	ld	a4,88(a0)
    800026c8:	613c                	ld	a5,64(a0)
    800026ca:	6685                	lui	a3,0x1
    800026cc:	97b6                	add	a5,a5,a3
    800026ce:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800026d0:	6d3c                	ld	a5,88(a0)
    800026d2:	00000717          	auipc	a4,0x0
    800026d6:	0fe70713          	addi	a4,a4,254 # 800027d0 <usertrap>
    800026da:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    800026dc:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    800026de:	8712                	mv	a4,tp
    800026e0:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800026e2:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800026e6:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800026ea:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800026ee:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800026f2:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    800026f4:	6f9c                	ld	a5,24(a5)
    800026f6:	14179073          	csrw	sepc,a5
}
    800026fa:	60a2                	ld	ra,8(sp)
    800026fc:	6402                	ld	s0,0(sp)
    800026fe:	0141                	addi	sp,sp,16
    80002700:	8082                	ret

0000000080002702 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002702:	1101                	addi	sp,sp,-32
    80002704:	ec06                	sd	ra,24(sp)
    80002706:	e822                	sd	s0,16(sp)
    80002708:	1000                	addi	s0,sp,32
  if (cpuid() == 0) {
    8000270a:	962ff0ef          	jal	8000186c <cpuid>
    8000270e:	cd09                	beqz	a0,80002728 <clockintr+0x26>
  asm volatile("csrr %0, time" : "=r"(x));
    80002710:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. TICK_INTERVAL is set in
  // param.h (10 ms for Project 1C).
  w_stimecmp(r_time() + TICK_INTERVAL);
    80002714:	6761                	lui	a4,0x18
    80002716:	6a070713          	addi	a4,a4,1696 # 186a0 <_entry-0x7ffe7960>
    8000271a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000271c:	14d79073          	csrw	stimecmp,a5
}
    80002720:	60e2                	ld	ra,24(sp)
    80002722:	6442                	ld	s0,16(sp)
    80002724:	6105                	addi	sp,sp,32
    80002726:	8082                	ret
    80002728:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    8000272a:	0001a497          	auipc	s1,0x1a
    8000272e:	a8648493          	addi	s1,s1,-1402 # 8001c1b0 <tickslock>
    80002732:	8526                	mv	a0,s1
    80002734:	c5afe0ef          	jal	80000b8e <acquire>
    ticks++;
    80002738:	0000b517          	auipc	a0,0xb
    8000273c:	ee050513          	addi	a0,a0,-288 # 8000d618 <ticks>
    80002740:	411c                	lw	a5,0(a0)
    80002742:	2785                	addiw	a5,a5,1
    80002744:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80002746:	857ff0ef          	jal	80001f9c <wakeup>
    wl_clock(myproc()); // Project 1C: workload accounting
    8000274a:	94eff0ef          	jal	80001898 <myproc>
    8000274e:	374040ef          	jal	80006ac2 <wl_clock>
    release(&tickslock);
    80002752:	8526                	mv	a0,s1
    80002754:	cc6fe0ef          	jal	80000c1a <release>
    80002758:	64a2                	ld	s1,8(sp)
    8000275a:	bf5d                	j	80002710 <clockintr+0xe>

000000008000275c <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000275c:	1101                	addi	sp,sp,-32
    8000275e:	ec06                	sd	ra,24(sp)
    80002760:	e822                	sd	s0,16(sp)
    80002762:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    80002764:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    80002768:	57fd                	li	a5,-1
    8000276a:	17fe                	slli	a5,a5,0x3f
    8000276c:	07a5                	addi	a5,a5,9
    8000276e:	00f70c63          	beq	a4,a5,80002786 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    80002772:	57fd                	li	a5,-1
    80002774:	17fe                	slli	a5,a5,0x3f
    80002776:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002778:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    8000277a:	04f70763          	beq	a4,a5,800027c8 <devintr+0x6c>
  }
}
    8000277e:	60e2                	ld	ra,24(sp)
    80002780:	6442                	ld	s0,16(sp)
    80002782:	6105                	addi	sp,sp,32
    80002784:	8082                	ret
    80002786:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002788:	194030ef          	jal	8000591c <plic_claim>
    8000278c:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    8000278e:	47a9                	li	a5,10
    80002790:	00f50963          	beq	a0,a5,800027a2 <devintr+0x46>
    } else if (irq == VIRTIO0_IRQ) {
    80002794:	4785                	li	a5,1
    80002796:	00f50963          	beq	a0,a5,800027a8 <devintr+0x4c>
    return 1;
    8000279a:	4505                	li	a0,1
    } else if (irq) {
    8000279c:	e889                	bnez	s1,800027ae <devintr+0x52>
    8000279e:	64a2                	ld	s1,8(sp)
    800027a0:	bff9                	j	8000277e <devintr+0x22>
      uartintr();
    800027a2:	9e8fe0ef          	jal	8000098a <uartintr>
    if (irq)
    800027a6:	a819                	j	800027bc <devintr+0x60>
      virtio_disk_intr();
    800027a8:	658030ef          	jal	80005e00 <virtio_disk_intr>
    if (irq)
    800027ac:	a801                	j	800027bc <devintr+0x60>
      printk("unexpected interrupt irq=%d\n", irq);
    800027ae:	85a6                	mv	a1,s1
    800027b0:	00007517          	auipc	a0,0x7
    800027b4:	b2050513          	addi	a0,a0,-1248 # 800092d0 <etext+0x2d0>
    800027b8:	d51fd0ef          	jal	80000508 <printk>
      plic_complete(irq);
    800027bc:	8526                	mv	a0,s1
    800027be:	17e030ef          	jal	8000593c <plic_complete>
    return 1;
    800027c2:	4505                	li	a0,1
    800027c4:	64a2                	ld	s1,8(sp)
    800027c6:	bf65                	j	8000277e <devintr+0x22>
    clockintr();
    800027c8:	f3bff0ef          	jal	80002702 <clockintr>
    return 2;
    800027cc:	4509                	li	a0,2
    800027ce:	bf45                	j	8000277e <devintr+0x22>

00000000800027d0 <usertrap>:
{
    800027d0:	1101                	addi	sp,sp,-32
    800027d2:	ec06                	sd	ra,24(sp)
    800027d4:	e822                	sd	s0,16(sp)
    800027d6:	e426                	sd	s1,8(sp)
    800027d8:	e04a                	sd	s2,0(sp)
    800027da:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800027dc:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    800027e0:	1007f793          	andi	a5,a5,256
    800027e4:	eba5                	bnez	a5,80002854 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    800027e6:	00003797          	auipc	a5,0x3
    800027ea:	08a78793          	addi	a5,a5,138 # 80005870 <kernelvec>
    800027ee:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800027f2:	8a6ff0ef          	jal	80001898 <myproc>
    800027f6:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800027f8:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    800027fa:	14102773          	csrr	a4,sepc
    800027fe:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    80002800:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002804:	47a1                	li	a5,8
    80002806:	04f70d63          	beq	a4,a5,80002860 <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    8000280a:	f53ff0ef          	jal	8000275c <devintr>
    8000280e:	892a                	mv	s2,a0
    80002810:	e54d                	bnez	a0,800028ba <usertrap+0xea>
    80002812:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002816:	47bd                	li	a5,15
    80002818:	08f70463          	beq	a4,a5,800028a0 <usertrap+0xd0>
    8000281c:	14202773          	csrr	a4,scause
    80002820:	47b5                	li	a5,13
    80002822:	06f70f63          	beq	a4,a5,800028a0 <usertrap+0xd0>
    80002826:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    8000282a:	5890                	lw	a2,48(s1)
    8000282c:	00007517          	auipc	a0,0x7
    80002830:	ae450513          	addi	a0,a0,-1308 # 80009310 <etext+0x310>
    80002834:	cd5fd0ef          	jal	80000508 <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002838:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000283c:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002840:	00007517          	auipc	a0,0x7
    80002844:	b0050513          	addi	a0,a0,-1280 # 80009340 <etext+0x340>
    80002848:	cc1fd0ef          	jal	80000508 <printk>
    setkilled(p);
    8000284c:	8526                	mv	a0,s1
    8000284e:	92bff0ef          	jal	80002178 <setkilled>
    80002852:	a015                	j	80002876 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    80002854:	00007517          	auipc	a0,0x7
    80002858:	a9c50513          	addi	a0,a0,-1380 # 800092f0 <etext+0x2f0>
    8000285c:	f93fd0ef          	jal	800007ee <panic>
    if (killed(p))
    80002860:	93dff0ef          	jal	8000219c <killed>
    80002864:	e915                	bnez	a0,80002898 <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002866:	6cb8                	ld	a4,88(s1)
    80002868:	6f1c                	ld	a5,24(a4)
    8000286a:	0791                	addi	a5,a5,4
    8000286c:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    8000286e:	10016073          	csrsi	sstatus,2
    syscall();
    80002872:	254000ef          	jal	80002ac6 <syscall>
  if (killed(p))
    80002876:	8526                	mv	a0,s1
    80002878:	925ff0ef          	jal	8000219c <killed>
    8000287c:	e521                	bnez	a0,800028c4 <usertrap+0xf4>
  prepare_return();
    8000287e:	e11ff0ef          	jal	8000268e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002882:	68a8                	ld	a0,80(s1)
    80002884:	8131                	srli	a0,a0,0xc
    80002886:	57fd                	li	a5,-1
    80002888:	17fe                	slli	a5,a5,0x3f
    8000288a:	8d5d                	or	a0,a0,a5
}
    8000288c:	60e2                	ld	ra,24(sp)
    8000288e:	6442                	ld	s0,16(sp)
    80002890:	64a2                	ld	s1,8(sp)
    80002892:	6902                	ld	s2,0(sp)
    80002894:	6105                	addi	sp,sp,32
    80002896:	8082                	ret
      kexit(-1);
    80002898:	557d                	li	a0,-1
    8000289a:	fc4ff0ef          	jal	8000205e <kexit>
    8000289e:	b7e1                	j	80002866 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    800028a0:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    800028a4:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    800028a8:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    800028aa:	0016b693          	seqz	a3,a3
    800028ae:	64ac                	ld	a1,72(s1)
    800028b0:	68a8                	ld	a0,80(s1)
    800028b2:	badfe0ef          	jal	8000145e <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800028b6:	f161                	bnez	a0,80002876 <usertrap+0xa6>
    800028b8:	b7bd                	j	80002826 <usertrap+0x56>
  if (killed(p))
    800028ba:	8526                	mv	a0,s1
    800028bc:	8e1ff0ef          	jal	8000219c <killed>
    800028c0:	c511                	beqz	a0,800028cc <usertrap+0xfc>
    800028c2:	a011                	j	800028c6 <usertrap+0xf6>
    800028c4:	4901                	li	s2,0
    kexit(-1);
    800028c6:	557d                	li	a0,-1
    800028c8:	f96ff0ef          	jal	8000205e <kexit>
  if (which_dev == 2)
    800028cc:	4789                	li	a5,2
    800028ce:	faf918e3          	bne	s2,a5,8000287e <usertrap+0xae>
    timer_tick(p, 1);
    800028d2:	4585                	li	a1,1
    800028d4:	8526                	mv	a0,s1
    800028d6:	e18ff0ef          	jal	80001eee <timer_tick>
    800028da:	b755                	j	8000287e <usertrap+0xae>

00000000800028dc <kerneltrap>:
{
    800028dc:	7179                	addi	sp,sp,-48
    800028de:	f406                	sd	ra,40(sp)
    800028e0:	f022                	sd	s0,32(sp)
    800028e2:	ec26                	sd	s1,24(sp)
    800028e4:	e84a                	sd	s2,16(sp)
    800028e6:	e44e                	sd	s3,8(sp)
    800028e8:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    800028ea:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800028ee:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    800028f2:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    800028f6:	1004f793          	andi	a5,s1,256
    800028fa:	c795                	beqz	a5,80002926 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800028fc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002900:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    80002902:	eb85                	bnez	a5,80002932 <kerneltrap+0x56>
  if ((which_dev = devintr()) == 0) {
    80002904:	e59ff0ef          	jal	8000275c <devintr>
    80002908:	c91d                	beqz	a0,8000293e <kerneltrap+0x62>
  if (which_dev == 2 && myproc() != 0)
    8000290a:	4789                	li	a5,2
    8000290c:	04f50a63          	beq	a0,a5,80002960 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002910:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002914:	10049073          	csrw	sstatus,s1
}
    80002918:	70a2                	ld	ra,40(sp)
    8000291a:	7402                	ld	s0,32(sp)
    8000291c:	64e2                	ld	s1,24(sp)
    8000291e:	6942                	ld	s2,16(sp)
    80002920:	69a2                	ld	s3,8(sp)
    80002922:	6145                	addi	sp,sp,48
    80002924:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002926:	00007517          	auipc	a0,0x7
    8000292a:	a4250513          	addi	a0,a0,-1470 # 80009368 <etext+0x368>
    8000292e:	ec1fd0ef          	jal	800007ee <panic>
    panic("kerneltrap: interrupts enabled");
    80002932:	00007517          	auipc	a0,0x7
    80002936:	a5e50513          	addi	a0,a0,-1442 # 80009390 <etext+0x390>
    8000293a:	eb5fd0ef          	jal	800007ee <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    8000293e:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002942:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    80002946:	85ce                	mv	a1,s3
    80002948:	00007517          	auipc	a0,0x7
    8000294c:	a6850513          	addi	a0,a0,-1432 # 800093b0 <etext+0x3b0>
    80002950:	bb9fd0ef          	jal	80000508 <printk>
    panic("kerneltrap");
    80002954:	00007517          	auipc	a0,0x7
    80002958:	a8450513          	addi	a0,a0,-1404 # 800093d8 <etext+0x3d8>
    8000295c:	e93fd0ef          	jal	800007ee <panic>
  if (which_dev == 2 && myproc() != 0)
    80002960:	f39fe0ef          	jal	80001898 <myproc>
    80002964:	d555                	beqz	a0,80002910 <kerneltrap+0x34>
    timer_tick(myproc(), 0);
    80002966:	f33fe0ef          	jal	80001898 <myproc>
    8000296a:	4581                	li	a1,0
    8000296c:	d82ff0ef          	jal	80001eee <timer_tick>
    80002970:	b745                	j	80002910 <kerneltrap+0x34>

0000000080002972 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002972:	1101                	addi	sp,sp,-32
    80002974:	ec06                	sd	ra,24(sp)
    80002976:	e822                	sd	s0,16(sp)
    80002978:	e426                	sd	s1,8(sp)
    8000297a:	1000                	addi	s0,sp,32
    8000297c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    8000297e:	f1bfe0ef          	jal	80001898 <myproc>
  switch (n) {
    80002982:	4795                	li	a5,5
    80002984:	0497e163          	bltu	a5,s1,800029c6 <argraw+0x54>
    80002988:	048a                	slli	s1,s1,0x2
    8000298a:	00007717          	auipc	a4,0x7
    8000298e:	04e70713          	addi	a4,a4,78 # 800099d8 <states.0+0x30>
    80002992:	94ba                	add	s1,s1,a4
    80002994:	409c                	lw	a5,0(s1)
    80002996:	97ba                	add	a5,a5,a4
    80002998:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000299a:	6d3c                	ld	a5,88(a0)
    8000299c:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    8000299e:	60e2                	ld	ra,24(sp)
    800029a0:	6442                	ld	s0,16(sp)
    800029a2:	64a2                	ld	s1,8(sp)
    800029a4:	6105                	addi	sp,sp,32
    800029a6:	8082                	ret
    return p->trapframe->a1;
    800029a8:	6d3c                	ld	a5,88(a0)
    800029aa:	7fa8                	ld	a0,120(a5)
    800029ac:	bfcd                	j	8000299e <argraw+0x2c>
    return p->trapframe->a2;
    800029ae:	6d3c                	ld	a5,88(a0)
    800029b0:	63c8                	ld	a0,128(a5)
    800029b2:	b7f5                	j	8000299e <argraw+0x2c>
    return p->trapframe->a3;
    800029b4:	6d3c                	ld	a5,88(a0)
    800029b6:	67c8                	ld	a0,136(a5)
    800029b8:	b7dd                	j	8000299e <argraw+0x2c>
    return p->trapframe->a4;
    800029ba:	6d3c                	ld	a5,88(a0)
    800029bc:	6bc8                	ld	a0,144(a5)
    800029be:	b7c5                	j	8000299e <argraw+0x2c>
    return p->trapframe->a5;
    800029c0:	6d3c                	ld	a5,88(a0)
    800029c2:	6fc8                	ld	a0,152(a5)
    800029c4:	bfe9                	j	8000299e <argraw+0x2c>
  panic("argraw");
    800029c6:	00007517          	auipc	a0,0x7
    800029ca:	a2250513          	addi	a0,a0,-1502 # 800093e8 <etext+0x3e8>
    800029ce:	e21fd0ef          	jal	800007ee <panic>

00000000800029d2 <fetchaddr>:
{
    800029d2:	1101                	addi	sp,sp,-32
    800029d4:	ec06                	sd	ra,24(sp)
    800029d6:	e822                	sd	s0,16(sp)
    800029d8:	e426                	sd	s1,8(sp)
    800029da:	e04a                	sd	s2,0(sp)
    800029dc:	1000                	addi	s0,sp,32
    800029de:	84aa                	mv	s1,a0
    800029e0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800029e2:	eb7fe0ef          	jal	80001898 <myproc>
  if (addr >= p->sz ||
    800029e6:	652c                	ld	a1,72(a0)
    800029e8:	02b4f663          	bgeu	s1,a1,80002a14 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800029ec:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    800029f0:	02f5e463          	bltu	a1,a5,80002a18 <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    800029f4:	4721                	li	a4,8
    800029f6:	86a6                	mv	a3,s1
    800029f8:	864a                	mv	a2,s2
    800029fa:	6928                	ld	a0,80(a0)
    800029fc:	bcbfe0ef          	jal	800015c6 <copyin>
    80002a00:	00a03533          	snez	a0,a0
    80002a04:	40a00533          	neg	a0,a0
}
    80002a08:	60e2                	ld	ra,24(sp)
    80002a0a:	6442                	ld	s0,16(sp)
    80002a0c:	64a2                	ld	s1,8(sp)
    80002a0e:	6902                	ld	s2,0(sp)
    80002a10:	6105                	addi	sp,sp,32
    80002a12:	8082                	ret
    return -1;
    80002a14:	557d                	li	a0,-1
    80002a16:	bfcd                	j	80002a08 <fetchaddr+0x36>
    80002a18:	557d                	li	a0,-1
    80002a1a:	b7fd                	j	80002a08 <fetchaddr+0x36>

0000000080002a1c <fetchstr>:
{
    80002a1c:	7179                	addi	sp,sp,-48
    80002a1e:	f406                	sd	ra,40(sp)
    80002a20:	f022                	sd	s0,32(sp)
    80002a22:	ec26                	sd	s1,24(sp)
    80002a24:	e84a                	sd	s2,16(sp)
    80002a26:	e44e                	sd	s3,8(sp)
    80002a28:	1800                	addi	s0,sp,48
    80002a2a:	892a                	mv	s2,a0
    80002a2c:	84ae                	mv	s1,a1
    80002a2e:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002a30:	e69fe0ef          	jal	80001898 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    80002a34:	874e                	mv	a4,s3
    80002a36:	86ca                	mv	a3,s2
    80002a38:	8626                	mv	a2,s1
    80002a3a:	652c                	ld	a1,72(a0)
    80002a3c:	6928                	ld	a0,80(a0)
    80002a3e:	c1ffe0ef          	jal	8000165c <copyinstr>
    80002a42:	00054c63          	bltz	a0,80002a5a <fetchstr+0x3e>
  return strlen(buf);
    80002a46:	8526                	mv	a0,s1
    80002a48:	b7afe0ef          	jal	80000dc2 <strlen>
}
    80002a4c:	70a2                	ld	ra,40(sp)
    80002a4e:	7402                	ld	s0,32(sp)
    80002a50:	64e2                	ld	s1,24(sp)
    80002a52:	6942                	ld	s2,16(sp)
    80002a54:	69a2                	ld	s3,8(sp)
    80002a56:	6145                	addi	sp,sp,48
    80002a58:	8082                	ret
    return -1;
    80002a5a:	557d                	li	a0,-1
    80002a5c:	bfc5                	j	80002a4c <fetchstr+0x30>

0000000080002a5e <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002a5e:	1101                	addi	sp,sp,-32
    80002a60:	ec06                	sd	ra,24(sp)
    80002a62:	e822                	sd	s0,16(sp)
    80002a64:	e426                	sd	s1,8(sp)
    80002a66:	1000                	addi	s0,sp,32
    80002a68:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a6a:	f09ff0ef          	jal	80002972 <argraw>
    80002a6e:	c088                	sw	a0,0(s1)
}
    80002a70:	60e2                	ld	ra,24(sp)
    80002a72:	6442                	ld	s0,16(sp)
    80002a74:	64a2                	ld	s1,8(sp)
    80002a76:	6105                	addi	sp,sp,32
    80002a78:	8082                	ret

0000000080002a7a <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002a7a:	1101                	addi	sp,sp,-32
    80002a7c:	ec06                	sd	ra,24(sp)
    80002a7e:	e822                	sd	s0,16(sp)
    80002a80:	e426                	sd	s1,8(sp)
    80002a82:	1000                	addi	s0,sp,32
    80002a84:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002a86:	eedff0ef          	jal	80002972 <argraw>
    80002a8a:	e088                	sd	a0,0(s1)
}
    80002a8c:	60e2                	ld	ra,24(sp)
    80002a8e:	6442                	ld	s0,16(sp)
    80002a90:	64a2                	ld	s1,8(sp)
    80002a92:	6105                	addi	sp,sp,32
    80002a94:	8082                	ret

0000000080002a96 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002a96:	7179                	addi	sp,sp,-48
    80002a98:	f406                	sd	ra,40(sp)
    80002a9a:	f022                	sd	s0,32(sp)
    80002a9c:	ec26                	sd	s1,24(sp)
    80002a9e:	e84a                	sd	s2,16(sp)
    80002aa0:	1800                	addi	s0,sp,48
    80002aa2:	84ae                	mv	s1,a1
    80002aa4:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002aa6:	fd840593          	addi	a1,s0,-40
    80002aaa:	fd1ff0ef          	jal	80002a7a <argaddr>
  return fetchstr(addr, buf, max);
    80002aae:	864a                	mv	a2,s2
    80002ab0:	85a6                	mv	a1,s1
    80002ab2:	fd843503          	ld	a0,-40(s0)
    80002ab6:	f67ff0ef          	jal	80002a1c <fetchstr>
}
    80002aba:	70a2                	ld	ra,40(sp)
    80002abc:	7402                	ld	s0,32(sp)
    80002abe:	64e2                	ld	s1,24(sp)
    80002ac0:	6942                	ld	s2,16(sp)
    80002ac2:	6145                	addi	sp,sp,48
    80002ac4:	8082                	ret

0000000080002ac6 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    80002ac6:	1101                	addi	sp,sp,-32
    80002ac8:	ec06                	sd	ra,24(sp)
    80002aca:	e822                	sd	s0,16(sp)
    80002acc:	e426                	sd	s1,8(sp)
    80002ace:	e04a                	sd	s2,0(sp)
    80002ad0:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002ad2:	dc7fe0ef          	jal	80001898 <myproc>
    80002ad6:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002ad8:	05853903          	ld	s2,88(a0)
    80002adc:	0a893783          	ld	a5,168(s2)
    80002ae0:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002ae4:	37fd                	addiw	a5,a5,-1
    80002ae6:	02000713          	li	a4,32
    80002aea:	00f76f63          	bltu	a4,a5,80002b08 <syscall+0x42>
    80002aee:	00369713          	slli	a4,a3,0x3
    80002af2:	00007797          	auipc	a5,0x7
    80002af6:	efe78793          	addi	a5,a5,-258 # 800099f0 <syscalls>
    80002afa:	97ba                	add	a5,a5,a4
    80002afc:	639c                	ld	a5,0(a5)
    80002afe:	c789                	beqz	a5,80002b08 <syscall+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002b00:	9782                	jalr	a5
    80002b02:	06a93823          	sd	a0,112(s2)
    80002b06:	a829                	j	80002b20 <syscall+0x5a>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    80002b08:	15848613          	addi	a2,s1,344
    80002b0c:	588c                	lw	a1,48(s1)
    80002b0e:	00007517          	auipc	a0,0x7
    80002b12:	8e250513          	addi	a0,a0,-1822 # 800093f0 <etext+0x3f0>
    80002b16:	9f3fd0ef          	jal	80000508 <printk>
    p->trapframe->a0 = -1;
    80002b1a:	6cbc                	ld	a5,88(s1)
    80002b1c:	577d                	li	a4,-1
    80002b1e:	fbb8                	sd	a4,112(a5)
  }
}
    80002b20:	60e2                	ld	ra,24(sp)
    80002b22:	6442                	ld	s0,16(sp)
    80002b24:	64a2                	ld	s1,8(sp)
    80002b26:	6902                	ld	s2,0(sp)
    80002b28:	6105                	addi	sp,sp,32
    80002b2a:	8082                	ret

0000000080002b2c <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002b2c:	1101                	addi	sp,sp,-32
    80002b2e:	ec06                	sd	ra,24(sp)
    80002b30:	e822                	sd	s0,16(sp)
    80002b32:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002b34:	fec40593          	addi	a1,s0,-20
    80002b38:	4501                	li	a0,0
    80002b3a:	f25ff0ef          	jal	80002a5e <argint>
  kexit(n);
    80002b3e:	fec42503          	lw	a0,-20(s0)
    80002b42:	d1cff0ef          	jal	8000205e <kexit>
  return 0; // not reached
}
    80002b46:	4501                	li	a0,0
    80002b48:	60e2                	ld	ra,24(sp)
    80002b4a:	6442                	ld	s0,16(sp)
    80002b4c:	6105                	addi	sp,sp,32
    80002b4e:	8082                	ret

0000000080002b50 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002b50:	1141                	addi	sp,sp,-16
    80002b52:	e406                	sd	ra,8(sp)
    80002b54:	e022                	sd	s0,0(sp)
    80002b56:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002b58:	d41fe0ef          	jal	80001898 <myproc>
}
    80002b5c:	5908                	lw	a0,48(a0)
    80002b5e:	60a2                	ld	ra,8(sp)
    80002b60:	6402                	ld	s0,0(sp)
    80002b62:	0141                	addi	sp,sp,16
    80002b64:	8082                	ret

0000000080002b66 <sys_fork>:

uint64
sys_fork(void)
{
    80002b66:	1141                	addi	sp,sp,-16
    80002b68:	e406                	sd	ra,8(sp)
    80002b6a:	e022                	sd	s0,0(sp)
    80002b6c:	0800                	addi	s0,sp,16
  return kfork();
    80002b6e:	8b0ff0ef          	jal	80001c1e <kfork>
}
    80002b72:	60a2                	ld	ra,8(sp)
    80002b74:	6402                	ld	s0,0(sp)
    80002b76:	0141                	addi	sp,sp,16
    80002b78:	8082                	ret

0000000080002b7a <sys_wait>:

uint64
sys_wait(void)
{
    80002b7a:	1101                	addi	sp,sp,-32
    80002b7c:	ec06                	sd	ra,24(sp)
    80002b7e:	e822                	sd	s0,16(sp)
    80002b80:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002b82:	fe840593          	addi	a1,s0,-24
    80002b86:	4501                	li	a0,0
    80002b88:	ef3ff0ef          	jal	80002a7a <argaddr>
  return kwait(p);
    80002b8c:	fe843503          	ld	a0,-24(s0)
    80002b90:	e36ff0ef          	jal	800021c6 <kwait>
}
    80002b94:	60e2                	ld	ra,24(sp)
    80002b96:	6442                	ld	s0,16(sp)
    80002b98:	6105                	addi	sp,sp,32
    80002b9a:	8082                	ret

0000000080002b9c <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002b9c:	7179                	addi	sp,sp,-48
    80002b9e:	f406                	sd	ra,40(sp)
    80002ba0:	f022                	sd	s0,32(sp)
    80002ba2:	ec26                	sd	s1,24(sp)
    80002ba4:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002ba6:	fd840593          	addi	a1,s0,-40
    80002baa:	4501                	li	a0,0
    80002bac:	eb3ff0ef          	jal	80002a5e <argint>
  argint(1, &t);
    80002bb0:	fdc40593          	addi	a1,s0,-36
    80002bb4:	4505                	li	a0,1
    80002bb6:	ea9ff0ef          	jal	80002a5e <argint>
  addr = myproc()->sz;
    80002bba:	cdffe0ef          	jal	80001898 <myproc>
    80002bbe:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002bc0:	fdc42703          	lw	a4,-36(s0)
    80002bc4:	4785                	li	a5,1
    80002bc6:	02f70763          	beq	a4,a5,80002bf4 <sys_sbrk+0x58>
    80002bca:	fd842783          	lw	a5,-40(s0)
    80002bce:	0207c363          	bltz	a5,80002bf4 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002bd2:	97a6                	add	a5,a5,s1
    80002bd4:	0297ee63          	bltu	a5,s1,80002c10 <sys_sbrk+0x74>
      return -1;
    if (addr + n > TRAPFRAME)
    80002bd8:	02000737          	lui	a4,0x2000
    80002bdc:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002bde:	0736                	slli	a4,a4,0xd
    80002be0:	02f76a63          	bltu	a4,a5,80002c14 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002be4:	cb5fe0ef          	jal	80001898 <myproc>
    80002be8:	fd842703          	lw	a4,-40(s0)
    80002bec:	653c                	ld	a5,72(a0)
    80002bee:	97ba                	add	a5,a5,a4
    80002bf0:	e53c                	sd	a5,72(a0)
    80002bf2:	a039                	j	80002c00 <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80002bf4:	fd842503          	lw	a0,-40(s0)
    80002bf8:	fc5fe0ef          	jal	80001bbc <growproc>
    80002bfc:	00054863          	bltz	a0,80002c0c <sys_sbrk+0x70>
  }
  return addr;
}
    80002c00:	8526                	mv	a0,s1
    80002c02:	70a2                	ld	ra,40(sp)
    80002c04:	7402                	ld	s0,32(sp)
    80002c06:	64e2                	ld	s1,24(sp)
    80002c08:	6145                	addi	sp,sp,48
    80002c0a:	8082                	ret
      return -1;
    80002c0c:	54fd                	li	s1,-1
    80002c0e:	bfcd                	j	80002c00 <sys_sbrk+0x64>
      return -1;
    80002c10:	54fd                	li	s1,-1
    80002c12:	b7fd                	j	80002c00 <sys_sbrk+0x64>
      return -1;
    80002c14:	54fd                	li	s1,-1
    80002c16:	b7ed                	j	80002c00 <sys_sbrk+0x64>

0000000080002c18 <sys_pause>:

uint64
sys_pause(void)
{
    80002c18:	7139                	addi	sp,sp,-64
    80002c1a:	fc06                	sd	ra,56(sp)
    80002c1c:	f822                	sd	s0,48(sp)
    80002c1e:	ec4e                	sd	s3,24(sp)
    80002c20:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002c22:	fcc40593          	addi	a1,s0,-52
    80002c26:	4501                	li	a0,0
    80002c28:	e37ff0ef          	jal	80002a5e <argint>
  if (n < 0)
    80002c2c:	fcc42783          	lw	a5,-52(s0)
    80002c30:	0607cf63          	bltz	a5,80002cae <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002c34:	00019517          	auipc	a0,0x19
    80002c38:	57c50513          	addi	a0,a0,1404 # 8001c1b0 <tickslock>
    80002c3c:	f53fd0ef          	jal	80000b8e <acquire>
  ticks0 = ticks;
    80002c40:	0000b997          	auipc	s3,0xb
    80002c44:	9d89a983          	lw	s3,-1576(s3) # 8000d618 <ticks>
  while (ticks - ticks0 < n) {
    80002c48:	fcc42783          	lw	a5,-52(s0)
    80002c4c:	c7a9                	beqz	a5,80002c96 <sys_pause+0x7e>
    80002c4e:	f426                	sd	s1,40(sp)
    80002c50:	f04a                	sd	s2,32(sp)
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002c52:	0000b917          	auipc	s2,0xb
    80002c56:	9c690913          	addi	s2,s2,-1594 # 8000d618 <ticks>
    release(&tickslock);
    80002c5a:	00019497          	auipc	s1,0x19
    80002c5e:	55648493          	addi	s1,s1,1366 # 8001c1b0 <tickslock>
    if (killed(myproc())) {
    80002c62:	c37fe0ef          	jal	80001898 <myproc>
    80002c66:	d36ff0ef          	jal	8000219c <killed>
    80002c6a:	e529                	bnez	a0,80002cb4 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002c6c:	854a                	mv	a0,s2
    80002c6e:	ac2ff0ef          	jal	80001f30 <sleep_prepare>
    release(&tickslock);
    80002c72:	8526                	mv	a0,s1
    80002c74:	fa7fd0ef          	jal	80000c1a <release>
    sleep();
    80002c78:	af4ff0ef          	jal	80001f6c <sleep>
    acquire(&tickslock);
    80002c7c:	8526                	mv	a0,s1
    80002c7e:	f11fd0ef          	jal	80000b8e <acquire>
  while (ticks - ticks0 < n) {
    80002c82:	00092783          	lw	a5,0(s2)
    80002c86:	413787bb          	subw	a5,a5,s3
    80002c8a:	fcc42703          	lw	a4,-52(s0)
    80002c8e:	fce7eae3          	bltu	a5,a4,80002c62 <sys_pause+0x4a>
    80002c92:	74a2                	ld	s1,40(sp)
    80002c94:	7902                	ld	s2,32(sp)
  }
  release(&tickslock);
    80002c96:	00019517          	auipc	a0,0x19
    80002c9a:	51a50513          	addi	a0,a0,1306 # 8001c1b0 <tickslock>
    80002c9e:	f7dfd0ef          	jal	80000c1a <release>
  return 0;
    80002ca2:	4501                	li	a0,0
}
    80002ca4:	70e2                	ld	ra,56(sp)
    80002ca6:	7442                	ld	s0,48(sp)
    80002ca8:	69e2                	ld	s3,24(sp)
    80002caa:	6121                	addi	sp,sp,64
    80002cac:	8082                	ret
    n = 0;
    80002cae:	fc042623          	sw	zero,-52(s0)
    80002cb2:	b749                	j	80002c34 <sys_pause+0x1c>
      release(&tickslock);
    80002cb4:	00019517          	auipc	a0,0x19
    80002cb8:	4fc50513          	addi	a0,a0,1276 # 8001c1b0 <tickslock>
    80002cbc:	f5ffd0ef          	jal	80000c1a <release>
      return -1;
    80002cc0:	557d                	li	a0,-1
    80002cc2:	74a2                	ld	s1,40(sp)
    80002cc4:	7902                	ld	s2,32(sp)
    80002cc6:	bff9                	j	80002ca4 <sys_pause+0x8c>

0000000080002cc8 <sys_kill>:

uint64
sys_kill(void)
{
    80002cc8:	1101                	addi	sp,sp,-32
    80002cca:	ec06                	sd	ra,24(sp)
    80002ccc:	e822                	sd	s0,16(sp)
    80002cce:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002cd0:	fec40593          	addi	a1,s0,-20
    80002cd4:	4501                	li	a0,0
    80002cd6:	d89ff0ef          	jal	80002a5e <argint>
  return kkill(pid);
    80002cda:	fec42503          	lw	a0,-20(s0)
    80002cde:	c2eff0ef          	jal	8000210c <kkill>
}
    80002ce2:	60e2                	ld	ra,24(sp)
    80002ce4:	6442                	ld	s0,16(sp)
    80002ce6:	6105                	addi	sp,sp,32
    80002ce8:	8082                	ret

0000000080002cea <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002cea:	1101                	addi	sp,sp,-32
    80002cec:	ec06                	sd	ra,24(sp)
    80002cee:	e822                	sd	s0,16(sp)
    80002cf0:	e426                	sd	s1,8(sp)
    80002cf2:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002cf4:	00019517          	auipc	a0,0x19
    80002cf8:	4bc50513          	addi	a0,a0,1212 # 8001c1b0 <tickslock>
    80002cfc:	e93fd0ef          	jal	80000b8e <acquire>
  xticks = ticks;
    80002d00:	0000b497          	auipc	s1,0xb
    80002d04:	9184a483          	lw	s1,-1768(s1) # 8000d618 <ticks>
  release(&tickslock);
    80002d08:	00019517          	auipc	a0,0x19
    80002d0c:	4a850513          	addi	a0,a0,1192 # 8001c1b0 <tickslock>
    80002d10:	f0bfd0ef          	jal	80000c1a <release>
  return xticks;
}
    80002d14:	02049513          	slli	a0,s1,0x20
    80002d18:	9101                	srli	a0,a0,0x20
    80002d1a:	60e2                	ld	ra,24(sp)
    80002d1c:	6442                	ld	s0,16(sp)
    80002d1e:	64a2                	ld	s1,8(sp)
    80002d20:	6105                	addi	sp,sp,32
    80002d22:	8082                	ret

0000000080002d24 <sys_workload_load>:

// Project 1C: workload harness system calls (see workload.c).

uint64
sys_workload_load(void)
{
    80002d24:	1101                	addi	sp,sp,-32
    80002d26:	ec06                	sd	ra,24(sp)
    80002d28:	e822                	sd	s0,16(sp)
    80002d2a:	1000                	addi	s0,sp,32
  int id;
  argint(0, &id);
    80002d2c:	fec40593          	addi	a1,s0,-20
    80002d30:	4501                	li	a0,0
    80002d32:	d2dff0ef          	jal	80002a5e <argint>
  return wl_load(id);
    80002d36:	fec42503          	lw	a0,-20(s0)
    80002d3a:	0ac040ef          	jal	80006de6 <wl_load>
}
    80002d3e:	60e2                	ld	ra,24(sp)
    80002d40:	6442                	ld	s0,16(sp)
    80002d42:	6105                	addi	sp,sp,32
    80002d44:	8082                	ret

0000000080002d46 <sys_workload_process_count>:

uint64
sys_workload_process_count(void)
{
    80002d46:	1141                	addi	sp,sp,-16
    80002d48:	e406                	sd	ra,8(sp)
    80002d4a:	e022                	sd	s0,0(sp)
    80002d4c:	0800                	addi	s0,sp,16
  return wl_count();
    80002d4e:	246040ef          	jal	80006f94 <wl_count>
}
    80002d52:	60a2                	ld	ra,8(sp)
    80002d54:	6402                	ld	s0,0(sp)
    80002d56:	0141                	addi	sp,sp,16
    80002d58:	8082                	ret

0000000080002d5a <sys_workload_attach>:

uint64
sys_workload_attach(void)
{
    80002d5a:	1101                	addi	sp,sp,-32
    80002d5c:	ec06                	sd	ra,24(sp)
    80002d5e:	e822                	sd	s0,16(sp)
    80002d60:	1000                	addi	s0,sp,32
  int index;
  argint(0, &index);
    80002d62:	fec40593          	addi	a1,s0,-20
    80002d66:	4501                	li	a0,0
    80002d68:	cf7ff0ef          	jal	80002a5e <argint>
  return wl_attach(index);
    80002d6c:	fec42503          	lw	a0,-20(s0)
    80002d70:	27c040ef          	jal	80006fec <wl_attach>
}
    80002d74:	60e2                	ld	ra,24(sp)
    80002d76:	6442                	ld	s0,16(sp)
    80002d78:	6105                	addi	sp,sp,32
    80002d7a:	8082                	ret

0000000080002d7c <sys_workload_start>:

uint64
sys_workload_start(void)
{
    80002d7c:	1141                	addi	sp,sp,-16
    80002d7e:	e406                	sd	ra,8(sp)
    80002d80:	e022                	sd	s0,0(sp)
    80002d82:	0800                	addi	s0,sp,16
  return wl_start();
    80002d84:	33c040ef          	jal	800070c0 <wl_start>
}
    80002d88:	60a2                	ld	ra,8(sp)
    80002d8a:	6402                	ld	s0,0(sp)
    80002d8c:	0141                	addi	sp,sp,16
    80002d8e:	8082                	ret

0000000080002d90 <sys_workload_checkpoint>:

uint64
sys_workload_checkpoint(void)
{
    80002d90:	1141                	addi	sp,sp,-16
    80002d92:	e406                	sd	ra,8(sp)
    80002d94:	e022                	sd	s0,0(sp)
    80002d96:	0800                	addi	s0,sp,16
  return wl_checkpoint();
    80002d98:	468040ef          	jal	80007200 <wl_checkpoint>
}
    80002d9c:	60a2                	ld	ra,8(sp)
    80002d9e:	6402                	ld	s0,0(sp)
    80002da0:	0141                	addi	sp,sp,16
    80002da2:	8082                	ret

0000000080002da4 <sys_workload_stop>:

uint64
sys_workload_stop(void)
{
    80002da4:	1141                	addi	sp,sp,-16
    80002da6:	e406                	sd	ra,8(sp)
    80002da8:	e022                	sd	s0,0(sp)
    80002daa:	0800                	addi	s0,sp,16
  return wl_stop();
    80002dac:	640040ef          	jal	800073ec <wl_stop>
}
    80002db0:	60a2                	ld	ra,8(sp)
    80002db2:	6402                	ld	s0,0(sp)
    80002db4:	0141                	addi	sp,sp,16
    80002db6:	8082                	ret

0000000080002db8 <sys_workload_stats>:

uint64
sys_workload_stats(void)
{
    80002db8:	1101                	addi	sp,sp,-32
    80002dba:	ec06                	sd	ra,24(sp)
    80002dbc:	e822                	sd	s0,16(sp)
    80002dbe:	1000                	addi	s0,sp,32
  int index;
  uint64 addr;
  argint(0, &index);
    80002dc0:	fec40593          	addi	a1,s0,-20
    80002dc4:	4501                	li	a0,0
    80002dc6:	c99ff0ef          	jal	80002a5e <argint>
  argaddr(1, &addr);
    80002dca:	fe040593          	addi	a1,s0,-32
    80002dce:	4505                	li	a0,1
    80002dd0:	cabff0ef          	jal	80002a7a <argaddr>
  return wl_stats(index, addr);
    80002dd4:	fe043583          	ld	a1,-32(s0)
    80002dd8:	fec42503          	lw	a0,-20(s0)
    80002ddc:	668040ef          	jal	80007444 <wl_stats>
}
    80002de0:	60e2                	ld	ra,24(sp)
    80002de2:	6442                	ld	s0,16(sp)
    80002de4:	6105                	addi	sp,sp,32
    80002de6:	8082                	ret

0000000080002de8 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002de8:	7179                	addi	sp,sp,-48
    80002dea:	f406                	sd	ra,40(sp)
    80002dec:	f022                	sd	s0,32(sp)
    80002dee:	ec26                	sd	s1,24(sp)
    80002df0:	e84a                	sd	s2,16(sp)
    80002df2:	e44e                	sd	s3,8(sp)
    80002df4:	e052                	sd	s4,0(sp)
    80002df6:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002df8:	00006597          	auipc	a1,0x6
    80002dfc:	61858593          	addi	a1,a1,1560 # 80009410 <etext+0x410>
    80002e00:	00019517          	auipc	a0,0x19
    80002e04:	3c850513          	addi	a0,a0,968 # 8001c1c8 <bcache>
    80002e08:	d11fd0ef          	jal	80000b18 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002e0c:	00021797          	auipc	a5,0x21
    80002e10:	3bc78793          	addi	a5,a5,956 # 800241c8 <bcache+0x8000>
    80002e14:	00021717          	auipc	a4,0x21
    80002e18:	61c70713          	addi	a4,a4,1564 # 80024430 <bcache+0x8268>
    80002e1c:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002e20:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002e24:	00019497          	auipc	s1,0x19
    80002e28:	3bc48493          	addi	s1,s1,956 # 8001c1e0 <bcache+0x18>
    b->next = bcache.head.next;
    80002e2c:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002e2e:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002e30:	00006a17          	auipc	s4,0x6
    80002e34:	5e8a0a13          	addi	s4,s4,1512 # 80009418 <etext+0x418>
    b->next = bcache.head.next;
    80002e38:	2b893783          	ld	a5,696(s2)
    80002e3c:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002e3e:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002e42:	85d2                	mv	a1,s4
    80002e44:	01048513          	addi	a0,s1,16
    80002e48:	412010ef          	jal	8000425a <initsleeplock>
    bcache.head.next->prev = b;
    80002e4c:	2b893783          	ld	a5,696(s2)
    80002e50:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002e52:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002e56:	45848493          	addi	s1,s1,1112
    80002e5a:	fd349fe3          	bne	s1,s3,80002e38 <binit+0x50>
  }
}
    80002e5e:	70a2                	ld	ra,40(sp)
    80002e60:	7402                	ld	s0,32(sp)
    80002e62:	64e2                	ld	s1,24(sp)
    80002e64:	6942                	ld	s2,16(sp)
    80002e66:	69a2                	ld	s3,8(sp)
    80002e68:	6a02                	ld	s4,0(sp)
    80002e6a:	6145                	addi	sp,sp,48
    80002e6c:	8082                	ret

0000000080002e6e <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002e6e:	7179                	addi	sp,sp,-48
    80002e70:	f406                	sd	ra,40(sp)
    80002e72:	f022                	sd	s0,32(sp)
    80002e74:	ec26                	sd	s1,24(sp)
    80002e76:	e84a                	sd	s2,16(sp)
    80002e78:	e44e                	sd	s3,8(sp)
    80002e7a:	1800                	addi	s0,sp,48
    80002e7c:	892a                	mv	s2,a0
    80002e7e:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002e80:	00019517          	auipc	a0,0x19
    80002e84:	34850513          	addi	a0,a0,840 # 8001c1c8 <bcache>
    80002e88:	d07fd0ef          	jal	80000b8e <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002e8c:	00021497          	auipc	s1,0x21
    80002e90:	5f44b483          	ld	s1,1524(s1) # 80024480 <bcache+0x82b8>
    80002e94:	00021797          	auipc	a5,0x21
    80002e98:	59c78793          	addi	a5,a5,1436 # 80024430 <bcache+0x8268>
    80002e9c:	02f48b63          	beq	s1,a5,80002ed2 <bread+0x64>
    80002ea0:	873e                	mv	a4,a5
    80002ea2:	a021                	j	80002eaa <bread+0x3c>
    80002ea4:	68a4                	ld	s1,80(s1)
    80002ea6:	02e48663          	beq	s1,a4,80002ed2 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002eaa:	449c                	lw	a5,8(s1)
    80002eac:	ff279ce3          	bne	a5,s2,80002ea4 <bread+0x36>
    80002eb0:	44dc                	lw	a5,12(s1)
    80002eb2:	ff3799e3          	bne	a5,s3,80002ea4 <bread+0x36>
      b->refcnt++;
    80002eb6:	40bc                	lw	a5,64(s1)
    80002eb8:	2785                	addiw	a5,a5,1
    80002eba:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002ebc:	00019517          	auipc	a0,0x19
    80002ec0:	30c50513          	addi	a0,a0,780 # 8001c1c8 <bcache>
    80002ec4:	d57fd0ef          	jal	80000c1a <release>
      acquiresleep(&b->lock);
    80002ec8:	01048513          	addi	a0,s1,16
    80002ecc:	3c4010ef          	jal	80004290 <acquiresleep>
      return b;
    80002ed0:	a889                	j	80002f22 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002ed2:	00021497          	auipc	s1,0x21
    80002ed6:	5a64b483          	ld	s1,1446(s1) # 80024478 <bcache+0x82b0>
    80002eda:	00021797          	auipc	a5,0x21
    80002ede:	55678793          	addi	a5,a5,1366 # 80024430 <bcache+0x8268>
    80002ee2:	00f48863          	beq	s1,a5,80002ef2 <bread+0x84>
    80002ee6:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002ee8:	40bc                	lw	a5,64(s1)
    80002eea:	cb91                	beqz	a5,80002efe <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002eec:	64a4                	ld	s1,72(s1)
    80002eee:	fee49de3          	bne	s1,a4,80002ee8 <bread+0x7a>
  panic("bget: no buffers");
    80002ef2:	00006517          	auipc	a0,0x6
    80002ef6:	52e50513          	addi	a0,a0,1326 # 80009420 <etext+0x420>
    80002efa:	8f5fd0ef          	jal	800007ee <panic>
      b->dev = dev;
    80002efe:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002f02:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002f06:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002f0a:	4785                	li	a5,1
    80002f0c:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002f0e:	00019517          	auipc	a0,0x19
    80002f12:	2ba50513          	addi	a0,a0,698 # 8001c1c8 <bcache>
    80002f16:	d05fd0ef          	jal	80000c1a <release>
      acquiresleep(&b->lock);
    80002f1a:	01048513          	addi	a0,s1,16
    80002f1e:	372010ef          	jal	80004290 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002f22:	409c                	lw	a5,0(s1)
    80002f24:	cb89                	beqz	a5,80002f36 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002f26:	8526                	mv	a0,s1
    80002f28:	70a2                	ld	ra,40(sp)
    80002f2a:	7402                	ld	s0,32(sp)
    80002f2c:	64e2                	ld	s1,24(sp)
    80002f2e:	6942                	ld	s2,16(sp)
    80002f30:	69a2                	ld	s3,8(sp)
    80002f32:	6145                	addi	sp,sp,48
    80002f34:	8082                	ret
    virtio_disk_rw(b, 0);
    80002f36:	4581                	li	a1,0
    80002f38:	8526                	mv	a0,s1
    80002f3a:	497020ef          	jal	80005bd0 <virtio_disk_rw>
    b->valid = 1;
    80002f3e:	4785                	li	a5,1
    80002f40:	c09c                	sw	a5,0(s1)
  return b;
    80002f42:	b7d5                	j	80002f26 <bread+0xb8>

0000000080002f44 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002f44:	1101                	addi	sp,sp,-32
    80002f46:	ec06                	sd	ra,24(sp)
    80002f48:	e822                	sd	s0,16(sp)
    80002f4a:	e426                	sd	s1,8(sp)
    80002f4c:	1000                	addi	s0,sp,32
    80002f4e:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002f50:	0541                	addi	a0,a0,16
    80002f52:	3ca010ef          	jal	8000431c <holdingsleep>
    80002f56:	c911                	beqz	a0,80002f6a <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002f58:	4585                	li	a1,1
    80002f5a:	8526                	mv	a0,s1
    80002f5c:	475020ef          	jal	80005bd0 <virtio_disk_rw>
}
    80002f60:	60e2                	ld	ra,24(sp)
    80002f62:	6442                	ld	s0,16(sp)
    80002f64:	64a2                	ld	s1,8(sp)
    80002f66:	6105                	addi	sp,sp,32
    80002f68:	8082                	ret
    panic("bwrite");
    80002f6a:	00006517          	auipc	a0,0x6
    80002f6e:	4ce50513          	addi	a0,a0,1230 # 80009438 <etext+0x438>
    80002f72:	87dfd0ef          	jal	800007ee <panic>

0000000080002f76 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002f76:	1101                	addi	sp,sp,-32
    80002f78:	ec06                	sd	ra,24(sp)
    80002f7a:	e822                	sd	s0,16(sp)
    80002f7c:	e426                	sd	s1,8(sp)
    80002f7e:	e04a                	sd	s2,0(sp)
    80002f80:	1000                	addi	s0,sp,32
    80002f82:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002f84:	01050913          	addi	s2,a0,16
    80002f88:	854a                	mv	a0,s2
    80002f8a:	392010ef          	jal	8000431c <holdingsleep>
    80002f8e:	c135                	beqz	a0,80002ff2 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002f90:	854a                	mv	a0,s2
    80002f92:	352010ef          	jal	800042e4 <releasesleep>

  acquire(&bcache.lock);
    80002f96:	00019517          	auipc	a0,0x19
    80002f9a:	23250513          	addi	a0,a0,562 # 8001c1c8 <bcache>
    80002f9e:	bf1fd0ef          	jal	80000b8e <acquire>
  b->refcnt--;
    80002fa2:	40bc                	lw	a5,64(s1)
    80002fa4:	37fd                	addiw	a5,a5,-1
    80002fa6:	0007871b          	sext.w	a4,a5
    80002faa:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002fac:	e71d                	bnez	a4,80002fda <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002fae:	68b8                	ld	a4,80(s1)
    80002fb0:	64bc                	ld	a5,72(s1)
    80002fb2:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002fb4:	68b8                	ld	a4,80(s1)
    80002fb6:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002fb8:	00021797          	auipc	a5,0x21
    80002fbc:	21078793          	addi	a5,a5,528 # 800241c8 <bcache+0x8000>
    80002fc0:	2b87b703          	ld	a4,696(a5)
    80002fc4:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002fc6:	00021717          	auipc	a4,0x21
    80002fca:	46a70713          	addi	a4,a4,1130 # 80024430 <bcache+0x8268>
    80002fce:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002fd0:	2b87b703          	ld	a4,696(a5)
    80002fd4:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002fd6:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002fda:	00019517          	auipc	a0,0x19
    80002fde:	1ee50513          	addi	a0,a0,494 # 8001c1c8 <bcache>
    80002fe2:	c39fd0ef          	jal	80000c1a <release>
}
    80002fe6:	60e2                	ld	ra,24(sp)
    80002fe8:	6442                	ld	s0,16(sp)
    80002fea:	64a2                	ld	s1,8(sp)
    80002fec:	6902                	ld	s2,0(sp)
    80002fee:	6105                	addi	sp,sp,32
    80002ff0:	8082                	ret
    panic("brelse");
    80002ff2:	00006517          	auipc	a0,0x6
    80002ff6:	44e50513          	addi	a0,a0,1102 # 80009440 <etext+0x440>
    80002ffa:	ff4fd0ef          	jal	800007ee <panic>

0000000080002ffe <bpin>:

void
bpin(struct buf *b)
{
    80002ffe:	1101                	addi	sp,sp,-32
    80003000:	ec06                	sd	ra,24(sp)
    80003002:	e822                	sd	s0,16(sp)
    80003004:	e426                	sd	s1,8(sp)
    80003006:	1000                	addi	s0,sp,32
    80003008:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000300a:	00019517          	auipc	a0,0x19
    8000300e:	1be50513          	addi	a0,a0,446 # 8001c1c8 <bcache>
    80003012:	b7dfd0ef          	jal	80000b8e <acquire>
  b->refcnt++;
    80003016:	40bc                	lw	a5,64(s1)
    80003018:	2785                	addiw	a5,a5,1
    8000301a:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000301c:	00019517          	auipc	a0,0x19
    80003020:	1ac50513          	addi	a0,a0,428 # 8001c1c8 <bcache>
    80003024:	bf7fd0ef          	jal	80000c1a <release>
}
    80003028:	60e2                	ld	ra,24(sp)
    8000302a:	6442                	ld	s0,16(sp)
    8000302c:	64a2                	ld	s1,8(sp)
    8000302e:	6105                	addi	sp,sp,32
    80003030:	8082                	ret

0000000080003032 <bunpin>:

void
bunpin(struct buf *b)
{
    80003032:	1101                	addi	sp,sp,-32
    80003034:	ec06                	sd	ra,24(sp)
    80003036:	e822                	sd	s0,16(sp)
    80003038:	e426                	sd	s1,8(sp)
    8000303a:	1000                	addi	s0,sp,32
    8000303c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000303e:	00019517          	auipc	a0,0x19
    80003042:	18a50513          	addi	a0,a0,394 # 8001c1c8 <bcache>
    80003046:	b49fd0ef          	jal	80000b8e <acquire>
  b->refcnt--;
    8000304a:	40bc                	lw	a5,64(s1)
    8000304c:	37fd                	addiw	a5,a5,-1
    8000304e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003050:	00019517          	auipc	a0,0x19
    80003054:	17850513          	addi	a0,a0,376 # 8001c1c8 <bcache>
    80003058:	bc3fd0ef          	jal	80000c1a <release>
}
    8000305c:	60e2                	ld	ra,24(sp)
    8000305e:	6442                	ld	s0,16(sp)
    80003060:	64a2                	ld	s1,8(sp)
    80003062:	6105                	addi	sp,sp,32
    80003064:	8082                	ret

0000000080003066 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003066:	1101                	addi	sp,sp,-32
    80003068:	ec06                	sd	ra,24(sp)
    8000306a:	e822                	sd	s0,16(sp)
    8000306c:	e426                	sd	s1,8(sp)
    8000306e:	e04a                	sd	s2,0(sp)
    80003070:	1000                	addi	s0,sp,32
    80003072:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003074:	00d5d59b          	srliw	a1,a1,0xd
    80003078:	00022797          	auipc	a5,0x22
    8000307c:	82c7a783          	lw	a5,-2004(a5) # 800248a4 <sb+0x1c>
    80003080:	9dbd                	addw	a1,a1,a5
    80003082:	dedff0ef          	jal	80002e6e <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003086:	0074f713          	andi	a4,s1,7
    8000308a:	4785                	li	a5,1
    8000308c:	00e797bb          	sllw	a5,a5,a4
  if ((bp->data[bi / 8] & m) == 0)
    80003090:	14ce                	slli	s1,s1,0x33
    80003092:	90d9                	srli	s1,s1,0x36
    80003094:	00950733          	add	a4,a0,s1
    80003098:	05874703          	lbu	a4,88(a4)
    8000309c:	00e7f6b3          	and	a3,a5,a4
    800030a0:	c29d                	beqz	a3,800030c6 <bfree+0x60>
    800030a2:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    800030a4:	94aa                	add	s1,s1,a0
    800030a6:	fff7c793          	not	a5,a5
    800030aa:	8f7d                	and	a4,a4,a5
    800030ac:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800030b0:	078010ef          	jal	80004128 <log_write>
  brelse(bp);
    800030b4:	854a                	mv	a0,s2
    800030b6:	ec1ff0ef          	jal	80002f76 <brelse>
}
    800030ba:	60e2                	ld	ra,24(sp)
    800030bc:	6442                	ld	s0,16(sp)
    800030be:	64a2                	ld	s1,8(sp)
    800030c0:	6902                	ld	s2,0(sp)
    800030c2:	6105                	addi	sp,sp,32
    800030c4:	8082                	ret
    panic("freeing free block");
    800030c6:	00006517          	auipc	a0,0x6
    800030ca:	38250513          	addi	a0,a0,898 # 80009448 <etext+0x448>
    800030ce:	f20fd0ef          	jal	800007ee <panic>

00000000800030d2 <balloc>:
{
    800030d2:	711d                	addi	sp,sp,-96
    800030d4:	ec86                	sd	ra,88(sp)
    800030d6:	e8a2                	sd	s0,80(sp)
    800030d8:	e4a6                	sd	s1,72(sp)
    800030da:	1080                	addi	s0,sp,96
  for (b = 0; b < sb.size; b += BPB) {
    800030dc:	00021797          	auipc	a5,0x21
    800030e0:	7b07a783          	lw	a5,1968(a5) # 8002488c <sb+0x4>
    800030e4:	0e078f63          	beqz	a5,800031e2 <balloc+0x110>
    800030e8:	e0ca                	sd	s2,64(sp)
    800030ea:	fc4e                	sd	s3,56(sp)
    800030ec:	f852                	sd	s4,48(sp)
    800030ee:	f456                	sd	s5,40(sp)
    800030f0:	f05a                	sd	s6,32(sp)
    800030f2:	ec5e                	sd	s7,24(sp)
    800030f4:	e862                	sd	s8,16(sp)
    800030f6:	e466                	sd	s9,8(sp)
    800030f8:	8baa                	mv	s7,a0
    800030fa:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800030fc:	00021b17          	auipc	s6,0x21
    80003100:	78cb0b13          	addi	s6,s6,1932 # 80024888 <sb>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003104:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003106:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003108:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    8000310a:	6c89                	lui	s9,0x2
    8000310c:	a0b5                	j	80003178 <balloc+0xa6>
        bp->data[bi / 8] |= m;           // Mark block in use.
    8000310e:	97ca                	add	a5,a5,s2
    80003110:	8e55                	or	a2,a2,a3
    80003112:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80003116:	854a                	mv	a0,s2
    80003118:	010010ef          	jal	80004128 <log_write>
        brelse(bp);
    8000311c:	854a                	mv	a0,s2
    8000311e:	e59ff0ef          	jal	80002f76 <brelse>
  bp = bread(dev, bno);
    80003122:	85a6                	mv	a1,s1
    80003124:	855e                	mv	a0,s7
    80003126:	d49ff0ef          	jal	80002e6e <bread>
    8000312a:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000312c:	40000613          	li	a2,1024
    80003130:	4581                	li	a1,0
    80003132:	05850513          	addi	a0,a0,88
    80003136:	b1dfd0ef          	jal	80000c52 <memset>
  log_write(bp);
    8000313a:	854a                	mv	a0,s2
    8000313c:	7ed000ef          	jal	80004128 <log_write>
  brelse(bp);
    80003140:	854a                	mv	a0,s2
    80003142:	e35ff0ef          	jal	80002f76 <brelse>
}
    80003146:	6906                	ld	s2,64(sp)
    80003148:	79e2                	ld	s3,56(sp)
    8000314a:	7a42                	ld	s4,48(sp)
    8000314c:	7aa2                	ld	s5,40(sp)
    8000314e:	7b02                	ld	s6,32(sp)
    80003150:	6be2                	ld	s7,24(sp)
    80003152:	6c42                	ld	s8,16(sp)
    80003154:	6ca2                	ld	s9,8(sp)
}
    80003156:	8526                	mv	a0,s1
    80003158:	60e6                	ld	ra,88(sp)
    8000315a:	6446                	ld	s0,80(sp)
    8000315c:	64a6                	ld	s1,72(sp)
    8000315e:	6125                	addi	sp,sp,96
    80003160:	8082                	ret
    brelse(bp);
    80003162:	854a                	mv	a0,s2
    80003164:	e13ff0ef          	jal	80002f76 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80003168:	015c87bb          	addw	a5,s9,s5
    8000316c:	00078a9b          	sext.w	s5,a5
    80003170:	004b2703          	lw	a4,4(s6)
    80003174:	04eaff63          	bgeu	s5,a4,800031d2 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80003178:	41fad79b          	sraiw	a5,s5,0x1f
    8000317c:	0137d79b          	srliw	a5,a5,0x13
    80003180:	015787bb          	addw	a5,a5,s5
    80003184:	40d7d79b          	sraiw	a5,a5,0xd
    80003188:	01cb2583          	lw	a1,28(s6)
    8000318c:	9dbd                	addw	a1,a1,a5
    8000318e:	855e                	mv	a0,s7
    80003190:	cdfff0ef          	jal	80002e6e <bread>
    80003194:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003196:	004b2503          	lw	a0,4(s6)
    8000319a:	000a849b          	sext.w	s1,s5
    8000319e:	8762                	mv	a4,s8
    800031a0:	fca4f1e3          	bgeu	s1,a0,80003162 <balloc+0x90>
      m = 1 << (bi % 8);
    800031a4:	00777693          	andi	a3,a4,7
    800031a8:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    800031ac:	41f7579b          	sraiw	a5,a4,0x1f
    800031b0:	01d7d79b          	srliw	a5,a5,0x1d
    800031b4:	9fb9                	addw	a5,a5,a4
    800031b6:	4037d79b          	sraiw	a5,a5,0x3
    800031ba:	00f90633          	add	a2,s2,a5
    800031be:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    800031c2:	00c6f5b3          	and	a1,a3,a2
    800031c6:	d5a1                	beqz	a1,8000310e <balloc+0x3c>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    800031c8:	2705                	addiw	a4,a4,1
    800031ca:	2485                	addiw	s1,s1,1
    800031cc:	fd471ae3          	bne	a4,s4,800031a0 <balloc+0xce>
    800031d0:	bf49                	j	80003162 <balloc+0x90>
    800031d2:	6906                	ld	s2,64(sp)
    800031d4:	79e2                	ld	s3,56(sp)
    800031d6:	7a42                	ld	s4,48(sp)
    800031d8:	7aa2                	ld	s5,40(sp)
    800031da:	7b02                	ld	s6,32(sp)
    800031dc:	6be2                	ld	s7,24(sp)
    800031de:	6c42                	ld	s8,16(sp)
    800031e0:	6ca2                	ld	s9,8(sp)
  printk("balloc: out of blocks\n");
    800031e2:	00006517          	auipc	a0,0x6
    800031e6:	27e50513          	addi	a0,a0,638 # 80009460 <etext+0x460>
    800031ea:	b1efd0ef          	jal	80000508 <printk>
  return 0;
    800031ee:	4481                	li	s1,0
    800031f0:	b79d                	j	80003156 <balloc+0x84>

00000000800031f2 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800031f2:	7179                	addi	sp,sp,-48
    800031f4:	f406                	sd	ra,40(sp)
    800031f6:	f022                	sd	s0,32(sp)
    800031f8:	ec26                	sd	s1,24(sp)
    800031fa:	e84a                	sd	s2,16(sp)
    800031fc:	e44e                	sd	s3,8(sp)
    800031fe:	1800                	addi	s0,sp,48
    80003200:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80003202:	47ad                	li	a5,11
    80003204:	02b7e663          	bltu	a5,a1,80003230 <bmap+0x3e>
    if ((addr = ip->addrs[bn]) == 0) {
    80003208:	02059793          	slli	a5,a1,0x20
    8000320c:	01e7d593          	srli	a1,a5,0x1e
    80003210:	00b504b3          	add	s1,a0,a1
    80003214:	0504a903          	lw	s2,80(s1)
    80003218:	06091a63          	bnez	s2,8000328c <bmap+0x9a>
      addr = balloc(ip->dev);
    8000321c:	4108                	lw	a0,0(a0)
    8000321e:	eb5ff0ef          	jal	800030d2 <balloc>
    80003222:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80003226:	06090363          	beqz	s2,8000328c <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    8000322a:	0524a823          	sw	s2,80(s1)
    8000322e:	a8b9                	j	8000328c <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003230:	ff45849b          	addiw	s1,a1,-12
    80003234:	0004871b          	sext.w	a4,s1

  if (bn < NINDIRECT) {
    80003238:	0ff00793          	li	a5,255
    8000323c:	06e7ee63          	bltu	a5,a4,800032b8 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80003240:	08052903          	lw	s2,128(a0)
    80003244:	00091d63          	bnez	s2,8000325e <bmap+0x6c>
      addr = balloc(ip->dev);
    80003248:	4108                	lw	a0,0(a0)
    8000324a:	e89ff0ef          	jal	800030d2 <balloc>
    8000324e:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80003252:	02090d63          	beqz	s2,8000328c <bmap+0x9a>
    80003256:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003258:	0929a023          	sw	s2,128(s3)
    8000325c:	a011                	j	80003260 <bmap+0x6e>
    8000325e:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80003260:	85ca                	mv	a1,s2
    80003262:	0009a503          	lw	a0,0(s3)
    80003266:	c09ff0ef          	jal	80002e6e <bread>
    8000326a:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    8000326c:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80003270:	02049713          	slli	a4,s1,0x20
    80003274:	01e75593          	srli	a1,a4,0x1e
    80003278:	00b784b3          	add	s1,a5,a1
    8000327c:	0004a903          	lw	s2,0(s1)
    80003280:	00090e63          	beqz	s2,8000329c <bmap+0xaa>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003284:	8552                	mv	a0,s4
    80003286:	cf1ff0ef          	jal	80002f76 <brelse>
    return addr;
    8000328a:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000328c:	854a                	mv	a0,s2
    8000328e:	70a2                	ld	ra,40(sp)
    80003290:	7402                	ld	s0,32(sp)
    80003292:	64e2                	ld	s1,24(sp)
    80003294:	6942                	ld	s2,16(sp)
    80003296:	69a2                	ld	s3,8(sp)
    80003298:	6145                	addi	sp,sp,48
    8000329a:	8082                	ret
      addr = balloc(ip->dev);
    8000329c:	0009a503          	lw	a0,0(s3)
    800032a0:	e33ff0ef          	jal	800030d2 <balloc>
    800032a4:	0005091b          	sext.w	s2,a0
      if (addr) {
    800032a8:	fc090ee3          	beqz	s2,80003284 <bmap+0x92>
        a[bn] = addr;
    800032ac:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800032b0:	8552                	mv	a0,s4
    800032b2:	677000ef          	jal	80004128 <log_write>
    800032b6:	b7f9                	j	80003284 <bmap+0x92>
    800032b8:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800032ba:	00006517          	auipc	a0,0x6
    800032be:	1be50513          	addi	a0,a0,446 # 80009478 <etext+0x478>
    800032c2:	d2cfd0ef          	jal	800007ee <panic>

00000000800032c6 <iget>:
{
    800032c6:	7179                	addi	sp,sp,-48
    800032c8:	f406                	sd	ra,40(sp)
    800032ca:	f022                	sd	s0,32(sp)
    800032cc:	ec26                	sd	s1,24(sp)
    800032ce:	e84a                	sd	s2,16(sp)
    800032d0:	e44e                	sd	s3,8(sp)
    800032d2:	e052                	sd	s4,0(sp)
    800032d4:	1800                	addi	s0,sp,48
    800032d6:	89aa                	mv	s3,a0
    800032d8:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800032da:	00021517          	auipc	a0,0x21
    800032de:	5ce50513          	addi	a0,a0,1486 # 800248a8 <itable>
    800032e2:	8adfd0ef          	jal	80000b8e <acquire>
  empty = 0;
    800032e6:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    800032e8:	00021497          	auipc	s1,0x21
    800032ec:	5d848493          	addi	s1,s1,1496 # 800248c0 <itable+0x18>
    800032f0:	00023697          	auipc	a3,0x23
    800032f4:	06068693          	addi	a3,a3,96 # 80026350 <log>
    800032f8:	a039                	j	80003306 <iget+0x40>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    800032fa:	02090963          	beqz	s2,8000332c <iget+0x66>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    800032fe:	08848493          	addi	s1,s1,136
    80003302:	02d48863          	beq	s1,a3,80003332 <iget+0x6c>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003306:	449c                	lw	a5,8(s1)
    80003308:	fef059e3          	blez	a5,800032fa <iget+0x34>
    8000330c:	4098                	lw	a4,0(s1)
    8000330e:	ff3716e3          	bne	a4,s3,800032fa <iget+0x34>
    80003312:	40d8                	lw	a4,4(s1)
    80003314:	ff4713e3          	bne	a4,s4,800032fa <iget+0x34>
      ip->ref++;
    80003318:	2785                	addiw	a5,a5,1
    8000331a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000331c:	00021517          	auipc	a0,0x21
    80003320:	58c50513          	addi	a0,a0,1420 # 800248a8 <itable>
    80003324:	8f7fd0ef          	jal	80000c1a <release>
      return ip;
    80003328:	8926                	mv	s2,s1
    8000332a:	a02d                	j	80003354 <iget+0x8e>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    8000332c:	fbe9                	bnez	a5,800032fe <iget+0x38>
      empty = ip;
    8000332e:	8926                	mv	s2,s1
    80003330:	b7f9                	j	800032fe <iget+0x38>
  if (empty == 0)
    80003332:	02090a63          	beqz	s2,80003366 <iget+0xa0>
  ip->dev = dev;
    80003336:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    8000333a:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    8000333e:	4785                	li	a5,1
    80003340:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003344:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003348:	00021517          	auipc	a0,0x21
    8000334c:	56050513          	addi	a0,a0,1376 # 800248a8 <itable>
    80003350:	8cbfd0ef          	jal	80000c1a <release>
}
    80003354:	854a                	mv	a0,s2
    80003356:	70a2                	ld	ra,40(sp)
    80003358:	7402                	ld	s0,32(sp)
    8000335a:	64e2                	ld	s1,24(sp)
    8000335c:	6942                	ld	s2,16(sp)
    8000335e:	69a2                	ld	s3,8(sp)
    80003360:	6a02                	ld	s4,0(sp)
    80003362:	6145                	addi	sp,sp,48
    80003364:	8082                	ret
    panic("iget: no inodes");
    80003366:	00006517          	auipc	a0,0x6
    8000336a:	12a50513          	addi	a0,a0,298 # 80009490 <etext+0x490>
    8000336e:	c80fd0ef          	jal	800007ee <panic>

0000000080003372 <iinit>:
{
    80003372:	7179                	addi	sp,sp,-48
    80003374:	f406                	sd	ra,40(sp)
    80003376:	f022                	sd	s0,32(sp)
    80003378:	ec26                	sd	s1,24(sp)
    8000337a:	e84a                	sd	s2,16(sp)
    8000337c:	e44e                	sd	s3,8(sp)
    8000337e:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003380:	00006597          	auipc	a1,0x6
    80003384:	12058593          	addi	a1,a1,288 # 800094a0 <etext+0x4a0>
    80003388:	00021517          	auipc	a0,0x21
    8000338c:	52050513          	addi	a0,a0,1312 # 800248a8 <itable>
    80003390:	f88fd0ef          	jal	80000b18 <initlock>
  for (i = 0; i < NINODE; i++) {
    80003394:	00021497          	auipc	s1,0x21
    80003398:	53c48493          	addi	s1,s1,1340 # 800248d0 <itable+0x28>
    8000339c:	00023997          	auipc	s3,0x23
    800033a0:	fc498993          	addi	s3,s3,-60 # 80026360 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800033a4:	00006917          	auipc	s2,0x6
    800033a8:	10490913          	addi	s2,s2,260 # 800094a8 <etext+0x4a8>
    800033ac:	85ca                	mv	a1,s2
    800033ae:	8526                	mv	a0,s1
    800033b0:	6ab000ef          	jal	8000425a <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    800033b4:	08848493          	addi	s1,s1,136
    800033b8:	ff349ae3          	bne	s1,s3,800033ac <iinit+0x3a>
}
    800033bc:	70a2                	ld	ra,40(sp)
    800033be:	7402                	ld	s0,32(sp)
    800033c0:	64e2                	ld	s1,24(sp)
    800033c2:	6942                	ld	s2,16(sp)
    800033c4:	69a2                	ld	s3,8(sp)
    800033c6:	6145                	addi	sp,sp,48
    800033c8:	8082                	ret

00000000800033ca <ialloc>:
{
    800033ca:	7139                	addi	sp,sp,-64
    800033cc:	fc06                	sd	ra,56(sp)
    800033ce:	f822                	sd	s0,48(sp)
    800033d0:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    800033d2:	00021717          	auipc	a4,0x21
    800033d6:	4c272703          	lw	a4,1218(a4) # 80024894 <sb+0xc>
    800033da:	4785                	li	a5,1
    800033dc:	06e7f063          	bgeu	a5,a4,8000343c <ialloc+0x72>
    800033e0:	f426                	sd	s1,40(sp)
    800033e2:	f04a                	sd	s2,32(sp)
    800033e4:	ec4e                	sd	s3,24(sp)
    800033e6:	e852                	sd	s4,16(sp)
    800033e8:	e456                	sd	s5,8(sp)
    800033ea:	e05a                	sd	s6,0(sp)
    800033ec:	8aaa                	mv	s5,a0
    800033ee:	8b2e                	mv	s6,a1
    800033f0:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    800033f2:	00021a17          	auipc	s4,0x21
    800033f6:	496a0a13          	addi	s4,s4,1174 # 80024888 <sb>
    800033fa:	00495593          	srli	a1,s2,0x4
    800033fe:	018a2783          	lw	a5,24(s4)
    80003402:	9dbd                	addw	a1,a1,a5
    80003404:	8556                	mv	a0,s5
    80003406:	a69ff0ef          	jal	80002e6e <bread>
    8000340a:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    8000340c:	05850993          	addi	s3,a0,88
    80003410:	00f97793          	andi	a5,s2,15
    80003414:	079a                	slli	a5,a5,0x6
    80003416:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    80003418:	00099783          	lh	a5,0(s3)
    8000341c:	cb9d                	beqz	a5,80003452 <ialloc+0x88>
    brelse(bp);
    8000341e:	b59ff0ef          	jal	80002f76 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003422:	0905                	addi	s2,s2,1
    80003424:	00ca2703          	lw	a4,12(s4)
    80003428:	0009079b          	sext.w	a5,s2
    8000342c:	fce7e7e3          	bltu	a5,a4,800033fa <ialloc+0x30>
    80003430:	74a2                	ld	s1,40(sp)
    80003432:	7902                	ld	s2,32(sp)
    80003434:	69e2                	ld	s3,24(sp)
    80003436:	6a42                	ld	s4,16(sp)
    80003438:	6aa2                	ld	s5,8(sp)
    8000343a:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    8000343c:	00006517          	auipc	a0,0x6
    80003440:	07450513          	addi	a0,a0,116 # 800094b0 <etext+0x4b0>
    80003444:	8c4fd0ef          	jal	80000508 <printk>
  return 0;
    80003448:	4501                	li	a0,0
}
    8000344a:	70e2                	ld	ra,56(sp)
    8000344c:	7442                	ld	s0,48(sp)
    8000344e:	6121                	addi	sp,sp,64
    80003450:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003452:	04000613          	li	a2,64
    80003456:	4581                	li	a1,0
    80003458:	854e                	mv	a0,s3
    8000345a:	ff8fd0ef          	jal	80000c52 <memset>
      dip->type = type;
    8000345e:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    80003462:	8526                	mv	a0,s1
    80003464:	4c5000ef          	jal	80004128 <log_write>
      brelse(bp);
    80003468:	8526                	mv	a0,s1
    8000346a:	b0dff0ef          	jal	80002f76 <brelse>
      return iget(dev, inum);
    8000346e:	0009059b          	sext.w	a1,s2
    80003472:	8556                	mv	a0,s5
    80003474:	e53ff0ef          	jal	800032c6 <iget>
    80003478:	74a2                	ld	s1,40(sp)
    8000347a:	7902                	ld	s2,32(sp)
    8000347c:	69e2                	ld	s3,24(sp)
    8000347e:	6a42                	ld	s4,16(sp)
    80003480:	6aa2                	ld	s5,8(sp)
    80003482:	6b02                	ld	s6,0(sp)
    80003484:	b7d9                	j	8000344a <ialloc+0x80>

0000000080003486 <iupdate>:
{
    80003486:	1101                	addi	sp,sp,-32
    80003488:	ec06                	sd	ra,24(sp)
    8000348a:	e822                	sd	s0,16(sp)
    8000348c:	e426                	sd	s1,8(sp)
    8000348e:	e04a                	sd	s2,0(sp)
    80003490:	1000                	addi	s0,sp,32
    80003492:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003494:	415c                	lw	a5,4(a0)
    80003496:	0047d79b          	srliw	a5,a5,0x4
    8000349a:	00021597          	auipc	a1,0x21
    8000349e:	4065a583          	lw	a1,1030(a1) # 800248a0 <sb+0x18>
    800034a2:	9dbd                	addw	a1,a1,a5
    800034a4:	4108                	lw	a0,0(a0)
    800034a6:	9c9ff0ef          	jal	80002e6e <bread>
    800034aa:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    800034ac:	05850793          	addi	a5,a0,88
    800034b0:	40d8                	lw	a4,4(s1)
    800034b2:	8b3d                	andi	a4,a4,15
    800034b4:	071a                	slli	a4,a4,0x6
    800034b6:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800034b8:	04449703          	lh	a4,68(s1)
    800034bc:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800034c0:	04649703          	lh	a4,70(s1)
    800034c4:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800034c8:	04849703          	lh	a4,72(s1)
    800034cc:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800034d0:	04a49703          	lh	a4,74(s1)
    800034d4:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800034d8:	44f8                	lw	a4,76(s1)
    800034da:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800034dc:	03400613          	li	a2,52
    800034e0:	05048593          	addi	a1,s1,80
    800034e4:	00c78513          	addi	a0,a5,12
    800034e8:	fc6fd0ef          	jal	80000cae <memmove>
  log_write(bp);
    800034ec:	854a                	mv	a0,s2
    800034ee:	43b000ef          	jal	80004128 <log_write>
  brelse(bp);
    800034f2:	854a                	mv	a0,s2
    800034f4:	a83ff0ef          	jal	80002f76 <brelse>
}
    800034f8:	60e2                	ld	ra,24(sp)
    800034fa:	6442                	ld	s0,16(sp)
    800034fc:	64a2                	ld	s1,8(sp)
    800034fe:	6902                	ld	s2,0(sp)
    80003500:	6105                	addi	sp,sp,32
    80003502:	8082                	ret

0000000080003504 <idup>:
{
    80003504:	1101                	addi	sp,sp,-32
    80003506:	ec06                	sd	ra,24(sp)
    80003508:	e822                	sd	s0,16(sp)
    8000350a:	e426                	sd	s1,8(sp)
    8000350c:	1000                	addi	s0,sp,32
    8000350e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003510:	00021517          	auipc	a0,0x21
    80003514:	39850513          	addi	a0,a0,920 # 800248a8 <itable>
    80003518:	e76fd0ef          	jal	80000b8e <acquire>
  ip->ref++;
    8000351c:	449c                	lw	a5,8(s1)
    8000351e:	2785                	addiw	a5,a5,1
    80003520:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003522:	00021517          	auipc	a0,0x21
    80003526:	38650513          	addi	a0,a0,902 # 800248a8 <itable>
    8000352a:	ef0fd0ef          	jal	80000c1a <release>
}
    8000352e:	8526                	mv	a0,s1
    80003530:	60e2                	ld	ra,24(sp)
    80003532:	6442                	ld	s0,16(sp)
    80003534:	64a2                	ld	s1,8(sp)
    80003536:	6105                	addi	sp,sp,32
    80003538:	8082                	ret

000000008000353a <ilock>:
{
    8000353a:	1101                	addi	sp,sp,-32
    8000353c:	ec06                	sd	ra,24(sp)
    8000353e:	e822                	sd	s0,16(sp)
    80003540:	e426                	sd	s1,8(sp)
    80003542:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003544:	cd19                	beqz	a0,80003562 <ilock+0x28>
    80003546:	84aa                	mv	s1,a0
    80003548:	451c                	lw	a5,8(a0)
    8000354a:	00f05c63          	blez	a5,80003562 <ilock+0x28>
  acquiresleep(&ip->lock);
    8000354e:	0541                	addi	a0,a0,16
    80003550:	541000ef          	jal	80004290 <acquiresleep>
  if (ip->valid == 0) {
    80003554:	40bc                	lw	a5,64(s1)
    80003556:	cf89                	beqz	a5,80003570 <ilock+0x36>
}
    80003558:	60e2                	ld	ra,24(sp)
    8000355a:	6442                	ld	s0,16(sp)
    8000355c:	64a2                	ld	s1,8(sp)
    8000355e:	6105                	addi	sp,sp,32
    80003560:	8082                	ret
    80003562:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003564:	00006517          	auipc	a0,0x6
    80003568:	f6450513          	addi	a0,a0,-156 # 800094c8 <etext+0x4c8>
    8000356c:	a82fd0ef          	jal	800007ee <panic>
    80003570:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003572:	40dc                	lw	a5,4(s1)
    80003574:	0047d79b          	srliw	a5,a5,0x4
    80003578:	00021597          	auipc	a1,0x21
    8000357c:	3285a583          	lw	a1,808(a1) # 800248a0 <sb+0x18>
    80003580:	9dbd                	addw	a1,a1,a5
    80003582:	4088                	lw	a0,0(s1)
    80003584:	8ebff0ef          	jal	80002e6e <bread>
    80003588:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    8000358a:	05850593          	addi	a1,a0,88
    8000358e:	40dc                	lw	a5,4(s1)
    80003590:	8bbd                	andi	a5,a5,15
    80003592:	079a                	slli	a5,a5,0x6
    80003594:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003596:	00059783          	lh	a5,0(a1)
    8000359a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000359e:	00259783          	lh	a5,2(a1)
    800035a2:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800035a6:	00459783          	lh	a5,4(a1)
    800035aa:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800035ae:	00659783          	lh	a5,6(a1)
    800035b2:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800035b6:	459c                	lw	a5,8(a1)
    800035b8:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800035ba:	03400613          	li	a2,52
    800035be:	05b1                	addi	a1,a1,12
    800035c0:	05048513          	addi	a0,s1,80
    800035c4:	eeafd0ef          	jal	80000cae <memmove>
    brelse(bp);
    800035c8:	854a                	mv	a0,s2
    800035ca:	9adff0ef          	jal	80002f76 <brelse>
    ip->valid = 1;
    800035ce:	4785                	li	a5,1
    800035d0:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    800035d2:	04449783          	lh	a5,68(s1)
    800035d6:	c399                	beqz	a5,800035dc <ilock+0xa2>
    800035d8:	6902                	ld	s2,0(sp)
    800035da:	bfbd                	j	80003558 <ilock+0x1e>
      panic("ilock: no type");
    800035dc:	00006517          	auipc	a0,0x6
    800035e0:	ef450513          	addi	a0,a0,-268 # 800094d0 <etext+0x4d0>
    800035e4:	a0afd0ef          	jal	800007ee <panic>

00000000800035e8 <iunlock>:
{
    800035e8:	1101                	addi	sp,sp,-32
    800035ea:	ec06                	sd	ra,24(sp)
    800035ec:	e822                	sd	s0,16(sp)
    800035ee:	e426                	sd	s1,8(sp)
    800035f0:	e04a                	sd	s2,0(sp)
    800035f2:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800035f4:	c505                	beqz	a0,8000361c <iunlock+0x34>
    800035f6:	84aa                	mv	s1,a0
    800035f8:	01050913          	addi	s2,a0,16
    800035fc:	854a                	mv	a0,s2
    800035fe:	51f000ef          	jal	8000431c <holdingsleep>
    80003602:	cd09                	beqz	a0,8000361c <iunlock+0x34>
    80003604:	449c                	lw	a5,8(s1)
    80003606:	00f05b63          	blez	a5,8000361c <iunlock+0x34>
  releasesleep(&ip->lock);
    8000360a:	854a                	mv	a0,s2
    8000360c:	4d9000ef          	jal	800042e4 <releasesleep>
}
    80003610:	60e2                	ld	ra,24(sp)
    80003612:	6442                	ld	s0,16(sp)
    80003614:	64a2                	ld	s1,8(sp)
    80003616:	6902                	ld	s2,0(sp)
    80003618:	6105                	addi	sp,sp,32
    8000361a:	8082                	ret
    panic("iunlock");
    8000361c:	00006517          	auipc	a0,0x6
    80003620:	ec450513          	addi	a0,a0,-316 # 800094e0 <etext+0x4e0>
    80003624:	9cafd0ef          	jal	800007ee <panic>

0000000080003628 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003628:	7179                	addi	sp,sp,-48
    8000362a:	f406                	sd	ra,40(sp)
    8000362c:	f022                	sd	s0,32(sp)
    8000362e:	ec26                	sd	s1,24(sp)
    80003630:	e84a                	sd	s2,16(sp)
    80003632:	e44e                	sd	s3,8(sp)
    80003634:	1800                	addi	s0,sp,48
    80003636:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    80003638:	05050493          	addi	s1,a0,80
    8000363c:	08050913          	addi	s2,a0,128
    80003640:	a021                	j	80003648 <itrunc+0x20>
    80003642:	0491                	addi	s1,s1,4
    80003644:	01248b63          	beq	s1,s2,8000365a <itrunc+0x32>
    if (ip->addrs[i]) {
    80003648:	408c                	lw	a1,0(s1)
    8000364a:	dde5                	beqz	a1,80003642 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000364c:	0009a503          	lw	a0,0(s3)
    80003650:	a17ff0ef          	jal	80003066 <bfree>
      ip->addrs[i] = 0;
    80003654:	0004a023          	sw	zero,0(s1)
    80003658:	b7ed                	j	80003642 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    8000365a:	0809a583          	lw	a1,128(s3)
    8000365e:	ed89                	bnez	a1,80003678 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003660:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003664:	854e                	mv	a0,s3
    80003666:	e21ff0ef          	jal	80003486 <iupdate>
}
    8000366a:	70a2                	ld	ra,40(sp)
    8000366c:	7402                	ld	s0,32(sp)
    8000366e:	64e2                	ld	s1,24(sp)
    80003670:	6942                	ld	s2,16(sp)
    80003672:	69a2                	ld	s3,8(sp)
    80003674:	6145                	addi	sp,sp,48
    80003676:	8082                	ret
    80003678:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000367a:	0009a503          	lw	a0,0(s3)
    8000367e:	ff0ff0ef          	jal	80002e6e <bread>
    80003682:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    80003684:	05850493          	addi	s1,a0,88
    80003688:	45850913          	addi	s2,a0,1112
    8000368c:	a021                	j	80003694 <itrunc+0x6c>
    8000368e:	0491                	addi	s1,s1,4
    80003690:	01248963          	beq	s1,s2,800036a2 <itrunc+0x7a>
      if (a[j])
    80003694:	408c                	lw	a1,0(s1)
    80003696:	dde5                	beqz	a1,8000368e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003698:	0009a503          	lw	a0,0(s3)
    8000369c:	9cbff0ef          	jal	80003066 <bfree>
    800036a0:	b7fd                	j	8000368e <itrunc+0x66>
    brelse(bp);
    800036a2:	8552                	mv	a0,s4
    800036a4:	8d3ff0ef          	jal	80002f76 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800036a8:	0809a583          	lw	a1,128(s3)
    800036ac:	0009a503          	lw	a0,0(s3)
    800036b0:	9b7ff0ef          	jal	80003066 <bfree>
    ip->addrs[NDIRECT] = 0;
    800036b4:	0809a023          	sw	zero,128(s3)
    800036b8:	6a02                	ld	s4,0(sp)
    800036ba:	b75d                	j	80003660 <itrunc+0x38>

00000000800036bc <iput>:
{
    800036bc:	7179                	addi	sp,sp,-48
    800036be:	f406                	sd	ra,40(sp)
    800036c0:	f022                	sd	s0,32(sp)
    800036c2:	ec26                	sd	s1,24(sp)
    800036c4:	1800                	addi	s0,sp,48
    800036c6:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800036c8:	00021517          	auipc	a0,0x21
    800036cc:	1e050513          	addi	a0,a0,480 # 800248a8 <itable>
    800036d0:	cbefd0ef          	jal	80000b8e <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800036d4:	449c                	lw	a5,8(s1)
    800036d6:	4705                	li	a4,1
    800036d8:	00e78f63          	beq	a5,a4,800036f6 <iput+0x3a>
  ip->ref--;
    800036dc:	37fd                	addiw	a5,a5,-1
    800036de:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800036e0:	00021517          	auipc	a0,0x21
    800036e4:	1c850513          	addi	a0,a0,456 # 800248a8 <itable>
    800036e8:	d32fd0ef          	jal	80000c1a <release>
}
    800036ec:	70a2                	ld	ra,40(sp)
    800036ee:	7402                	ld	s0,32(sp)
    800036f0:	64e2                	ld	s1,24(sp)
    800036f2:	6145                	addi	sp,sp,48
    800036f4:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    800036f6:	40b8                	lw	a4,64(s1)
    800036f8:	d375                	beqz	a4,800036dc <iput+0x20>
    800036fa:	e84a                	sd	s2,16(sp)
    800036fc:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    800036fe:	0004aa03          	lw	s4,0(s1)
    80003702:	0044a903          	lw	s2,4(s1)
  if (last) {
    80003706:	04a49703          	lh	a4,74(s1)
    8000370a:	ef35                	bnez	a4,80003786 <iput+0xca>
    8000370c:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    8000370e:	01048993          	addi	s3,s1,16
    80003712:	854e                	mv	a0,s3
    80003714:	37d000ef          	jal	80004290 <acquiresleep>
    release(&itable.lock);
    80003718:	00021517          	auipc	a0,0x21
    8000371c:	19050513          	addi	a0,a0,400 # 800248a8 <itable>
    80003720:	cfafd0ef          	jal	80000c1a <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003724:	8526                	mv	a0,s1
    80003726:	f03ff0ef          	jal	80003628 <itrunc>
    ip->valid = 0;
    8000372a:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000372e:	854e                	mv	a0,s3
    80003730:	3b5000ef          	jal	800042e4 <releasesleep>
    acquire(&itable.lock);
    80003734:	00021517          	auipc	a0,0x21
    80003738:	17450513          	addi	a0,a0,372 # 800248a8 <itable>
    8000373c:	c52fd0ef          	jal	80000b8e <acquire>
  ip->ref--;
    80003740:	449c                	lw	a5,8(s1)
    80003742:	37fd                	addiw	a5,a5,-1
    80003744:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003746:	00021517          	auipc	a0,0x21
    8000374a:	16250513          	addi	a0,a0,354 # 800248a8 <itable>
    8000374e:	cccfd0ef          	jal	80000c1a <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003752:	0049559b          	srliw	a1,s2,0x4
    80003756:	00021797          	auipc	a5,0x21
    8000375a:	14a7a783          	lw	a5,330(a5) # 800248a0 <sb+0x18>
    8000375e:	9dbd                	addw	a1,a1,a5
    80003760:	8552                	mv	a0,s4
    80003762:	f0cff0ef          	jal	80002e6e <bread>
    80003766:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003768:	00f97913          	andi	s2,s2,15
  dip->type = 0;
    8000376c:	091a                	slli	s2,s2,0x6
    8000376e:	992a                	add	s2,s2,a0
    80003770:	04091c23          	sh	zero,88(s2)
  log_write(bp);
    80003774:	1b5000ef          	jal	80004128 <log_write>
  brelse(bp);
    80003778:	8526                	mv	a0,s1
    8000377a:	ffcff0ef          	jal	80002f76 <brelse>
}
    8000377e:	6942                	ld	s2,16(sp)
    80003780:	69a2                	ld	s3,8(sp)
    80003782:	6a02                	ld	s4,0(sp)
    80003784:	b7a5                	j	800036ec <iput+0x30>
    80003786:	6942                	ld	s2,16(sp)
    80003788:	6a02                	ld	s4,0(sp)
    8000378a:	bf89                	j	800036dc <iput+0x20>

000000008000378c <iunlockput>:
{
    8000378c:	1101                	addi	sp,sp,-32
    8000378e:	ec06                	sd	ra,24(sp)
    80003790:	e822                	sd	s0,16(sp)
    80003792:	e426                	sd	s1,8(sp)
    80003794:	1000                	addi	s0,sp,32
    80003796:	84aa                	mv	s1,a0
  iunlock(ip);
    80003798:	e51ff0ef          	jal	800035e8 <iunlock>
  iput(ip);
    8000379c:	8526                	mv	a0,s1
    8000379e:	f1fff0ef          	jal	800036bc <iput>
}
    800037a2:	60e2                	ld	ra,24(sp)
    800037a4:	6442                	ld	s0,16(sp)
    800037a6:	64a2                	ld	s1,8(sp)
    800037a8:	6105                	addi	sp,sp,32
    800037aa:	8082                	ret

00000000800037ac <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800037ac:	00021717          	auipc	a4,0x21
    800037b0:	0e872703          	lw	a4,232(a4) # 80024894 <sb+0xc>
    800037b4:	4785                	li	a5,1
    800037b6:	0ae7ff63          	bgeu	a5,a4,80003874 <ireclaim+0xc8>
{
    800037ba:	7139                	addi	sp,sp,-64
    800037bc:	fc06                	sd	ra,56(sp)
    800037be:	f822                	sd	s0,48(sp)
    800037c0:	f426                	sd	s1,40(sp)
    800037c2:	f04a                	sd	s2,32(sp)
    800037c4:	ec4e                	sd	s3,24(sp)
    800037c6:	e852                	sd	s4,16(sp)
    800037c8:	e456                	sd	s5,8(sp)
    800037ca:	e05a                	sd	s6,0(sp)
    800037cc:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800037ce:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800037d0:	00050a1b          	sext.w	s4,a0
    800037d4:	00021a97          	auipc	s5,0x21
    800037d8:	0b4a8a93          	addi	s5,s5,180 # 80024888 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    800037dc:	00006b17          	auipc	s6,0x6
    800037e0:	d0cb0b13          	addi	s6,s6,-756 # 800094e8 <etext+0x4e8>
    800037e4:	a099                	j	8000382a <ireclaim+0x7e>
    800037e6:	85ce                	mv	a1,s3
    800037e8:	855a                	mv	a0,s6
    800037ea:	d1ffc0ef          	jal	80000508 <printk>
      ip = iget(dev, inum);
    800037ee:	85ce                	mv	a1,s3
    800037f0:	8552                	mv	a0,s4
    800037f2:	ad5ff0ef          	jal	800032c6 <iget>
    800037f6:	89aa                	mv	s3,a0
    brelse(bp);
    800037f8:	854a                	mv	a0,s2
    800037fa:	f7cff0ef          	jal	80002f76 <brelse>
    if (ip) {
    800037fe:	00098f63          	beqz	s3,8000381c <ireclaim+0x70>
      begin_op();
    80003802:	780000ef          	jal	80003f82 <begin_op>
      ilock(ip);
    80003806:	854e                	mv	a0,s3
    80003808:	d33ff0ef          	jal	8000353a <ilock>
      iunlock(ip);
    8000380c:	854e                	mv	a0,s3
    8000380e:	ddbff0ef          	jal	800035e8 <iunlock>
      iput(ip);
    80003812:	854e                	mv	a0,s3
    80003814:	ea9ff0ef          	jal	800036bc <iput>
      end_op();
    80003818:	7f0000ef          	jal	80004008 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000381c:	0485                	addi	s1,s1,1
    8000381e:	00caa703          	lw	a4,12(s5)
    80003822:	0004879b          	sext.w	a5,s1
    80003826:	02e7fd63          	bgeu	a5,a4,80003860 <ireclaim+0xb4>
    8000382a:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000382e:	0044d593          	srli	a1,s1,0x4
    80003832:	018aa783          	lw	a5,24(s5)
    80003836:	9dbd                	addw	a1,a1,a5
    80003838:	8552                	mv	a0,s4
    8000383a:	e34ff0ef          	jal	80002e6e <bread>
    8000383e:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003840:	05850793          	addi	a5,a0,88
    80003844:	00f9f713          	andi	a4,s3,15
    80003848:	071a                	slli	a4,a4,0x6
    8000384a:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    8000384c:	00079703          	lh	a4,0(a5)
    80003850:	c701                	beqz	a4,80003858 <ireclaim+0xac>
    80003852:	00679783          	lh	a5,6(a5)
    80003856:	dbc1                	beqz	a5,800037e6 <ireclaim+0x3a>
    brelse(bp);
    80003858:	854a                	mv	a0,s2
    8000385a:	f1cff0ef          	jal	80002f76 <brelse>
    if (ip) {
    8000385e:	bf7d                	j	8000381c <ireclaim+0x70>
}
    80003860:	70e2                	ld	ra,56(sp)
    80003862:	7442                	ld	s0,48(sp)
    80003864:	74a2                	ld	s1,40(sp)
    80003866:	7902                	ld	s2,32(sp)
    80003868:	69e2                	ld	s3,24(sp)
    8000386a:	6a42                	ld	s4,16(sp)
    8000386c:	6aa2                	ld	s5,8(sp)
    8000386e:	6b02                	ld	s6,0(sp)
    80003870:	6121                	addi	sp,sp,64
    80003872:	8082                	ret
    80003874:	8082                	ret

0000000080003876 <fsinit>:
{
    80003876:	7179                	addi	sp,sp,-48
    80003878:	f406                	sd	ra,40(sp)
    8000387a:	f022                	sd	s0,32(sp)
    8000387c:	ec26                	sd	s1,24(sp)
    8000387e:	e84a                	sd	s2,16(sp)
    80003880:	e44e                	sd	s3,8(sp)
    80003882:	1800                	addi	s0,sp,48
    80003884:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    80003886:	4585                	li	a1,1
    80003888:	de6ff0ef          	jal	80002e6e <bread>
    8000388c:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000388e:	00021997          	auipc	s3,0x21
    80003892:	ffa98993          	addi	s3,s3,-6 # 80024888 <sb>
    80003896:	02000613          	li	a2,32
    8000389a:	05850593          	addi	a1,a0,88
    8000389e:	854e                	mv	a0,s3
    800038a0:	c0efd0ef          	jal	80000cae <memmove>
  brelse(bp);
    800038a4:	854a                	mv	a0,s2
    800038a6:	ed0ff0ef          	jal	80002f76 <brelse>
  if (sb.magic != FSMAGIC)
    800038aa:	0009a703          	lw	a4,0(s3)
    800038ae:	102037b7          	lui	a5,0x10203
    800038b2:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800038b6:	02f71363          	bne	a4,a5,800038dc <fsinit+0x66>
  initlog(dev, &sb);
    800038ba:	00021597          	auipc	a1,0x21
    800038be:	fce58593          	addi	a1,a1,-50 # 80024888 <sb>
    800038c2:	8526                	mv	a0,s1
    800038c4:	640000ef          	jal	80003f04 <initlog>
  ireclaim(dev);
    800038c8:	8526                	mv	a0,s1
    800038ca:	ee3ff0ef          	jal	800037ac <ireclaim>
}
    800038ce:	70a2                	ld	ra,40(sp)
    800038d0:	7402                	ld	s0,32(sp)
    800038d2:	64e2                	ld	s1,24(sp)
    800038d4:	6942                	ld	s2,16(sp)
    800038d6:	69a2                	ld	s3,8(sp)
    800038d8:	6145                	addi	sp,sp,48
    800038da:	8082                	ret
    panic("invalid file system");
    800038dc:	00006517          	auipc	a0,0x6
    800038e0:	c2c50513          	addi	a0,a0,-980 # 80009508 <etext+0x508>
    800038e4:	f0bfc0ef          	jal	800007ee <panic>

00000000800038e8 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800038e8:	1141                	addi	sp,sp,-16
    800038ea:	e422                	sd	s0,8(sp)
    800038ec:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800038ee:	411c                	lw	a5,0(a0)
    800038f0:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800038f2:	415c                	lw	a5,4(a0)
    800038f4:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800038f6:	04451783          	lh	a5,68(a0)
    800038fa:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800038fe:	04a51783          	lh	a5,74(a0)
    80003902:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003906:	04c56783          	lwu	a5,76(a0)
    8000390a:	e99c                	sd	a5,16(a1)
}
    8000390c:	6422                	ld	s0,8(sp)
    8000390e:	0141                	addi	sp,sp,16
    80003910:	8082                	ret

0000000080003912 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003912:	457c                	lw	a5,76(a0)
    80003914:	0ed7eb63          	bltu	a5,a3,80003a0a <readi+0xf8>
{
    80003918:	7159                	addi	sp,sp,-112
    8000391a:	f486                	sd	ra,104(sp)
    8000391c:	f0a2                	sd	s0,96(sp)
    8000391e:	eca6                	sd	s1,88(sp)
    80003920:	e0d2                	sd	s4,64(sp)
    80003922:	fc56                	sd	s5,56(sp)
    80003924:	f85a                	sd	s6,48(sp)
    80003926:	f45e                	sd	s7,40(sp)
    80003928:	1880                	addi	s0,sp,112
    8000392a:	8b2a                	mv	s6,a0
    8000392c:	8bae                	mv	s7,a1
    8000392e:	8a32                	mv	s4,a2
    80003930:	84b6                	mv	s1,a3
    80003932:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003934:	9f35                	addw	a4,a4,a3
    return 0;
    80003936:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003938:	0cd76063          	bltu	a4,a3,800039f8 <readi+0xe6>
    8000393c:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    8000393e:	00e7f463          	bgeu	a5,a4,80003946 <readi+0x34>
    n = ip->size - off;
    80003942:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003946:	080a8f63          	beqz	s5,800039e4 <readi+0xd2>
    8000394a:	e8ca                	sd	s2,80(sp)
    8000394c:	f062                	sd	s8,32(sp)
    8000394e:	ec66                	sd	s9,24(sp)
    80003950:	e86a                	sd	s10,16(sp)
    80003952:	e46e                	sd	s11,8(sp)
    80003954:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003956:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000395a:	5c7d                	li	s8,-1
    8000395c:	a80d                	j	8000398e <readi+0x7c>
    8000395e:	020d1d93          	slli	s11,s10,0x20
    80003962:	020ddd93          	srli	s11,s11,0x20
    80003966:	05890613          	addi	a2,s2,88
    8000396a:	86ee                	mv	a3,s11
    8000396c:	963a                	add	a2,a2,a4
    8000396e:	85d2                	mv	a1,s4
    80003970:	855e                	mv	a0,s7
    80003972:	965fe0ef          	jal	800022d6 <either_copyout>
    80003976:	05850763          	beq	a0,s8,800039c4 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000397a:	854a                	mv	a0,s2
    8000397c:	dfaff0ef          	jal	80002f76 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003980:	013d09bb          	addw	s3,s10,s3
    80003984:	009d04bb          	addw	s1,s10,s1
    80003988:	9a6e                	add	s4,s4,s11
    8000398a:	0559f763          	bgeu	s3,s5,800039d8 <readi+0xc6>
    uint addr = bmap(ip, off / BSIZE);
    8000398e:	00a4d59b          	srliw	a1,s1,0xa
    80003992:	855a                	mv	a0,s6
    80003994:	85fff0ef          	jal	800031f2 <bmap>
    80003998:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    8000399c:	c5b1                	beqz	a1,800039e8 <readi+0xd6>
    bp = bread(ip->dev, addr);
    8000399e:	000b2503          	lw	a0,0(s6)
    800039a2:	cccff0ef          	jal	80002e6e <bread>
    800039a6:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800039a8:	3ff4f713          	andi	a4,s1,1023
    800039ac:	40ec87bb          	subw	a5,s9,a4
    800039b0:	413a86bb          	subw	a3,s5,s3
    800039b4:	8d3e                	mv	s10,a5
    800039b6:	2781                	sext.w	a5,a5
    800039b8:	0006861b          	sext.w	a2,a3
    800039bc:	faf671e3          	bgeu	a2,a5,8000395e <readi+0x4c>
    800039c0:	8d36                	mv	s10,a3
    800039c2:	bf71                	j	8000395e <readi+0x4c>
      brelse(bp);
    800039c4:	854a                	mv	a0,s2
    800039c6:	db0ff0ef          	jal	80002f76 <brelse>
      tot = -1;
    800039ca:	59fd                	li	s3,-1
      break;
    800039cc:	6946                	ld	s2,80(sp)
    800039ce:	7c02                	ld	s8,32(sp)
    800039d0:	6ce2                	ld	s9,24(sp)
    800039d2:	6d42                	ld	s10,16(sp)
    800039d4:	6da2                	ld	s11,8(sp)
    800039d6:	a831                	j	800039f2 <readi+0xe0>
    800039d8:	6946                	ld	s2,80(sp)
    800039da:	7c02                	ld	s8,32(sp)
    800039dc:	6ce2                	ld	s9,24(sp)
    800039de:	6d42                	ld	s10,16(sp)
    800039e0:	6da2                	ld	s11,8(sp)
    800039e2:	a801                	j	800039f2 <readi+0xe0>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800039e4:	89d6                	mv	s3,s5
    800039e6:	a031                	j	800039f2 <readi+0xe0>
    800039e8:	6946                	ld	s2,80(sp)
    800039ea:	7c02                	ld	s8,32(sp)
    800039ec:	6ce2                	ld	s9,24(sp)
    800039ee:	6d42                	ld	s10,16(sp)
    800039f0:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800039f2:	0009851b          	sext.w	a0,s3
    800039f6:	69a6                	ld	s3,72(sp)
}
    800039f8:	70a6                	ld	ra,104(sp)
    800039fa:	7406                	ld	s0,96(sp)
    800039fc:	64e6                	ld	s1,88(sp)
    800039fe:	6a06                	ld	s4,64(sp)
    80003a00:	7ae2                	ld	s5,56(sp)
    80003a02:	7b42                	ld	s6,48(sp)
    80003a04:	7ba2                	ld	s7,40(sp)
    80003a06:	6165                	addi	sp,sp,112
    80003a08:	8082                	ret
    return 0;
    80003a0a:	4501                	li	a0,0
}
    80003a0c:	8082                	ret

0000000080003a0e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003a0e:	457c                	lw	a5,76(a0)
    80003a10:	10d7e363          	bltu	a5,a3,80003b16 <writei+0x108>
{
    80003a14:	7159                	addi	sp,sp,-112
    80003a16:	f486                	sd	ra,104(sp)
    80003a18:	f0a2                	sd	s0,96(sp)
    80003a1a:	e8ca                	sd	s2,80(sp)
    80003a1c:	e0d2                	sd	s4,64(sp)
    80003a1e:	fc56                	sd	s5,56(sp)
    80003a20:	f85a                	sd	s6,48(sp)
    80003a22:	f45e                	sd	s7,40(sp)
    80003a24:	1880                	addi	s0,sp,112
    80003a26:	8aaa                	mv	s5,a0
    80003a28:	8bae                	mv	s7,a1
    80003a2a:	8a32                	mv	s4,a2
    80003a2c:	8936                	mv	s2,a3
    80003a2e:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003a30:	00e687bb          	addw	a5,a3,a4
    80003a34:	0ed7e363          	bltu	a5,a3,80003b1a <writei+0x10c>
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003a38:	00043737          	lui	a4,0x43
    80003a3c:	0ef76163          	bltu	a4,a5,80003b1e <writei+0x110>
    80003a40:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003a42:	0c0b0263          	beqz	s6,80003b06 <writei+0xf8>
    80003a46:	eca6                	sd	s1,88(sp)
    80003a48:	f062                	sd	s8,32(sp)
    80003a4a:	ec66                	sd	s9,24(sp)
    80003a4c:	e86a                	sd	s10,16(sp)
    80003a4e:	e46e                	sd	s11,8(sp)
    80003a50:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003a52:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003a56:	5c7d                	li	s8,-1
    80003a58:	a825                	j	80003a90 <writei+0x82>
    80003a5a:	020d1d93          	slli	s11,s10,0x20
    80003a5e:	020ddd93          	srli	s11,s11,0x20
    80003a62:	05848513          	addi	a0,s1,88
    80003a66:	86ee                	mv	a3,s11
    80003a68:	8652                	mv	a2,s4
    80003a6a:	85de                	mv	a1,s7
    80003a6c:	953a                	add	a0,a0,a4
    80003a6e:	8b5fe0ef          	jal	80002322 <either_copyin>
    80003a72:	05850a63          	beq	a0,s8,80003ac6 <writei+0xb8>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003a76:	8526                	mv	a0,s1
    80003a78:	6b0000ef          	jal	80004128 <log_write>
    brelse(bp);
    80003a7c:	8526                	mv	a0,s1
    80003a7e:	cf8ff0ef          	jal	80002f76 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003a82:	013d09bb          	addw	s3,s10,s3
    80003a86:	012d093b          	addw	s2,s10,s2
    80003a8a:	9a6e                	add	s4,s4,s11
    80003a8c:	0569f363          	bgeu	s3,s6,80003ad2 <writei+0xc4>
    uint addr = bmap(ip, off / BSIZE);
    80003a90:	00a9559b          	srliw	a1,s2,0xa
    80003a94:	8556                	mv	a0,s5
    80003a96:	f5cff0ef          	jal	800031f2 <bmap>
    80003a9a:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    80003a9e:	c995                	beqz	a1,80003ad2 <writei+0xc4>
    bp = bread(ip->dev, addr);
    80003aa0:	000aa503          	lw	a0,0(s5)
    80003aa4:	bcaff0ef          	jal	80002e6e <bread>
    80003aa8:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003aaa:	3ff97713          	andi	a4,s2,1023
    80003aae:	40ec87bb          	subw	a5,s9,a4
    80003ab2:	413b06bb          	subw	a3,s6,s3
    80003ab6:	8d3e                	mv	s10,a5
    80003ab8:	2781                	sext.w	a5,a5
    80003aba:	0006861b          	sext.w	a2,a3
    80003abe:	f8f67ee3          	bgeu	a2,a5,80003a5a <writei+0x4c>
    80003ac2:	8d36                	mv	s10,a3
    80003ac4:	bf59                	j	80003a5a <writei+0x4c>
      log_write(bp);
    80003ac6:	8526                	mv	a0,s1
    80003ac8:	660000ef          	jal	80004128 <log_write>
      brelse(bp);
    80003acc:	8526                	mv	a0,s1
    80003ace:	ca8ff0ef          	jal	80002f76 <brelse>
  }

  if (off > ip->size)
    80003ad2:	04caa783          	lw	a5,76(s5)
    80003ad6:	0327fa63          	bgeu	a5,s2,80003b0a <writei+0xfc>
    ip->size = off;
    80003ada:	052aa623          	sw	s2,76(s5)
    80003ade:	64e6                	ld	s1,88(sp)
    80003ae0:	7c02                	ld	s8,32(sp)
    80003ae2:	6ce2                	ld	s9,24(sp)
    80003ae4:	6d42                	ld	s10,16(sp)
    80003ae6:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003ae8:	8556                	mv	a0,s5
    80003aea:	99dff0ef          	jal	80003486 <iupdate>

  return tot;
    80003aee:	0009851b          	sext.w	a0,s3
    80003af2:	69a6                	ld	s3,72(sp)
}
    80003af4:	70a6                	ld	ra,104(sp)
    80003af6:	7406                	ld	s0,96(sp)
    80003af8:	6946                	ld	s2,80(sp)
    80003afa:	6a06                	ld	s4,64(sp)
    80003afc:	7ae2                	ld	s5,56(sp)
    80003afe:	7b42                	ld	s6,48(sp)
    80003b00:	7ba2                	ld	s7,40(sp)
    80003b02:	6165                	addi	sp,sp,112
    80003b04:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003b06:	89da                	mv	s3,s6
    80003b08:	b7c5                	j	80003ae8 <writei+0xda>
    80003b0a:	64e6                	ld	s1,88(sp)
    80003b0c:	7c02                	ld	s8,32(sp)
    80003b0e:	6ce2                	ld	s9,24(sp)
    80003b10:	6d42                	ld	s10,16(sp)
    80003b12:	6da2                	ld	s11,8(sp)
    80003b14:	bfd1                	j	80003ae8 <writei+0xda>
    return -1;
    80003b16:	557d                	li	a0,-1
}
    80003b18:	8082                	ret
    return -1;
    80003b1a:	557d                	li	a0,-1
    80003b1c:	bfe1                	j	80003af4 <writei+0xe6>
    return -1;
    80003b1e:	557d                	li	a0,-1
    80003b20:	bfd1                	j	80003af4 <writei+0xe6>

0000000080003b22 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003b22:	1141                	addi	sp,sp,-16
    80003b24:	e406                	sd	ra,8(sp)
    80003b26:	e022                	sd	s0,0(sp)
    80003b28:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003b2a:	4639                	li	a2,14
    80003b2c:	9f2fd0ef          	jal	80000d1e <strncmp>
}
    80003b30:	60a2                	ld	ra,8(sp)
    80003b32:	6402                	ld	s0,0(sp)
    80003b34:	0141                	addi	sp,sp,16
    80003b36:	8082                	ret

0000000080003b38 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003b38:	7139                	addi	sp,sp,-64
    80003b3a:	fc06                	sd	ra,56(sp)
    80003b3c:	f822                	sd	s0,48(sp)
    80003b3e:	f426                	sd	s1,40(sp)
    80003b40:	f04a                	sd	s2,32(sp)
    80003b42:	ec4e                	sd	s3,24(sp)
    80003b44:	e852                	sd	s4,16(sp)
    80003b46:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003b48:	04451703          	lh	a4,68(a0)
    80003b4c:	4785                	li	a5,1
    80003b4e:	00f71a63          	bne	a4,a5,80003b62 <dirlookup+0x2a>
    80003b52:	892a                	mv	s2,a0
    80003b54:	89ae                	mv	s3,a1
    80003b56:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b58:	457c                	lw	a5,76(a0)
    80003b5a:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003b5c:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b5e:	e39d                	bnez	a5,80003b84 <dirlookup+0x4c>
    80003b60:	a095                	j	80003bc4 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003b62:	00006517          	auipc	a0,0x6
    80003b66:	9be50513          	addi	a0,a0,-1602 # 80009520 <etext+0x520>
    80003b6a:	c85fc0ef          	jal	800007ee <panic>
      panic("dirlookup read");
    80003b6e:	00006517          	auipc	a0,0x6
    80003b72:	9ca50513          	addi	a0,a0,-1590 # 80009538 <etext+0x538>
    80003b76:	c79fc0ef          	jal	800007ee <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b7a:	24c1                	addiw	s1,s1,16
    80003b7c:	04c92783          	lw	a5,76(s2)
    80003b80:	04f4f163          	bgeu	s1,a5,80003bc2 <dirlookup+0x8a>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b84:	4741                	li	a4,16
    80003b86:	86a6                	mv	a3,s1
    80003b88:	fc040613          	addi	a2,s0,-64
    80003b8c:	4581                	li	a1,0
    80003b8e:	854a                	mv	a0,s2
    80003b90:	d83ff0ef          	jal	80003912 <readi>
    80003b94:	47c1                	li	a5,16
    80003b96:	fcf51ce3          	bne	a0,a5,80003b6e <dirlookup+0x36>
    if (de.inum == 0)
    80003b9a:	fc045783          	lhu	a5,-64(s0)
    80003b9e:	dff1                	beqz	a5,80003b7a <dirlookup+0x42>
    if (namecmp(name, de.name) == 0) {
    80003ba0:	fc240593          	addi	a1,s0,-62
    80003ba4:	854e                	mv	a0,s3
    80003ba6:	f7dff0ef          	jal	80003b22 <namecmp>
    80003baa:	f961                	bnez	a0,80003b7a <dirlookup+0x42>
      if (poff)
    80003bac:	000a0463          	beqz	s4,80003bb4 <dirlookup+0x7c>
        *poff = off;
    80003bb0:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003bb4:	fc045583          	lhu	a1,-64(s0)
    80003bb8:	00092503          	lw	a0,0(s2)
    80003bbc:	f0aff0ef          	jal	800032c6 <iget>
    80003bc0:	a011                	j	80003bc4 <dirlookup+0x8c>
  return 0;
    80003bc2:	4501                	li	a0,0
}
    80003bc4:	70e2                	ld	ra,56(sp)
    80003bc6:	7442                	ld	s0,48(sp)
    80003bc8:	74a2                	ld	s1,40(sp)
    80003bca:	7902                	ld	s2,32(sp)
    80003bcc:	69e2                	ld	s3,24(sp)
    80003bce:	6a42                	ld	s4,16(sp)
    80003bd0:	6121                	addi	sp,sp,64
    80003bd2:	8082                	ret

0000000080003bd4 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003bd4:	711d                	addi	sp,sp,-96
    80003bd6:	ec86                	sd	ra,88(sp)
    80003bd8:	e8a2                	sd	s0,80(sp)
    80003bda:	e4a6                	sd	s1,72(sp)
    80003bdc:	e0ca                	sd	s2,64(sp)
    80003bde:	fc4e                	sd	s3,56(sp)
    80003be0:	f852                	sd	s4,48(sp)
    80003be2:	f456                	sd	s5,40(sp)
    80003be4:	f05a                	sd	s6,32(sp)
    80003be6:	ec5e                	sd	s7,24(sp)
    80003be8:	e862                	sd	s8,16(sp)
    80003bea:	e466                	sd	s9,8(sp)
    80003bec:	1080                	addi	s0,sp,96
    80003bee:	84aa                	mv	s1,a0
    80003bf0:	8b2e                	mv	s6,a1
    80003bf2:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003bf4:	00054703          	lbu	a4,0(a0)
    80003bf8:	02f00793          	li	a5,47
    80003bfc:	00f70e63          	beq	a4,a5,80003c18 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003c00:	c99fd0ef          	jal	80001898 <myproc>
    80003c04:	15053503          	ld	a0,336(a0)
    80003c08:	8fdff0ef          	jal	80003504 <idup>
    80003c0c:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003c0e:	02f00913          	li	s2,47
  if (len >= DIRSIZ)
    80003c12:	4c35                	li	s8,13

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003c14:	4b85                	li	s7,1
    80003c16:	a075                	j	80003cc2 <namex+0xee>
    ip = iget(ROOTDEV, ROOTINO);
    80003c18:	4585                	li	a1,1
    80003c1a:	4505                	li	a0,1
    80003c1c:	eaaff0ef          	jal	800032c6 <iget>
    80003c20:	8a2a                	mv	s4,a0
    80003c22:	b7f5                	j	80003c0e <namex+0x3a>
      iunlockput(ip);
    80003c24:	8552                	mv	a0,s4
    80003c26:	b67ff0ef          	jal	8000378c <iunlockput>
      return 0;
    80003c2a:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003c2c:	8552                	mv	a0,s4
    80003c2e:	60e6                	ld	ra,88(sp)
    80003c30:	6446                	ld	s0,80(sp)
    80003c32:	64a6                	ld	s1,72(sp)
    80003c34:	6906                	ld	s2,64(sp)
    80003c36:	79e2                	ld	s3,56(sp)
    80003c38:	7a42                	ld	s4,48(sp)
    80003c3a:	7aa2                	ld	s5,40(sp)
    80003c3c:	7b02                	ld	s6,32(sp)
    80003c3e:	6be2                	ld	s7,24(sp)
    80003c40:	6c42                	ld	s8,16(sp)
    80003c42:	6ca2                	ld	s9,8(sp)
    80003c44:	6125                	addi	sp,sp,96
    80003c46:	8082                	ret
      iunlockput(ip);
    80003c48:	8552                	mv	a0,s4
    80003c4a:	b43ff0ef          	jal	8000378c <iunlockput>
      return 0;
    80003c4e:	4a01                	li	s4,0
    80003c50:	bff1                	j	80003c2c <namex+0x58>
      iunlock(ip);
    80003c52:	8552                	mv	a0,s4
    80003c54:	995ff0ef          	jal	800035e8 <iunlock>
      return ip;
    80003c58:	bfd1                	j	80003c2c <namex+0x58>
      iunlockput(ip);
    80003c5a:	8552                	mv	a0,s4
    80003c5c:	b31ff0ef          	jal	8000378c <iunlockput>
      return 0;
    80003c60:	8a4e                	mv	s4,s3
    80003c62:	b7e9                	j	80003c2c <namex+0x58>
  len = path - s;
    80003c64:	40998633          	sub	a2,s3,s1
    80003c68:	00060c9b          	sext.w	s9,a2
  if (len >= DIRSIZ)
    80003c6c:	099c5363          	bge	s8,s9,80003cf2 <namex+0x11e>
    memmove(name, s, DIRSIZ);
    80003c70:	4639                	li	a2,14
    80003c72:	85a6                	mv	a1,s1
    80003c74:	8556                	mv	a0,s5
    80003c76:	838fd0ef          	jal	80000cae <memmove>
    80003c7a:	84ce                	mv	s1,s3
  while (*path == '/')
    80003c7c:	0004c783          	lbu	a5,0(s1)
    80003c80:	01279763          	bne	a5,s2,80003c8e <namex+0xba>
    path++;
    80003c84:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003c86:	0004c783          	lbu	a5,0(s1)
    80003c8a:	ff278de3          	beq	a5,s2,80003c84 <namex+0xb0>
    ilock(ip);
    80003c8e:	8552                	mv	a0,s4
    80003c90:	8abff0ef          	jal	8000353a <ilock>
    if (ip->type != T_DIR) {
    80003c94:	044a1783          	lh	a5,68(s4)
    80003c98:	f97796e3          	bne	a5,s7,80003c24 <namex+0x50>
    if (ip->nlink == 0) {
    80003c9c:	04aa1783          	lh	a5,74(s4)
    80003ca0:	d7c5                	beqz	a5,80003c48 <namex+0x74>
    if (nameiparent && *path == '\0') {
    80003ca2:	000b0563          	beqz	s6,80003cac <namex+0xd8>
    80003ca6:	0004c783          	lbu	a5,0(s1)
    80003caa:	d7c5                	beqz	a5,80003c52 <namex+0x7e>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003cac:	4601                	li	a2,0
    80003cae:	85d6                	mv	a1,s5
    80003cb0:	8552                	mv	a0,s4
    80003cb2:	e87ff0ef          	jal	80003b38 <dirlookup>
    80003cb6:	89aa                	mv	s3,a0
    80003cb8:	d14d                	beqz	a0,80003c5a <namex+0x86>
    iunlockput(ip);
    80003cba:	8552                	mv	a0,s4
    80003cbc:	ad1ff0ef          	jal	8000378c <iunlockput>
    ip = next;
    80003cc0:	8a4e                	mv	s4,s3
  while (*path == '/')
    80003cc2:	0004c783          	lbu	a5,0(s1)
    80003cc6:	01279763          	bne	a5,s2,80003cd4 <namex+0x100>
    path++;
    80003cca:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003ccc:	0004c783          	lbu	a5,0(s1)
    80003cd0:	ff278de3          	beq	a5,s2,80003cca <namex+0xf6>
  if (*path == 0)
    80003cd4:	cb8d                	beqz	a5,80003d06 <namex+0x132>
  while (*path != '/' && *path != 0)
    80003cd6:	0004c783          	lbu	a5,0(s1)
    80003cda:	89a6                	mv	s3,s1
  len = path - s;
    80003cdc:	4c81                	li	s9,0
    80003cde:	4601                	li	a2,0
  while (*path != '/' && *path != 0)
    80003ce0:	01278963          	beq	a5,s2,80003cf2 <namex+0x11e>
    80003ce4:	d3c1                	beqz	a5,80003c64 <namex+0x90>
    path++;
    80003ce6:	0985                	addi	s3,s3,1
  while (*path != '/' && *path != 0)
    80003ce8:	0009c783          	lbu	a5,0(s3)
    80003cec:	ff279ce3          	bne	a5,s2,80003ce4 <namex+0x110>
    80003cf0:	bf95                	j	80003c64 <namex+0x90>
    memmove(name, s, len);
    80003cf2:	2601                	sext.w	a2,a2
    80003cf4:	85a6                	mv	a1,s1
    80003cf6:	8556                	mv	a0,s5
    80003cf8:	fb7fc0ef          	jal	80000cae <memmove>
    name[len] = 0;
    80003cfc:	9cd6                	add	s9,s9,s5
    80003cfe:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003d02:	84ce                	mv	s1,s3
    80003d04:	bfa5                	j	80003c7c <namex+0xa8>
  if (nameiparent) {
    80003d06:	f20b03e3          	beqz	s6,80003c2c <namex+0x58>
    iput(ip);
    80003d0a:	8552                	mv	a0,s4
    80003d0c:	9b1ff0ef          	jal	800036bc <iput>
    return 0;
    80003d10:	4a01                	li	s4,0
    80003d12:	bf29                	j	80003c2c <namex+0x58>

0000000080003d14 <dirlink>:
{
    80003d14:	7139                	addi	sp,sp,-64
    80003d16:	fc06                	sd	ra,56(sp)
    80003d18:	f822                	sd	s0,48(sp)
    80003d1a:	f04a                	sd	s2,32(sp)
    80003d1c:	ec4e                	sd	s3,24(sp)
    80003d1e:	e852                	sd	s4,16(sp)
    80003d20:	0080                	addi	s0,sp,64
    80003d22:	892a                	mv	s2,a0
    80003d24:	8a2e                	mv	s4,a1
    80003d26:	89b2                	mv	s3,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003d28:	4601                	li	a2,0
    80003d2a:	e0fff0ef          	jal	80003b38 <dirlookup>
    80003d2e:	e535                	bnez	a0,80003d9a <dirlink+0x86>
    80003d30:	f426                	sd	s1,40(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003d32:	04c92483          	lw	s1,76(s2)
    80003d36:	c48d                	beqz	s1,80003d60 <dirlink+0x4c>
    80003d38:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d3a:	4741                	li	a4,16
    80003d3c:	86a6                	mv	a3,s1
    80003d3e:	fc040613          	addi	a2,s0,-64
    80003d42:	4581                	li	a1,0
    80003d44:	854a                	mv	a0,s2
    80003d46:	bcdff0ef          	jal	80003912 <readi>
    80003d4a:	47c1                	li	a5,16
    80003d4c:	04f51b63          	bne	a0,a5,80003da2 <dirlink+0x8e>
    if (de.inum == 0)
    80003d50:	fc045783          	lhu	a5,-64(s0)
    80003d54:	c791                	beqz	a5,80003d60 <dirlink+0x4c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003d56:	24c1                	addiw	s1,s1,16
    80003d58:	04c92783          	lw	a5,76(s2)
    80003d5c:	fcf4efe3          	bltu	s1,a5,80003d3a <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003d60:	4639                	li	a2,14
    80003d62:	85d2                	mv	a1,s4
    80003d64:	fc240513          	addi	a0,s0,-62
    80003d68:	fedfc0ef          	jal	80000d54 <strncpy>
  de.inum = inum;
    80003d6c:	fd341023          	sh	s3,-64(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d70:	4741                	li	a4,16
    80003d72:	86a6                	mv	a3,s1
    80003d74:	fc040613          	addi	a2,s0,-64
    80003d78:	4581                	li	a1,0
    80003d7a:	854a                	mv	a0,s2
    80003d7c:	c93ff0ef          	jal	80003a0e <writei>
    80003d80:	1541                	addi	a0,a0,-16
    80003d82:	00a03533          	snez	a0,a0
    80003d86:	40a00533          	neg	a0,a0
    80003d8a:	74a2                	ld	s1,40(sp)
}
    80003d8c:	70e2                	ld	ra,56(sp)
    80003d8e:	7442                	ld	s0,48(sp)
    80003d90:	7902                	ld	s2,32(sp)
    80003d92:	69e2                	ld	s3,24(sp)
    80003d94:	6a42                	ld	s4,16(sp)
    80003d96:	6121                	addi	sp,sp,64
    80003d98:	8082                	ret
    iput(ip);
    80003d9a:	923ff0ef          	jal	800036bc <iput>
    return -1;
    80003d9e:	557d                	li	a0,-1
    80003da0:	b7f5                	j	80003d8c <dirlink+0x78>
      panic("dirlink read");
    80003da2:	00005517          	auipc	a0,0x5
    80003da6:	7a650513          	addi	a0,a0,1958 # 80009548 <etext+0x548>
    80003daa:	a45fc0ef          	jal	800007ee <panic>

0000000080003dae <namei>:

struct inode *
namei(char *path)
{
    80003dae:	1101                	addi	sp,sp,-32
    80003db0:	ec06                	sd	ra,24(sp)
    80003db2:	e822                	sd	s0,16(sp)
    80003db4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003db6:	fe040613          	addi	a2,s0,-32
    80003dba:	4581                	li	a1,0
    80003dbc:	e19ff0ef          	jal	80003bd4 <namex>
}
    80003dc0:	60e2                	ld	ra,24(sp)
    80003dc2:	6442                	ld	s0,16(sp)
    80003dc4:	6105                	addi	sp,sp,32
    80003dc6:	8082                	ret

0000000080003dc8 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003dc8:	1141                	addi	sp,sp,-16
    80003dca:	e406                	sd	ra,8(sp)
    80003dcc:	e022                	sd	s0,0(sp)
    80003dce:	0800                	addi	s0,sp,16
    80003dd0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003dd2:	4585                	li	a1,1
    80003dd4:	e01ff0ef          	jal	80003bd4 <namex>
}
    80003dd8:	60a2                	ld	ra,8(sp)
    80003dda:	6402                	ld	s0,0(sp)
    80003ddc:	0141                	addi	sp,sp,16
    80003dde:	8082                	ret

0000000080003de0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003de0:	1101                	addi	sp,sp,-32
    80003de2:	ec06                	sd	ra,24(sp)
    80003de4:	e822                	sd	s0,16(sp)
    80003de6:	e426                	sd	s1,8(sp)
    80003de8:	e04a                	sd	s2,0(sp)
    80003dea:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003dec:	00022917          	auipc	s2,0x22
    80003df0:	56490913          	addi	s2,s2,1380 # 80026350 <log>
    80003df4:	01892583          	lw	a1,24(s2)
    80003df8:	02492503          	lw	a0,36(s2)
    80003dfc:	872ff0ef          	jal	80002e6e <bread>
    80003e00:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003e02:	02c92603          	lw	a2,44(s2)
    80003e06:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003e08:	00c05f63          	blez	a2,80003e26 <write_head+0x46>
    80003e0c:	00022717          	auipc	a4,0x22
    80003e10:	57470713          	addi	a4,a4,1396 # 80026380 <log+0x30>
    80003e14:	87aa                	mv	a5,a0
    80003e16:	060a                	slli	a2,a2,0x2
    80003e18:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003e1a:	4314                	lw	a3,0(a4)
    80003e1c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003e1e:	0711                	addi	a4,a4,4
    80003e20:	0791                	addi	a5,a5,4
    80003e22:	fec79ce3          	bne	a5,a2,80003e1a <write_head+0x3a>
  }
  bwrite(buf);
    80003e26:	8526                	mv	a0,s1
    80003e28:	91cff0ef          	jal	80002f44 <bwrite>
  brelse(buf);
    80003e2c:	8526                	mv	a0,s1
    80003e2e:	948ff0ef          	jal	80002f76 <brelse>
}
    80003e32:	60e2                	ld	ra,24(sp)
    80003e34:	6442                	ld	s0,16(sp)
    80003e36:	64a2                	ld	s1,8(sp)
    80003e38:	6902                	ld	s2,0(sp)
    80003e3a:	6105                	addi	sp,sp,32
    80003e3c:	8082                	ret

0000000080003e3e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e3e:	00022797          	auipc	a5,0x22
    80003e42:	53e7a783          	lw	a5,1342(a5) # 8002637c <log+0x2c>
    80003e46:	0af05e63          	blez	a5,80003f02 <install_trans+0xc4>
{
    80003e4a:	715d                	addi	sp,sp,-80
    80003e4c:	e486                	sd	ra,72(sp)
    80003e4e:	e0a2                	sd	s0,64(sp)
    80003e50:	fc26                	sd	s1,56(sp)
    80003e52:	f84a                	sd	s2,48(sp)
    80003e54:	f44e                	sd	s3,40(sp)
    80003e56:	f052                	sd	s4,32(sp)
    80003e58:	ec56                	sd	s5,24(sp)
    80003e5a:	e85a                	sd	s6,16(sp)
    80003e5c:	e45e                	sd	s7,8(sp)
    80003e5e:	0880                	addi	s0,sp,80
    80003e60:	8b2a                	mv	s6,a0
    80003e62:	00022a97          	auipc	s5,0x22
    80003e66:	51ea8a93          	addi	s5,s5,1310 # 80026380 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e6a:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003e6c:	00005b97          	auipc	s7,0x5
    80003e70:	6ecb8b93          	addi	s7,s7,1772 # 80009558 <etext+0x558>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003e74:	00022a17          	auipc	s4,0x22
    80003e78:	4dca0a13          	addi	s4,s4,1244 # 80026350 <log>
    80003e7c:	a025                	j	80003ea4 <install_trans+0x66>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003e7e:	000aa603          	lw	a2,0(s5)
    80003e82:	85ce                	mv	a1,s3
    80003e84:	855e                	mv	a0,s7
    80003e86:	e82fc0ef          	jal	80000508 <printk>
    80003e8a:	a839                	j	80003ea8 <install_trans+0x6a>
    brelse(lbuf);
    80003e8c:	854a                	mv	a0,s2
    80003e8e:	8e8ff0ef          	jal	80002f76 <brelse>
    brelse(dbuf);
    80003e92:	8526                	mv	a0,s1
    80003e94:	8e2ff0ef          	jal	80002f76 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e98:	2985                	addiw	s3,s3,1
    80003e9a:	0a91                	addi	s5,s5,4
    80003e9c:	02ca2783          	lw	a5,44(s4)
    80003ea0:	04f9d663          	bge	s3,a5,80003eec <install_trans+0xae>
    if (recovering) {
    80003ea4:	fc0b1de3          	bnez	s6,80003e7e <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003ea8:	018a2583          	lw	a1,24(s4)
    80003eac:	013585bb          	addw	a1,a1,s3
    80003eb0:	2585                	addiw	a1,a1,1
    80003eb2:	024a2503          	lw	a0,36(s4)
    80003eb6:	fb9fe0ef          	jal	80002e6e <bread>
    80003eba:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003ebc:	000aa583          	lw	a1,0(s5)
    80003ec0:	024a2503          	lw	a0,36(s4)
    80003ec4:	fabfe0ef          	jal	80002e6e <bread>
    80003ec8:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003eca:	40000613          	li	a2,1024
    80003ece:	05890593          	addi	a1,s2,88
    80003ed2:	05850513          	addi	a0,a0,88
    80003ed6:	dd9fc0ef          	jal	80000cae <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003eda:	8526                	mv	a0,s1
    80003edc:	868ff0ef          	jal	80002f44 <bwrite>
    if (recovering == 0)
    80003ee0:	fa0b16e3          	bnez	s6,80003e8c <install_trans+0x4e>
      bunpin(dbuf);
    80003ee4:	8526                	mv	a0,s1
    80003ee6:	94cff0ef          	jal	80003032 <bunpin>
    80003eea:	b74d                	j	80003e8c <install_trans+0x4e>
}
    80003eec:	60a6                	ld	ra,72(sp)
    80003eee:	6406                	ld	s0,64(sp)
    80003ef0:	74e2                	ld	s1,56(sp)
    80003ef2:	7942                	ld	s2,48(sp)
    80003ef4:	79a2                	ld	s3,40(sp)
    80003ef6:	7a02                	ld	s4,32(sp)
    80003ef8:	6ae2                	ld	s5,24(sp)
    80003efa:	6b42                	ld	s6,16(sp)
    80003efc:	6ba2                	ld	s7,8(sp)
    80003efe:	6161                	addi	sp,sp,80
    80003f00:	8082                	ret
    80003f02:	8082                	ret

0000000080003f04 <initlog>:
{
    80003f04:	7179                	addi	sp,sp,-48
    80003f06:	f406                	sd	ra,40(sp)
    80003f08:	f022                	sd	s0,32(sp)
    80003f0a:	ec26                	sd	s1,24(sp)
    80003f0c:	e84a                	sd	s2,16(sp)
    80003f0e:	e44e                	sd	s3,8(sp)
    80003f10:	1800                	addi	s0,sp,48
    80003f12:	892a                	mv	s2,a0
    80003f14:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003f16:	00022497          	auipc	s1,0x22
    80003f1a:	43a48493          	addi	s1,s1,1082 # 80026350 <log>
    80003f1e:	00005597          	auipc	a1,0x5
    80003f22:	65a58593          	addi	a1,a1,1626 # 80009578 <etext+0x578>
    80003f26:	8526                	mv	a0,s1
    80003f28:	bf1fc0ef          	jal	80000b18 <initlock>
  log.start = sb->logstart;
    80003f2c:	0149a583          	lw	a1,20(s3)
    80003f30:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003f32:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003f36:	854a                	mv	a0,s2
    80003f38:	f37fe0ef          	jal	80002e6e <bread>
  log.lh.n = lh->n;
    80003f3c:	4d30                	lw	a2,88(a0)
    80003f3e:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003f40:	00c05f63          	blez	a2,80003f5e <initlog+0x5a>
    80003f44:	87aa                	mv	a5,a0
    80003f46:	00022717          	auipc	a4,0x22
    80003f4a:	43a70713          	addi	a4,a4,1082 # 80026380 <log+0x30>
    80003f4e:	060a                	slli	a2,a2,0x2
    80003f50:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003f52:	4ff4                	lw	a3,92(a5)
    80003f54:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003f56:	0791                	addi	a5,a5,4
    80003f58:	0711                	addi	a4,a4,4
    80003f5a:	fec79ce3          	bne	a5,a2,80003f52 <initlog+0x4e>
  brelse(buf);
    80003f5e:	818ff0ef          	jal	80002f76 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003f62:	4505                	li	a0,1
    80003f64:	edbff0ef          	jal	80003e3e <install_trans>
  log.lh.n = 0;
    80003f68:	00022797          	auipc	a5,0x22
    80003f6c:	4007aa23          	sw	zero,1044(a5) # 8002637c <log+0x2c>
  write_head(); // clear the log
    80003f70:	e71ff0ef          	jal	80003de0 <write_head>
}
    80003f74:	70a2                	ld	ra,40(sp)
    80003f76:	7402                	ld	s0,32(sp)
    80003f78:	64e2                	ld	s1,24(sp)
    80003f7a:	6942                	ld	s2,16(sp)
    80003f7c:	69a2                	ld	s3,8(sp)
    80003f7e:	6145                	addi	sp,sp,48
    80003f80:	8082                	ret

0000000080003f82 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003f82:	1101                	addi	sp,sp,-32
    80003f84:	ec06                	sd	ra,24(sp)
    80003f86:	e822                	sd	s0,16(sp)
    80003f88:	e426                	sd	s1,8(sp)
    80003f8a:	e04a                	sd	s2,0(sp)
    80003f8c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003f8e:	00022517          	auipc	a0,0x22
    80003f92:	3c250513          	addi	a0,a0,962 # 80026350 <log>
    80003f96:	bf9fc0ef          	jal	80000b8e <acquire>
  while (1) {
    if (log.committing) {
    80003f9a:	00022497          	auipc	s1,0x22
    80003f9e:	3b648493          	addi	s1,s1,950 # 80026350 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003fa2:	4979                	li	s2,30
    80003fa4:	a821                	j	80003fbc <begin_op+0x3a>
      sleep_prepare(&log);
    80003fa6:	8526                	mv	a0,s1
    80003fa8:	f89fd0ef          	jal	80001f30 <sleep_prepare>
      release(&log.lock);
    80003fac:	8526                	mv	a0,s1
    80003fae:	c6dfc0ef          	jal	80000c1a <release>
      sleep();
    80003fb2:	fbbfd0ef          	jal	80001f6c <sleep>
      acquire(&log.lock);
    80003fb6:	8526                	mv	a0,s1
    80003fb8:	bd7fc0ef          	jal	80000b8e <acquire>
    if (log.committing) {
    80003fbc:	509c                	lw	a5,32(s1)
    80003fbe:	f7e5                	bnez	a5,80003fa6 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003fc0:	4cd8                	lw	a4,28(s1)
    80003fc2:	2705                	addiw	a4,a4,1
    80003fc4:	0027179b          	slliw	a5,a4,0x2
    80003fc8:	9fb9                	addw	a5,a5,a4
    80003fca:	0017979b          	slliw	a5,a5,0x1
    80003fce:	54d4                	lw	a3,44(s1)
    80003fd0:	9fb5                	addw	a5,a5,a3
    80003fd2:	00f95e63          	bge	s2,a5,80003fee <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003fd6:	8526                	mv	a0,s1
    80003fd8:	f59fd0ef          	jal	80001f30 <sleep_prepare>
      release(&log.lock);
    80003fdc:	8526                	mv	a0,s1
    80003fde:	c3dfc0ef          	jal	80000c1a <release>
      sleep();
    80003fe2:	f8bfd0ef          	jal	80001f6c <sleep>
      acquire(&log.lock);
    80003fe6:	8526                	mv	a0,s1
    80003fe8:	ba7fc0ef          	jal	80000b8e <acquire>
    80003fec:	bfc1                	j	80003fbc <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003fee:	00022517          	auipc	a0,0x22
    80003ff2:	36250513          	addi	a0,a0,866 # 80026350 <log>
    80003ff6:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003ff8:	c23fc0ef          	jal	80000c1a <release>
      break;
    }
  }
}
    80003ffc:	60e2                	ld	ra,24(sp)
    80003ffe:	6442                	ld	s0,16(sp)
    80004000:	64a2                	ld	s1,8(sp)
    80004002:	6902                	ld	s2,0(sp)
    80004004:	6105                	addi	sp,sp,32
    80004006:	8082                	ret

0000000080004008 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004008:	7139                	addi	sp,sp,-64
    8000400a:	fc06                	sd	ra,56(sp)
    8000400c:	f822                	sd	s0,48(sp)
    8000400e:	f426                	sd	s1,40(sp)
    80004010:	f04a                	sd	s2,32(sp)
    80004012:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004014:	00022497          	auipc	s1,0x22
    80004018:	33c48493          	addi	s1,s1,828 # 80026350 <log>
    8000401c:	8526                	mv	a0,s1
    8000401e:	b71fc0ef          	jal	80000b8e <acquire>
  log.outstanding -= 1;
    80004022:	4cdc                	lw	a5,28(s1)
    80004024:	37fd                	addiw	a5,a5,-1
    80004026:	0007891b          	sext.w	s2,a5
    8000402a:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    8000402c:	509c                	lw	a5,32(s1)
    8000402e:	e3b1                	bnez	a5,80004072 <end_op+0x6a>
    panic("log.committing");
  if (log.outstanding == 0) {
    80004030:	04091a63          	bnez	s2,80004084 <end_op+0x7c>
    do_commit = 1;
    log.committing = 1;
    80004034:	00022497          	auipc	s1,0x22
    80004038:	31c48493          	addi	s1,s1,796 # 80026350 <log>
    8000403c:	4785                	li	a5,1
    8000403e:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80004040:	8526                	mv	a0,s1
    80004042:	bd9fc0ef          	jal	80000c1a <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80004046:	54dc                	lw	a5,44(s1)
    80004048:	04f04e63          	bgtz	a5,800040a4 <end_op+0x9c>
    acquire(&log.lock);
    8000404c:	00022497          	auipc	s1,0x22
    80004050:	30448493          	addi	s1,s1,772 # 80026350 <log>
    80004054:	8526                	mv	a0,s1
    80004056:	b39fc0ef          	jal	80000b8e <acquire>
    log.committing = 0;
    8000405a:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    8000405e:	549c                	lw	a5,40(s1)
    80004060:	2785                	addiw	a5,a5,1
    80004062:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80004064:	8526                	mv	a0,s1
    80004066:	f37fd0ef          	jal	80001f9c <wakeup>
    release(&log.lock);
    8000406a:	8526                	mv	a0,s1
    8000406c:	baffc0ef          	jal	80000c1a <release>
}
    80004070:	a025                	j	80004098 <end_op+0x90>
    80004072:	ec4e                	sd	s3,24(sp)
    80004074:	e852                	sd	s4,16(sp)
    80004076:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80004078:	00005517          	auipc	a0,0x5
    8000407c:	50850513          	addi	a0,a0,1288 # 80009580 <etext+0x580>
    80004080:	f6efc0ef          	jal	800007ee <panic>
    wakeup(&log);
    80004084:	00022497          	auipc	s1,0x22
    80004088:	2cc48493          	addi	s1,s1,716 # 80026350 <log>
    8000408c:	8526                	mv	a0,s1
    8000408e:	f0ffd0ef          	jal	80001f9c <wakeup>
  release(&log.lock);
    80004092:	8526                	mv	a0,s1
    80004094:	b87fc0ef          	jal	80000c1a <release>
}
    80004098:	70e2                	ld	ra,56(sp)
    8000409a:	7442                	ld	s0,48(sp)
    8000409c:	74a2                	ld	s1,40(sp)
    8000409e:	7902                	ld	s2,32(sp)
    800040a0:	6121                	addi	sp,sp,64
    800040a2:	8082                	ret
    800040a4:	ec4e                	sd	s3,24(sp)
    800040a6:	e852                	sd	s4,16(sp)
    800040a8:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    800040aa:	00022a97          	auipc	s5,0x22
    800040ae:	2d6a8a93          	addi	s5,s5,726 # 80026380 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    800040b2:	00022a17          	auipc	s4,0x22
    800040b6:	29ea0a13          	addi	s4,s4,670 # 80026350 <log>
    800040ba:	018a2583          	lw	a1,24(s4)
    800040be:	012585bb          	addw	a1,a1,s2
    800040c2:	2585                	addiw	a1,a1,1
    800040c4:	024a2503          	lw	a0,36(s4)
    800040c8:	da7fe0ef          	jal	80002e6e <bread>
    800040cc:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800040ce:	000aa583          	lw	a1,0(s5)
    800040d2:	024a2503          	lw	a0,36(s4)
    800040d6:	d99fe0ef          	jal	80002e6e <bread>
    800040da:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800040dc:	40000613          	li	a2,1024
    800040e0:	05850593          	addi	a1,a0,88
    800040e4:	05848513          	addi	a0,s1,88
    800040e8:	bc7fc0ef          	jal	80000cae <memmove>
    bwrite(to); // write the log
    800040ec:	8526                	mv	a0,s1
    800040ee:	e57fe0ef          	jal	80002f44 <bwrite>
    brelse(from);
    800040f2:	854e                	mv	a0,s3
    800040f4:	e83fe0ef          	jal	80002f76 <brelse>
    brelse(to);
    800040f8:	8526                	mv	a0,s1
    800040fa:	e7dfe0ef          	jal	80002f76 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800040fe:	2905                	addiw	s2,s2,1
    80004100:	0a91                	addi	s5,s5,4
    80004102:	02ca2783          	lw	a5,44(s4)
    80004106:	faf94ae3          	blt	s2,a5,800040ba <end_op+0xb2>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    8000410a:	cd7ff0ef          	jal	80003de0 <write_head>
    install_trans(0); // Now install writes to home locations
    8000410e:	4501                	li	a0,0
    80004110:	d2fff0ef          	jal	80003e3e <install_trans>
    log.lh.n = 0;
    80004114:	00022797          	auipc	a5,0x22
    80004118:	2607a423          	sw	zero,616(a5) # 8002637c <log+0x2c>
    write_head(); // Erase the transaction from the log
    8000411c:	cc5ff0ef          	jal	80003de0 <write_head>
    80004120:	69e2                	ld	s3,24(sp)
    80004122:	6a42                	ld	s4,16(sp)
    80004124:	6aa2                	ld	s5,8(sp)
    80004126:	b71d                	j	8000404c <end_op+0x44>

0000000080004128 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80004128:	1101                	addi	sp,sp,-32
    8000412a:	ec06                	sd	ra,24(sp)
    8000412c:	e822                	sd	s0,16(sp)
    8000412e:	e426                	sd	s1,8(sp)
    80004130:	e04a                	sd	s2,0(sp)
    80004132:	1000                	addi	s0,sp,32
    80004134:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004136:	00022917          	auipc	s2,0x22
    8000413a:	21a90913          	addi	s2,s2,538 # 80026350 <log>
    8000413e:	854a                	mv	a0,s2
    80004140:	a4ffc0ef          	jal	80000b8e <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004144:	02c92603          	lw	a2,44(s2)
    80004148:	47f5                	li	a5,29
    8000414a:	04c7cc63          	blt	a5,a2,800041a2 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000414e:	00022797          	auipc	a5,0x22
    80004152:	21e7a783          	lw	a5,542(a5) # 8002636c <log+0x1c>
    80004156:	04f05c63          	blez	a5,800041ae <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    8000415a:	4781                	li	a5,0
    8000415c:	04c05f63          	blez	a2,800041ba <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80004160:	44cc                	lw	a1,12(s1)
    80004162:	00022717          	auipc	a4,0x22
    80004166:	21e70713          	addi	a4,a4,542 # 80026380 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    8000416a:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    8000416c:	4314                	lw	a3,0(a4)
    8000416e:	04b68663          	beq	a3,a1,800041ba <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80004172:	2785                	addiw	a5,a5,1
    80004174:	0711                	addi	a4,a4,4
    80004176:	fef61be3          	bne	a2,a5,8000416c <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    8000417a:	0621                	addi	a2,a2,8
    8000417c:	060a                	slli	a2,a2,0x2
    8000417e:	00022797          	auipc	a5,0x22
    80004182:	1d278793          	addi	a5,a5,466 # 80026350 <log>
    80004186:	97b2                	add	a5,a5,a2
    80004188:	44d8                	lw	a4,12(s1)
    8000418a:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    8000418c:	8526                	mv	a0,s1
    8000418e:	e71fe0ef          	jal	80002ffe <bpin>
    log.lh.n++;
    80004192:	00022717          	auipc	a4,0x22
    80004196:	1be70713          	addi	a4,a4,446 # 80026350 <log>
    8000419a:	575c                	lw	a5,44(a4)
    8000419c:	2785                	addiw	a5,a5,1
    8000419e:	d75c                	sw	a5,44(a4)
    800041a0:	a80d                	j	800041d2 <log_write+0xaa>
    panic("too big a transaction");
    800041a2:	00005517          	auipc	a0,0x5
    800041a6:	3ee50513          	addi	a0,a0,1006 # 80009590 <etext+0x590>
    800041aa:	e44fc0ef          	jal	800007ee <panic>
    panic("log_write outside of trans");
    800041ae:	00005517          	auipc	a0,0x5
    800041b2:	3fa50513          	addi	a0,a0,1018 # 800095a8 <etext+0x5a8>
    800041b6:	e38fc0ef          	jal	800007ee <panic>
  log.lh.block[i] = b->blockno;
    800041ba:	00878693          	addi	a3,a5,8
    800041be:	068a                	slli	a3,a3,0x2
    800041c0:	00022717          	auipc	a4,0x22
    800041c4:	19070713          	addi	a4,a4,400 # 80026350 <log>
    800041c8:	9736                	add	a4,a4,a3
    800041ca:	44d4                	lw	a3,12(s1)
    800041cc:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    800041ce:	faf60fe3          	beq	a2,a5,8000418c <log_write+0x64>
  }
  release(&log.lock);
    800041d2:	00022517          	auipc	a0,0x22
    800041d6:	17e50513          	addi	a0,a0,382 # 80026350 <log>
    800041da:	a41fc0ef          	jal	80000c1a <release>
}
    800041de:	60e2                	ld	ra,24(sp)
    800041e0:	6442                	ld	s0,16(sp)
    800041e2:	64a2                	ld	s1,8(sp)
    800041e4:	6902                	ld	s2,0(sp)
    800041e6:	6105                	addi	sp,sp,32
    800041e8:	8082                	ret

00000000800041ea <sys_sync>:

uint64
sys_sync(void)
{
    800041ea:	1101                	addi	sp,sp,-32
    800041ec:	ec06                	sd	ra,24(sp)
    800041ee:	e822                	sd	s0,16(sp)
    800041f0:	e426                	sd	s1,8(sp)
    800041f2:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    800041f4:	00022497          	auipc	s1,0x22
    800041f8:	15c48493          	addi	s1,s1,348 # 80026350 <log>
    800041fc:	8526                	mv	a0,s1
    800041fe:	991fc0ef          	jal	80000b8e <acquire>
  if (log.committing || log.outstanding > 0) {
    80004202:	509c                	lw	a5,32(s1)
    80004204:	e799                	bnez	a5,80004212 <sys_sync+0x28>
    80004206:	00022797          	auipc	a5,0x22
    8000420a:	1667a783          	lw	a5,358(a5) # 8002636c <log+0x1c>
    8000420e:	02f05a63          	blez	a5,80004242 <sys_sync+0x58>
    80004212:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80004214:	00022917          	auipc	s2,0x22
    80004218:	16492903          	lw	s2,356(s2) # 80026378 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    8000421c:	00022497          	auipc	s1,0x22
    80004220:	13448493          	addi	s1,s1,308 # 80026350 <log>
    80004224:	8526                	mv	a0,s1
    80004226:	d0bfd0ef          	jal	80001f30 <sleep_prepare>
      release(&log.lock);
    8000422a:	8526                	mv	a0,s1
    8000422c:	9effc0ef          	jal	80000c1a <release>
      sleep();
    80004230:	d3dfd0ef          	jal	80001f6c <sleep>
      acquire(&log.lock);
    80004234:	8526                	mv	a0,s1
    80004236:	959fc0ef          	jal	80000b8e <acquire>
    while (log.ncommit < n) {
    8000423a:	549c                	lw	a5,40(s1)
    8000423c:	fef954e3          	bge	s2,a5,80004224 <sys_sync+0x3a>
    80004240:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80004242:	00022517          	auipc	a0,0x22
    80004246:	10e50513          	addi	a0,a0,270 # 80026350 <log>
    8000424a:	9d1fc0ef          	jal	80000c1a <release>
  return 0;
}
    8000424e:	4501                	li	a0,0
    80004250:	60e2                	ld	ra,24(sp)
    80004252:	6442                	ld	s0,16(sp)
    80004254:	64a2                	ld	s1,8(sp)
    80004256:	6105                	addi	sp,sp,32
    80004258:	8082                	ret

000000008000425a <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000425a:	1101                	addi	sp,sp,-32
    8000425c:	ec06                	sd	ra,24(sp)
    8000425e:	e822                	sd	s0,16(sp)
    80004260:	e426                	sd	s1,8(sp)
    80004262:	e04a                	sd	s2,0(sp)
    80004264:	1000                	addi	s0,sp,32
    80004266:	84aa                	mv	s1,a0
    80004268:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000426a:	00005597          	auipc	a1,0x5
    8000426e:	35e58593          	addi	a1,a1,862 # 800095c8 <etext+0x5c8>
    80004272:	0521                	addi	a0,a0,8
    80004274:	8a5fc0ef          	jal	80000b18 <initlock>
  lk->name = name;
    80004278:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000427c:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004280:	0204a423          	sw	zero,40(s1)
}
    80004284:	60e2                	ld	ra,24(sp)
    80004286:	6442                	ld	s0,16(sp)
    80004288:	64a2                	ld	s1,8(sp)
    8000428a:	6902                	ld	s2,0(sp)
    8000428c:	6105                	addi	sp,sp,32
    8000428e:	8082                	ret

0000000080004290 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004290:	1101                	addi	sp,sp,-32
    80004292:	ec06                	sd	ra,24(sp)
    80004294:	e822                	sd	s0,16(sp)
    80004296:	e426                	sd	s1,8(sp)
    80004298:	e04a                	sd	s2,0(sp)
    8000429a:	1000                	addi	s0,sp,32
    8000429c:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000429e:	00850913          	addi	s2,a0,8
    800042a2:	854a                	mv	a0,s2
    800042a4:	8ebfc0ef          	jal	80000b8e <acquire>
  while (lk->locked) {
    800042a8:	409c                	lw	a5,0(s1)
    800042aa:	cf91                	beqz	a5,800042c6 <acquiresleep+0x36>
    sleep_prepare(lk);
    800042ac:	8526                	mv	a0,s1
    800042ae:	c83fd0ef          	jal	80001f30 <sleep_prepare>
    release(&lk->lk);
    800042b2:	854a                	mv	a0,s2
    800042b4:	967fc0ef          	jal	80000c1a <release>
    sleep();
    800042b8:	cb5fd0ef          	jal	80001f6c <sleep>
    acquire(&lk->lk);
    800042bc:	854a                	mv	a0,s2
    800042be:	8d1fc0ef          	jal	80000b8e <acquire>
  while (lk->locked) {
    800042c2:	409c                	lw	a5,0(s1)
    800042c4:	f7e5                	bnez	a5,800042ac <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800042c6:	4785                	li	a5,1
    800042c8:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800042ca:	dcefd0ef          	jal	80001898 <myproc>
    800042ce:	591c                	lw	a5,48(a0)
    800042d0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800042d2:	854a                	mv	a0,s2
    800042d4:	947fc0ef          	jal	80000c1a <release>
}
    800042d8:	60e2                	ld	ra,24(sp)
    800042da:	6442                	ld	s0,16(sp)
    800042dc:	64a2                	ld	s1,8(sp)
    800042de:	6902                	ld	s2,0(sp)
    800042e0:	6105                	addi	sp,sp,32
    800042e2:	8082                	ret

00000000800042e4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800042e4:	1101                	addi	sp,sp,-32
    800042e6:	ec06                	sd	ra,24(sp)
    800042e8:	e822                	sd	s0,16(sp)
    800042ea:	e426                	sd	s1,8(sp)
    800042ec:	e04a                	sd	s2,0(sp)
    800042ee:	1000                	addi	s0,sp,32
    800042f0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800042f2:	00850913          	addi	s2,a0,8
    800042f6:	854a                	mv	a0,s2
    800042f8:	897fc0ef          	jal	80000b8e <acquire>
  lk->locked = 0;
    800042fc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004300:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004304:	8526                	mv	a0,s1
    80004306:	c97fd0ef          	jal	80001f9c <wakeup>
  release(&lk->lk);
    8000430a:	854a                	mv	a0,s2
    8000430c:	90ffc0ef          	jal	80000c1a <release>
}
    80004310:	60e2                	ld	ra,24(sp)
    80004312:	6442                	ld	s0,16(sp)
    80004314:	64a2                	ld	s1,8(sp)
    80004316:	6902                	ld	s2,0(sp)
    80004318:	6105                	addi	sp,sp,32
    8000431a:	8082                	ret

000000008000431c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000431c:	7179                	addi	sp,sp,-48
    8000431e:	f406                	sd	ra,40(sp)
    80004320:	f022                	sd	s0,32(sp)
    80004322:	ec26                	sd	s1,24(sp)
    80004324:	e84a                	sd	s2,16(sp)
    80004326:	1800                	addi	s0,sp,48
    80004328:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    8000432a:	00850913          	addi	s2,a0,8
    8000432e:	854a                	mv	a0,s2
    80004330:	85ffc0ef          	jal	80000b8e <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004334:	409c                	lw	a5,0(s1)
    80004336:	ef81                	bnez	a5,8000434e <holdingsleep+0x32>
    80004338:	4481                	li	s1,0
  release(&lk->lk);
    8000433a:	854a                	mv	a0,s2
    8000433c:	8dffc0ef          	jal	80000c1a <release>
  return r;
}
    80004340:	8526                	mv	a0,s1
    80004342:	70a2                	ld	ra,40(sp)
    80004344:	7402                	ld	s0,32(sp)
    80004346:	64e2                	ld	s1,24(sp)
    80004348:	6942                	ld	s2,16(sp)
    8000434a:	6145                	addi	sp,sp,48
    8000434c:	8082                	ret
    8000434e:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004350:	0284a983          	lw	s3,40(s1)
    80004354:	d44fd0ef          	jal	80001898 <myproc>
    80004358:	5904                	lw	s1,48(a0)
    8000435a:	413484b3          	sub	s1,s1,s3
    8000435e:	0014b493          	seqz	s1,s1
    80004362:	69a2                	ld	s3,8(sp)
    80004364:	bfd9                	j	8000433a <holdingsleep+0x1e>

0000000080004366 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004366:	1141                	addi	sp,sp,-16
    80004368:	e406                	sd	ra,8(sp)
    8000436a:	e022                	sd	s0,0(sp)
    8000436c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000436e:	00005597          	auipc	a1,0x5
    80004372:	26a58593          	addi	a1,a1,618 # 800095d8 <etext+0x5d8>
    80004376:	00022517          	auipc	a0,0x22
    8000437a:	12250513          	addi	a0,a0,290 # 80026498 <ftable>
    8000437e:	f9afc0ef          	jal	80000b18 <initlock>
}
    80004382:	60a2                	ld	ra,8(sp)
    80004384:	6402                	ld	s0,0(sp)
    80004386:	0141                	addi	sp,sp,16
    80004388:	8082                	ret

000000008000438a <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    8000438a:	1101                	addi	sp,sp,-32
    8000438c:	ec06                	sd	ra,24(sp)
    8000438e:	e822                	sd	s0,16(sp)
    80004390:	e426                	sd	s1,8(sp)
    80004392:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004394:	00022517          	auipc	a0,0x22
    80004398:	10450513          	addi	a0,a0,260 # 80026498 <ftable>
    8000439c:	ff2fc0ef          	jal	80000b8e <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800043a0:	00022497          	auipc	s1,0x22
    800043a4:	11048493          	addi	s1,s1,272 # 800264b0 <ftable+0x18>
    800043a8:	00023717          	auipc	a4,0x23
    800043ac:	0a870713          	addi	a4,a4,168 # 80027450 <disk>
    if (f->ref == 0) {
    800043b0:	40dc                	lw	a5,4(s1)
    800043b2:	cf89                	beqz	a5,800043cc <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800043b4:	02848493          	addi	s1,s1,40
    800043b8:	fee49ce3          	bne	s1,a4,800043b0 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800043bc:	00022517          	auipc	a0,0x22
    800043c0:	0dc50513          	addi	a0,a0,220 # 80026498 <ftable>
    800043c4:	857fc0ef          	jal	80000c1a <release>
  return 0;
    800043c8:	4481                	li	s1,0
    800043ca:	a809                	j	800043dc <filealloc+0x52>
      f->ref = 1;
    800043cc:	4785                	li	a5,1
    800043ce:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800043d0:	00022517          	auipc	a0,0x22
    800043d4:	0c850513          	addi	a0,a0,200 # 80026498 <ftable>
    800043d8:	843fc0ef          	jal	80000c1a <release>
}
    800043dc:	8526                	mv	a0,s1
    800043de:	60e2                	ld	ra,24(sp)
    800043e0:	6442                	ld	s0,16(sp)
    800043e2:	64a2                	ld	s1,8(sp)
    800043e4:	6105                	addi	sp,sp,32
    800043e6:	8082                	ret

00000000800043e8 <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    800043e8:	1101                	addi	sp,sp,-32
    800043ea:	ec06                	sd	ra,24(sp)
    800043ec:	e822                	sd	s0,16(sp)
    800043ee:	e426                	sd	s1,8(sp)
    800043f0:	1000                	addi	s0,sp,32
    800043f2:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800043f4:	00022517          	auipc	a0,0x22
    800043f8:	0a450513          	addi	a0,a0,164 # 80026498 <ftable>
    800043fc:	f92fc0ef          	jal	80000b8e <acquire>
  if (f->ref < 1)
    80004400:	40dc                	lw	a5,4(s1)
    80004402:	02f05063          	blez	a5,80004422 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004406:	2785                	addiw	a5,a5,1
    80004408:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000440a:	00022517          	auipc	a0,0x22
    8000440e:	08e50513          	addi	a0,a0,142 # 80026498 <ftable>
    80004412:	809fc0ef          	jal	80000c1a <release>
  return f;
}
    80004416:	8526                	mv	a0,s1
    80004418:	60e2                	ld	ra,24(sp)
    8000441a:	6442                	ld	s0,16(sp)
    8000441c:	64a2                	ld	s1,8(sp)
    8000441e:	6105                	addi	sp,sp,32
    80004420:	8082                	ret
    panic("filedup");
    80004422:	00005517          	auipc	a0,0x5
    80004426:	1be50513          	addi	a0,a0,446 # 800095e0 <etext+0x5e0>
    8000442a:	bc4fc0ef          	jal	800007ee <panic>

000000008000442e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000442e:	7139                	addi	sp,sp,-64
    80004430:	fc06                	sd	ra,56(sp)
    80004432:	f822                	sd	s0,48(sp)
    80004434:	f426                	sd	s1,40(sp)
    80004436:	0080                	addi	s0,sp,64
    80004438:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000443a:	00022517          	auipc	a0,0x22
    8000443e:	05e50513          	addi	a0,a0,94 # 80026498 <ftable>
    80004442:	f4cfc0ef          	jal	80000b8e <acquire>
  if (f->ref < 1)
    80004446:	40dc                	lw	a5,4(s1)
    80004448:	04f05a63          	blez	a5,8000449c <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    8000444c:	37fd                	addiw	a5,a5,-1
    8000444e:	0007871b          	sext.w	a4,a5
    80004452:	c0dc                	sw	a5,4(s1)
    80004454:	04e04e63          	bgtz	a4,800044b0 <fileclose+0x82>
    80004458:	f04a                	sd	s2,32(sp)
    8000445a:	ec4e                	sd	s3,24(sp)
    8000445c:	e852                	sd	s4,16(sp)
    8000445e:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004460:	0004a903          	lw	s2,0(s1)
    80004464:	0094ca83          	lbu	s5,9(s1)
    80004468:	0104ba03          	ld	s4,16(s1)
    8000446c:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004470:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004474:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004478:	00022517          	auipc	a0,0x22
    8000447c:	02050513          	addi	a0,a0,32 # 80026498 <ftable>
    80004480:	f9afc0ef          	jal	80000c1a <release>

  if (ff.type == FD_PIPE) {
    80004484:	4785                	li	a5,1
    80004486:	04f90063          	beq	s2,a5,800044c6 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    8000448a:	3979                	addiw	s2,s2,-2
    8000448c:	4785                	li	a5,1
    8000448e:	0527f563          	bgeu	a5,s2,800044d8 <fileclose+0xaa>
    80004492:	7902                	ld	s2,32(sp)
    80004494:	69e2                	ld	s3,24(sp)
    80004496:	6a42                	ld	s4,16(sp)
    80004498:	6aa2                	ld	s5,8(sp)
    8000449a:	a00d                	j	800044bc <fileclose+0x8e>
    8000449c:	f04a                	sd	s2,32(sp)
    8000449e:	ec4e                	sd	s3,24(sp)
    800044a0:	e852                	sd	s4,16(sp)
    800044a2:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800044a4:	00005517          	auipc	a0,0x5
    800044a8:	14450513          	addi	a0,a0,324 # 800095e8 <etext+0x5e8>
    800044ac:	b42fc0ef          	jal	800007ee <panic>
    release(&ftable.lock);
    800044b0:	00022517          	auipc	a0,0x22
    800044b4:	fe850513          	addi	a0,a0,-24 # 80026498 <ftable>
    800044b8:	f62fc0ef          	jal	80000c1a <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800044bc:	70e2                	ld	ra,56(sp)
    800044be:	7442                	ld	s0,48(sp)
    800044c0:	74a2                	ld	s1,40(sp)
    800044c2:	6121                	addi	sp,sp,64
    800044c4:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800044c6:	85d6                	mv	a1,s5
    800044c8:	8552                	mv	a0,s4
    800044ca:	34c000ef          	jal	80004816 <pipeclose>
    800044ce:	7902                	ld	s2,32(sp)
    800044d0:	69e2                	ld	s3,24(sp)
    800044d2:	6a42                	ld	s4,16(sp)
    800044d4:	6aa2                	ld	s5,8(sp)
    800044d6:	b7dd                	j	800044bc <fileclose+0x8e>
    begin_op();
    800044d8:	aabff0ef          	jal	80003f82 <begin_op>
    iput(ff.ip);
    800044dc:	854e                	mv	a0,s3
    800044de:	9deff0ef          	jal	800036bc <iput>
    end_op();
    800044e2:	b27ff0ef          	jal	80004008 <end_op>
    800044e6:	7902                	ld	s2,32(sp)
    800044e8:	69e2                	ld	s3,24(sp)
    800044ea:	6a42                	ld	s4,16(sp)
    800044ec:	6aa2                	ld	s5,8(sp)
    800044ee:	b7f9                	j	800044bc <fileclose+0x8e>

00000000800044f0 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800044f0:	715d                	addi	sp,sp,-80
    800044f2:	e486                	sd	ra,72(sp)
    800044f4:	e0a2                	sd	s0,64(sp)
    800044f6:	fc26                	sd	s1,56(sp)
    800044f8:	f44e                	sd	s3,40(sp)
    800044fa:	0880                	addi	s0,sp,80
    800044fc:	84aa                	mv	s1,a0
    800044fe:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004500:	b98fd0ef          	jal	80001898 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80004504:	409c                	lw	a5,0(s1)
    80004506:	37f9                	addiw	a5,a5,-2
    80004508:	4705                	li	a4,1
    8000450a:	04f76263          	bltu	a4,a5,8000454e <filestat+0x5e>
    8000450e:	f84a                	sd	s2,48(sp)
    80004510:	892a                	mv	s2,a0
    ilock(f->ip);
    80004512:	6c88                	ld	a0,24(s1)
    80004514:	826ff0ef          	jal	8000353a <ilock>
    stati(f->ip, &st);
    80004518:	fb840593          	addi	a1,s0,-72
    8000451c:	6c88                	ld	a0,24(s1)
    8000451e:	bcaff0ef          	jal	800038e8 <stati>
    iunlock(f->ip);
    80004522:	6c88                	ld	a0,24(s1)
    80004524:	8c4ff0ef          	jal	800035e8 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    80004528:	4761                	li	a4,24
    8000452a:	fb840693          	addi	a3,s0,-72
    8000452e:	864e                	mv	a2,s3
    80004530:	04893583          	ld	a1,72(s2)
    80004534:	05093503          	ld	a0,80(s2)
    80004538:	fa3fc0ef          	jal	800014da <copyout>
    8000453c:	41f5551b          	sraiw	a0,a0,0x1f
    80004540:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004542:	60a6                	ld	ra,72(sp)
    80004544:	6406                	ld	s0,64(sp)
    80004546:	74e2                	ld	s1,56(sp)
    80004548:	79a2                	ld	s3,40(sp)
    8000454a:	6161                	addi	sp,sp,80
    8000454c:	8082                	ret
  return -1;
    8000454e:	557d                	li	a0,-1
    80004550:	bfcd                	j	80004542 <filestat+0x52>

0000000080004552 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004552:	7179                	addi	sp,sp,-48
    80004554:	f406                	sd	ra,40(sp)
    80004556:	f022                	sd	s0,32(sp)
    80004558:	e84a                	sd	s2,16(sp)
    8000455a:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    8000455c:	00854783          	lbu	a5,8(a0)
    80004560:	c3c5                	beqz	a5,80004600 <fileread+0xae>
    80004562:	ec26                	sd	s1,24(sp)
    80004564:	e44e                	sd	s3,8(sp)
    80004566:	84aa                	mv	s1,a0
    80004568:	89ae                	mv	s3,a1
    8000456a:	8932                	mv	s2,a2
    8000456c:	08064c63          	bltz	a2,80004604 <fileread+0xb2>
    return -1;

  if (f->type == FD_PIPE) {
    80004570:	411c                	lw	a5,0(a0)
    80004572:	4705                	li	a4,1
    80004574:	04e78363          	beq	a5,a4,800045ba <fileread+0x68>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004578:	470d                	li	a4,3
    8000457a:	04e78763          	beq	a5,a4,800045c8 <fileread+0x76>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000457e:	4709                	li	a4,2
    80004580:	06e79a63          	bne	a5,a4,800045f4 <fileread+0xa2>
    ilock(f->ip);
    80004584:	6d08                	ld	a0,24(a0)
    80004586:	fb5fe0ef          	jal	8000353a <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000458a:	874a                	mv	a4,s2
    8000458c:	5094                	lw	a3,32(s1)
    8000458e:	864e                	mv	a2,s3
    80004590:	4585                	li	a1,1
    80004592:	6c88                	ld	a0,24(s1)
    80004594:	b7eff0ef          	jal	80003912 <readi>
    80004598:	892a                	mv	s2,a0
    8000459a:	00a05563          	blez	a0,800045a4 <fileread+0x52>
      f->off += r;
    8000459e:	509c                	lw	a5,32(s1)
    800045a0:	9fa9                	addw	a5,a5,a0
    800045a2:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800045a4:	6c88                	ld	a0,24(s1)
    800045a6:	842ff0ef          	jal	800035e8 <iunlock>
    800045aa:	64e2                	ld	s1,24(sp)
    800045ac:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800045ae:	854a                	mv	a0,s2
    800045b0:	70a2                	ld	ra,40(sp)
    800045b2:	7402                	ld	s0,32(sp)
    800045b4:	6942                	ld	s2,16(sp)
    800045b6:	6145                	addi	sp,sp,48
    800045b8:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800045ba:	6908                	ld	a0,16(a0)
    800045bc:	3b6000ef          	jal	80004972 <piperead>
    800045c0:	892a                	mv	s2,a0
    800045c2:	64e2                	ld	s1,24(sp)
    800045c4:	69a2                	ld	s3,8(sp)
    800045c6:	b7e5                	j	800045ae <fileread+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800045c8:	02451783          	lh	a5,36(a0)
    800045cc:	03079693          	slli	a3,a5,0x30
    800045d0:	92c1                	srli	a3,a3,0x30
    800045d2:	4725                	li	a4,9
    800045d4:	02d76c63          	bltu	a4,a3,8000460c <fileread+0xba>
    800045d8:	0792                	slli	a5,a5,0x4
    800045da:	00022717          	auipc	a4,0x22
    800045de:	e1e70713          	addi	a4,a4,-482 # 800263f8 <devsw>
    800045e2:	97ba                	add	a5,a5,a4
    800045e4:	639c                	ld	a5,0(a5)
    800045e6:	c79d                	beqz	a5,80004614 <fileread+0xc2>
    r = devsw[f->major].read(1, addr, n);
    800045e8:	4505                	li	a0,1
    800045ea:	9782                	jalr	a5
    800045ec:	892a                	mv	s2,a0
    800045ee:	64e2                	ld	s1,24(sp)
    800045f0:	69a2                	ld	s3,8(sp)
    800045f2:	bf75                	j	800045ae <fileread+0x5c>
    panic("fileread");
    800045f4:	00005517          	auipc	a0,0x5
    800045f8:	00450513          	addi	a0,a0,4 # 800095f8 <etext+0x5f8>
    800045fc:	9f2fc0ef          	jal	800007ee <panic>
    return -1;
    80004600:	597d                	li	s2,-1
    80004602:	b775                	j	800045ae <fileread+0x5c>
    80004604:	597d                	li	s2,-1
    80004606:	64e2                	ld	s1,24(sp)
    80004608:	69a2                	ld	s3,8(sp)
    8000460a:	b755                	j	800045ae <fileread+0x5c>
      return -1;
    8000460c:	597d                	li	s2,-1
    8000460e:	64e2                	ld	s1,24(sp)
    80004610:	69a2                	ld	s3,8(sp)
    80004612:	bf71                	j	800045ae <fileread+0x5c>
    80004614:	597d                	li	s2,-1
    80004616:	64e2                	ld	s1,24(sp)
    80004618:	69a2                	ld	s3,8(sp)
    8000461a:	bf51                	j	800045ae <fileread+0x5c>

000000008000461c <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    8000461c:	00954783          	lbu	a5,9(a0)
    80004620:	10078663          	beqz	a5,8000472c <filewrite+0x110>
{
    80004624:	715d                	addi	sp,sp,-80
    80004626:	e486                	sd	ra,72(sp)
    80004628:	e0a2                	sd	s0,64(sp)
    8000462a:	f84a                	sd	s2,48(sp)
    8000462c:	f052                	sd	s4,32(sp)
    8000462e:	e85a                	sd	s6,16(sp)
    80004630:	0880                	addi	s0,sp,80
    80004632:	892a                	mv	s2,a0
    80004634:	8b2e                	mv	s6,a1
    80004636:	8a32                	mv	s4,a2
  if (f->writable == 0 || n < 0)
    80004638:	0e064c63          	bltz	a2,80004730 <filewrite+0x114>
    return -1;

  if (f->type == FD_PIPE) {
    8000463c:	411c                	lw	a5,0(a0)
    8000463e:	4705                	li	a4,1
    80004640:	02e78763          	beq	a5,a4,8000466e <filewrite+0x52>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004644:	470d                	li	a4,3
    80004646:	02e78863          	beq	a5,a4,80004676 <filewrite+0x5a>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000464a:	4709                	li	a4,2
    8000464c:	0ce79563          	bne	a5,a4,80004716 <filewrite+0xfa>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    80004650:	0ec05663          	blez	a2,8000473c <filewrite+0x120>
    80004654:	fc26                	sd	s1,56(sp)
    80004656:	f44e                	sd	s3,40(sp)
    80004658:	ec56                	sd	s5,24(sp)
    8000465a:	e45e                	sd	s7,8(sp)
    8000465c:	e062                	sd	s8,0(sp)
    int i = 0;
    8000465e:	4981                	li	s3,0
      int n1 = n - i;
      if (n1 > max)
    80004660:	6b85                	lui	s7,0x1
    80004662:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004666:	6c05                	lui	s8,0x1
    80004668:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000466c:	a8b5                	j	800046e8 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000466e:	6908                	ld	a0,16(a0)
    80004670:	1fe000ef          	jal	8000486e <pipewrite>
    80004674:	a851                	j	80004708 <filewrite+0xec>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004676:	02451783          	lh	a5,36(a0)
    8000467a:	03079693          	slli	a3,a5,0x30
    8000467e:	92c1                	srli	a3,a3,0x30
    80004680:	4725                	li	a4,9
    80004682:	0ad76963          	bltu	a4,a3,80004734 <filewrite+0x118>
    80004686:	0792                	slli	a5,a5,0x4
    80004688:	00022717          	auipc	a4,0x22
    8000468c:	d7070713          	addi	a4,a4,-656 # 800263f8 <devsw>
    80004690:	97ba                	add	a5,a5,a4
    80004692:	679c                	ld	a5,8(a5)
    80004694:	c3d5                	beqz	a5,80004738 <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    80004696:	4505                	li	a0,1
    80004698:	9782                	jalr	a5
    8000469a:	a0bd                	j	80004708 <filewrite+0xec>
      if (n1 > max)
    8000469c:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    800046a0:	8e3ff0ef          	jal	80003f82 <begin_op>
      ilock(f->ip);
    800046a4:	01893503          	ld	a0,24(s2)
    800046a8:	e93fe0ef          	jal	8000353a <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800046ac:	8756                	mv	a4,s5
    800046ae:	02092683          	lw	a3,32(s2)
    800046b2:	01698633          	add	a2,s3,s6
    800046b6:	4585                	li	a1,1
    800046b8:	01893503          	ld	a0,24(s2)
    800046bc:	b52ff0ef          	jal	80003a0e <writei>
    800046c0:	84aa                	mv	s1,a0
    800046c2:	00a05763          	blez	a0,800046d0 <filewrite+0xb4>
        f->off += r;
    800046c6:	02092783          	lw	a5,32(s2)
    800046ca:	9fa9                	addw	a5,a5,a0
    800046cc:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800046d0:	01893503          	ld	a0,24(s2)
    800046d4:	f15fe0ef          	jal	800035e8 <iunlock>
      end_op();
    800046d8:	931ff0ef          	jal	80004008 <end_op>

      if (r != n1) {
    800046dc:	009a9e63          	bne	s5,s1,800046f8 <filewrite+0xdc>
        // error from writei
        break;
      }
      i += r;
    800046e0:	013489bb          	addw	s3,s1,s3
    while (i < n) {
    800046e4:	0149da63          	bge	s3,s4,800046f8 <filewrite+0xdc>
      int n1 = n - i;
    800046e8:	413a04bb          	subw	s1,s4,s3
      if (n1 > max)
    800046ec:	0004879b          	sext.w	a5,s1
    800046f0:	fafbd6e3          	bge	s7,a5,8000469c <filewrite+0x80>
    800046f4:	84e2                	mv	s1,s8
    800046f6:	b75d                	j	8000469c <filewrite+0x80>
    }
    ret = (i == n ? n : -1);
    800046f8:	053a1463          	bne	s4,s3,80004740 <filewrite+0x124>
    800046fc:	8552                	mv	a0,s4
    800046fe:	74e2                	ld	s1,56(sp)
    80004700:	79a2                	ld	s3,40(sp)
    80004702:	6ae2                	ld	s5,24(sp)
    80004704:	6ba2                	ld	s7,8(sp)
    80004706:	6c02                	ld	s8,0(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004708:	60a6                	ld	ra,72(sp)
    8000470a:	6406                	ld	s0,64(sp)
    8000470c:	7942                	ld	s2,48(sp)
    8000470e:	7a02                	ld	s4,32(sp)
    80004710:	6b42                	ld	s6,16(sp)
    80004712:	6161                	addi	sp,sp,80
    80004714:	8082                	ret
    80004716:	fc26                	sd	s1,56(sp)
    80004718:	f44e                	sd	s3,40(sp)
    8000471a:	ec56                	sd	s5,24(sp)
    8000471c:	e45e                	sd	s7,8(sp)
    8000471e:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004720:	00005517          	auipc	a0,0x5
    80004724:	ee850513          	addi	a0,a0,-280 # 80009608 <etext+0x608>
    80004728:	8c6fc0ef          	jal	800007ee <panic>
    return -1;
    8000472c:	557d                	li	a0,-1
}
    8000472e:	8082                	ret
    return -1;
    80004730:	557d                	li	a0,-1
    80004732:	bfd9                	j	80004708 <filewrite+0xec>
      return -1;
    80004734:	557d                	li	a0,-1
    80004736:	bfc9                	j	80004708 <filewrite+0xec>
    80004738:	557d                	li	a0,-1
    8000473a:	b7f9                	j	80004708 <filewrite+0xec>
    ret = (i == n ? n : -1);
    8000473c:	8532                	mv	a0,a2
    8000473e:	b7e9                	j	80004708 <filewrite+0xec>
    80004740:	557d                	li	a0,-1
    80004742:	74e2                	ld	s1,56(sp)
    80004744:	79a2                	ld	s3,40(sp)
    80004746:	6ae2                	ld	s5,24(sp)
    80004748:	6ba2                	ld	s7,8(sp)
    8000474a:	6c02                	ld	s8,0(sp)
    8000474c:	bf75                	j	80004708 <filewrite+0xec>

000000008000474e <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    8000474e:	7179                	addi	sp,sp,-48
    80004750:	f406                	sd	ra,40(sp)
    80004752:	f022                	sd	s0,32(sp)
    80004754:	ec26                	sd	s1,24(sp)
    80004756:	e052                	sd	s4,0(sp)
    80004758:	1800                	addi	s0,sp,48
    8000475a:	84aa                	mv	s1,a0
    8000475c:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000475e:	0005b023          	sd	zero,0(a1)
    80004762:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004766:	c25ff0ef          	jal	8000438a <filealloc>
    8000476a:	e088                	sd	a0,0(s1)
    8000476c:	c549                	beqz	a0,800047f6 <pipealloc+0xa8>
    8000476e:	c1dff0ef          	jal	8000438a <filealloc>
    80004772:	00aa3023          	sd	a0,0(s4)
    80004776:	cd25                	beqz	a0,800047ee <pipealloc+0xa0>
    80004778:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    8000477a:	b4efc0ef          	jal	80000ac8 <kalloc>
    8000477e:	892a                	mv	s2,a0
    80004780:	c12d                	beqz	a0,800047e2 <pipealloc+0x94>
    80004782:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004784:	4985                	li	s3,1
    80004786:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000478a:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000478e:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004792:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004796:	00005597          	auipc	a1,0x5
    8000479a:	e8258593          	addi	a1,a1,-382 # 80009618 <etext+0x618>
    8000479e:	b7afc0ef          	jal	80000b18 <initlock>
  (*f0)->type = FD_PIPE;
    800047a2:	609c                	ld	a5,0(s1)
    800047a4:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800047a8:	609c                	ld	a5,0(s1)
    800047aa:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800047ae:	609c                	ld	a5,0(s1)
    800047b0:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800047b4:	609c                	ld	a5,0(s1)
    800047b6:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800047ba:	000a3783          	ld	a5,0(s4)
    800047be:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800047c2:	000a3783          	ld	a5,0(s4)
    800047c6:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800047ca:	000a3783          	ld	a5,0(s4)
    800047ce:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800047d2:	000a3783          	ld	a5,0(s4)
    800047d6:	0127b823          	sd	s2,16(a5)
  return 0;
    800047da:	4501                	li	a0,0
    800047dc:	6942                	ld	s2,16(sp)
    800047de:	69a2                	ld	s3,8(sp)
    800047e0:	a01d                	j	80004806 <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    800047e2:	6088                	ld	a0,0(s1)
    800047e4:	c119                	beqz	a0,800047ea <pipealloc+0x9c>
    800047e6:	6942                	ld	s2,16(sp)
    800047e8:	a029                	j	800047f2 <pipealloc+0xa4>
    800047ea:	6942                	ld	s2,16(sp)
    800047ec:	a029                	j	800047f6 <pipealloc+0xa8>
    800047ee:	6088                	ld	a0,0(s1)
    800047f0:	c10d                	beqz	a0,80004812 <pipealloc+0xc4>
    fileclose(*f0);
    800047f2:	c3dff0ef          	jal	8000442e <fileclose>
  if (*f1)
    800047f6:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800047fa:	557d                	li	a0,-1
  if (*f1)
    800047fc:	c789                	beqz	a5,80004806 <pipealloc+0xb8>
    fileclose(*f1);
    800047fe:	853e                	mv	a0,a5
    80004800:	c2fff0ef          	jal	8000442e <fileclose>
  return -1;
    80004804:	557d                	li	a0,-1
}
    80004806:	70a2                	ld	ra,40(sp)
    80004808:	7402                	ld	s0,32(sp)
    8000480a:	64e2                	ld	s1,24(sp)
    8000480c:	6a02                	ld	s4,0(sp)
    8000480e:	6145                	addi	sp,sp,48
    80004810:	8082                	ret
  return -1;
    80004812:	557d                	li	a0,-1
    80004814:	bfcd                	j	80004806 <pipealloc+0xb8>

0000000080004816 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004816:	1101                	addi	sp,sp,-32
    80004818:	ec06                	sd	ra,24(sp)
    8000481a:	e822                	sd	s0,16(sp)
    8000481c:	e426                	sd	s1,8(sp)
    8000481e:	e04a                	sd	s2,0(sp)
    80004820:	1000                	addi	s0,sp,32
    80004822:	84aa                	mv	s1,a0
    80004824:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004826:	b68fc0ef          	jal	80000b8e <acquire>
  if (writable) {
    8000482a:	02090763          	beqz	s2,80004858 <pipeclose+0x42>
    pi->writeopen = 0;
    8000482e:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004832:	21848513          	addi	a0,s1,536
    80004836:	f66fd0ef          	jal	80001f9c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000483a:	2204b783          	ld	a5,544(s1)
    8000483e:	e785                	bnez	a5,80004866 <pipeclose+0x50>
    release(&pi->lock);
    80004840:	8526                	mv	a0,s1
    80004842:	bd8fc0ef          	jal	80000c1a <release>
    kfree((char *)pi);
    80004846:	8526                	mv	a0,s1
    80004848:	99efc0ef          	jal	800009e6 <kfree>
  } else
    release(&pi->lock);
}
    8000484c:	60e2                	ld	ra,24(sp)
    8000484e:	6442                	ld	s0,16(sp)
    80004850:	64a2                	ld	s1,8(sp)
    80004852:	6902                	ld	s2,0(sp)
    80004854:	6105                	addi	sp,sp,32
    80004856:	8082                	ret
    pi->readopen = 0;
    80004858:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000485c:	21c48513          	addi	a0,s1,540
    80004860:	f3cfd0ef          	jal	80001f9c <wakeup>
    80004864:	bfd9                	j	8000483a <pipeclose+0x24>
    release(&pi->lock);
    80004866:	8526                	mv	a0,s1
    80004868:	bb2fc0ef          	jal	80000c1a <release>
}
    8000486c:	b7c5                	j	8000484c <pipeclose+0x36>

000000008000486e <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    8000486e:	711d                	addi	sp,sp,-96
    80004870:	ec86                	sd	ra,88(sp)
    80004872:	e8a2                	sd	s0,80(sp)
    80004874:	e4a6                	sd	s1,72(sp)
    80004876:	e0ca                	sd	s2,64(sp)
    80004878:	fc4e                	sd	s3,56(sp)
    8000487a:	f852                	sd	s4,48(sp)
    8000487c:	f456                	sd	s5,40(sp)
    8000487e:	1080                	addi	s0,sp,96
    80004880:	84aa                	mv	s1,a0
    80004882:	8aae                	mv	s5,a1
    80004884:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004886:	812fd0ef          	jal	80001898 <myproc>
    8000488a:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000488c:	8526                	mv	a0,s1
    8000488e:	b00fc0ef          	jal	80000b8e <acquire>
  while (i < n) {
    80004892:	0d405e63          	blez	s4,8000496e <pipewrite+0x100>
    80004896:	f05a                	sd	s6,32(sp)
    80004898:	ec5e                	sd	s7,24(sp)
    8000489a:	e862                	sd	s8,16(sp)
  int i = 0;
    8000489c:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000489e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800048a0:	21848c13          	addi	s8,s1,536
      sleep_prepare(&pi->nwrite);
    800048a4:	21c48b93          	addi	s7,s1,540
    800048a8:	a091                	j	800048ec <pipewrite+0x7e>
      release(&pi->lock);
    800048aa:	8526                	mv	a0,s1
    800048ac:	b6efc0ef          	jal	80000c1a <release>
      return -1;
    800048b0:	597d                	li	s2,-1
    800048b2:	7b02                	ld	s6,32(sp)
    800048b4:	6be2                	ld	s7,24(sp)
    800048b6:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800048b8:	854a                	mv	a0,s2
    800048ba:	60e6                	ld	ra,88(sp)
    800048bc:	6446                	ld	s0,80(sp)
    800048be:	64a6                	ld	s1,72(sp)
    800048c0:	6906                	ld	s2,64(sp)
    800048c2:	79e2                	ld	s3,56(sp)
    800048c4:	7a42                	ld	s4,48(sp)
    800048c6:	7aa2                	ld	s5,40(sp)
    800048c8:	6125                	addi	sp,sp,96
    800048ca:	8082                	ret
      wakeup(&pi->nread);
    800048cc:	8562                	mv	a0,s8
    800048ce:	ecefd0ef          	jal	80001f9c <wakeup>
      sleep_prepare(&pi->nwrite);
    800048d2:	855e                	mv	a0,s7
    800048d4:	e5cfd0ef          	jal	80001f30 <sleep_prepare>
      release(&pi->lock);
    800048d8:	8526                	mv	a0,s1
    800048da:	b40fc0ef          	jal	80000c1a <release>
      sleep();
    800048de:	e8efd0ef          	jal	80001f6c <sleep>
      acquire(&pi->lock);
    800048e2:	8526                	mv	a0,s1
    800048e4:	aaafc0ef          	jal	80000b8e <acquire>
  while (i < n) {
    800048e8:	07495863          	bge	s2,s4,80004958 <pipewrite+0xea>
    if (pi->readopen == 0 || killed(pr)) {
    800048ec:	2204a783          	lw	a5,544(s1)
    800048f0:	dfcd                	beqz	a5,800048aa <pipewrite+0x3c>
    800048f2:	854e                	mv	a0,s3
    800048f4:	8a9fd0ef          	jal	8000219c <killed>
    800048f8:	f94d                	bnez	a0,800048aa <pipewrite+0x3c>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    800048fa:	2184a783          	lw	a5,536(s1)
    800048fe:	21c4a703          	lw	a4,540(s1)
    80004902:	2007879b          	addiw	a5,a5,512
    80004906:	fcf703e3          	beq	a4,a5,800048cc <pipewrite+0x5e>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000490a:	4705                	li	a4,1
    8000490c:	015906b3          	add	a3,s2,s5
    80004910:	faf40613          	addi	a2,s0,-81
    80004914:	0489b583          	ld	a1,72(s3)
    80004918:	0509b503          	ld	a0,80(s3)
    8000491c:	cabfc0ef          	jal	800015c6 <copyin>
    80004920:	03650163          	beq	a0,s6,80004942 <pipewrite+0xd4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004924:	21c4a783          	lw	a5,540(s1)
    80004928:	0017871b          	addiw	a4,a5,1
    8000492c:	20e4ae23          	sw	a4,540(s1)
    80004930:	1ff7f793          	andi	a5,a5,511
    80004934:	97a6                	add	a5,a5,s1
    80004936:	faf44703          	lbu	a4,-81(s0)
    8000493a:	00e78c23          	sb	a4,24(a5)
      i++;
    8000493e:	2905                	addiw	s2,s2,1
    80004940:	b765                	j	800048e8 <pipewrite+0x7a>
        if (i == 0)
    80004942:	00090663          	beqz	s2,8000494e <pipewrite+0xe0>
    80004946:	7b02                	ld	s6,32(sp)
    80004948:	6be2                	ld	s7,24(sp)
    8000494a:	6c42                	ld	s8,16(sp)
    8000494c:	a809                	j	8000495e <pipewrite+0xf0>
          i = -1;
    8000494e:	892a                	mv	s2,a0
        break;
    80004950:	7b02                	ld	s6,32(sp)
    80004952:	6be2                	ld	s7,24(sp)
    80004954:	6c42                	ld	s8,16(sp)
    80004956:	a021                	j	8000495e <pipewrite+0xf0>
    80004958:	7b02                	ld	s6,32(sp)
    8000495a:	6be2                	ld	s7,24(sp)
    8000495c:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    8000495e:	21848513          	addi	a0,s1,536
    80004962:	e3afd0ef          	jal	80001f9c <wakeup>
  release(&pi->lock);
    80004966:	8526                	mv	a0,s1
    80004968:	ab2fc0ef          	jal	80000c1a <release>
  return i;
    8000496c:	b7b1                	j	800048b8 <pipewrite+0x4a>
  int i = 0;
    8000496e:	4901                	li	s2,0
    80004970:	b7fd                	j	8000495e <pipewrite+0xf0>

0000000080004972 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004972:	715d                	addi	sp,sp,-80
    80004974:	e486                	sd	ra,72(sp)
    80004976:	e0a2                	sd	s0,64(sp)
    80004978:	fc26                	sd	s1,56(sp)
    8000497a:	f84a                	sd	s2,48(sp)
    8000497c:	f44e                	sd	s3,40(sp)
    8000497e:	f052                	sd	s4,32(sp)
    80004980:	ec56                	sd	s5,24(sp)
    80004982:	0880                	addi	s0,sp,80
    80004984:	84aa                	mv	s1,a0
    80004986:	89ae                	mv	s3,a1
    80004988:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000498a:	f0ffc0ef          	jal	80001898 <myproc>
    8000498e:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    80004990:	8526                	mv	a0,s1
    80004992:	9fcfc0ef          	jal	80000b8e <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004996:	2184a703          	lw	a4,536(s1)
    8000499a:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    8000499e:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800049a2:	02f71c63          	bne	a4,a5,800049da <piperead+0x68>
    800049a6:	2244a783          	lw	a5,548(s1)
    800049aa:	cf9d                	beqz	a5,800049e8 <piperead+0x76>
    if (killed(pr)) {
    800049ac:	854a                	mv	a0,s2
    800049ae:	feefd0ef          	jal	8000219c <killed>
    800049b2:	e515                	bnez	a0,800049de <piperead+0x6c>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800049b4:	8552                	mv	a0,s4
    800049b6:	d7afd0ef          	jal	80001f30 <sleep_prepare>
    release(&pi->lock);
    800049ba:	8526                	mv	a0,s1
    800049bc:	a5efc0ef          	jal	80000c1a <release>
    sleep();
    800049c0:	dacfd0ef          	jal	80001f6c <sleep>
    acquire(&pi->lock);
    800049c4:	8526                	mv	a0,s1
    800049c6:	9c8fc0ef          	jal	80000b8e <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800049ca:	2184a703          	lw	a4,536(s1)
    800049ce:	21c4a783          	lw	a5,540(s1)
    800049d2:	fcf70ae3          	beq	a4,a5,800049a6 <piperead+0x34>
    800049d6:	e85a                	sd	s6,16(sp)
    800049d8:	a809                	j	800049ea <piperead+0x78>
    800049da:	e85a                	sd	s6,16(sp)
    800049dc:	a039                	j	800049ea <piperead+0x78>
      release(&pi->lock);
    800049de:	8526                	mv	a0,s1
    800049e0:	a3afc0ef          	jal	80000c1a <release>
      return -1;
    800049e4:	5a7d                	li	s4,-1
    800049e6:	a08d                	j	80004a48 <piperead+0xd6>
    800049e8:	e85a                	sd	s6,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800049ea:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    800049ec:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800049ee:	05505563          	blez	s5,80004a38 <piperead+0xc6>
    if (pi->nread == pi->nwrite)
    800049f2:	2184a783          	lw	a5,536(s1)
    800049f6:	21c4a703          	lw	a4,540(s1)
    800049fa:	02f70f63          	beq	a4,a5,80004a38 <piperead+0xc6>
    ch = pi->data[pi->nread % PIPESIZE];
    800049fe:	1ff7f793          	andi	a5,a5,511
    80004a02:	97a6                	add	a5,a5,s1
    80004a04:	0187c783          	lbu	a5,24(a5)
    80004a08:	faf40fa3          	sb	a5,-65(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004a0c:	4705                	li	a4,1
    80004a0e:	fbf40693          	addi	a3,s0,-65
    80004a12:	864e                	mv	a2,s3
    80004a14:	04893583          	ld	a1,72(s2)
    80004a18:	05093503          	ld	a0,80(s2)
    80004a1c:	abffc0ef          	jal	800014da <copyout>
    80004a20:	03650e63          	beq	a0,s6,80004a5c <piperead+0xea>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004a24:	2184a783          	lw	a5,536(s1)
    80004a28:	2785                	addiw	a5,a5,1
    80004a2a:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004a2e:	2a05                	addiw	s4,s4,1
    80004a30:	0985                	addi	s3,s3,1
    80004a32:	fd4a90e3          	bne	s5,s4,800049f2 <piperead+0x80>
    80004a36:	8a56                	mv	s4,s5
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    80004a38:	21c48513          	addi	a0,s1,540
    80004a3c:	d60fd0ef          	jal	80001f9c <wakeup>
  release(&pi->lock);
    80004a40:	8526                	mv	a0,s1
    80004a42:	9d8fc0ef          	jal	80000c1a <release>
    80004a46:	6b42                	ld	s6,16(sp)
  return i;
}
    80004a48:	8552                	mv	a0,s4
    80004a4a:	60a6                	ld	ra,72(sp)
    80004a4c:	6406                	ld	s0,64(sp)
    80004a4e:	74e2                	ld	s1,56(sp)
    80004a50:	7942                	ld	s2,48(sp)
    80004a52:	79a2                	ld	s3,40(sp)
    80004a54:	7a02                	ld	s4,32(sp)
    80004a56:	6ae2                	ld	s5,24(sp)
    80004a58:	6161                	addi	sp,sp,80
    80004a5a:	8082                	ret
      if (i == 0)
    80004a5c:	fc0a1ee3          	bnez	s4,80004a38 <piperead+0xc6>
        i = -1;
    80004a60:	8a2a                	mv	s4,a0
    80004a62:	bfd9                	j	80004a38 <piperead+0xc6>

0000000080004a64 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    80004a64:	1141                	addi	sp,sp,-16
    80004a66:	e422                	sd	s0,8(sp)
    80004a68:	0800                	addi	s0,sp,16
    80004a6a:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    80004a6c:	8905                	andi	a0,a0,1
    80004a6e:	050e                	slli	a0,a0,0x3
    perm = PTE_X;
  if (flags & 0x2)
    80004a70:	8b89                	andi	a5,a5,2
    80004a72:	c399                	beqz	a5,80004a78 <flags2perm+0x14>
    perm |= PTE_W;
    80004a74:	00456513          	ori	a0,a0,4
  return perm;
}
    80004a78:	6422                	ld	s0,8(sp)
    80004a7a:	0141                	addi	sp,sp,16
    80004a7c:	8082                	ret

0000000080004a7e <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004a7e:	df010113          	addi	sp,sp,-528
    80004a82:	20113423          	sd	ra,520(sp)
    80004a86:	20813023          	sd	s0,512(sp)
    80004a8a:	ffa6                	sd	s1,504(sp)
    80004a8c:	fbca                	sd	s2,496(sp)
    80004a8e:	0c00                	addi	s0,sp,528
    80004a90:	892a                	mv	s2,a0
    80004a92:	dea43c23          	sd	a0,-520(s0)
    80004a96:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004a9a:	dfffc0ef          	jal	80001898 <myproc>
    80004a9e:	84aa                	mv	s1,a0

  begin_op();
    80004aa0:	ce2ff0ef          	jal	80003f82 <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    80004aa4:	854a                	mv	a0,s2
    80004aa6:	b08ff0ef          	jal	80003dae <namei>
    80004aaa:	c931                	beqz	a0,80004afe <kexec+0x80>
    80004aac:	f3d2                	sd	s4,480(sp)
    80004aae:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004ab0:	a8bfe0ef          	jal	8000353a <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004ab4:	04000713          	li	a4,64
    80004ab8:	4681                	li	a3,0
    80004aba:	e5040613          	addi	a2,s0,-432
    80004abe:	4581                	li	a1,0
    80004ac0:	8552                	mv	a0,s4
    80004ac2:	e51fe0ef          	jal	80003912 <readi>
    80004ac6:	04000793          	li	a5,64
    80004aca:	00f51a63          	bne	a0,a5,80004ade <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80004ace:	e5042703          	lw	a4,-432(s0)
    80004ad2:	464c47b7          	lui	a5,0x464c4
    80004ad6:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004ada:	02f70663          	beq	a4,a5,80004b06 <kexec+0x88>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80004ade:	8552                	mv	a0,s4
    80004ae0:	cadfe0ef          	jal	8000378c <iunlockput>
    end_op();
    80004ae4:	d24ff0ef          	jal	80004008 <end_op>
  }
  return -1;
    80004ae8:	557d                	li	a0,-1
    80004aea:	7a1e                	ld	s4,480(sp)
}
    80004aec:	20813083          	ld	ra,520(sp)
    80004af0:	20013403          	ld	s0,512(sp)
    80004af4:	74fe                	ld	s1,504(sp)
    80004af6:	795e                	ld	s2,496(sp)
    80004af8:	21010113          	addi	sp,sp,528
    80004afc:	8082                	ret
    end_op();
    80004afe:	d0aff0ef          	jal	80004008 <end_op>
    return -1;
    80004b02:	557d                	li	a0,-1
    80004b04:	b7e5                	j	80004aec <kexec+0x6e>
    80004b06:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    80004b08:	8526                	mv	a0,s1
    80004b0a:	ea1fc0ef          	jal	800019aa <proc_pagetable>
    80004b0e:	8b2a                	mv	s6,a0
    80004b10:	2c050963          	beqz	a0,80004de2 <kexec+0x364>
    80004b14:	f7ce                	sd	s3,488(sp)
    80004b16:	efd6                	sd	s5,472(sp)
    80004b18:	e7de                	sd	s7,456(sp)
    80004b1a:	e3e2                	sd	s8,448(sp)
    80004b1c:	ff66                	sd	s9,440(sp)
    80004b1e:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004b20:	e7042d03          	lw	s10,-400(s0)
    80004b24:	e8845783          	lhu	a5,-376(s0)
    80004b28:	12078863          	beqz	a5,80004c58 <kexec+0x1da>
    80004b2c:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b2e:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004b30:	4d81                	li	s11,0
    if (ph.vaddr % PGSIZE != 0)
    80004b32:	6c85                	lui	s9,0x1
    80004b34:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004b38:	def43823          	sd	a5,-528(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    80004b3c:	6a85                	lui	s5,0x1
    80004b3e:	a085                	j	80004b9e <kexec+0x120>
      panic("loadseg: address should exist");
    80004b40:	00005517          	auipc	a0,0x5
    80004b44:	ae050513          	addi	a0,a0,-1312 # 80009620 <etext+0x620>
    80004b48:	ca7fb0ef          	jal	800007ee <panic>
    if (sz - i < PGSIZE)
    80004b4c:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004b4e:	8726                	mv	a4,s1
    80004b50:	012c06bb          	addw	a3,s8,s2
    80004b54:	4581                	li	a1,0
    80004b56:	8552                	mv	a0,s4
    80004b58:	dbbfe0ef          	jal	80003912 <readi>
    80004b5c:	2501                	sext.w	a0,a0
    80004b5e:	24a49863          	bne	s1,a0,80004dae <kexec+0x330>
  for (i = 0; i < sz; i += PGSIZE) {
    80004b62:	012a893b          	addw	s2,s5,s2
    80004b66:	03397363          	bgeu	s2,s3,80004b8c <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    80004b6a:	02091593          	slli	a1,s2,0x20
    80004b6e:	9181                	srli	a1,a1,0x20
    80004b70:	95de                	add	a1,a1,s7
    80004b72:	855a                	mv	a0,s6
    80004b74:	bf2fc0ef          	jal	80000f66 <walkaddr>
    80004b78:	862a                	mv	a2,a0
    if (pa == 0)
    80004b7a:	d179                	beqz	a0,80004b40 <kexec+0xc2>
    if (sz - i < PGSIZE)
    80004b7c:	412984bb          	subw	s1,s3,s2
    80004b80:	0004879b          	sext.w	a5,s1
    80004b84:	fcfcf4e3          	bgeu	s9,a5,80004b4c <kexec+0xce>
    80004b88:	84d6                	mv	s1,s5
    80004b8a:	b7c9                	j	80004b4c <kexec+0xce>
    sz = sz1;
    80004b8c:	e0843903          	ld	s2,-504(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004b90:	2d85                	addiw	s11,s11,1
    80004b92:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    80004b96:	e8845783          	lhu	a5,-376(s0)
    80004b9a:	08fdd063          	bge	s11,a5,80004c1a <kexec+0x19c>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004b9e:	2d01                	sext.w	s10,s10
    80004ba0:	03800713          	li	a4,56
    80004ba4:	86ea                	mv	a3,s10
    80004ba6:	e1840613          	addi	a2,s0,-488
    80004baa:	4581                	li	a1,0
    80004bac:	8552                	mv	a0,s4
    80004bae:	d65fe0ef          	jal	80003912 <readi>
    80004bb2:	03800793          	li	a5,56
    80004bb6:	1cf51463          	bne	a0,a5,80004d7e <kexec+0x300>
    if (ph.type != ELF_PROG_LOAD)
    80004bba:	e1842783          	lw	a5,-488(s0)
    80004bbe:	4705                	li	a4,1
    80004bc0:	fce798e3          	bne	a5,a4,80004b90 <kexec+0x112>
    if (ph.memsz < ph.filesz)
    80004bc4:	e4043483          	ld	s1,-448(s0)
    80004bc8:	e3843783          	ld	a5,-456(s0)
    80004bcc:	1af4ed63          	bltu	s1,a5,80004d86 <kexec+0x308>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004bd0:	e2843783          	ld	a5,-472(s0)
    80004bd4:	94be                	add	s1,s1,a5
    80004bd6:	1af4ec63          	bltu	s1,a5,80004d8e <kexec+0x310>
    if (ph.vaddr % PGSIZE != 0)
    80004bda:	df043703          	ld	a4,-528(s0)
    80004bde:	8ff9                	and	a5,a5,a4
    80004be0:	1a079b63          	bnez	a5,80004d96 <kexec+0x318>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004be4:	e1c42503          	lw	a0,-484(s0)
    80004be8:	e7dff0ef          	jal	80004a64 <flags2perm>
    80004bec:	86aa                	mv	a3,a0
    80004bee:	8626                	mv	a2,s1
    80004bf0:	85ca                	mv	a1,s2
    80004bf2:	855a                	mv	a0,s6
    80004bf4:	e4afc0ef          	jal	8000123e <uvmalloc>
    80004bf8:	e0a43423          	sd	a0,-504(s0)
    80004bfc:	1a050163          	beqz	a0,80004d9e <kexec+0x320>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004c00:	e2843b83          	ld	s7,-472(s0)
    80004c04:	e2042c03          	lw	s8,-480(s0)
    80004c08:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004c0c:	00098463          	beqz	s3,80004c14 <kexec+0x196>
    80004c10:	4901                	li	s2,0
    80004c12:	bfa1                	j	80004b6a <kexec+0xec>
    sz = sz1;
    80004c14:	e0843903          	ld	s2,-504(s0)
    80004c18:	bfa5                	j	80004b90 <kexec+0x112>
    80004c1a:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004c1c:	8552                	mv	a0,s4
    80004c1e:	b6ffe0ef          	jal	8000378c <iunlockput>
  end_op();
    80004c22:	be6ff0ef          	jal	80004008 <end_op>
  p = myproc();
    80004c26:	c73fc0ef          	jal	80001898 <myproc>
    80004c2a:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004c2c:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004c30:	6b85                	lui	s7,0x1
    80004c32:	1bfd                	addi	s7,s7,-1 # fff <_entry-0x7ffff001>
    80004c34:	9bca                	add	s7,s7,s2
    80004c36:	77fd                	lui	a5,0xfffff
    80004c38:	00fbfbb3          	and	s7,s7,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004c3c:	4691                	li	a3,4
    80004c3e:	6609                	lui	a2,0x2
    80004c40:	965e                	add	a2,a2,s7
    80004c42:	85de                	mv	a1,s7
    80004c44:	855a                	mv	a0,s6
    80004c46:	df8fc0ef          	jal	8000123e <uvmalloc>
    80004c4a:	e0a43423          	sd	a0,-504(s0)
    80004c4e:	e519                	bnez	a0,80004c5c <kexec+0x1de>
  if (pagetable)
    80004c50:	e1743423          	sd	s7,-504(s0)
    80004c54:	4a01                	li	s4,0
    80004c56:	aaa9                	j	80004db0 <kexec+0x332>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004c58:	4901                	li	s2,0
    80004c5a:	b7c9                	j	80004c1c <kexec+0x19e>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004c5c:	75f9                	lui	a1,0xffffe
    80004c5e:	8baa                	mv	s7,a0
    80004c60:	95aa                	add	a1,a1,a0
    80004c62:	855a                	mv	a0,s6
    80004c64:	fb0fc0ef          	jal	80001414 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004c68:	7afd                	lui	s5,0xfffff
    80004c6a:	9ade                	add	s5,s5,s7
  for (argc = 0; argv[argc]; argc++) {
    80004c6c:	e0043783          	ld	a5,-512(s0)
    80004c70:	6388                	ld	a0,0(a5)
    80004c72:	c15d                	beqz	a0,80004d18 <kexec+0x29a>
    80004c74:	e9040913          	addi	s2,s0,-368
    80004c78:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004c7a:	948fc0ef          	jal	80000dc2 <strlen>
    80004c7e:	0015079b          	addiw	a5,a0,1
    80004c82:	40fb87b3          	sub	a5,s7,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004c86:	ff07fb93          	andi	s7,a5,-16
    if (sp < stackbase)
    80004c8a:	115bee63          	bltu	s7,s5,80004da6 <kexec+0x328>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004c8e:	e0043c83          	ld	s9,-512(s0)
    80004c92:	000cbc03          	ld	s8,0(s9)
    80004c96:	8562                	mv	a0,s8
    80004c98:	92afc0ef          	jal	80000dc2 <strlen>
    80004c9c:	0015071b          	addiw	a4,a0,1
    80004ca0:	86e2                	mv	a3,s8
    80004ca2:	865e                	mv	a2,s7
    80004ca4:	e0843583          	ld	a1,-504(s0)
    80004ca8:	855a                	mv	a0,s6
    80004caa:	831fc0ef          	jal	800014da <copyout>
    80004cae:	0e054e63          	bltz	a0,80004daa <kexec+0x32c>
    ustack[argc] = sp;
    80004cb2:	01793023          	sd	s7,0(s2)
  for (argc = 0; argv[argc]; argc++) {
    80004cb6:	0485                	addi	s1,s1,1
    80004cb8:	008c8793          	addi	a5,s9,8
    80004cbc:	e0f43023          	sd	a5,-512(s0)
    80004cc0:	008cb503          	ld	a0,8(s9)
    80004cc4:	0921                	addi	s2,s2,8
    80004cc6:	f955                	bnez	a0,80004c7a <kexec+0x1fc>
  ustack[argc] = 0;
    80004cc8:	00349793          	slli	a5,s1,0x3
    80004ccc:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffd6fd8>
    80004cd0:	97a2                	add	a5,a5,s0
    80004cd2:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004cd6:	00148713          	addi	a4,s1,1
    80004cda:	070e                	slli	a4,a4,0x3
    80004cdc:	40eb8933          	sub	s2,s7,a4
  sp -= sp % 16;
    80004ce0:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004ce4:	e0843583          	ld	a1,-504(s0)
    80004ce8:	8bae                	mv	s7,a1
  if (sp < stackbase)
    80004cea:	f75963e3          	bltu	s2,s5,80004c50 <kexec+0x1d2>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004cee:	e9040693          	addi	a3,s0,-368
    80004cf2:	864a                	mv	a2,s2
    80004cf4:	855a                	mv	a0,s6
    80004cf6:	fe4fc0ef          	jal	800014da <copyout>
    80004cfa:	0e054663          	bltz	a0,80004de6 <kexec+0x368>
  p->trapframe->a1 = sp;
    80004cfe:	0589b783          	ld	a5,88(s3)
    80004d02:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004d06:	df843783          	ld	a5,-520(s0)
    80004d0a:	0007c703          	lbu	a4,0(a5)
    80004d0e:	c315                	beqz	a4,80004d32 <kexec+0x2b4>
    80004d10:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004d12:	02f00693          	li	a3,47
    80004d16:	a809                	j	80004d28 <kexec+0x2aa>
  sp = sz;
    80004d18:	e0843b83          	ld	s7,-504(s0)
  for (argc = 0; argv[argc]; argc++) {
    80004d1c:	4481                	li	s1,0
    80004d1e:	b76d                	j	80004cc8 <kexec+0x24a>
  for (last = s = path; *s; s++)
    80004d20:	0785                	addi	a5,a5,1
    80004d22:	fff7c703          	lbu	a4,-1(a5)
    80004d26:	c711                	beqz	a4,80004d32 <kexec+0x2b4>
    if (*s == '/')
    80004d28:	fed71ce3          	bne	a4,a3,80004d20 <kexec+0x2a2>
      last = s + 1;
    80004d2c:	def43c23          	sd	a5,-520(s0)
    80004d30:	bfc5                	j	80004d20 <kexec+0x2a2>
  safestrcpy(p->name, last, sizeof(p->name));
    80004d32:	4641                	li	a2,16
    80004d34:	df843583          	ld	a1,-520(s0)
    80004d38:	15898513          	addi	a0,s3,344
    80004d3c:	854fc0ef          	jal	80000d90 <safestrcpy>
  oldpagetable = p->pagetable;
    80004d40:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004d44:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004d48:	e0843783          	ld	a5,-504(s0)
    80004d4c:	04f9b423          	sd	a5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004d50:	0589b783          	ld	a5,88(s3)
    80004d54:	e6843703          	ld	a4,-408(s0)
    80004d58:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004d5a:	0589b783          	ld	a5,88(s3)
    80004d5e:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004d62:	85d2                	mv	a1,s4
    80004d64:	ccbfc0ef          	jal	80001a2e <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004d68:	0004851b          	sext.w	a0,s1
    80004d6c:	79be                	ld	s3,488(sp)
    80004d6e:	7a1e                	ld	s4,480(sp)
    80004d70:	6afe                	ld	s5,472(sp)
    80004d72:	6b5e                	ld	s6,464(sp)
    80004d74:	6bbe                	ld	s7,456(sp)
    80004d76:	6c1e                	ld	s8,448(sp)
    80004d78:	7cfa                	ld	s9,440(sp)
    80004d7a:	7d5a                	ld	s10,432(sp)
    80004d7c:	bb85                	j	80004aec <kexec+0x6e>
    80004d7e:	e1243423          	sd	s2,-504(s0)
    80004d82:	7dba                	ld	s11,424(sp)
    80004d84:	a035                	j	80004db0 <kexec+0x332>
    80004d86:	e1243423          	sd	s2,-504(s0)
    80004d8a:	7dba                	ld	s11,424(sp)
    80004d8c:	a015                	j	80004db0 <kexec+0x332>
    80004d8e:	e1243423          	sd	s2,-504(s0)
    80004d92:	7dba                	ld	s11,424(sp)
    80004d94:	a831                	j	80004db0 <kexec+0x332>
    80004d96:	e1243423          	sd	s2,-504(s0)
    80004d9a:	7dba                	ld	s11,424(sp)
    80004d9c:	a811                	j	80004db0 <kexec+0x332>
    80004d9e:	e1243423          	sd	s2,-504(s0)
    80004da2:	7dba                	ld	s11,424(sp)
    80004da4:	a031                	j	80004db0 <kexec+0x332>
  ip = 0;
    80004da6:	4a01                	li	s4,0
    80004da8:	a021                	j	80004db0 <kexec+0x332>
    80004daa:	4a01                	li	s4,0
  if (pagetable)
    80004dac:	a011                	j	80004db0 <kexec+0x332>
    80004dae:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004db0:	e0843583          	ld	a1,-504(s0)
    80004db4:	855a                	mv	a0,s6
    80004db6:	c79fc0ef          	jal	80001a2e <proc_freepagetable>
  return -1;
    80004dba:	557d                	li	a0,-1
  if (ip) {
    80004dbc:	000a1b63          	bnez	s4,80004dd2 <kexec+0x354>
    80004dc0:	79be                	ld	s3,488(sp)
    80004dc2:	7a1e                	ld	s4,480(sp)
    80004dc4:	6afe                	ld	s5,472(sp)
    80004dc6:	6b5e                	ld	s6,464(sp)
    80004dc8:	6bbe                	ld	s7,456(sp)
    80004dca:	6c1e                	ld	s8,448(sp)
    80004dcc:	7cfa                	ld	s9,440(sp)
    80004dce:	7d5a                	ld	s10,432(sp)
    80004dd0:	bb31                	j	80004aec <kexec+0x6e>
    80004dd2:	79be                	ld	s3,488(sp)
    80004dd4:	6afe                	ld	s5,472(sp)
    80004dd6:	6b5e                	ld	s6,464(sp)
    80004dd8:	6bbe                	ld	s7,456(sp)
    80004dda:	6c1e                	ld	s8,448(sp)
    80004ddc:	7cfa                	ld	s9,440(sp)
    80004dde:	7d5a                	ld	s10,432(sp)
    80004de0:	b9fd                	j	80004ade <kexec+0x60>
    80004de2:	6b5e                	ld	s6,464(sp)
    80004de4:	b9ed                	j	80004ade <kexec+0x60>
  sz = sz1;
    80004de6:	e0843b83          	ld	s7,-504(s0)
    80004dea:	b59d                	j	80004c50 <kexec+0x1d2>

0000000080004dec <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004dec:	7179                	addi	sp,sp,-48
    80004dee:	f406                	sd	ra,40(sp)
    80004df0:	f022                	sd	s0,32(sp)
    80004df2:	ec26                	sd	s1,24(sp)
    80004df4:	e84a                	sd	s2,16(sp)
    80004df6:	1800                	addi	s0,sp,48
    80004df8:	892e                	mv	s2,a1
    80004dfa:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004dfc:	fdc40593          	addi	a1,s0,-36
    80004e00:	c5ffd0ef          	jal	80002a5e <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004e04:	fdc42703          	lw	a4,-36(s0)
    80004e08:	47bd                	li	a5,15
    80004e0a:	02e7e963          	bltu	a5,a4,80004e3c <argfd+0x50>
    80004e0e:	a8bfc0ef          	jal	80001898 <myproc>
    80004e12:	fdc42703          	lw	a4,-36(s0)
    80004e16:	01a70793          	addi	a5,a4,26
    80004e1a:	078e                	slli	a5,a5,0x3
    80004e1c:	953e                	add	a0,a0,a5
    80004e1e:	611c                	ld	a5,0(a0)
    80004e20:	c385                	beqz	a5,80004e40 <argfd+0x54>
    return -1;
  if (pfd)
    80004e22:	00090463          	beqz	s2,80004e2a <argfd+0x3e>
    *pfd = fd;
    80004e26:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    80004e2a:	4501                	li	a0,0
  if (pf)
    80004e2c:	c091                	beqz	s1,80004e30 <argfd+0x44>
    *pf = f;
    80004e2e:	e09c                	sd	a5,0(s1)
}
    80004e30:	70a2                	ld	ra,40(sp)
    80004e32:	7402                	ld	s0,32(sp)
    80004e34:	64e2                	ld	s1,24(sp)
    80004e36:	6942                	ld	s2,16(sp)
    80004e38:	6145                	addi	sp,sp,48
    80004e3a:	8082                	ret
    return -1;
    80004e3c:	557d                	li	a0,-1
    80004e3e:	bfcd                	j	80004e30 <argfd+0x44>
    80004e40:	557d                	li	a0,-1
    80004e42:	b7fd                	j	80004e30 <argfd+0x44>

0000000080004e44 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004e44:	1101                	addi	sp,sp,-32
    80004e46:	ec06                	sd	ra,24(sp)
    80004e48:	e822                	sd	s0,16(sp)
    80004e4a:	e426                	sd	s1,8(sp)
    80004e4c:	1000                	addi	s0,sp,32
    80004e4e:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004e50:	a49fc0ef          	jal	80001898 <myproc>
    80004e54:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004e56:	0d050793          	addi	a5,a0,208
    80004e5a:	4501                	li	a0,0
    80004e5c:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004e5e:	6398                	ld	a4,0(a5)
    80004e60:	cb19                	beqz	a4,80004e76 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004e62:	2505                	addiw	a0,a0,1
    80004e64:	07a1                	addi	a5,a5,8
    80004e66:	fed51ce3          	bne	a0,a3,80004e5e <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004e6a:	557d                	li	a0,-1
}
    80004e6c:	60e2                	ld	ra,24(sp)
    80004e6e:	6442                	ld	s0,16(sp)
    80004e70:	64a2                	ld	s1,8(sp)
    80004e72:	6105                	addi	sp,sp,32
    80004e74:	8082                	ret
      p->ofile[fd] = f;
    80004e76:	01a50793          	addi	a5,a0,26
    80004e7a:	078e                	slli	a5,a5,0x3
    80004e7c:	963e                	add	a2,a2,a5
    80004e7e:	e204                	sd	s1,0(a2)
      return fd;
    80004e80:	b7f5                	j	80004e6c <fdalloc+0x28>

0000000080004e82 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004e82:	715d                	addi	sp,sp,-80
    80004e84:	e486                	sd	ra,72(sp)
    80004e86:	e0a2                	sd	s0,64(sp)
    80004e88:	fc26                	sd	s1,56(sp)
    80004e8a:	f84a                	sd	s2,48(sp)
    80004e8c:	f44e                	sd	s3,40(sp)
    80004e8e:	f052                	sd	s4,32(sp)
    80004e90:	ec56                	sd	s5,24(sp)
    80004e92:	0880                	addi	s0,sp,80
    80004e94:	892e                	mv	s2,a1
    80004e96:	89b2                	mv	s3,a2
    80004e98:	8a36                	mv	s4,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004e9a:	fb040593          	addi	a1,s0,-80
    80004e9e:	f2bfe0ef          	jal	80003dc8 <nameiparent>
    80004ea2:	8aaa                	mv	s5,a0
    80004ea4:	cd45                	beqz	a0,80004f5c <create+0xda>
    return 0;

  ilock(dp);
    80004ea6:	e94fe0ef          	jal	8000353a <ilock>

  if (dp->nlink == 0) {
    80004eaa:	04aa9783          	lh	a5,74(s5) # fffffffffffff04a <end+0xffffffff7ffd7092>
    80004eae:	cf8d                	beqz	a5,80004ee8 <create+0x66>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004eb0:	4705                	li	a4,1
    80004eb2:	04e91563          	bne	s2,a4,80004efc <create+0x7a>
    80004eb6:	6721                	lui	a4,0x8
    80004eb8:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004eba:	02e78c63          	beq	a5,a4,80004ef2 <create+0x70>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004ebe:	4601                	li	a2,0
    80004ec0:	fb040593          	addi	a1,s0,-80
    80004ec4:	8556                	mv	a0,s5
    80004ec6:	c73fe0ef          	jal	80003b38 <dirlookup>
    80004eca:	84aa                	mv	s1,a0
    80004ecc:	e951                	bnez	a0,80004f60 <create+0xde>
      return ip;
    iunlockput(ip);
    return 0;
  }

  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004ece:	85ca                	mv	a1,s2
    80004ed0:	000aa503          	lw	a0,0(s5)
    80004ed4:	cf6fe0ef          	jal	800033ca <ialloc>
    80004ed8:	84aa                	mv	s1,a0
    80004eda:	0c051e63          	bnez	a0,80004fb6 <create+0x134>
    iunlockput(dp);
    80004ede:	8556                	mv	a0,s5
    80004ee0:	8adfe0ef          	jal	8000378c <iunlockput>
    return 0;
    80004ee4:	4481                	li	s1,0
    80004ee6:	a0a1                	j	80004f2e <create+0xac>
    iunlockput(dp);
    80004ee8:	8556                	mv	a0,s5
    80004eea:	8a3fe0ef          	jal	8000378c <iunlockput>
    return 0;
    80004eee:	4481                	li	s1,0
    80004ef0:	a83d                	j	80004f2e <create+0xac>
    iunlockput(dp);
    80004ef2:	8556                	mv	a0,s5
    80004ef4:	899fe0ef          	jal	8000378c <iunlockput>
    return 0;
    80004ef8:	4481                	li	s1,0
    80004efa:	a815                	j	80004f2e <create+0xac>
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004efc:	4601                	li	a2,0
    80004efe:	fb040593          	addi	a1,s0,-80
    80004f02:	8556                	mv	a0,s5
    80004f04:	c35fe0ef          	jal	80003b38 <dirlookup>
    80004f08:	84aa                	mv	s1,a0
    80004f0a:	c535                	beqz	a0,80004f76 <create+0xf4>
    iunlockput(dp);
    80004f0c:	8556                	mv	a0,s5
    80004f0e:	87ffe0ef          	jal	8000378c <iunlockput>
    ilock(ip);
    80004f12:	8526                	mv	a0,s1
    80004f14:	e26fe0ef          	jal	8000353a <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004f18:	4789                	li	a5,2
    80004f1a:	04f91963          	bne	s2,a5,80004f6c <create+0xea>
    80004f1e:	0444d783          	lhu	a5,68(s1)
    80004f22:	37f9                	addiw	a5,a5,-2
    80004f24:	17c2                	slli	a5,a5,0x30
    80004f26:	93c1                	srli	a5,a5,0x30
    80004f28:	4705                	li	a4,1
    80004f2a:	04f76163          	bltu	a4,a5,80004f6c <create+0xea>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004f2e:	8526                	mv	a0,s1
    80004f30:	60a6                	ld	ra,72(sp)
    80004f32:	6406                	ld	s0,64(sp)
    80004f34:	74e2                	ld	s1,56(sp)
    80004f36:	7942                	ld	s2,48(sp)
    80004f38:	79a2                	ld	s3,40(sp)
    80004f3a:	7a02                	ld	s4,32(sp)
    80004f3c:	6ae2                	ld	s5,24(sp)
    80004f3e:	6161                	addi	sp,sp,80
    80004f40:	8082                	ret
  ip->nlink = 0;
    80004f42:	04049523          	sh	zero,74(s1)
  iupdate(ip);
    80004f46:	8526                	mv	a0,s1
    80004f48:	d3efe0ef          	jal	80003486 <iupdate>
  iunlockput(ip);
    80004f4c:	8526                	mv	a0,s1
    80004f4e:	83ffe0ef          	jal	8000378c <iunlockput>
  iunlockput(dp);
    80004f52:	8556                	mv	a0,s5
    80004f54:	839fe0ef          	jal	8000378c <iunlockput>
  return 0;
    80004f58:	4481                	li	s1,0
    80004f5a:	bfd1                	j	80004f2e <create+0xac>
    return 0;
    80004f5c:	84aa                	mv	s1,a0
    80004f5e:	bfc1                	j	80004f2e <create+0xac>
    iunlockput(dp);
    80004f60:	8556                	mv	a0,s5
    80004f62:	82bfe0ef          	jal	8000378c <iunlockput>
    ilock(ip);
    80004f66:	8526                	mv	a0,s1
    80004f68:	dd2fe0ef          	jal	8000353a <ilock>
    iunlockput(ip);
    80004f6c:	8526                	mv	a0,s1
    80004f6e:	81ffe0ef          	jal	8000378c <iunlockput>
    return 0;
    80004f72:	4481                	li	s1,0
    80004f74:	bf6d                	j	80004f2e <create+0xac>
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004f76:	85ca                	mv	a1,s2
    80004f78:	000aa503          	lw	a0,0(s5)
    80004f7c:	c4efe0ef          	jal	800033ca <ialloc>
    80004f80:	84aa                	mv	s1,a0
    80004f82:	dd31                	beqz	a0,80004ede <create+0x5c>
  ilock(ip);
    80004f84:	8526                	mv	a0,s1
    80004f86:	db4fe0ef          	jal	8000353a <ilock>
  ip->major = major;
    80004f8a:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004f8e:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004f92:	4785                	li	a5,1
    80004f94:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f98:	8526                	mv	a0,s1
    80004f9a:	cecfe0ef          	jal	80003486 <iupdate>
  if (dirlink(dp, name, ip->inum) < 0)
    80004f9e:	40d0                	lw	a2,4(s1)
    80004fa0:	fb040593          	addi	a1,s0,-80
    80004fa4:	8556                	mv	a0,s5
    80004fa6:	d6ffe0ef          	jal	80003d14 <dirlink>
    80004faa:	f8054ce3          	bltz	a0,80004f42 <create+0xc0>
  iunlockput(dp);
    80004fae:	8556                	mv	a0,s5
    80004fb0:	fdcfe0ef          	jal	8000378c <iunlockput>
  return ip;
    80004fb4:	bfad                	j	80004f2e <create+0xac>
  ilock(ip);
    80004fb6:	8526                	mv	a0,s1
    80004fb8:	d82fe0ef          	jal	8000353a <ilock>
  ip->major = major;
    80004fbc:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004fc0:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004fc4:	4785                	li	a5,1
    80004fc6:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fca:	8526                	mv	a0,s1
    80004fcc:	cbafe0ef          	jal	80003486 <iupdate>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004fd0:	40d0                	lw	a2,4(s1)
    80004fd2:	00004597          	auipc	a1,0x4
    80004fd6:	67658593          	addi	a1,a1,1654 # 80009648 <etext+0x648>
    80004fda:	8526                	mv	a0,s1
    80004fdc:	d39fe0ef          	jal	80003d14 <dirlink>
    80004fe0:	f60541e3          	bltz	a0,80004f42 <create+0xc0>
    80004fe4:	004aa603          	lw	a2,4(s5)
    80004fe8:	00004597          	auipc	a1,0x4
    80004fec:	65858593          	addi	a1,a1,1624 # 80009640 <etext+0x640>
    80004ff0:	8526                	mv	a0,s1
    80004ff2:	d23fe0ef          	jal	80003d14 <dirlink>
    80004ff6:	f40546e3          	bltz	a0,80004f42 <create+0xc0>
  if (dirlink(dp, name, ip->inum) < 0)
    80004ffa:	40d0                	lw	a2,4(s1)
    80004ffc:	fb040593          	addi	a1,s0,-80
    80005000:	8556                	mv	a0,s5
    80005002:	d13fe0ef          	jal	80003d14 <dirlink>
    80005006:	f2054ee3          	bltz	a0,80004f42 <create+0xc0>
    dp->nlink++; // for ".."
    8000500a:	04aad783          	lhu	a5,74(s5)
    8000500e:	2785                	addiw	a5,a5,1
    80005010:	04fa9523          	sh	a5,74(s5)
    iupdate(dp);
    80005014:	8556                	mv	a0,s5
    80005016:	c70fe0ef          	jal	80003486 <iupdate>
    8000501a:	bf51                	j	80004fae <create+0x12c>

000000008000501c <sys_dup>:
{
    8000501c:	7179                	addi	sp,sp,-48
    8000501e:	f406                	sd	ra,40(sp)
    80005020:	f022                	sd	s0,32(sp)
    80005022:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80005024:	fd840613          	addi	a2,s0,-40
    80005028:	4581                	li	a1,0
    8000502a:	4501                	li	a0,0
    8000502c:	dc1ff0ef          	jal	80004dec <argfd>
    return -1;
    80005030:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80005032:	02054363          	bltz	a0,80005058 <sys_dup+0x3c>
    80005036:	ec26                	sd	s1,24(sp)
    80005038:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    8000503a:	fd843903          	ld	s2,-40(s0)
    8000503e:	854a                	mv	a0,s2
    80005040:	e05ff0ef          	jal	80004e44 <fdalloc>
    80005044:	84aa                	mv	s1,a0
    return -1;
    80005046:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80005048:	00054d63          	bltz	a0,80005062 <sys_dup+0x46>
  filedup(f);
    8000504c:	854a                	mv	a0,s2
    8000504e:	b9aff0ef          	jal	800043e8 <filedup>
  return fd;
    80005052:	87a6                	mv	a5,s1
    80005054:	64e2                	ld	s1,24(sp)
    80005056:	6942                	ld	s2,16(sp)
}
    80005058:	853e                	mv	a0,a5
    8000505a:	70a2                	ld	ra,40(sp)
    8000505c:	7402                	ld	s0,32(sp)
    8000505e:	6145                	addi	sp,sp,48
    80005060:	8082                	ret
    80005062:	64e2                	ld	s1,24(sp)
    80005064:	6942                	ld	s2,16(sp)
    80005066:	bfcd                	j	80005058 <sys_dup+0x3c>

0000000080005068 <sys_read>:
{
    80005068:	7179                	addi	sp,sp,-48
    8000506a:	f406                	sd	ra,40(sp)
    8000506c:	f022                	sd	s0,32(sp)
    8000506e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005070:	fd840593          	addi	a1,s0,-40
    80005074:	4505                	li	a0,1
    80005076:	a05fd0ef          	jal	80002a7a <argaddr>
  argint(2, &n);
    8000507a:	fe440593          	addi	a1,s0,-28
    8000507e:	4509                	li	a0,2
    80005080:	9dffd0ef          	jal	80002a5e <argint>
  if (argfd(0, 0, &f) < 0)
    80005084:	fe840613          	addi	a2,s0,-24
    80005088:	4581                	li	a1,0
    8000508a:	4501                	li	a0,0
    8000508c:	d61ff0ef          	jal	80004dec <argfd>
    80005090:	87aa                	mv	a5,a0
    return -1;
    80005092:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80005094:	0007ca63          	bltz	a5,800050a8 <sys_read+0x40>
  return fileread(f, p, n);
    80005098:	fe442603          	lw	a2,-28(s0)
    8000509c:	fd843583          	ld	a1,-40(s0)
    800050a0:	fe843503          	ld	a0,-24(s0)
    800050a4:	caeff0ef          	jal	80004552 <fileread>
}
    800050a8:	70a2                	ld	ra,40(sp)
    800050aa:	7402                	ld	s0,32(sp)
    800050ac:	6145                	addi	sp,sp,48
    800050ae:	8082                	ret

00000000800050b0 <sys_write>:
{
    800050b0:	7179                	addi	sp,sp,-48
    800050b2:	f406                	sd	ra,40(sp)
    800050b4:	f022                	sd	s0,32(sp)
    800050b6:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800050b8:	fd840593          	addi	a1,s0,-40
    800050bc:	4505                	li	a0,1
    800050be:	9bdfd0ef          	jal	80002a7a <argaddr>
  argint(2, &n);
    800050c2:	fe440593          	addi	a1,s0,-28
    800050c6:	4509                	li	a0,2
    800050c8:	997fd0ef          	jal	80002a5e <argint>
  if (argfd(0, 0, &f) < 0)
    800050cc:	fe840613          	addi	a2,s0,-24
    800050d0:	4581                	li	a1,0
    800050d2:	4501                	li	a0,0
    800050d4:	d19ff0ef          	jal	80004dec <argfd>
    800050d8:	87aa                	mv	a5,a0
    return -1;
    800050da:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    800050dc:	0007ca63          	bltz	a5,800050f0 <sys_write+0x40>
  return filewrite(f, p, n);
    800050e0:	fe442603          	lw	a2,-28(s0)
    800050e4:	fd843583          	ld	a1,-40(s0)
    800050e8:	fe843503          	ld	a0,-24(s0)
    800050ec:	d30ff0ef          	jal	8000461c <filewrite>
}
    800050f0:	70a2                	ld	ra,40(sp)
    800050f2:	7402                	ld	s0,32(sp)
    800050f4:	6145                	addi	sp,sp,48
    800050f6:	8082                	ret

00000000800050f8 <sys_close>:
{
    800050f8:	1101                	addi	sp,sp,-32
    800050fa:	ec06                	sd	ra,24(sp)
    800050fc:	e822                	sd	s0,16(sp)
    800050fe:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80005100:	fe040613          	addi	a2,s0,-32
    80005104:	fec40593          	addi	a1,s0,-20
    80005108:	4501                	li	a0,0
    8000510a:	ce3ff0ef          	jal	80004dec <argfd>
    return -1;
    8000510e:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80005110:	02054063          	bltz	a0,80005130 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80005114:	f84fc0ef          	jal	80001898 <myproc>
    80005118:	fec42783          	lw	a5,-20(s0)
    8000511c:	07e9                	addi	a5,a5,26
    8000511e:	078e                	slli	a5,a5,0x3
    80005120:	953e                	add	a0,a0,a5
    80005122:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005126:	fe043503          	ld	a0,-32(s0)
    8000512a:	b04ff0ef          	jal	8000442e <fileclose>
  return 0;
    8000512e:	4781                	li	a5,0
}
    80005130:	853e                	mv	a0,a5
    80005132:	60e2                	ld	ra,24(sp)
    80005134:	6442                	ld	s0,16(sp)
    80005136:	6105                	addi	sp,sp,32
    80005138:	8082                	ret

000000008000513a <sys_fstat>:
{
    8000513a:	1101                	addi	sp,sp,-32
    8000513c:	ec06                	sd	ra,24(sp)
    8000513e:	e822                	sd	s0,16(sp)
    80005140:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005142:	fe040593          	addi	a1,s0,-32
    80005146:	4505                	li	a0,1
    80005148:	933fd0ef          	jal	80002a7a <argaddr>
  if (argfd(0, 0, &f) < 0)
    8000514c:	fe840613          	addi	a2,s0,-24
    80005150:	4581                	li	a1,0
    80005152:	4501                	li	a0,0
    80005154:	c99ff0ef          	jal	80004dec <argfd>
    80005158:	87aa                	mv	a5,a0
    return -1;
    8000515a:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    8000515c:	0007c863          	bltz	a5,8000516c <sys_fstat+0x32>
  return filestat(f, st);
    80005160:	fe043583          	ld	a1,-32(s0)
    80005164:	fe843503          	ld	a0,-24(s0)
    80005168:	b88ff0ef          	jal	800044f0 <filestat>
}
    8000516c:	60e2                	ld	ra,24(sp)
    8000516e:	6442                	ld	s0,16(sp)
    80005170:	6105                	addi	sp,sp,32
    80005172:	8082                	ret

0000000080005174 <sys_link>:
{
    80005174:	7169                	addi	sp,sp,-304
    80005176:	f606                	sd	ra,296(sp)
    80005178:	f222                	sd	s0,288(sp)
    8000517a:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000517c:	08000613          	li	a2,128
    80005180:	ed040593          	addi	a1,s0,-304
    80005184:	4501                	li	a0,0
    80005186:	911fd0ef          	jal	80002a96 <argstr>
    return -1;
    8000518a:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000518c:	10054163          	bltz	a0,8000528e <sys_link+0x11a>
    80005190:	08000613          	li	a2,128
    80005194:	f5040593          	addi	a1,s0,-176
    80005198:	4505                	li	a0,1
    8000519a:	8fdfd0ef          	jal	80002a96 <argstr>
    return -1;
    8000519e:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800051a0:	0e054763          	bltz	a0,8000528e <sys_link+0x11a>
    800051a4:	ee26                	sd	s1,280(sp)
  begin_op();
    800051a6:	dddfe0ef          	jal	80003f82 <begin_op>
  if ((ip = namei(old)) == 0) {
    800051aa:	ed040513          	addi	a0,s0,-304
    800051ae:	c01fe0ef          	jal	80003dae <namei>
    800051b2:	84aa                	mv	s1,a0
    800051b4:	cd35                	beqz	a0,80005230 <sys_link+0xbc>
  ilock(ip);
    800051b6:	b84fe0ef          	jal	8000353a <ilock>
  if (ip->type == T_DIR) {
    800051ba:	04449703          	lh	a4,68(s1)
    800051be:	4785                	li	a5,1
    800051c0:	06f70d63          	beq	a4,a5,8000523a <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    800051c4:	04a49783          	lh	a5,74(s1)
    800051c8:	6721                	lui	a4,0x8
    800051ca:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    800051cc:	06e78f63          	beq	a5,a4,8000524a <sys_link+0xd6>
    800051d0:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800051d2:	2785                	addiw	a5,a5,1
    800051d4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800051d8:	8526                	mv	a0,s1
    800051da:	aacfe0ef          	jal	80003486 <iupdate>
  iunlock(ip);
    800051de:	8526                	mv	a0,s1
    800051e0:	c08fe0ef          	jal	800035e8 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    800051e4:	fd040593          	addi	a1,s0,-48
    800051e8:	f5040513          	addi	a0,s0,-176
    800051ec:	bddfe0ef          	jal	80003dc8 <nameiparent>
    800051f0:	892a                	mv	s2,a0
    800051f2:	c93d                	beqz	a0,80005268 <sys_link+0xf4>
  ilock(dp);
    800051f4:	b46fe0ef          	jal	8000353a <ilock>
  if (dp->nlink == 0) {
    800051f8:	04a91783          	lh	a5,74(s2)
    800051fc:	cfb9                	beqz	a5,8000525a <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    800051fe:	00092703          	lw	a4,0(s2)
    80005202:	409c                	lw	a5,0(s1)
    80005204:	04f71f63          	bne	a4,a5,80005262 <sys_link+0xee>
    80005208:	40d0                	lw	a2,4(s1)
    8000520a:	fd040593          	addi	a1,s0,-48
    8000520e:	854a                	mv	a0,s2
    80005210:	b05fe0ef          	jal	80003d14 <dirlink>
    80005214:	04054763          	bltz	a0,80005262 <sys_link+0xee>
  iunlockput(dp);
    80005218:	854a                	mv	a0,s2
    8000521a:	d72fe0ef          	jal	8000378c <iunlockput>
  iput(ip);
    8000521e:	8526                	mv	a0,s1
    80005220:	c9cfe0ef          	jal	800036bc <iput>
  end_op();
    80005224:	de5fe0ef          	jal	80004008 <end_op>
  return 0;
    80005228:	4781                	li	a5,0
    8000522a:	64f2                	ld	s1,280(sp)
    8000522c:	6952                	ld	s2,272(sp)
    8000522e:	a085                	j	8000528e <sys_link+0x11a>
    end_op();
    80005230:	dd9fe0ef          	jal	80004008 <end_op>
    return -1;
    80005234:	57fd                	li	a5,-1
    80005236:	64f2                	ld	s1,280(sp)
    80005238:	a899                	j	8000528e <sys_link+0x11a>
    iunlockput(ip);
    8000523a:	8526                	mv	a0,s1
    8000523c:	d50fe0ef          	jal	8000378c <iunlockput>
    end_op();
    80005240:	dc9fe0ef          	jal	80004008 <end_op>
    return -1;
    80005244:	57fd                	li	a5,-1
    80005246:	64f2                	ld	s1,280(sp)
    80005248:	a099                	j	8000528e <sys_link+0x11a>
    iunlockput(ip);
    8000524a:	8526                	mv	a0,s1
    8000524c:	d40fe0ef          	jal	8000378c <iunlockput>
    end_op();
    80005250:	db9fe0ef          	jal	80004008 <end_op>
    return -1;
    80005254:	57fd                	li	a5,-1
    80005256:	64f2                	ld	s1,280(sp)
    80005258:	a81d                	j	8000528e <sys_link+0x11a>
    iunlockput(dp);
    8000525a:	854a                	mv	a0,s2
    8000525c:	d30fe0ef          	jal	8000378c <iunlockput>
    goto bad;
    80005260:	a021                	j	80005268 <sys_link+0xf4>
    iunlockput(dp);
    80005262:	854a                	mv	a0,s2
    80005264:	d28fe0ef          	jal	8000378c <iunlockput>
  ilock(ip);
    80005268:	8526                	mv	a0,s1
    8000526a:	ad0fe0ef          	jal	8000353a <ilock>
  ip->nlink--;
    8000526e:	04a4d783          	lhu	a5,74(s1)
    80005272:	37fd                	addiw	a5,a5,-1
    80005274:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005278:	8526                	mv	a0,s1
    8000527a:	a0cfe0ef          	jal	80003486 <iupdate>
  iunlockput(ip);
    8000527e:	8526                	mv	a0,s1
    80005280:	d0cfe0ef          	jal	8000378c <iunlockput>
  end_op();
    80005284:	d85fe0ef          	jal	80004008 <end_op>
  return -1;
    80005288:	57fd                	li	a5,-1
    8000528a:	64f2                	ld	s1,280(sp)
    8000528c:	6952                	ld	s2,272(sp)
}
    8000528e:	853e                	mv	a0,a5
    80005290:	70b2                	ld	ra,296(sp)
    80005292:	7412                	ld	s0,288(sp)
    80005294:	6155                	addi	sp,sp,304
    80005296:	8082                	ret

0000000080005298 <sys_unlink>:
{
    80005298:	7151                	addi	sp,sp,-240
    8000529a:	f586                	sd	ra,232(sp)
    8000529c:	f1a2                	sd	s0,224(sp)
    8000529e:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    800052a0:	08000613          	li	a2,128
    800052a4:	f3040593          	addi	a1,s0,-208
    800052a8:	4501                	li	a0,0
    800052aa:	fecfd0ef          	jal	80002a96 <argstr>
    800052ae:	16054063          	bltz	a0,8000540e <sys_unlink+0x176>
    800052b2:	eda6                	sd	s1,216(sp)
  begin_op();
    800052b4:	ccffe0ef          	jal	80003f82 <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    800052b8:	fb040593          	addi	a1,s0,-80
    800052bc:	f3040513          	addi	a0,s0,-208
    800052c0:	b09fe0ef          	jal	80003dc8 <nameiparent>
    800052c4:	84aa                	mv	s1,a0
    800052c6:	c945                	beqz	a0,80005376 <sys_unlink+0xde>
  ilock(dp);
    800052c8:	a72fe0ef          	jal	8000353a <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800052cc:	00004597          	auipc	a1,0x4
    800052d0:	37c58593          	addi	a1,a1,892 # 80009648 <etext+0x648>
    800052d4:	fb040513          	addi	a0,s0,-80
    800052d8:	84bfe0ef          	jal	80003b22 <namecmp>
    800052dc:	10050e63          	beqz	a0,800053f8 <sys_unlink+0x160>
    800052e0:	00004597          	auipc	a1,0x4
    800052e4:	36058593          	addi	a1,a1,864 # 80009640 <etext+0x640>
    800052e8:	fb040513          	addi	a0,s0,-80
    800052ec:	837fe0ef          	jal	80003b22 <namecmp>
    800052f0:	10050463          	beqz	a0,800053f8 <sys_unlink+0x160>
    800052f4:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    800052f6:	f2c40613          	addi	a2,s0,-212
    800052fa:	fb040593          	addi	a1,s0,-80
    800052fe:	8526                	mv	a0,s1
    80005300:	839fe0ef          	jal	80003b38 <dirlookup>
    80005304:	892a                	mv	s2,a0
    80005306:	0e050863          	beqz	a0,800053f6 <sys_unlink+0x15e>
  ilock(ip);
    8000530a:	a30fe0ef          	jal	8000353a <ilock>
  if (ip->nlink < 1)
    8000530e:	04a91783          	lh	a5,74(s2)
    80005312:	06f05763          	blez	a5,80005380 <sys_unlink+0xe8>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    80005316:	04491703          	lh	a4,68(s2)
    8000531a:	4785                	li	a5,1
    8000531c:	06f70963          	beq	a4,a5,8000538e <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80005320:	4641                	li	a2,16
    80005322:	4581                	li	a1,0
    80005324:	fc040513          	addi	a0,s0,-64
    80005328:	92bfb0ef          	jal	80000c52 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000532c:	4741                	li	a4,16
    8000532e:	f2c42683          	lw	a3,-212(s0)
    80005332:	fc040613          	addi	a2,s0,-64
    80005336:	4581                	li	a1,0
    80005338:	8526                	mv	a0,s1
    8000533a:	ed4fe0ef          	jal	80003a0e <writei>
    8000533e:	47c1                	li	a5,16
    80005340:	08f51b63          	bne	a0,a5,800053d6 <sys_unlink+0x13e>
  if (ip->type == T_DIR) {
    80005344:	04491703          	lh	a4,68(s2)
    80005348:	4785                	li	a5,1
    8000534a:	08f70d63          	beq	a4,a5,800053e4 <sys_unlink+0x14c>
  iunlockput(dp);
    8000534e:	8526                	mv	a0,s1
    80005350:	c3cfe0ef          	jal	8000378c <iunlockput>
  ip->nlink--;
    80005354:	04a95783          	lhu	a5,74(s2)
    80005358:	37fd                	addiw	a5,a5,-1
    8000535a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000535e:	854a                	mv	a0,s2
    80005360:	926fe0ef          	jal	80003486 <iupdate>
  iunlockput(ip);
    80005364:	854a                	mv	a0,s2
    80005366:	c26fe0ef          	jal	8000378c <iunlockput>
  end_op();
    8000536a:	c9ffe0ef          	jal	80004008 <end_op>
  return 0;
    8000536e:	4501                	li	a0,0
    80005370:	64ee                	ld	s1,216(sp)
    80005372:	694e                	ld	s2,208(sp)
    80005374:	a849                	j	80005406 <sys_unlink+0x16e>
    end_op();
    80005376:	c93fe0ef          	jal	80004008 <end_op>
    return -1;
    8000537a:	557d                	li	a0,-1
    8000537c:	64ee                	ld	s1,216(sp)
    8000537e:	a061                	j	80005406 <sys_unlink+0x16e>
    80005380:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80005382:	00004517          	auipc	a0,0x4
    80005386:	2ce50513          	addi	a0,a0,718 # 80009650 <etext+0x650>
    8000538a:	c64fb0ef          	jal	800007ee <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    8000538e:	04c92703          	lw	a4,76(s2)
    80005392:	02000793          	li	a5,32
    80005396:	f8e7f5e3          	bgeu	a5,a4,80005320 <sys_unlink+0x88>
    8000539a:	e5ce                	sd	s3,200(sp)
    8000539c:	02000993          	li	s3,32
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800053a0:	4741                	li	a4,16
    800053a2:	86ce                	mv	a3,s3
    800053a4:	f1840613          	addi	a2,s0,-232
    800053a8:	4581                	li	a1,0
    800053aa:	854a                	mv	a0,s2
    800053ac:	d66fe0ef          	jal	80003912 <readi>
    800053b0:	47c1                	li	a5,16
    800053b2:	00f51c63          	bne	a0,a5,800053ca <sys_unlink+0x132>
    if (de.inum != 0)
    800053b6:	f1845783          	lhu	a5,-232(s0)
    800053ba:	efa1                	bnez	a5,80005412 <sys_unlink+0x17a>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800053bc:	29c1                	addiw	s3,s3,16
    800053be:	04c92783          	lw	a5,76(s2)
    800053c2:	fcf9efe3          	bltu	s3,a5,800053a0 <sys_unlink+0x108>
    800053c6:	69ae                	ld	s3,200(sp)
    800053c8:	bfa1                	j	80005320 <sys_unlink+0x88>
      panic("isdirempty: readi");
    800053ca:	00004517          	auipc	a0,0x4
    800053ce:	29e50513          	addi	a0,a0,670 # 80009668 <etext+0x668>
    800053d2:	c1cfb0ef          	jal	800007ee <panic>
    800053d6:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    800053d8:	00004517          	auipc	a0,0x4
    800053dc:	2a850513          	addi	a0,a0,680 # 80009680 <etext+0x680>
    800053e0:	c0efb0ef          	jal	800007ee <panic>
    dp->nlink--;
    800053e4:	04a4d783          	lhu	a5,74(s1)
    800053e8:	37fd                	addiw	a5,a5,-1
    800053ea:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800053ee:	8526                	mv	a0,s1
    800053f0:	896fe0ef          	jal	80003486 <iupdate>
    800053f4:	bfa9                	j	8000534e <sys_unlink+0xb6>
    800053f6:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800053f8:	8526                	mv	a0,s1
    800053fa:	b92fe0ef          	jal	8000378c <iunlockput>
  end_op();
    800053fe:	c0bfe0ef          	jal	80004008 <end_op>
  return -1;
    80005402:	557d                	li	a0,-1
    80005404:	64ee                	ld	s1,216(sp)
}
    80005406:	70ae                	ld	ra,232(sp)
    80005408:	740e                	ld	s0,224(sp)
    8000540a:	616d                	addi	sp,sp,240
    8000540c:	8082                	ret
    return -1;
    8000540e:	557d                	li	a0,-1
    80005410:	bfdd                	j	80005406 <sys_unlink+0x16e>
    iunlockput(ip);
    80005412:	854a                	mv	a0,s2
    80005414:	b78fe0ef          	jal	8000378c <iunlockput>
    goto bad;
    80005418:	694e                	ld	s2,208(sp)
    8000541a:	69ae                	ld	s3,200(sp)
    8000541c:	bff1                	j	800053f8 <sys_unlink+0x160>

000000008000541e <sys_open>:

uint64
sys_open(void)
{
    8000541e:	7131                	addi	sp,sp,-192
    80005420:	fd06                	sd	ra,184(sp)
    80005422:	f922                	sd	s0,176(sp)
    80005424:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005426:	f4c40593          	addi	a1,s0,-180
    8000542a:	4505                	li	a0,1
    8000542c:	e32fd0ef          	jal	80002a5e <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005430:	08000613          	li	a2,128
    80005434:	f5040593          	addi	a1,s0,-176
    80005438:	4501                	li	a0,0
    8000543a:	e5cfd0ef          	jal	80002a96 <argstr>
    8000543e:	87aa                	mv	a5,a0
    return -1;
    80005440:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005442:	0a07c263          	bltz	a5,800054e6 <sys_open+0xc8>
    80005446:	f526                	sd	s1,168(sp)

  begin_op();
    80005448:	b3bfe0ef          	jal	80003f82 <begin_op>

  if (omode & O_CREATE) {
    8000544c:	f4c42783          	lw	a5,-180(s0)
    80005450:	2007f793          	andi	a5,a5,512
    80005454:	c3d5                	beqz	a5,800054f8 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80005456:	4681                	li	a3,0
    80005458:	4601                	li	a2,0
    8000545a:	4589                	li	a1,2
    8000545c:	f5040513          	addi	a0,s0,-176
    80005460:	a23ff0ef          	jal	80004e82 <create>
    80005464:	84aa                	mv	s1,a0
    if (ip == 0) {
    80005466:	c541                	beqz	a0,800054ee <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    80005468:	04449703          	lh	a4,68(s1)
    8000546c:	478d                	li	a5,3
    8000546e:	00f71763          	bne	a4,a5,8000547c <sys_open+0x5e>
    80005472:	0464d703          	lhu	a4,70(s1)
    80005476:	47a5                	li	a5,9
    80005478:	0ae7ed63          	bltu	a5,a4,80005532 <sys_open+0x114>
    8000547c:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    8000547e:	f0dfe0ef          	jal	8000438a <filealloc>
    80005482:	892a                	mv	s2,a0
    80005484:	c179                	beqz	a0,8000554a <sys_open+0x12c>
    80005486:	ed4e                	sd	s3,152(sp)
    80005488:	9bdff0ef          	jal	80004e44 <fdalloc>
    8000548c:	89aa                	mv	s3,a0
    8000548e:	0a054a63          	bltz	a0,80005542 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    80005492:	04449703          	lh	a4,68(s1)
    80005496:	478d                	li	a5,3
    80005498:	0cf70263          	beq	a4,a5,8000555c <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000549c:	4789                	li	a5,2
    8000549e:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800054a2:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800054a6:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800054aa:	f4c42783          	lw	a5,-180(s0)
    800054ae:	0017c713          	xori	a4,a5,1
    800054b2:	8b05                	andi	a4,a4,1
    800054b4:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800054b8:	0037f713          	andi	a4,a5,3
    800054bc:	00e03733          	snez	a4,a4
    800054c0:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    800054c4:	4007f793          	andi	a5,a5,1024
    800054c8:	c791                	beqz	a5,800054d4 <sys_open+0xb6>
    800054ca:	04449703          	lh	a4,68(s1)
    800054ce:	4789                	li	a5,2
    800054d0:	08f70d63          	beq	a4,a5,8000556a <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    800054d4:	8526                	mv	a0,s1
    800054d6:	912fe0ef          	jal	800035e8 <iunlock>
  end_op();
    800054da:	b2ffe0ef          	jal	80004008 <end_op>

  return fd;
    800054de:	854e                	mv	a0,s3
    800054e0:	74aa                	ld	s1,168(sp)
    800054e2:	790a                	ld	s2,160(sp)
    800054e4:	69ea                	ld	s3,152(sp)
}
    800054e6:	70ea                	ld	ra,184(sp)
    800054e8:	744a                	ld	s0,176(sp)
    800054ea:	6129                	addi	sp,sp,192
    800054ec:	8082                	ret
      end_op();
    800054ee:	b1bfe0ef          	jal	80004008 <end_op>
      return -1;
    800054f2:	557d                	li	a0,-1
    800054f4:	74aa                	ld	s1,168(sp)
    800054f6:	bfc5                	j	800054e6 <sys_open+0xc8>
    if ((ip = namei(path)) == 0) {
    800054f8:	f5040513          	addi	a0,s0,-176
    800054fc:	8b3fe0ef          	jal	80003dae <namei>
    80005500:	84aa                	mv	s1,a0
    80005502:	c11d                	beqz	a0,80005528 <sys_open+0x10a>
    ilock(ip);
    80005504:	836fe0ef          	jal	8000353a <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    80005508:	04449703          	lh	a4,68(s1)
    8000550c:	4785                	li	a5,1
    8000550e:	f4f71de3          	bne	a4,a5,80005468 <sys_open+0x4a>
    80005512:	f4c42783          	lw	a5,-180(s0)
    80005516:	d3bd                	beqz	a5,8000547c <sys_open+0x5e>
      iunlockput(ip);
    80005518:	8526                	mv	a0,s1
    8000551a:	a72fe0ef          	jal	8000378c <iunlockput>
      end_op();
    8000551e:	aebfe0ef          	jal	80004008 <end_op>
      return -1;
    80005522:	557d                	li	a0,-1
    80005524:	74aa                	ld	s1,168(sp)
    80005526:	b7c1                	j	800054e6 <sys_open+0xc8>
      end_op();
    80005528:	ae1fe0ef          	jal	80004008 <end_op>
      return -1;
    8000552c:	557d                	li	a0,-1
    8000552e:	74aa                	ld	s1,168(sp)
    80005530:	bf5d                	j	800054e6 <sys_open+0xc8>
    iunlockput(ip);
    80005532:	8526                	mv	a0,s1
    80005534:	a58fe0ef          	jal	8000378c <iunlockput>
    end_op();
    80005538:	ad1fe0ef          	jal	80004008 <end_op>
    return -1;
    8000553c:	557d                	li	a0,-1
    8000553e:	74aa                	ld	s1,168(sp)
    80005540:	b75d                	j	800054e6 <sys_open+0xc8>
      fileclose(f);
    80005542:	854a                	mv	a0,s2
    80005544:	eebfe0ef          	jal	8000442e <fileclose>
    80005548:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000554a:	8526                	mv	a0,s1
    8000554c:	a40fe0ef          	jal	8000378c <iunlockput>
    end_op();
    80005550:	ab9fe0ef          	jal	80004008 <end_op>
    return -1;
    80005554:	557d                	li	a0,-1
    80005556:	74aa                	ld	s1,168(sp)
    80005558:	790a                	ld	s2,160(sp)
    8000555a:	b771                	j	800054e6 <sys_open+0xc8>
    f->type = FD_DEVICE;
    8000555c:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80005560:	04649783          	lh	a5,70(s1)
    80005564:	02f91223          	sh	a5,36(s2)
    80005568:	bf3d                	j	800054a6 <sys_open+0x88>
    itrunc(ip);
    8000556a:	8526                	mv	a0,s1
    8000556c:	8bcfe0ef          	jal	80003628 <itrunc>
    80005570:	b795                	j	800054d4 <sys_open+0xb6>

0000000080005572 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005572:	7175                	addi	sp,sp,-144
    80005574:	e506                	sd	ra,136(sp)
    80005576:	e122                	sd	s0,128(sp)
    80005578:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000557a:	a09fe0ef          	jal	80003f82 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    8000557e:	08000613          	li	a2,128
    80005582:	f7040593          	addi	a1,s0,-144
    80005586:	4501                	li	a0,0
    80005588:	d0efd0ef          	jal	80002a96 <argstr>
    8000558c:	02054363          	bltz	a0,800055b2 <sys_mkdir+0x40>
    80005590:	4681                	li	a3,0
    80005592:	4601                	li	a2,0
    80005594:	4585                	li	a1,1
    80005596:	f7040513          	addi	a0,s0,-144
    8000559a:	8e9ff0ef          	jal	80004e82 <create>
    8000559e:	c911                	beqz	a0,800055b2 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800055a0:	9ecfe0ef          	jal	8000378c <iunlockput>
  end_op();
    800055a4:	a65fe0ef          	jal	80004008 <end_op>
  return 0;
    800055a8:	4501                	li	a0,0
}
    800055aa:	60aa                	ld	ra,136(sp)
    800055ac:	640a                	ld	s0,128(sp)
    800055ae:	6149                	addi	sp,sp,144
    800055b0:	8082                	ret
    end_op();
    800055b2:	a57fe0ef          	jal	80004008 <end_op>
    return -1;
    800055b6:	557d                	li	a0,-1
    800055b8:	bfcd                	j	800055aa <sys_mkdir+0x38>

00000000800055ba <sys_mknod>:

uint64
sys_mknod(void)
{
    800055ba:	7135                	addi	sp,sp,-160
    800055bc:	ed06                	sd	ra,152(sp)
    800055be:	e922                	sd	s0,144(sp)
    800055c0:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800055c2:	9c1fe0ef          	jal	80003f82 <begin_op>
  argint(1, &major);
    800055c6:	f6c40593          	addi	a1,s0,-148
    800055ca:	4505                	li	a0,1
    800055cc:	c92fd0ef          	jal	80002a5e <argint>
  argint(2, &minor);
    800055d0:	f6840593          	addi	a1,s0,-152
    800055d4:	4509                	li	a0,2
    800055d6:	c88fd0ef          	jal	80002a5e <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800055da:	08000613          	li	a2,128
    800055de:	f7040593          	addi	a1,s0,-144
    800055e2:	4501                	li	a0,0
    800055e4:	cb2fd0ef          	jal	80002a96 <argstr>
    800055e8:	02054563          	bltz	a0,80005612 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800055ec:	f6841683          	lh	a3,-152(s0)
    800055f0:	f6c41603          	lh	a2,-148(s0)
    800055f4:	458d                	li	a1,3
    800055f6:	f7040513          	addi	a0,s0,-144
    800055fa:	889ff0ef          	jal	80004e82 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800055fe:	c911                	beqz	a0,80005612 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005600:	98cfe0ef          	jal	8000378c <iunlockput>
  end_op();
    80005604:	a05fe0ef          	jal	80004008 <end_op>
  return 0;
    80005608:	4501                	li	a0,0
}
    8000560a:	60ea                	ld	ra,152(sp)
    8000560c:	644a                	ld	s0,144(sp)
    8000560e:	610d                	addi	sp,sp,160
    80005610:	8082                	ret
    end_op();
    80005612:	9f7fe0ef          	jal	80004008 <end_op>
    return -1;
    80005616:	557d                	li	a0,-1
    80005618:	bfcd                	j	8000560a <sys_mknod+0x50>

000000008000561a <sys_chdir>:

uint64
sys_chdir(void)
{
    8000561a:	7135                	addi	sp,sp,-160
    8000561c:	ed06                	sd	ra,152(sp)
    8000561e:	e922                	sd	s0,144(sp)
    80005620:	e14a                	sd	s2,128(sp)
    80005622:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005624:	a74fc0ef          	jal	80001898 <myproc>
    80005628:	892a                	mv	s2,a0

  begin_op();
    8000562a:	959fe0ef          	jal	80003f82 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    8000562e:	08000613          	li	a2,128
    80005632:	f6040593          	addi	a1,s0,-160
    80005636:	4501                	li	a0,0
    80005638:	c5efd0ef          	jal	80002a96 <argstr>
    8000563c:	04054363          	bltz	a0,80005682 <sys_chdir+0x68>
    80005640:	e526                	sd	s1,136(sp)
    80005642:	f6040513          	addi	a0,s0,-160
    80005646:	f68fe0ef          	jal	80003dae <namei>
    8000564a:	84aa                	mv	s1,a0
    8000564c:	c915                	beqz	a0,80005680 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    8000564e:	eedfd0ef          	jal	8000353a <ilock>
  if (ip->type != T_DIR) {
    80005652:	04449703          	lh	a4,68(s1)
    80005656:	4785                	li	a5,1
    80005658:	02f71963          	bne	a4,a5,8000568a <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000565c:	8526                	mv	a0,s1
    8000565e:	f8bfd0ef          	jal	800035e8 <iunlock>
  iput(p->cwd);
    80005662:	15093503          	ld	a0,336(s2)
    80005666:	856fe0ef          	jal	800036bc <iput>
  end_op();
    8000566a:	99ffe0ef          	jal	80004008 <end_op>
  p->cwd = ip;
    8000566e:	14993823          	sd	s1,336(s2)
  return 0;
    80005672:	4501                	li	a0,0
    80005674:	64aa                	ld	s1,136(sp)
}
    80005676:	60ea                	ld	ra,152(sp)
    80005678:	644a                	ld	s0,144(sp)
    8000567a:	690a                	ld	s2,128(sp)
    8000567c:	610d                	addi	sp,sp,160
    8000567e:	8082                	ret
    80005680:	64aa                	ld	s1,136(sp)
    end_op();
    80005682:	987fe0ef          	jal	80004008 <end_op>
    return -1;
    80005686:	557d                	li	a0,-1
    80005688:	b7fd                	j	80005676 <sys_chdir+0x5c>
    iunlockput(ip);
    8000568a:	8526                	mv	a0,s1
    8000568c:	900fe0ef          	jal	8000378c <iunlockput>
    end_op();
    80005690:	979fe0ef          	jal	80004008 <end_op>
    return -1;
    80005694:	557d                	li	a0,-1
    80005696:	64aa                	ld	s1,136(sp)
    80005698:	bff9                	j	80005676 <sys_chdir+0x5c>

000000008000569a <sys_exec>:

uint64
sys_exec(void)
{
    8000569a:	7121                	addi	sp,sp,-448
    8000569c:	ff06                	sd	ra,440(sp)
    8000569e:	fb22                	sd	s0,432(sp)
    800056a0:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800056a2:	e4840593          	addi	a1,s0,-440
    800056a6:	4505                	li	a0,1
    800056a8:	bd2fd0ef          	jal	80002a7a <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    800056ac:	08000613          	li	a2,128
    800056b0:	f5040593          	addi	a1,s0,-176
    800056b4:	4501                	li	a0,0
    800056b6:	be0fd0ef          	jal	80002a96 <argstr>
    800056ba:	87aa                	mv	a5,a0
    return -1;
    800056bc:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    800056be:	0c07c463          	bltz	a5,80005786 <sys_exec+0xec>
    800056c2:	f726                	sd	s1,424(sp)
    800056c4:	f34a                	sd	s2,416(sp)
    800056c6:	ef4e                	sd	s3,408(sp)
    800056c8:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800056ca:	10000613          	li	a2,256
    800056ce:	4581                	li	a1,0
    800056d0:	e5040513          	addi	a0,s0,-432
    800056d4:	d7efb0ef          	jal	80000c52 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800056d8:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800056dc:	89a6                	mv	s3,s1
    800056de:	4901                	li	s2,0
    if (i >= NELEM(argv)) {
    800056e0:	02000a13          	li	s4,32
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800056e4:	00391513          	slli	a0,s2,0x3
    800056e8:	e4040593          	addi	a1,s0,-448
    800056ec:	e4843783          	ld	a5,-440(s0)
    800056f0:	953e                	add	a0,a0,a5
    800056f2:	ae0fd0ef          	jal	800029d2 <fetchaddr>
    800056f6:	02054663          	bltz	a0,80005722 <sys_exec+0x88>
      goto bad;
    }
    if (uarg == 0) {
    800056fa:	e4043783          	ld	a5,-448(s0)
    800056fe:	c3a9                	beqz	a5,80005740 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005700:	bc8fb0ef          	jal	80000ac8 <kalloc>
    80005704:	85aa                	mv	a1,a0
    80005706:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    8000570a:	cd01                	beqz	a0,80005722 <sys_exec+0x88>
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000570c:	6605                	lui	a2,0x1
    8000570e:	e4043503          	ld	a0,-448(s0)
    80005712:	b0afd0ef          	jal	80002a1c <fetchstr>
    80005716:	00054663          	bltz	a0,80005722 <sys_exec+0x88>
    if (i >= NELEM(argv)) {
    8000571a:	0905                	addi	s2,s2,1
    8000571c:	09a1                	addi	s3,s3,8
    8000571e:	fd4913e3          	bne	s2,s4,800056e4 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005722:	f5040913          	addi	s2,s0,-176
    80005726:	6088                	ld	a0,0(s1)
    80005728:	c931                	beqz	a0,8000577c <sys_exec+0xe2>
    kfree(argv[i]);
    8000572a:	abcfb0ef          	jal	800009e6 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000572e:	04a1                	addi	s1,s1,8
    80005730:	ff249be3          	bne	s1,s2,80005726 <sys_exec+0x8c>
  return -1;
    80005734:	557d                	li	a0,-1
    80005736:	74ba                	ld	s1,424(sp)
    80005738:	791a                	ld	s2,416(sp)
    8000573a:	69fa                	ld	s3,408(sp)
    8000573c:	6a5a                	ld	s4,400(sp)
    8000573e:	a0a1                	j	80005786 <sys_exec+0xec>
      argv[i] = 0;
    80005740:	0009079b          	sext.w	a5,s2
    80005744:	078e                	slli	a5,a5,0x3
    80005746:	fd078793          	addi	a5,a5,-48
    8000574a:	97a2                	add	a5,a5,s0
    8000574c:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    80005750:	e5040593          	addi	a1,s0,-432
    80005754:	f5040513          	addi	a0,s0,-176
    80005758:	b26ff0ef          	jal	80004a7e <kexec>
    8000575c:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000575e:	f5040993          	addi	s3,s0,-176
    80005762:	6088                	ld	a0,0(s1)
    80005764:	c511                	beqz	a0,80005770 <sys_exec+0xd6>
    kfree(argv[i]);
    80005766:	a80fb0ef          	jal	800009e6 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000576a:	04a1                	addi	s1,s1,8
    8000576c:	ff349be3          	bne	s1,s3,80005762 <sys_exec+0xc8>
  return ret;
    80005770:	854a                	mv	a0,s2
    80005772:	74ba                	ld	s1,424(sp)
    80005774:	791a                	ld	s2,416(sp)
    80005776:	69fa                	ld	s3,408(sp)
    80005778:	6a5a                	ld	s4,400(sp)
    8000577a:	a031                	j	80005786 <sys_exec+0xec>
  return -1;
    8000577c:	557d                	li	a0,-1
    8000577e:	74ba                	ld	s1,424(sp)
    80005780:	791a                	ld	s2,416(sp)
    80005782:	69fa                	ld	s3,408(sp)
    80005784:	6a5a                	ld	s4,400(sp)
}
    80005786:	70fa                	ld	ra,440(sp)
    80005788:	745a                	ld	s0,432(sp)
    8000578a:	6139                	addi	sp,sp,448
    8000578c:	8082                	ret

000000008000578e <sys_pipe>:

uint64
sys_pipe(void)
{
    8000578e:	7139                	addi	sp,sp,-64
    80005790:	fc06                	sd	ra,56(sp)
    80005792:	f822                	sd	s0,48(sp)
    80005794:	f426                	sd	s1,40(sp)
    80005796:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005798:	900fc0ef          	jal	80001898 <myproc>
    8000579c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000579e:	fd840593          	addi	a1,s0,-40
    800057a2:	4501                	li	a0,0
    800057a4:	ad6fd0ef          	jal	80002a7a <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    800057a8:	fc840593          	addi	a1,s0,-56
    800057ac:	fd040513          	addi	a0,s0,-48
    800057b0:	f9ffe0ef          	jal	8000474e <pipealloc>
    return -1;
    800057b4:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    800057b6:	0a054663          	bltz	a0,80005862 <sys_pipe+0xd4>
  fd0 = -1;
    800057ba:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    800057be:	fd043503          	ld	a0,-48(s0)
    800057c2:	e82ff0ef          	jal	80004e44 <fdalloc>
    800057c6:	fca42223          	sw	a0,-60(s0)
    800057ca:	08054363          	bltz	a0,80005850 <sys_pipe+0xc2>
    800057ce:	fc843503          	ld	a0,-56(s0)
    800057d2:	e72ff0ef          	jal	80004e44 <fdalloc>
    800057d6:	fca42023          	sw	a0,-64(s0)
    800057da:	06054263          	bltz	a0,8000583e <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800057de:	4711                	li	a4,4
    800057e0:	fc440693          	addi	a3,s0,-60
    800057e4:	fd843603          	ld	a2,-40(s0)
    800057e8:	64ac                	ld	a1,72(s1)
    800057ea:	68a8                	ld	a0,80(s1)
    800057ec:	ceffb0ef          	jal	800014da <copyout>
    800057f0:	00054f63          	bltz	a0,8000580e <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    800057f4:	4711                	li	a4,4
    800057f6:	fc040693          	addi	a3,s0,-64
    800057fa:	fd843603          	ld	a2,-40(s0)
    800057fe:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005800:	64ac                	ld	a1,72(s1)
    80005802:	68a8                	ld	a0,80(s1)
    80005804:	cd7fb0ef          	jal	800014da <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005808:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000580a:	04055c63          	bgez	a0,80005862 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    8000580e:	fc442783          	lw	a5,-60(s0)
    80005812:	07e9                	addi	a5,a5,26
    80005814:	078e                	slli	a5,a5,0x3
    80005816:	97a6                	add	a5,a5,s1
    80005818:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000581c:	fc042783          	lw	a5,-64(s0)
    80005820:	07e9                	addi	a5,a5,26
    80005822:	078e                	slli	a5,a5,0x3
    80005824:	94be                	add	s1,s1,a5
    80005826:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000582a:	fd043503          	ld	a0,-48(s0)
    8000582e:	c01fe0ef          	jal	8000442e <fileclose>
    fileclose(wf);
    80005832:	fc843503          	ld	a0,-56(s0)
    80005836:	bf9fe0ef          	jal	8000442e <fileclose>
    return -1;
    8000583a:	57fd                	li	a5,-1
    8000583c:	a01d                	j	80005862 <sys_pipe+0xd4>
    if (fd0 >= 0)
    8000583e:	fc442783          	lw	a5,-60(s0)
    80005842:	0007c763          	bltz	a5,80005850 <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    80005846:	07e9                	addi	a5,a5,26
    80005848:	078e                	slli	a5,a5,0x3
    8000584a:	97a6                	add	a5,a5,s1
    8000584c:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005850:	fd043503          	ld	a0,-48(s0)
    80005854:	bdbfe0ef          	jal	8000442e <fileclose>
    fileclose(wf);
    80005858:	fc843503          	ld	a0,-56(s0)
    8000585c:	bd3fe0ef          	jal	8000442e <fileclose>
    return -1;
    80005860:	57fd                	li	a5,-1
}
    80005862:	853e                	mv	a0,a5
    80005864:	70e2                	ld	ra,56(sp)
    80005866:	7442                	ld	s0,48(sp)
    80005868:	74a2                	ld	s1,40(sp)
    8000586a:	6121                	addi	sp,sp,64
    8000586c:	8082                	ret
	...

0000000080005870 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005870:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005872:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005874:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005876:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005878:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000587a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000587c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000587e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005880:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005882:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005884:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005886:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005888:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000588a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000588c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000588e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005890:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005892:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005894:	848fd0ef          	jal	800028dc <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005898:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000589a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000589c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000589e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800058a0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800058a2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800058a4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800058a6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800058a8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800058aa:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800058ac:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800058ae:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800058b0:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800058b2:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800058b4:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800058b6:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800058b8:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800058ba:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800058bc:	10200073          	sret
	...

00000000800058ce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800058ce:	1141                	addi	sp,sp,-16
    800058d0:	e422                	sd	s0,8(sp)
    800058d2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800058d4:	0c0007b7          	lui	a5,0xc000
    800058d8:	4705                	li	a4,1
    800058da:	d798                	sw	a4,40(a5)
  *(uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800058dc:	0c0007b7          	lui	a5,0xc000
    800058e0:	c3d8                	sw	a4,4(a5)
}
    800058e2:	6422                	ld	s0,8(sp)
    800058e4:	0141                	addi	sp,sp,16
    800058e6:	8082                	ret

00000000800058e8 <plicinithart>:

void
plicinithart(void)
{
    800058e8:	1141                	addi	sp,sp,-16
    800058ea:	e406                	sd	ra,8(sp)
    800058ec:	e022                	sd	s0,0(sp)
    800058ee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800058f0:	f7dfb0ef          	jal	8000186c <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32 *)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800058f4:	0085171b          	slliw	a4,a0,0x8
    800058f8:	0c0027b7          	lui	a5,0xc002
    800058fc:	97ba                	add	a5,a5,a4
    800058fe:	40200713          	li	a4,1026
    80005902:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005906:	00d5151b          	slliw	a0,a0,0xd
    8000590a:	0c2017b7          	lui	a5,0xc201
    8000590e:	97aa                	add	a5,a5,a0
    80005910:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005914:	60a2                	ld	ra,8(sp)
    80005916:	6402                	ld	s0,0(sp)
    80005918:	0141                	addi	sp,sp,16
    8000591a:	8082                	ret

000000008000591c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000591c:	1141                	addi	sp,sp,-16
    8000591e:	e406                	sd	ra,8(sp)
    80005920:	e022                	sd	s0,0(sp)
    80005922:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005924:	f49fb0ef          	jal	8000186c <cpuid>
  int irq = *(uint32 *)PLIC_SCLAIM(hart);
    80005928:	00d5151b          	slliw	a0,a0,0xd
    8000592c:	0c2017b7          	lui	a5,0xc201
    80005930:	97aa                	add	a5,a5,a0
  return irq;
}
    80005932:	43c8                	lw	a0,4(a5)
    80005934:	60a2                	ld	ra,8(sp)
    80005936:	6402                	ld	s0,0(sp)
    80005938:	0141                	addi	sp,sp,16
    8000593a:	8082                	ret

000000008000593c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000593c:	1101                	addi	sp,sp,-32
    8000593e:	ec06                	sd	ra,24(sp)
    80005940:	e822                	sd	s0,16(sp)
    80005942:	e426                	sd	s1,8(sp)
    80005944:	1000                	addi	s0,sp,32
    80005946:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005948:	f25fb0ef          	jal	8000186c <cpuid>
  *(uint32 *)PLIC_SCLAIM(hart) = irq;
    8000594c:	00d5151b          	slliw	a0,a0,0xd
    80005950:	0c2017b7          	lui	a5,0xc201
    80005954:	97aa                	add	a5,a5,a0
    80005956:	c3c4                	sw	s1,4(a5)
}
    80005958:	60e2                	ld	ra,24(sp)
    8000595a:	6442                	ld	s0,16(sp)
    8000595c:	64a2                	ld	s1,8(sp)
    8000595e:	6105                	addi	sp,sp,32
    80005960:	8082                	ret

0000000080005962 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005962:	1141                	addi	sp,sp,-16
    80005964:	e406                	sd	ra,8(sp)
    80005966:	e022                	sd	s0,0(sp)
    80005968:	0800                	addi	s0,sp,16
  if (i >= NUM)
    8000596a:	479d                	li	a5,7
    8000596c:	04a7ca63          	blt	a5,a0,800059c0 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005970:	00022797          	auipc	a5,0x22
    80005974:	ae078793          	addi	a5,a5,-1312 # 80027450 <disk>
    80005978:	97aa                	add	a5,a5,a0
    8000597a:	0187c783          	lbu	a5,24(a5)
    8000597e:	e7b9                	bnez	a5,800059cc <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005980:	00451693          	slli	a3,a0,0x4
    80005984:	00022797          	auipc	a5,0x22
    80005988:	acc78793          	addi	a5,a5,-1332 # 80027450 <disk>
    8000598c:	6398                	ld	a4,0(a5)
    8000598e:	9736                	add	a4,a4,a3
    80005990:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005994:	6398                	ld	a4,0(a5)
    80005996:	9736                	add	a4,a4,a3
    80005998:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000599c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800059a0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800059a4:	97aa                	add	a5,a5,a0
    800059a6:	4705                	li	a4,1
    800059a8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800059ac:	00022517          	auipc	a0,0x22
    800059b0:	abc50513          	addi	a0,a0,-1348 # 80027468 <disk+0x18>
    800059b4:	de8fc0ef          	jal	80001f9c <wakeup>
}
    800059b8:	60a2                	ld	ra,8(sp)
    800059ba:	6402                	ld	s0,0(sp)
    800059bc:	0141                	addi	sp,sp,16
    800059be:	8082                	ret
    panic("free_desc 1");
    800059c0:	00004517          	auipc	a0,0x4
    800059c4:	cd050513          	addi	a0,a0,-816 # 80009690 <etext+0x690>
    800059c8:	e27fa0ef          	jal	800007ee <panic>
    panic("free_desc 2");
    800059cc:	00004517          	auipc	a0,0x4
    800059d0:	cd450513          	addi	a0,a0,-812 # 800096a0 <etext+0x6a0>
    800059d4:	e1bfa0ef          	jal	800007ee <panic>

00000000800059d8 <virtio_disk_init>:
{
    800059d8:	1101                	addi	sp,sp,-32
    800059da:	ec06                	sd	ra,24(sp)
    800059dc:	e822                	sd	s0,16(sp)
    800059de:	e426                	sd	s1,8(sp)
    800059e0:	e04a                	sd	s2,0(sp)
    800059e2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800059e4:	00004597          	auipc	a1,0x4
    800059e8:	ccc58593          	addi	a1,a1,-820 # 800096b0 <etext+0x6b0>
    800059ec:	00022517          	auipc	a0,0x22
    800059f0:	b8c50513          	addi	a0,a0,-1140 # 80027578 <disk+0x128>
    800059f4:	924fb0ef          	jal	80000b18 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800059f8:	100017b7          	lui	a5,0x10001
    800059fc:	4398                	lw	a4,0(a5)
    800059fe:	2701                	sext.w	a4,a4
    80005a00:	747277b7          	lui	a5,0x74727
    80005a04:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005a08:	18f71063          	bne	a4,a5,80005b88 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005a0c:	100017b7          	lui	a5,0x10001
    80005a10:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005a12:	439c                	lw	a5,0(a5)
    80005a14:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005a16:	4709                	li	a4,2
    80005a18:	16e79863          	bne	a5,a4,80005b88 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005a1c:	100017b7          	lui	a5,0x10001
    80005a20:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005a22:	439c                	lw	a5,0(a5)
    80005a24:	2781                	sext.w	a5,a5
    80005a26:	16e79163          	bne	a5,a4,80005b88 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005a2a:	100017b7          	lui	a5,0x10001
    80005a2e:	47d8                	lw	a4,12(a5)
    80005a30:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005a32:	554d47b7          	lui	a5,0x554d4
    80005a36:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005a3a:	14f71763          	bne	a4,a5,80005b88 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a3e:	100017b7          	lui	a5,0x10001
    80005a42:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a46:	4705                	li	a4,1
    80005a48:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a4a:	470d                	li	a4,3
    80005a4c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005a4e:	10001737          	lui	a4,0x10001
    80005a52:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005a54:	c7ffe737          	lui	a4,0xc7ffe
    80005a58:	55f70713          	addi	a4,a4,1375 # ffffffffc7ffe55f <end+0xffffffff47fd65a7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005a5c:	8ef9                	and	a3,a3,a4
    80005a5e:	10001737          	lui	a4,0x10001
    80005a62:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a64:	472d                	li	a4,11
    80005a66:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a68:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005a6c:	439c                	lw	a5,0(a5)
    80005a6e:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005a72:	8ba1                	andi	a5,a5,8
    80005a74:	12078063          	beqz	a5,80005b94 <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005a78:	100017b7          	lui	a5,0x10001
    80005a7c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005a80:	100017b7          	lui	a5,0x10001
    80005a84:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005a88:	439c                	lw	a5,0(a5)
    80005a8a:	2781                	sext.w	a5,a5
    80005a8c:	10079a63          	bnez	a5,80005ba0 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005a90:	100017b7          	lui	a5,0x10001
    80005a94:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005a98:	439c                	lw	a5,0(a5)
    80005a9a:	2781                	sext.w	a5,a5
  if (max == 0)
    80005a9c:	10078863          	beqz	a5,80005bac <virtio_disk_init+0x1d4>
  if (max < NUM)
    80005aa0:	471d                	li	a4,7
    80005aa2:	10f77b63          	bgeu	a4,a5,80005bb8 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    80005aa6:	822fb0ef          	jal	80000ac8 <kalloc>
    80005aaa:	00022497          	auipc	s1,0x22
    80005aae:	9a648493          	addi	s1,s1,-1626 # 80027450 <disk>
    80005ab2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005ab4:	814fb0ef          	jal	80000ac8 <kalloc>
    80005ab8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005aba:	80efb0ef          	jal	80000ac8 <kalloc>
    80005abe:	87aa                	mv	a5,a0
    80005ac0:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80005ac2:	6088                	ld	a0,0(s1)
    80005ac4:	10050063          	beqz	a0,80005bc4 <virtio_disk_init+0x1ec>
    80005ac8:	00022717          	auipc	a4,0x22
    80005acc:	99073703          	ld	a4,-1648(a4) # 80027458 <disk+0x8>
    80005ad0:	0e070a63          	beqz	a4,80005bc4 <virtio_disk_init+0x1ec>
    80005ad4:	0e078863          	beqz	a5,80005bc4 <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    80005ad8:	6605                	lui	a2,0x1
    80005ada:	4581                	li	a1,0
    80005adc:	976fb0ef          	jal	80000c52 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005ae0:	00022497          	auipc	s1,0x22
    80005ae4:	97048493          	addi	s1,s1,-1680 # 80027450 <disk>
    80005ae8:	6605                	lui	a2,0x1
    80005aea:	4581                	li	a1,0
    80005aec:	6488                	ld	a0,8(s1)
    80005aee:	964fb0ef          	jal	80000c52 <memset>
  memset(disk.used, 0, PGSIZE);
    80005af2:	6605                	lui	a2,0x1
    80005af4:	4581                	li	a1,0
    80005af6:	6888                	ld	a0,16(s1)
    80005af8:	95afb0ef          	jal	80000c52 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005afc:	100017b7          	lui	a5,0x10001
    80005b00:	4721                	li	a4,8
    80005b02:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005b04:	4098                	lw	a4,0(s1)
    80005b06:	100017b7          	lui	a5,0x10001
    80005b0a:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005b0e:	40d8                	lw	a4,4(s1)
    80005b10:	100017b7          	lui	a5,0x10001
    80005b14:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005b18:	649c                	ld	a5,8(s1)
    80005b1a:	0007869b          	sext.w	a3,a5
    80005b1e:	10001737          	lui	a4,0x10001
    80005b22:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005b26:	9781                	srai	a5,a5,0x20
    80005b28:	10001737          	lui	a4,0x10001
    80005b2c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005b30:	689c                	ld	a5,16(s1)
    80005b32:	0007869b          	sext.w	a3,a5
    80005b36:	10001737          	lui	a4,0x10001
    80005b3a:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005b3e:	9781                	srai	a5,a5,0x20
    80005b40:	10001737          	lui	a4,0x10001
    80005b44:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005b48:	10001737          	lui	a4,0x10001
    80005b4c:	4785                	li	a5,1
    80005b4e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005b50:	00f48c23          	sb	a5,24(s1)
    80005b54:	00f48ca3          	sb	a5,25(s1)
    80005b58:	00f48d23          	sb	a5,26(s1)
    80005b5c:	00f48da3          	sb	a5,27(s1)
    80005b60:	00f48e23          	sb	a5,28(s1)
    80005b64:	00f48ea3          	sb	a5,29(s1)
    80005b68:	00f48f23          	sb	a5,30(s1)
    80005b6c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005b70:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005b74:	100017b7          	lui	a5,0x10001
    80005b78:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    80005b7c:	60e2                	ld	ra,24(sp)
    80005b7e:	6442                	ld	s0,16(sp)
    80005b80:	64a2                	ld	s1,8(sp)
    80005b82:	6902                	ld	s2,0(sp)
    80005b84:	6105                	addi	sp,sp,32
    80005b86:	8082                	ret
    panic("could not find virtio disk");
    80005b88:	00004517          	auipc	a0,0x4
    80005b8c:	b3850513          	addi	a0,a0,-1224 # 800096c0 <etext+0x6c0>
    80005b90:	c5ffa0ef          	jal	800007ee <panic>
    panic("virtio disk FEATURES_OK unset");
    80005b94:	00004517          	auipc	a0,0x4
    80005b98:	b4c50513          	addi	a0,a0,-1204 # 800096e0 <etext+0x6e0>
    80005b9c:	c53fa0ef          	jal	800007ee <panic>
    panic("virtio disk should not be ready");
    80005ba0:	00004517          	auipc	a0,0x4
    80005ba4:	b6050513          	addi	a0,a0,-1184 # 80009700 <etext+0x700>
    80005ba8:	c47fa0ef          	jal	800007ee <panic>
    panic("virtio disk has no queue 0");
    80005bac:	00004517          	auipc	a0,0x4
    80005bb0:	b7450513          	addi	a0,a0,-1164 # 80009720 <etext+0x720>
    80005bb4:	c3bfa0ef          	jal	800007ee <panic>
    panic("virtio disk max queue too short");
    80005bb8:	00004517          	auipc	a0,0x4
    80005bbc:	b8850513          	addi	a0,a0,-1144 # 80009740 <etext+0x740>
    80005bc0:	c2ffa0ef          	jal	800007ee <panic>
    panic("virtio disk kalloc");
    80005bc4:	00004517          	auipc	a0,0x4
    80005bc8:	b9c50513          	addi	a0,a0,-1124 # 80009760 <etext+0x760>
    80005bcc:	c23fa0ef          	jal	800007ee <panic>

0000000080005bd0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005bd0:	7159                	addi	sp,sp,-112
    80005bd2:	f486                	sd	ra,104(sp)
    80005bd4:	f0a2                	sd	s0,96(sp)
    80005bd6:	eca6                	sd	s1,88(sp)
    80005bd8:	e8ca                	sd	s2,80(sp)
    80005bda:	e4ce                	sd	s3,72(sp)
    80005bdc:	e0d2                	sd	s4,64(sp)
    80005bde:	fc56                	sd	s5,56(sp)
    80005be0:	f85a                	sd	s6,48(sp)
    80005be2:	f45e                	sd	s7,40(sp)
    80005be4:	f062                	sd	s8,32(sp)
    80005be6:	ec66                	sd	s9,24(sp)
    80005be8:	1880                	addi	s0,sp,112
    80005bea:	8a2a                	mv	s4,a0
    80005bec:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005bee:	00c52c83          	lw	s9,12(a0)
    80005bf2:	001c9c9b          	slliw	s9,s9,0x1
    80005bf6:	1c82                	slli	s9,s9,0x20
    80005bf8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005bfc:	00022517          	auipc	a0,0x22
    80005c00:	97c50513          	addi	a0,a0,-1668 # 80027578 <disk+0x128>
    80005c04:	f8bfa0ef          	jal	80000b8e <acquire>
  for (int i = 0; i < 3; i++) {
    80005c08:	4981                	li	s3,0
  for (int i = 0; i < NUM; i++) {
    80005c0a:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005c0c:	00022b17          	auipc	s6,0x22
    80005c10:	844b0b13          	addi	s6,s6,-1980 # 80027450 <disk>
  for (int i = 0; i < 3; i++) {
    80005c14:	4a8d                	li	s5,3
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005c16:	00022c17          	auipc	s8,0x22
    80005c1a:	852c0c13          	addi	s8,s8,-1966 # 80027468 <disk+0x18>
    80005c1e:	a0bd                	j	80005c8c <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80005c20:	00fb0733          	add	a4,s6,a5
    80005c24:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005c28:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80005c2a:	0207c563          	bltz	a5,80005c54 <virtio_disk_rw+0x84>
  for (int i = 0; i < 3; i++) {
    80005c2e:	2905                	addiw	s2,s2,1
    80005c30:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005c32:	07590163          	beq	s2,s5,80005c94 <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005c36:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005c38:	00022717          	auipc	a4,0x22
    80005c3c:	81870713          	addi	a4,a4,-2024 # 80027450 <disk>
    80005c40:	87ce                	mv	a5,s3
    if (disk.free[i]) {
    80005c42:	01874683          	lbu	a3,24(a4)
    80005c46:	fee9                	bnez	a3,80005c20 <virtio_disk_rw+0x50>
  for (int i = 0; i < NUM; i++) {
    80005c48:	2785                	addiw	a5,a5,1
    80005c4a:	0705                	addi	a4,a4,1
    80005c4c:	fe979be3          	bne	a5,s1,80005c42 <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005c50:	57fd                	li	a5,-1
    80005c52:	c19c                	sw	a5,0(a1)
      for (int j = 0; j < i; j++)
    80005c54:	01205d63          	blez	s2,80005c6e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005c58:	f9042503          	lw	a0,-112(s0)
    80005c5c:	d07ff0ef          	jal	80005962 <free_desc>
      for (int j = 0; j < i; j++)
    80005c60:	4785                	li	a5,1
    80005c62:	0127d663          	bge	a5,s2,80005c6e <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005c66:	f9442503          	lw	a0,-108(s0)
    80005c6a:	cf9ff0ef          	jal	80005962 <free_desc>
    sleep_prepare(&disk.free[0]);
    80005c6e:	8562                	mv	a0,s8
    80005c70:	ac0fc0ef          	jal	80001f30 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005c74:	00022917          	auipc	s2,0x22
    80005c78:	90490913          	addi	s2,s2,-1788 # 80027578 <disk+0x128>
    80005c7c:	854a                	mv	a0,s2
    80005c7e:	f9dfa0ef          	jal	80000c1a <release>
    sleep();
    80005c82:	aeafc0ef          	jal	80001f6c <sleep>
    acquire(&disk.vdisk_lock);
    80005c86:	854a                	mv	a0,s2
    80005c88:	f07fa0ef          	jal	80000b8e <acquire>
  for (int i = 0; i < 3; i++) {
    80005c8c:	f9040613          	addi	a2,s0,-112
    80005c90:	894e                	mv	s2,s3
    80005c92:	b755                	j	80005c36 <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005c94:	f9042503          	lw	a0,-112(s0)
    80005c98:	00451693          	slli	a3,a0,0x4

  if (write)
    80005c9c:	00021797          	auipc	a5,0x21
    80005ca0:	7b478793          	addi	a5,a5,1972 # 80027450 <disk>
    80005ca4:	00a50713          	addi	a4,a0,10
    80005ca8:	0712                	slli	a4,a4,0x4
    80005caa:	973e                	add	a4,a4,a5
    80005cac:	01703633          	snez	a2,s7
    80005cb0:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005cb2:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005cb6:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005cba:	6398                	ld	a4,0(a5)
    80005cbc:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005cbe:	0a868613          	addi	a2,a3,168
    80005cc2:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005cc4:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005cc6:	6390                	ld	a2,0(a5)
    80005cc8:	00d605b3          	add	a1,a2,a3
    80005ccc:	4741                	li	a4,16
    80005cce:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005cd0:	4805                	li	a6,1
    80005cd2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005cd6:	f9442703          	lw	a4,-108(s0)
    80005cda:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005cde:	0712                	slli	a4,a4,0x4
    80005ce0:	963a                	add	a2,a2,a4
    80005ce2:	058a0593          	addi	a1,s4,88
    80005ce6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005ce8:	0007b883          	ld	a7,0(a5)
    80005cec:	9746                	add	a4,a4,a7
    80005cee:	40000613          	li	a2,1024
    80005cf2:	c710                	sw	a2,8(a4)
  if (write)
    80005cf4:	001bb613          	seqz	a2,s7
    80005cf8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005cfc:	00166613          	ori	a2,a2,1
    80005d00:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005d04:	f9842583          	lw	a1,-104(s0)
    80005d08:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005d0c:	00250613          	addi	a2,a0,2
    80005d10:	0612                	slli	a2,a2,0x4
    80005d12:	963e                	add	a2,a2,a5
    80005d14:	577d                	li	a4,-1
    80005d16:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005d1a:	0592                	slli	a1,a1,0x4
    80005d1c:	98ae                	add	a7,a7,a1
    80005d1e:	03068713          	addi	a4,a3,48
    80005d22:	973e                	add	a4,a4,a5
    80005d24:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005d28:	6398                	ld	a4,0(a5)
    80005d2a:	972e                	add	a4,a4,a1
    80005d2c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005d30:	4689                	li	a3,2
    80005d32:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005d36:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005d3a:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005d3e:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005d42:	6794                	ld	a3,8(a5)
    80005d44:	0026d703          	lhu	a4,2(a3)
    80005d48:	8b1d                	andi	a4,a4,7
    80005d4a:	0706                	slli	a4,a4,0x1
    80005d4c:	96ba                	add	a3,a3,a4
    80005d4e:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005d52:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005d56:	6798                	ld	a4,8(a5)
    80005d58:	00275783          	lhu	a5,2(a4)
    80005d5c:	2785                	addiw	a5,a5,1
    80005d5e:	00f71123          	sh	a5,2(a4)
    80005d62:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005d66:	100017b7          	lui	a5,0x10001
    80005d6a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005d6e:	004a2783          	lw	a5,4(s4)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005d72:	00022497          	auipc	s1,0x22
    80005d76:	80648493          	addi	s1,s1,-2042 # 80027578 <disk+0x128>
  while (b->disk == 1) {
    80005d7a:	4905                	li	s2,1
    80005d7c:	03079163          	bne	a5,a6,80005d9e <virtio_disk_rw+0x1ce>
    sleep_prepare(b);
    80005d80:	8552                	mv	a0,s4
    80005d82:	9aefc0ef          	jal	80001f30 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005d86:	8526                	mv	a0,s1
    80005d88:	e93fa0ef          	jal	80000c1a <release>
    sleep();
    80005d8c:	9e0fc0ef          	jal	80001f6c <sleep>
    acquire(&disk.vdisk_lock);
    80005d90:	8526                	mv	a0,s1
    80005d92:	dfdfa0ef          	jal	80000b8e <acquire>
  while (b->disk == 1) {
    80005d96:	004a2783          	lw	a5,4(s4)
    80005d9a:	ff2783e3          	beq	a5,s2,80005d80 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80005d9e:	f9042903          	lw	s2,-112(s0)
    80005da2:	00290713          	addi	a4,s2,2
    80005da6:	0712                	slli	a4,a4,0x4
    80005da8:	00021797          	auipc	a5,0x21
    80005dac:	6a878793          	addi	a5,a5,1704 # 80027450 <disk>
    80005db0:	97ba                	add	a5,a5,a4
    80005db2:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005db6:	00021997          	auipc	s3,0x21
    80005dba:	69a98993          	addi	s3,s3,1690 # 80027450 <disk>
    80005dbe:	00491713          	slli	a4,s2,0x4
    80005dc2:	0009b783          	ld	a5,0(s3)
    80005dc6:	97ba                	add	a5,a5,a4
    80005dc8:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005dcc:	854a                	mv	a0,s2
    80005dce:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005dd2:	b91ff0ef          	jal	80005962 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005dd6:	8885                	andi	s1,s1,1
    80005dd8:	f0fd                	bnez	s1,80005dbe <virtio_disk_rw+0x1ee>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005dda:	00021517          	auipc	a0,0x21
    80005dde:	79e50513          	addi	a0,a0,1950 # 80027578 <disk+0x128>
    80005de2:	e39fa0ef          	jal	80000c1a <release>
}
    80005de6:	70a6                	ld	ra,104(sp)
    80005de8:	7406                	ld	s0,96(sp)
    80005dea:	64e6                	ld	s1,88(sp)
    80005dec:	6946                	ld	s2,80(sp)
    80005dee:	69a6                	ld	s3,72(sp)
    80005df0:	6a06                	ld	s4,64(sp)
    80005df2:	7ae2                	ld	s5,56(sp)
    80005df4:	7b42                	ld	s6,48(sp)
    80005df6:	7ba2                	ld	s7,40(sp)
    80005df8:	7c02                	ld	s8,32(sp)
    80005dfa:	6ce2                	ld	s9,24(sp)
    80005dfc:	6165                	addi	sp,sp,112
    80005dfe:	8082                	ret

0000000080005e00 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005e00:	1101                	addi	sp,sp,-32
    80005e02:	ec06                	sd	ra,24(sp)
    80005e04:	e822                	sd	s0,16(sp)
    80005e06:	e426                	sd	s1,8(sp)
    80005e08:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005e0a:	00021497          	auipc	s1,0x21
    80005e0e:	64648493          	addi	s1,s1,1606 # 80027450 <disk>
    80005e12:	00021517          	auipc	a0,0x21
    80005e16:	76650513          	addi	a0,a0,1894 # 80027578 <disk+0x128>
    80005e1a:	d75fa0ef          	jal	80000b8e <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005e1e:	100017b7          	lui	a5,0x10001
    80005e22:	53b8                	lw	a4,96(a5)
    80005e24:	8b0d                	andi	a4,a4,3
    80005e26:	100017b7          	lui	a5,0x10001
    80005e2a:	d3f8                	sw	a4,100(a5)
    80005e2c:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005e30:	689c                	ld	a5,16(s1)
    80005e32:	0204d703          	lhu	a4,32(s1)
    80005e36:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005e3a:	04f70663          	beq	a4,a5,80005e86 <virtio_disk_intr+0x86>
    80005e3e:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005e42:	6898                	ld	a4,16(s1)
    80005e44:	0204d783          	lhu	a5,32(s1)
    80005e48:	8b9d                	andi	a5,a5,7
    80005e4a:	078e                	slli	a5,a5,0x3
    80005e4c:	97ba                	add	a5,a5,a4
    80005e4e:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005e50:	00278713          	addi	a4,a5,2
    80005e54:	0712                	slli	a4,a4,0x4
    80005e56:	9726                	add	a4,a4,s1
    80005e58:	01074703          	lbu	a4,16(a4)
    80005e5c:	e321                	bnez	a4,80005e9c <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005e5e:	0789                	addi	a5,a5,2
    80005e60:	0792                	slli	a5,a5,0x4
    80005e62:	97a6                	add	a5,a5,s1
    80005e64:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005e66:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005e6a:	932fc0ef          	jal	80001f9c <wakeup>

    disk.used_idx += 1;
    80005e6e:	0204d783          	lhu	a5,32(s1)
    80005e72:	2785                	addiw	a5,a5,1
    80005e74:	17c2                	slli	a5,a5,0x30
    80005e76:	93c1                	srli	a5,a5,0x30
    80005e78:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005e7c:	6898                	ld	a4,16(s1)
    80005e7e:	00275703          	lhu	a4,2(a4)
    80005e82:	faf71ee3          	bne	a4,a5,80005e3e <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005e86:	00021517          	auipc	a0,0x21
    80005e8a:	6f250513          	addi	a0,a0,1778 # 80027578 <disk+0x128>
    80005e8e:	d8dfa0ef          	jal	80000c1a <release>
}
    80005e92:	60e2                	ld	ra,24(sp)
    80005e94:	6442                	ld	s0,16(sp)
    80005e96:	64a2                	ld	s1,8(sp)
    80005e98:	6105                	addi	sp,sp,32
    80005e9a:	8082                	ret
      panic("virtio_disk_intr status");
    80005e9c:	00004517          	auipc	a0,0x4
    80005ea0:	8dc50513          	addi	a0,a0,-1828 # 80009778 <etext+0x778>
    80005ea4:	94bfa0ef          	jal	800007ee <panic>

0000000080005ea8 <is_stride>:
static int stride_last = -1;
static int stride_reset_left; // per-process initializations remaining in sched_reset

static int
is_stride(int id)
{
    80005ea8:	1141                	addi	sp,sp,-16
    80005eaa:	e422                	sd	s0,8(sp)
    80005eac:	0800                	addi	s0,sp,16
  return id == SCHED_STRIDE || id == SCHED_STRIDE_AGING ||
    80005eae:	4795                	li	a5,5
    80005eb0:	00a7c863          	blt	a5,a0,80005ec0 <is_stride+0x18>
    80005eb4:	478d                	li	a5,3
    80005eb6:	00a7a533          	slt	a0,a5,a0
         id == SCHED_STRIDE5 || id == SCHED_STRIDE_FLOOR;
}
    80005eba:	6422                	ld	s0,8(sp)
    80005ebc:	0141                	addi	sp,sp,16
    80005ebe:	8082                	ret
    80005ec0:	3559                	addiw	a0,a0,-10
    80005ec2:	00253513          	sltiu	a0,a0,2
    80005ec6:	bfd5                	j	80005eba <is_stride+0x12>

0000000080005ec8 <is_mlfq>:

static int
is_mlfq(int id)
{
    80005ec8:	1141                	addi	sp,sp,-16
    80005eca:	e422                	sd	s0,8(sp)
    80005ecc:	0800                	addi	s0,sp,16
  return id == SCHED_MLFQ || id == SCHED_MLFQ_BOOST30 || id == SCHED_MLFQ_Q030;
    80005ece:	478d                	li	a5,3
    80005ed0:	00f50863          	beq	a0,a5,80005ee0 <is_mlfq+0x18>
    80005ed4:	3551                	addiw	a0,a0,-12
    80005ed6:	00253513          	sltiu	a0,a0,2
}
    80005eda:	6422                	ld	s0,8(sp)
    80005edc:	0141                	addi	sp,sp,16
    80005ede:	8082                	ret
{
    80005ee0:	4505                	li	a0,1
    80005ee2:	bfe5                	j	80005eda <is_mlfq+0x12>

0000000080005ee4 <stride_min_other>:

// Exclude p itself, including when wakeup has already made it RUNNABLE.
static int
stride_min_other(struct proc *p, uint64 *minimum)
{
    80005ee4:	1141                	addi	sp,sp,-16
    80005ee6:	e422                	sd	s0,8(sp)
    80005ee8:	0800                	addi	s0,sp,16
    80005eea:	862a                	mv	a2,a0
  int found = 0;

  for (struct proc *q = proc; q < &proc[NPROC]; q++) {
    80005eec:	00010797          	auipc	a5,0x10
    80005ef0:	cc478793          	addi	a5,a5,-828 # 80015bb0 <proc>
  int found = 0;
    80005ef4:	4501                	li	a0,0
    if (q == p || (q->state != RUNNING && q->state != RUNNABLE))
    80005ef6:	4685                	li	a3,1
  for (struct proc *q = proc; q < &proc[NPROC]; q++) {
    80005ef8:	00016817          	auipc	a6,0x16
    80005efc:	2b880813          	addi	a6,a6,696 # 8001c1b0 <tickslock>
    80005f00:	a809                	j	80005f12 <stride_min_other+0x2e>
      continue;
    if (!found || q->vrt < *minimum) {
      *minimum = q->vrt;
    80005f02:	1887b703          	ld	a4,392(a5)
    80005f06:	e198                	sd	a4,0(a1)
      found = 1;
    80005f08:	8536                	mv	a0,a3
  for (struct proc *q = proc; q < &proc[NPROC]; q++) {
    80005f0a:	19878793          	addi	a5,a5,408
    80005f0e:	01078f63          	beq	a5,a6,80005f2c <stride_min_other+0x48>
    if (q == p || (q->state != RUNNING && q->state != RUNNABLE))
    80005f12:	fef60ce3          	beq	a2,a5,80005f0a <stride_min_other+0x26>
    80005f16:	4f98                	lw	a4,24(a5)
    80005f18:	3775                	addiw	a4,a4,-3
    80005f1a:	fee6e8e3          	bltu	a3,a4,80005f0a <stride_min_other+0x26>
    if (!found || q->vrt < *minimum) {
    80005f1e:	d175                	beqz	a0,80005f02 <stride_min_other+0x1e>
    80005f20:	1887b883          	ld	a7,392(a5)
    80005f24:	6198                	ld	a4,0(a1)
    80005f26:	fee8f2e3          	bgeu	a7,a4,80005f0a <stride_min_other+0x26>
    80005f2a:	bfe1                	j	80005f02 <stride_min_other+0x1e>
    }
  }
  return found;
}
    80005f2c:	6422                	ld	s0,8(sp)
    80005f2e:	0141                	addi	sp,sp,16
    80005f30:	8082                	ret

0000000080005f32 <stride_place>:

static void
stride_place(struct proc *p)
{
    80005f32:	7179                	addi	sp,sp,-48
    80005f34:	f406                	sd	ra,40(sp)
    80005f36:	f022                	sd	s0,32(sp)
    80005f38:	ec26                	sd	s1,24(sp)
    80005f3a:	e84a                	sd	s2,16(sp)
    80005f3c:	1800                	addi	s0,sp,48
    80005f3e:	84aa                	mv	s1,a0
  uint64 minimum = 0;
    80005f40:	fc043c23          	sd	zero,-40(s0)

  uint64 before = p->vrt;
    80005f44:	18853903          	ld	s2,392(a0)
  int peers = stride_min_other(p, &minimum);
    80005f48:	fd840593          	addi	a1,s0,-40
    80005f4c:	f99ff0ef          	jal	80005ee4 <stride_min_other>
  if (peers && p->vrt < minimum)
    80005f50:	c519                	beqz	a0,80005f5e <stride_place+0x2c>
    80005f52:	fd843783          	ld	a5,-40(s0)
    80005f56:	00f97463          	bgeu	s2,a5,80005f5e <stride_place+0x2c>
    p->vrt = minimum;
    80005f5a:	18f4b423          	sd	a5,392(s1)
  if (logging)
    80005f5e:	00007797          	auipc	a5,0x7
    80005f62:	6ae7a783          	lw	a5,1710(a5) # 8000d60c <logging>
    80005f66:	e799                	bnez	a5,80005f74 <stride_place+0x42>
    printk("stride place pid %d before %lu peers %d minimum %lu after %lu at %d\n",
           p->pid, before, peers, minimum, p->vrt, ticks);
}
    80005f68:	70a2                	ld	ra,40(sp)
    80005f6a:	7402                	ld	s0,32(sp)
    80005f6c:	64e2                	ld	s1,24(sp)
    80005f6e:	6942                	ld	s2,16(sp)
    80005f70:	6145                	addi	sp,sp,48
    80005f72:	8082                	ret
    printk("stride place pid %d before %lu peers %d minimum %lu after %lu at %d\n",
    80005f74:	00007817          	auipc	a6,0x7
    80005f78:	6a482803          	lw	a6,1700(a6) # 8000d618 <ticks>
    80005f7c:	1884b783          	ld	a5,392(s1)
    80005f80:	fd843703          	ld	a4,-40(s0)
    80005f84:	86aa                	mv	a3,a0
    80005f86:	864a                	mv	a2,s2
    80005f88:	588c                	lw	a1,48(s1)
    80005f8a:	00004517          	auipc	a0,0x4
    80005f8e:	80650513          	addi	a0,a0,-2042 # 80009790 <etext+0x790>
    80005f92:	d76fa0ef          	jal	80000508 <printk>
}
    80005f96:	bfc9                	j	80005f68 <stride_place+0x36>

0000000080005f98 <change_queue>:
}

static void
change_queue(struct proc *p, int level)
{
  int old = p->level;
    80005f98:	17052603          	lw	a2,368(a0)

  p->level = level;
    80005f9c:	16b52823          	sw	a1,368(a0)
  if (logging && old != level)
    80005fa0:	00007797          	auipc	a5,0x7
    80005fa4:	66c7a783          	lw	a5,1644(a5) # 8000d60c <logging>
    80005fa8:	c399                	beqz	a5,80005fae <change_queue+0x16>
    80005faa:	00b61363          	bne	a2,a1,80005fb0 <change_queue+0x18>
    80005fae:	8082                	ret
{
    80005fb0:	1141                	addi	sp,sp,-16
    80005fb2:	e406                	sd	ra,8(sp)
    80005fb4:	e022                	sd	s0,0(sp)
    80005fb6:	0800                	addi	s0,sp,16
    printk("mlfq pid %d Q%d -> Q%d at %d\n", p->pid, old, level, ticks);
    80005fb8:	00007717          	auipc	a4,0x7
    80005fbc:	66072703          	lw	a4,1632(a4) # 8000d618 <ticks>
    80005fc0:	86ae                	mv	a3,a1
    80005fc2:	590c                	lw	a1,48(a0)
    80005fc4:	00004517          	auipc	a0,0x4
    80005fc8:	81450513          	addi	a0,a0,-2028 # 800097d8 <etext+0x7d8>
    80005fcc:	d3cfa0ef          	jal	80000508 <printk>
}
    80005fd0:	60a2                	ld	ra,8(sp)
    80005fd2:	6402                	ld	s0,0(sp)
    80005fd4:	0141                	addi	sp,sp,16
    80005fd6:	8082                	ret

0000000080005fd8 <mlfq_boost>:

// Called with interrupts off, including from selection after an idle interval.
static void
mlfq_boost(void)
{
  uint now = ticks;
    80005fd8:	00007717          	auipc	a4,0x7
    80005fdc:	64072703          	lw	a4,1600(a4) # 8000d618 <ticks>

  if (now - last_boost < mlfq_boost_interval)
    80005fe0:	00007797          	auipc	a5,0x7
    80005fe4:	6447a783          	lw	a5,1604(a5) # 8000d624 <last_boost>
    80005fe8:	40f707bb          	subw	a5,a4,a5
    80005fec:	00007697          	auipc	a3,0x7
    80005ff0:	f006a683          	lw	a3,-256(a3) # 8000ceec <mlfq_boost_interval>
    80005ff4:	0cd7e063          	bltu	a5,a3,800060b4 <mlfq_boost+0xdc>
{
    80005ff8:	711d                	addi	sp,sp,-96
    80005ffa:	ec86                	sd	ra,88(sp)
    80005ffc:	e8a2                	sd	s0,80(sp)
    80005ffe:	e4a6                	sd	s1,72(sp)
    80006000:	e0ca                	sd	s2,64(sp)
    80006002:	fc4e                	sd	s3,56(sp)
    80006004:	f852                	sd	s4,48(sp)
    80006006:	f456                	sd	s5,40(sp)
    80006008:	f05a                	sd	s6,32(sp)
    8000600a:	ec5e                	sd	s7,24(sp)
    8000600c:	e862                	sd	s8,16(sp)
    8000600e:	e466                	sd	s9,8(sp)
    80006010:	1080                	addi	s0,sp,96
    return;
  last_boost = now;
    80006012:	00007797          	auipc	a5,0x7
    80006016:	60e7a923          	sw	a4,1554(a5) # 8000d624 <last_boost>
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8000601a:	00010497          	auipc	s1,0x10
    8000601e:	b9648493          	addi	s1,s1,-1130 # 80015bb0 <proc>
    if (p->state == UNUSED || p->state == ZOMBIE)
    80006022:	4995                	li	s3,5
      continue;
    int old_level = p->level;
    int old_used = p->used;
    change_queue(p, p->start_level > 1 ? p->start_level : 1);
    p->used = 0; // refresh the allotment even if the queue did not change
    if (logging)
    80006024:	00007a97          	auipc	s5,0x7
    80006028:	5e8a8a93          	addi	s5,s5,1512 # 8000d60c <logging>
      printk("mlfq boostcheck pid %d level %d->%d used %d->%d at %d\n",
    8000602c:	00007c17          	auipc	s8,0x7
    80006030:	5ecc0c13          	addi	s8,s8,1516 # 8000d618 <ticks>
    80006034:	00003b97          	auipc	s7,0x3
    80006038:	7c4b8b93          	addi	s7,s7,1988 # 800097f8 <etext+0x7f8>
    change_queue(p, p->start_level > 1 ? p->start_level : 1);
    8000603c:	4b05                	li	s6,1
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8000603e:	00016917          	auipc	s2,0x16
    80006042:	17290913          	addi	s2,s2,370 # 8001c1b0 <tickslock>
    80006046:	a831                	j	80006062 <mlfq_boost+0x8a>
    change_queue(p, p->start_level > 1 ? p->start_level : 1);
    80006048:	2581                	sext.w	a1,a1
    8000604a:	8526                	mv	a0,s1
    8000604c:	f4dff0ef          	jal	80005f98 <change_queue>
    p->used = 0; // refresh the allotment even if the queue did not change
    80006050:	1604ac23          	sw	zero,376(s1)
    if (logging)
    80006054:	000aa783          	lw	a5,0(s5)
    80006058:	e78d                	bnez	a5,80006082 <mlfq_boost+0xaa>
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8000605a:	19848493          	addi	s1,s1,408
    8000605e:	03248e63          	beq	s1,s2,8000609a <mlfq_boost+0xc2>
    if (p->state == UNUSED || p->state == ZOMBIE)
    80006062:	4c9c                	lw	a5,24(s1)
    80006064:	dbfd                	beqz	a5,8000605a <mlfq_boost+0x82>
    80006066:	ff378ae3          	beq	a5,s3,8000605a <mlfq_boost+0x82>
    int old_level = p->level;
    8000606a:	1704aa03          	lw	s4,368(s1)
    int old_used = p->used;
    8000606e:	1784ac83          	lw	s9,376(s1)
    change_queue(p, p->start_level > 1 ? p->start_level : 1);
    80006072:	1744a783          	lw	a5,372(s1)
    80006076:	85be                	mv	a1,a5
    80006078:	2781                	sext.w	a5,a5
    8000607a:	fcf047e3          	bgtz	a5,80006048 <mlfq_boost+0x70>
    8000607e:	85da                	mv	a1,s6
    80006080:	b7e1                	j	80006048 <mlfq_boost+0x70>
      printk("mlfq boostcheck pid %d level %d->%d used %d->%d at %d\n",
    80006082:	000c2803          	lw	a6,0(s8)
    80006086:	4781                	li	a5,0
    80006088:	8766                	mv	a4,s9
    8000608a:	1704a683          	lw	a3,368(s1)
    8000608e:	8652                	mv	a2,s4
    80006090:	588c                	lw	a1,48(s1)
    80006092:	855e                	mv	a0,s7
    80006094:	c74fa0ef          	jal	80000508 <printk>
    80006098:	b7c9                	j	8000605a <mlfq_boost+0x82>
             p->pid, old_level, p->level, old_used, p->used, ticks);
  }
}
    8000609a:	60e6                	ld	ra,88(sp)
    8000609c:	6446                	ld	s0,80(sp)
    8000609e:	64a6                	ld	s1,72(sp)
    800060a0:	6906                	ld	s2,64(sp)
    800060a2:	79e2                	ld	s3,56(sp)
    800060a4:	7a42                	ld	s4,48(sp)
    800060a6:	7aa2                	ld	s5,40(sp)
    800060a8:	7b02                	ld	s6,32(sp)
    800060aa:	6be2                	ld	s7,24(sp)
    800060ac:	6c42                	ld	s8,16(sp)
    800060ae:	6ca2                	ld	s9,8(sp)
    800060b0:	6125                	addi	sp,sp,96
    800060b2:	8082                	ret
    800060b4:	8082                	ret

00000000800060b6 <policy_init>:
  int next_stride_quantum = 1;
  int next_ticket_floor = 0;
  uint next_boost_interval = 60;
  int next_q0_quantum = 15;

  switch (id) {
    800060b6:	47b5                	li	a5,13
    800060b8:	12a7ec63          	bltu	a5,a0,800061f0 <policy_init+0x13a>
    800060bc:	00251793          	slli	a5,a0,0x2
    800060c0:	00004717          	auipc	a4,0x4
    800060c4:	a4070713          	addi	a4,a4,-1472 # 80009b00 <syscalls+0x110>
    800060c8:	97ba                	add	a5,a5,a4
    800060ca:	439c                	lw	a5,0(a5)
    800060cc:	97ba                	add	a5,a5,a4
    800060ce:	8782                	jr	a5
  int next_q0_quantum = 15;
    800060d0:	473d                	li	a4,15
  uint next_boost_interval = 60;
    800060d2:	03c00793          	li	a5,60
  int next_ticket_floor = 0;
    800060d6:	4681                	li	a3,0
  int next_stride_quantum = 1;
    800060d8:	4605                	li	a2,1
  int next_quantum = 10;
    800060da:	45a9                	li	a1,10
{
    800060dc:	1141                	addi	sp,sp,-16
    800060de:	e406                	sd	ra,8(sp)
    800060e0:	e022                	sd	s0,0(sp)
    800060e2:	0800                	addi	s0,sp,16
    break;
  default:
    return -1;
  }
  // Reset every configurable parameter on each successful selection.
  quantum = next_quantum;
    800060e4:	00007817          	auipc	a6,0x7
    800060e8:	e0b82823          	sw	a1,-496(a6) # 8000cef4 <quantum>
  stride_quantum = next_stride_quantum;
    800060ec:	00007597          	auipc	a1,0x7
    800060f0:	dec5ae23          	sw	a2,-516(a1) # 8000cee8 <stride_quantum>
  stride_ticket_floor = next_ticket_floor;
    800060f4:	00007617          	auipc	a2,0x7
    800060f8:	52d62623          	sw	a3,1324(a2) # 8000d620 <stride_ticket_floor>
  aging_threshold = 20;
    800060fc:	46d1                	li	a3,20
    800060fe:	00007617          	auipc	a2,0x7
    80006102:	ded63123          	sd	a3,-542(a2) # 8000cee0 <aging_threshold>
  mlfq_boost_interval = next_boost_interval;
    80006106:	00007697          	auipc	a3,0x7
    8000610a:	def6a323          	sw	a5,-538(a3) # 8000ceec <mlfq_boost_interval>
  mlfq_quantum[0] = next_q0_quantum;
    8000610e:	00007797          	auipc	a5,0x7
    80006112:	df278793          	addi	a5,a5,-526 # 8000cf00 <mlfq_quantum>
    80006116:	c398                	sw	a4,0(a5)
  mlfq_quantum[1] = 10;
    80006118:	4729                	li	a4,10
    8000611a:	c3d8                	sw	a4,4(a5)
  mlfq_quantum[2] = 2;
    8000611c:	4709                	li	a4,2
    8000611e:	c798                	sw	a4,8(a5)
  last = -1;
    80006120:	57fd                	li	a5,-1
    80006122:	00007717          	auipc	a4,0x7
    80006126:	dcf72723          	sw	a5,-562(a4) # 8000cef0 <last>
  for (int level = 0; level < 3; level++)
    mlfq_last[level] = -1;
    8000612a:	00021717          	auipc	a4,0x21
    8000612e:	46670713          	addi	a4,a4,1126 # 80027590 <mlfq_last>
    80006132:	c31c                	sw	a5,0(a4)
    80006134:	c35c                	sw	a5,4(a4)
    80006136:	c71c                	sw	a5,8(a4)
  last_boost = ticks;
    80006138:	00007717          	auipc	a4,0x7
    8000613c:	4e072703          	lw	a4,1248(a4) # 8000d618 <ticks>
    80006140:	00007697          	auipc	a3,0x7
    80006144:	4ee6a223          	sw	a4,1252(a3) # 8000d624 <last_boost>
  stride_last = -1;
    80006148:	00007717          	auipc	a4,0x7
    8000614c:	d8f72823          	sw	a5,-624(a4) # 8000ced8 <stride_last>
  stride_reset_left = 0;
    80006150:	00007797          	auipc	a5,0x7
    80006154:	4c07a623          	sw	zero,1228(a5) # 8000d61c <stride_reset_left>
  // sched_reset calls policy_proc_init once per allocated process with
  // interrupts off. Suppress placement until all old passes are cleared.
  if (is_stride(id))
    80006158:	d51ff0ef          	jal	80005ea8 <is_stride>
    8000615c:	c551                	beqz	a0,800061e8 <policy_init+0x132>
    8000615e:	4581                	li	a1,0
    80006160:	4681                	li	a3,0
    for (struct proc *p = proc; p < &proc[NPROC]; p++)
    80006162:	00010797          	auipc	a5,0x10
    80006166:	a4e78793          	addi	a5,a5,-1458 # 80015bb0 <proc>
      if (p->state != UNUSED)
        stride_reset_left++;
    8000616a:	4505                	li	a0,1
    for (struct proc *p = proc; p < &proc[NPROC]; p++)
    8000616c:	00016617          	auipc	a2,0x16
    80006170:	04460613          	addi	a2,a2,68 # 8001c1b0 <tickslock>
    80006174:	a8b9                	j	800061d2 <policy_init+0x11c>
  int next_q0_quantum = 15;
    80006176:	473d                	li	a4,15
  uint next_boost_interval = 60;
    80006178:	03c00793          	li	a5,60
  int next_ticket_floor = 0;
    8000617c:	4681                	li	a3,0
  int next_stride_quantum = 1;
    8000617e:	4605                	li	a2,1
    next_quantum = 5;
    80006180:	4595                	li	a1,5
    break;
    80006182:	bfa9                	j	800060dc <policy_init+0x26>
  int next_q0_quantum = 15;
    80006184:	473d                	li	a4,15
  uint next_boost_interval = 60;
    80006186:	03c00793          	li	a5,60
  int next_ticket_floor = 0;
    8000618a:	4681                	li	a3,0
    next_stride_quantum = 5;
    8000618c:	4615                	li	a2,5
  int next_quantum = 10;
    8000618e:	45a9                	li	a1,10
    break;
    80006190:	b7b1                	j	800060dc <policy_init+0x26>
  int next_q0_quantum = 15;
    80006192:	473d                	li	a4,15
  uint next_boost_interval = 60;
    80006194:	03c00793          	li	a5,60
    next_ticket_floor = 335;
    80006198:	14f00693          	li	a3,335
  int next_stride_quantum = 1;
    8000619c:	4605                	li	a2,1
  int next_quantum = 10;
    8000619e:	45a9                	li	a1,10
    break;
    800061a0:	bf35                	j	800060dc <policy_init+0x26>
  int next_q0_quantum = 15;
    800061a2:	473d                	li	a4,15
    next_boost_interval = 30;
    800061a4:	47f9                	li	a5,30
  int next_ticket_floor = 0;
    800061a6:	4681                	li	a3,0
  int next_stride_quantum = 1;
    800061a8:	4605                	li	a2,1
  int next_quantum = 10;
    800061aa:	45a9                	li	a1,10
    break;
    800061ac:	bf05                	j	800060dc <policy_init+0x26>
    next_q0_quantum = 30;
    800061ae:	4779                	li	a4,30
  uint next_boost_interval = 60;
    800061b0:	03c00793          	li	a5,60
  int next_ticket_floor = 0;
    800061b4:	4681                	li	a3,0
  int next_stride_quantum = 1;
    800061b6:	4605                	li	a2,1
  int next_quantum = 10;
    800061b8:	45a9                	li	a1,10
    break;
    800061ba:	b70d                	j	800060dc <policy_init+0x26>
  switch (id) {
    800061bc:	862a                	mv	a2,a0
    800061be:	85aa                	mv	a1,a0
    800061c0:	473d                	li	a4,15
    800061c2:	03c00793          	li	a5,60
    800061c6:	4681                	li	a3,0
    800061c8:	bf11                	j	800060dc <policy_init+0x26>
    for (struct proc *p = proc; p < &proc[NPROC]; p++)
    800061ca:	19878793          	addi	a5,a5,408
    800061ce:	00c78763          	beq	a5,a2,800061dc <policy_init+0x126>
      if (p->state != UNUSED)
    800061d2:	4f98                	lw	a4,24(a5)
    800061d4:	db7d                	beqz	a4,800061ca <policy_init+0x114>
        stride_reset_left++;
    800061d6:	2685                	addiw	a3,a3,1
    800061d8:	85aa                	mv	a1,a0
    800061da:	bfc5                	j	800061ca <policy_init+0x114>
    800061dc:	c589                	beqz	a1,800061e6 <policy_init+0x130>
    800061de:	00007797          	auipc	a5,0x7
    800061e2:	42d7af23          	sw	a3,1086(a5) # 8000d61c <stride_reset_left>
  return 0;
    800061e6:	4501                	li	a0,0
}
    800061e8:	60a2                	ld	ra,8(sp)
    800061ea:	6402                	ld	s0,0(sp)
    800061ec:	0141                	addi	sp,sp,16
    800061ee:	8082                	ret
  switch (id) {
    800061f0:	557d                	li	a0,-1
}
    800061f2:	8082                	ret

00000000800061f4 <policy_proc_init>:
// Called when a process is created, and for every process when the
// policy changes or a workload starts. Initialize any per-process
// policy fields.
void
policy_proc_init(struct proc *p)
{
    800061f4:	7179                	addi	sp,sp,-48
    800061f6:	f406                	sd	ra,40(sp)
    800061f8:	f022                	sd	s0,32(sp)
    800061fa:	ec26                	sd	s1,24(sp)
    800061fc:	e84a                	sd	s2,16(sp)
    800061fe:	e44e                	sd	s3,8(sp)
    80006200:	1800                	addi	s0,sp,48
    80006202:	84aa                	mv	s1,a0
  p->qticks = 0;
    80006204:	16052623          	sw	zero,364(a0)
  // Level 0 is the lowest queue (Q0); Q2 is the highest. An MLFQ must
  // set the starting level from p->nice here: workload_start() calls
  // this for every process after the jobs' nice values are set.
  p->start_level = starting_queue(p->nice);
    80006208:	16852783          	lw	a5,360(a0)
  if (nice <= -10)
    8000620c:	575d                	li	a4,-9
    return 2;
    8000620e:	4909                	li	s2,2
  if (nice <= -10)
    80006210:	00e7c463          	blt	a5,a4,80006218 <policy_proc_init+0x24>
  if (nice <= 10)
    80006214:	00b7a913          	slti	s2,a5,11
  p->start_level = starting_queue(p->nice);
    80006218:	1724aa23          	sw	s2,372(s1)
  p->level = is_mlfq(sched_current) ? p->start_level : 0;
    8000621c:	00007997          	auipc	s3,0x7
    80006220:	3ec9a983          	lw	s3,1004(s3) # 8000d608 <sched_current>
    80006224:	854e                	mv	a0,s3
    80006226:	ca3ff0ef          	jal	80005ec8 <is_mlfq>
    8000622a:	e111                	bnez	a0,8000622e <policy_proc_init+0x3a>
    8000622c:	892a                	mv	s2,a0
    8000622e:	1724a823          	sw	s2,368(s1)
  p->used = 0;
    80006232:	1604ac23          	sw	zero,376(s1)
  p->vrt = 0;
    80006236:	1804b423          	sd	zero,392(s1)
  p->wait_ticks = 0;
    8000623a:	1804b023          	sd	zero,384(s1)
  if (is_stride(sched_current)) {
    8000623e:	854e                	mv	a0,s3
    80006240:	c69ff0ef          	jal	80005ea8 <is_stride>
    80006244:	cd01                	beqz	a0,8000625c <policy_proc_init+0x68>
    if (stride_reset_left > 0)
    80006246:	00007797          	auipc	a5,0x7
    8000624a:	3d67a783          	lw	a5,982(a5) # 8000d61c <stride_reset_left>
    8000624e:	00f05e63          	blez	a5,8000626a <policy_proc_init+0x76>
      stride_reset_left--;
    80006252:	37fd                	addiw	a5,a5,-1
    80006254:	00007717          	auipc	a4,0x7
    80006258:	3cf72423          	sw	a5,968(a4) # 8000d61c <stride_reset_left>
    else
      stride_place(p); // new process joins at the other active minimum
  }
}
    8000625c:	70a2                	ld	ra,40(sp)
    8000625e:	7402                	ld	s0,32(sp)
    80006260:	64e2                	ld	s1,24(sp)
    80006262:	6942                	ld	s2,16(sp)
    80006264:	69a2                	ld	s3,8(sp)
    80006266:	6145                	addi	sp,sp,48
    80006268:	8082                	ret
      stride_place(p); // new process joins at the other active minimum
    8000626a:	8526                	mv	a0,s1
    8000626c:	cc7ff0ef          	jal	80005f32 <stride_place>
}
    80006270:	b7f5                	j	8000625c <policy_proc_init+0x68>

0000000080006272 <policy_pick_next_proc>:
}

// Choose the next process to run, or return 0 if none is RUNNABLE.
struct proc *
policy_pick_next_proc(void)
{
    80006272:	1101                	addi	sp,sp,-32
    80006274:	ec06                	sd	ra,24(sp)
    80006276:	e822                	sd	s0,16(sp)
    80006278:	e426                	sd	s1,8(sp)
    8000627a:	1000                	addi	s0,sp,32
  switch (sched_current) {
    8000627c:	00007e97          	auipc	t4,0x7
    80006280:	38ceae83          	lw	t4,908(t4) # 8000d608 <sched_current>
    80006284:	47b5                	li	a5,13
    80006286:	29d7e363          	bltu	a5,t4,8000650c <policy_pick_next_proc+0x29a>
    8000628a:	002e9793          	slli	a5,t4,0x2
    8000628e:	00004717          	auipc	a4,0x4
    80006292:	8aa70713          	addi	a4,a4,-1878 # 80009b38 <syscalls+0x148>
    80006296:	97ba                	add	a5,a5,a4
    80006298:	439c                	lw	a5,0(a5)
    8000629a:	97ba                	add	a5,a5,a4
    8000629c:	8782                	jr	a5
    struct proc *p = &proc[(stride_last + i) % NPROC];
    8000629e:	00007817          	auipc	a6,0x7
    800062a2:	c3a82803          	lw	a6,-966(a6) # 8000ced8 <stride_last>
    if (sched_current == SCHED_STRIDE_AGING && p->wait_ticks >= aging_threshold &&
    800062a6:	00007f97          	auipc	t6,0x7
    800062aa:	c3afbf83          	ld	t6,-966(t6) # 8000cee0 <aging_threshold>
    800062ae:	0018071b          	addiw	a4,a6,1
    800062b2:	0418081b          	addiw	a6,a6,65
  struct proc *aged = 0;
    800062b6:	4481                	li	s1,0
  struct proc *best = 0;
    800062b8:	4881                	li	a7,0
    if (p->state != RUNNABLE)
    800062ba:	00010597          	auipc	a1,0x10
    800062be:	8f658593          	addi	a1,a1,-1802 # 80015bb0 <proc>
    800062c2:	19800613          	li	a2,408
    800062c6:	430d                	li	t1,3
    if (sched_current == SCHED_STRIDE_AGING && p->wait_ticks >= aging_threshold &&
    800062c8:	4f15                	li	t5,5
    800062ca:	a039                	j	800062d8 <policy_pick_next_proc+0x66>
      best = p;
    800062cc:	88b6                	mv	a7,a3
    if (sched_current == SCHED_STRIDE_AGING && p->wait_ticks >= aging_threshold &&
    800062ce:	05ee8163          	beq	t4,t5,80006310 <policy_pick_next_proc+0x9e>
  for (int i = 1; i <= NPROC; i++) {
    800062d2:	2705                	addiw	a4,a4,1
    800062d4:	05070e63          	beq	a4,a6,80006330 <policy_pick_next_proc+0xbe>
    struct proc *p = &proc[(stride_last + i) % NPROC];
    800062d8:	41f7569b          	sraiw	a3,a4,0x1f
    800062dc:	01a6d69b          	srliw	a3,a3,0x1a
    800062e0:	00e687bb          	addw	a5,a3,a4
    800062e4:	03f7f793          	andi	a5,a5,63
    800062e8:	9f95                	subw	a5,a5,a3
    if (p->state != RUNNABLE)
    800062ea:	02c786b3          	mul	a3,a5,a2
    800062ee:	96ae                	add	a3,a3,a1
    800062f0:	4e94                	lw	a3,24(a3)
    800062f2:	fe6690e3          	bne	a3,t1,800062d2 <policy_pick_next_proc+0x60>
    struct proc *p = &proc[(stride_last + i) % NPROC];
    800062f6:	02c786b3          	mul	a3,a5,a2
    800062fa:	96ae                	add	a3,a3,a1
    if (!best || p->vrt < best->vrt)
    800062fc:	fc0888e3          	beqz	a7,800062cc <policy_pick_next_proc+0x5a>
    80006300:	1886be03          	ld	t3,392(a3)
    80006304:	1888b503          	ld	a0,392(a7)
    80006308:	fcae73e3          	bgeu	t3,a0,800062ce <policy_pick_next_proc+0x5c>
      best = p;
    8000630c:	88b6                	mv	a7,a3
    8000630e:	b7c1                	j	800062ce <policy_pick_next_proc+0x5c>
    if (sched_current == SCHED_STRIDE_AGING && p->wait_ticks >= aging_threshold &&
    80006310:	02c787b3          	mul	a5,a5,a2
    80006314:	97ae                	add	a5,a5,a1
    80006316:	1807b783          	ld	a5,384(a5)
    8000631a:	fbf7ece3          	bltu	a5,t6,800062d2 <policy_pick_next_proc+0x60>
    8000631e:	c499                	beqz	s1,8000632c <policy_pick_next_proc+0xba>
        (!aged || p->wait_ticks > aged->wait_ticks))
    80006320:	1804b503          	ld	a0,384(s1)
    80006324:	faf577e3          	bgeu	a0,a5,800062d2 <policy_pick_next_proc+0x60>
      aged = p;
    80006328:	84b6                	mv	s1,a3
    8000632a:	b765                	j	800062d2 <policy_pick_next_proc+0x60>
    8000632c:	84b6                	mv	s1,a3
    8000632e:	b755                	j	800062d2 <policy_pick_next_proc+0x60>
  if (aged) {
    80006330:	c4a5                	beqz	s1,80006398 <policy_pick_next_proc+0x126>
    if (logging && aged != best)
    80006332:	00007797          	auipc	a5,0x7
    80006336:	2da7a783          	lw	a5,730(a5) # 8000d60c <logging>
    8000633a:	c795                	beqz	a5,80006366 <policy_pick_next_proc+0xf4>
    8000633c:	02988563          	beq	a7,s1,80006366 <policy_pick_next_proc+0xf4>
      printk("aging override pid %d wait %lu pass %lu over pid %d pass %lu at %d\n",
    80006340:	00007817          	auipc	a6,0x7
    80006344:	2d882803          	lw	a6,728(a6) # 8000d618 <ticks>
    80006348:	1888b783          	ld	a5,392(a7)
    8000634c:	0308a703          	lw	a4,48(a7)
    80006350:	1884b683          	ld	a3,392(s1)
    80006354:	1804b603          	ld	a2,384(s1)
    80006358:	588c                	lw	a1,48(s1)
    8000635a:	00003517          	auipc	a0,0x3
    8000635e:	4d650513          	addi	a0,a0,1238 # 80009830 <etext+0x830>
    80006362:	9a6fa0ef          	jal	80000508 <printk>
    stride_last = best - proc;
    80006366:	00010797          	auipc	a5,0x10
    8000636a:	84a78793          	addi	a5,a5,-1974 # 80015bb0 <proc>
    8000636e:	40f487b3          	sub	a5,s1,a5
    80006372:	4037d713          	srai	a4,a5,0x3
    80006376:	fafb07b7          	lui	a5,0xfafb0
    8000637a:	afb78793          	addi	a5,a5,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    8000637e:	07c2                	slli	a5,a5,0x10
    80006380:	afb78793          	addi	a5,a5,-1285
    80006384:	07c2                	slli	a5,a5,0x10
    80006386:	afb78793          	addi	a5,a5,-1285
    8000638a:	02f707b3          	mul	a5,a4,a5
    8000638e:	00007717          	auipc	a4,0x7
    80006392:	b4f72523          	sw	a5,-1206(a4) # 8000ced8 <stride_last>
    80006396:	aac5                	j	80006586 <policy_pick_next_proc+0x314>
  if (best)
    80006398:	84c6                	mv	s1,a7
    8000639a:	1e088663          	beqz	a7,80006586 <policy_pick_next_proc+0x314>
    8000639e:	b7e1                	j	80006366 <policy_pick_next_proc+0xf4>
  mlfq_boost();
    800063a0:	c39ff0ef          	jal	80005fd8 <mlfq_boost>
  for (int level = 2; level >= 0; level--) {
    800063a4:	00021317          	auipc	t1,0x21
    800063a8:	1ec30313          	addi	t1,t1,492 # 80027590 <mlfq_last>
    800063ac:	4889                	li	a7,2
      if (p->state == RUNNABLE && p->level == level) {
    800063ae:	00010597          	auipc	a1,0x10
    800063b2:	80258593          	addi	a1,a1,-2046 # 80015bb0 <proc>
    800063b6:	19800613          	li	a2,408
    800063ba:	480d                	li	a6,3
      struct proc *p = &proc[(mlfq_last[level] + i) % NPROC];
    800063bc:	00832503          	lw	a0,8(t1)
    800063c0:	0015069b          	addiw	a3,a0,1
    800063c4:	0415051b          	addiw	a0,a0,65
    800063c8:	a021                	j	800063d0 <policy_pick_next_proc+0x15e>
    for (int i = 1; i <= NPROC; i++) {
    800063ca:	2685                	addiw	a3,a3,1
    800063cc:	06a68663          	beq	a3,a0,80006438 <policy_pick_next_proc+0x1c6>
      struct proc *p = &proc[(mlfq_last[level] + i) % NPROC];
    800063d0:	41f6d71b          	sraiw	a4,a3,0x1f
    800063d4:	01a7571b          	srliw	a4,a4,0x1a
    800063d8:	00d707bb          	addw	a5,a4,a3
    800063dc:	03f7f793          	andi	a5,a5,63
    800063e0:	9f99                	subw	a5,a5,a4
      if (p->state == RUNNABLE && p->level == level) {
    800063e2:	02c78733          	mul	a4,a5,a2
    800063e6:	972e                	add	a4,a4,a1
    800063e8:	4f18                	lw	a4,24(a4)
    800063ea:	ff0710e3          	bne	a4,a6,800063ca <policy_pick_next_proc+0x158>
    800063ee:	02c78733          	mul	a4,a5,a2
    800063f2:	972e                	add	a4,a4,a1
    800063f4:	17072703          	lw	a4,368(a4)
    800063f8:	fd1719e3          	bne	a4,a7,800063ca <policy_pick_next_proc+0x158>
    800063fc:	19800713          	li	a4,408
    80006400:	02e787b3          	mul	a5,a5,a4
      struct proc *p = &proc[(mlfq_last[level] + i) % NPROC];
    80006404:	0000f497          	auipc	s1,0xf
    80006408:	7ac48493          	addi	s1,s1,1964 # 80015bb0 <proc>
    8000640c:	94be                	add	s1,s1,a5
        mlfq_last[level] = p - proc;
    8000640e:	088a                	slli	a7,a7,0x2
    80006410:	00021697          	auipc	a3,0x21
    80006414:	18068693          	addi	a3,a3,384 # 80027590 <mlfq_last>
    80006418:	96c6                	add	a3,a3,a7
    8000641a:	878d                	srai	a5,a5,0x3
    8000641c:	fafb0737          	lui	a4,0xfafb0
    80006420:	afb70713          	addi	a4,a4,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    80006424:	0742                	slli	a4,a4,0x10
    80006426:	afb70713          	addi	a4,a4,-1285
    8000642a:	0742                	slli	a4,a4,0x10
    8000642c:	afb70713          	addi	a4,a4,-1285
    80006430:	02e787b3          	mul	a5,a5,a4
    80006434:	c29c                	sw	a5,0(a3)
        return p;
    80006436:	aa81                	j	80006586 <policy_pick_next_proc+0x314>
  for (int level = 2; level >= 0; level--) {
    80006438:	38fd                	addiw	a7,a7,-1
    8000643a:	1371                	addi	t1,t1,-4
    8000643c:	57fd                	li	a5,-1
    8000643e:	f6f89fe3          	bne	a7,a5,800063bc <policy_pick_next_proc+0x14a>
  return 0;
    80006442:	4481                	li	s1,0
    80006444:	a289                	j	80006586 <policy_pick_next_proc+0x314>
  int best = 100;
    80006446:	06400613          	li	a2,100
  for (struct proc *p = proc; p < &proc[NPROC]; p++)
    8000644a:	0000f797          	auipc	a5,0xf
    8000644e:	76678793          	addi	a5,a5,1894 # 80015bb0 <proc>
    if (p->state == RUNNABLE && p->nice < best)
    80006452:	458d                	li	a1,3
  for (struct proc *p = proc; p < &proc[NPROC]; p++)
    80006454:	00016697          	auipc	a3,0x16
    80006458:	d5c68693          	addi	a3,a3,-676 # 8001c1b0 <tickslock>
    8000645c:	a039                	j	8000646a <policy_pick_next_proc+0x1f8>
    if (p->state == RUNNABLE && p->nice < best)
    8000645e:	0005061b          	sext.w	a2,a0
  for (struct proc *p = proc; p < &proc[NPROC]; p++)
    80006462:	19878793          	addi	a5,a5,408
    80006466:	00d78d63          	beq	a5,a3,80006480 <policy_pick_next_proc+0x20e>
    if (p->state == RUNNABLE && p->nice < best)
    8000646a:	4f98                	lw	a4,24(a5)
    8000646c:	feb71be3          	bne	a4,a1,80006462 <policy_pick_next_proc+0x1f0>
    80006470:	1687a703          	lw	a4,360(a5)
    80006474:	853a                	mv	a0,a4
    80006476:	2701                	sext.w	a4,a4
    80006478:	fee653e3          	bge	a2,a4,8000645e <policy_pick_next_proc+0x1ec>
    8000647c:	8532                	mv	a0,a2
    8000647e:	b7c5                	j	8000645e <policy_pick_next_proc+0x1ec>
    struct proc *p = &proc[(last + i) % NPROC];
    80006480:	00007817          	auipc	a6,0x7
    80006484:	a7082803          	lw	a6,-1424(a6) # 8000cef0 <last>
    80006488:	0018069b          	addiw	a3,a6,1
    8000648c:	0418081b          	addiw	a6,a6,65
    if (p->state == RUNNABLE && p->nice == best) {
    80006490:	0000f517          	auipc	a0,0xf
    80006494:	72050513          	addi	a0,a0,1824 # 80015bb0 <proc>
    80006498:	19800593          	li	a1,408
    8000649c:	488d                	li	a7,3
    8000649e:	a021                	j	800064a6 <policy_pick_next_proc+0x234>
  for (int i = 1; i <= NPROC; i++) {
    800064a0:	2685                	addiw	a3,a3,1
    800064a2:	07068363          	beq	a3,a6,80006508 <policy_pick_next_proc+0x296>
    struct proc *p = &proc[(last + i) % NPROC];
    800064a6:	41f6d71b          	sraiw	a4,a3,0x1f
    800064aa:	01a7571b          	srliw	a4,a4,0x1a
    800064ae:	00d707bb          	addw	a5,a4,a3
    800064b2:	03f7f793          	andi	a5,a5,63
    800064b6:	9f99                	subw	a5,a5,a4
    if (p->state == RUNNABLE && p->nice == best) {
    800064b8:	02b78733          	mul	a4,a5,a1
    800064bc:	972a                	add	a4,a4,a0
    800064be:	4f18                	lw	a4,24(a4)
    800064c0:	ff1710e3          	bne	a4,a7,800064a0 <policy_pick_next_proc+0x22e>
    800064c4:	02b78733          	mul	a4,a5,a1
    800064c8:	972a                	add	a4,a4,a0
    800064ca:	16872703          	lw	a4,360(a4)
    800064ce:	fcc719e3          	bne	a4,a2,800064a0 <policy_pick_next_proc+0x22e>
    800064d2:	19800713          	li	a4,408
    800064d6:	02e787b3          	mul	a5,a5,a4
    struct proc *p = &proc[(last + i) % NPROC];
    800064da:	0000f497          	auipc	s1,0xf
    800064de:	6d648493          	addi	s1,s1,1750 # 80015bb0 <proc>
    800064e2:	94be                	add	s1,s1,a5
      last = p - proc;
    800064e4:	878d                	srai	a5,a5,0x3
    800064e6:	fafb0737          	lui	a4,0xfafb0
    800064ea:	afb70713          	addi	a4,a4,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    800064ee:	0742                	slli	a4,a4,0x10
    800064f0:	afb70713          	addi	a4,a4,-1285
    800064f4:	0742                	slli	a4,a4,0x10
    800064f6:	afb70713          	addi	a4,a4,-1285
    800064fa:	02e787b3          	mul	a5,a5,a4
    800064fe:	00007717          	auipc	a4,0x7
    80006502:	9ef72923          	sw	a5,-1550(a4) # 8000cef0 <last>
      return p;
    80006506:	a041                	j	80006586 <policy_pick_next_proc+0x314>
  return 0;
    80006508:	4481                	li	s1,0
    8000650a:	a8b5                	j	80006586 <policy_pick_next_proc+0x314>
    struct proc *p = &proc[(last + i) % NPROC];
    8000650c:	00007617          	auipc	a2,0x7
    80006510:	9e462603          	lw	a2,-1564(a2) # 8000cef0 <last>
    80006514:	0016069b          	addiw	a3,a2,1
    80006518:	0416061b          	addiw	a2,a2,65
    if (p->state == RUNNABLE) {
    8000651c:	0000f817          	auipc	a6,0xf
    80006520:	69480813          	addi	a6,a6,1684 # 80015bb0 <proc>
    80006524:	19800513          	li	a0,408
    80006528:	458d                	li	a1,3
    struct proc *p = &proc[(last + i) % NPROC];
    8000652a:	41f6d71b          	sraiw	a4,a3,0x1f
    8000652e:	01a7571b          	srliw	a4,a4,0x1a
    80006532:	00d707bb          	addw	a5,a4,a3
    80006536:	03f7f793          	andi	a5,a5,63
    8000653a:	9f99                	subw	a5,a5,a4
    if (p->state == RUNNABLE) {
    8000653c:	02a78733          	mul	a4,a5,a0
    80006540:	9742                	add	a4,a4,a6
    80006542:	4f18                	lw	a4,24(a4)
    80006544:	00b70763          	beq	a4,a1,80006552 <policy_pick_next_proc+0x2e0>
  for (int i = 1; i <= NPROC; i++) {
    80006548:	2685                	addiw	a3,a3,1
    8000654a:	fec690e3          	bne	a3,a2,8000652a <policy_pick_next_proc+0x2b8>
  return 0;
    8000654e:	4481                	li	s1,0
    80006550:	a81d                	j	80006586 <policy_pick_next_proc+0x314>
    80006552:	19800713          	li	a4,408
    80006556:	02e787b3          	mul	a5,a5,a4
    struct proc *p = &proc[(last + i) % NPROC];
    8000655a:	0000f497          	auipc	s1,0xf
    8000655e:	65648493          	addi	s1,s1,1622 # 80015bb0 <proc>
    80006562:	94be                	add	s1,s1,a5
      last = p - proc;
    80006564:	878d                	srai	a5,a5,0x3
    80006566:	fafb0737          	lui	a4,0xfafb0
    8000656a:	afb70713          	addi	a4,a4,-1285 # fffffffffafafafb <end+0xffffffff7af87b43>
    8000656e:	0742                	slli	a4,a4,0x10
    80006570:	afb70713          	addi	a4,a4,-1285
    80006574:	0742                	slli	a4,a4,0x10
    80006576:	afb70713          	addi	a4,a4,-1285
    8000657a:	02e787b3          	mul	a5,a5,a4
    8000657e:	00007717          	auipc	a4,0x7
    80006582:	96f72923          	sw	a5,-1678(a4) # 8000cef0 <last>
  case SCHED_PRIO:
    return pick_prio();
  default:
    return pick_rr();
  }
}
    80006586:	8526                	mv	a0,s1
    80006588:	60e2                	ld	ra,24(sp)
    8000658a:	6442                	ld	s0,16(sp)
    8000658c:	64a2                	ld	s1,8(sp)
    8000658e:	6105                	addi	sp,sp,32
    80006590:	8082                	ret

0000000080006592 <policy_dispatch>:

// Called just before the framework switches to p.
void
policy_dispatch(struct proc *p)
{
  p->wait_ticks = 0;
    80006592:	18053023          	sd	zero,384(a0)
  p->qticks = 0; // a new quantum starts
    80006596:	16052623          	sw	zero,364(a0)
  if (logging && is_stride(sched_current))
    8000659a:	00007797          	auipc	a5,0x7
    8000659e:	0727a783          	lw	a5,114(a5) # 8000d60c <logging>
    800065a2:	c3b9                	beqz	a5,800065e8 <policy_dispatch+0x56>
{
    800065a4:	1101                	addi	sp,sp,-32
    800065a6:	ec06                	sd	ra,24(sp)
    800065a8:	e822                	sd	s0,16(sp)
    800065aa:	e426                	sd	s1,8(sp)
    800065ac:	1000                	addi	s0,sp,32
    800065ae:	84aa                	mv	s1,a0
  if (logging && is_stride(sched_current))
    800065b0:	00007517          	auipc	a0,0x7
    800065b4:	05852503          	lw	a0,88(a0) # 8000d608 <sched_current>
    800065b8:	8f1ff0ef          	jal	80005ea8 <is_stride>
    800065bc:	e511                	bnez	a0,800065c8 <policy_dispatch+0x36>
    printk("stride dispatch pid %d nice %d pass %lu at %d\n",
           p->pid, p->nice, p->vrt, ticks);
}
    800065be:	60e2                	ld	ra,24(sp)
    800065c0:	6442                	ld	s0,16(sp)
    800065c2:	64a2                	ld	s1,8(sp)
    800065c4:	6105                	addi	sp,sp,32
    800065c6:	8082                	ret
    printk("stride dispatch pid %d nice %d pass %lu at %d\n",
    800065c8:	00007717          	auipc	a4,0x7
    800065cc:	05072703          	lw	a4,80(a4) # 8000d618 <ticks>
    800065d0:	1884b683          	ld	a3,392(s1)
    800065d4:	1684a603          	lw	a2,360(s1)
    800065d8:	588c                	lw	a1,48(s1)
    800065da:	00003517          	auipc	a0,0x3
    800065de:	29e50513          	addi	a0,a0,670 # 80009878 <etext+0x878>
    800065e2:	f27f90ef          	jal	80000508 <printk>
}
    800065e6:	bfe1                	j	800065be <policy_dispatch+0x2c>
    800065e8:	8082                	ret

00000000800065ea <policy_tick>:
// such as an allotment kept across sleeps. A test that is charged must
// keep the CPU across a tick, for example by spinning until uptime()
// changes before each pause(1); workload jobs are charged correctly.
int
policy_tick(struct proc *p)
{
    800065ea:	7139                	addi	sp,sp,-64
    800065ec:	fc06                	sd	ra,56(sp)
    800065ee:	f822                	sd	s0,48(sp)
    800065f0:	f426                	sd	s1,40(sp)
    800065f2:	f04a                	sd	s2,32(sp)
    800065f4:	ec4e                	sd	s3,24(sp)
    800065f6:	0080                	addi	s0,sp,64
    800065f8:	84aa                	mv	s1,a0
  // Sample runnable waiting once per timer tick, even inside a quantum.
  // Reaching the threshold changes the next selection, not preemption timing.
  if (sched_current == SCHED_STRIDE_AGING)
    800065fa:	00007997          	auipc	s3,0x7
    800065fe:	00e9a983          	lw	s3,14(s3) # 8000d608 <sched_current>
    80006602:	4795                	li	a5,5
    80006604:	02f98c63          	beq	s3,a5,8000663c <policy_tick+0x52>
    for (struct proc *q = proc; q < &proc[NPROC]; q++)
      if (q->state == RUNNABLE && q->wait_ticks != ~0ULL)
        q->wait_ticks++;
  if (is_stride(sched_current)) {
    80006608:	854e                	mv	a0,s3
    8000660a:	89fff0ef          	jal	80005ea8 <is_stride>
    8000660e:	892a                	mv	s2,a0
    80006610:	e125                	bnez	a0,80006670 <policy_tick+0x86>
      printk("stride charge pid %d nice %d before %lu step %lu after %lu at %d\n",
             p->pid, p->nice, before, stride, p->vrt, ticks);
    stride_normalize();
    return p->qticks >= stride_quantum;
  }
  if (!is_mlfq(sched_current)) {
    80006612:	854e                	mv	a0,s3
    80006614:	8b5ff0ef          	jal	80005ec8 <is_mlfq>
    80006618:	12051b63          	bnez	a0,8000674e <policy_tick+0x164>
    p->qticks++;
    8000661c:	16c4a783          	lw	a5,364(s1)
    80006620:	2785                	addiw	a5,a5,1
    80006622:	0007871b          	sext.w	a4,a5
    80006626:	16f4a623          	sw	a5,364(s1)
    return p->qticks >= quantum;
    8000662a:	00007917          	auipc	s2,0x7
    8000662e:	8ca92903          	lw	s2,-1846(s2) # 8000cef4 <quantum>
    80006632:	01272933          	slt	s2,a4,s2
    80006636:	00194913          	xori	s2,s2,1
    8000663a:	a211                	j	8000673e <policy_tick+0x154>
    for (struct proc *q = proc; q < &proc[NPROC]; q++)
    8000663c:	0000f797          	auipc	a5,0xf
    80006640:	57478793          	addi	a5,a5,1396 # 80015bb0 <proc>
      if (q->state == RUNNABLE && q->wait_ticks != ~0ULL)
    80006644:	460d                	li	a2,3
    80006646:	55fd                	li	a1,-1
    for (struct proc *q = proc; q < &proc[NPROC]; q++)
    80006648:	00016697          	auipc	a3,0x16
    8000664c:	b6868693          	addi	a3,a3,-1176 # 8001c1b0 <tickslock>
    80006650:	a029                	j	8000665a <policy_tick+0x70>
    80006652:	19878793          	addi	a5,a5,408
    80006656:	fad789e3          	beq	a5,a3,80006608 <policy_tick+0x1e>
      if (q->state == RUNNABLE && q->wait_ticks != ~0ULL)
    8000665a:	4f98                	lw	a4,24(a5)
    8000665c:	fec71be3          	bne	a4,a2,80006652 <policy_tick+0x68>
    80006660:	1807b703          	ld	a4,384(a5)
    80006664:	feb707e3          	beq	a4,a1,80006652 <policy_tick+0x68>
        q->wait_ticks++;
    80006668:	0705                	addi	a4,a4,1
    8000666a:	18e7b023          	sd	a4,384(a5)
    8000666e:	b7d5                	j	80006652 <policy_tick+0x68>
    p->qticks++;
    80006670:	16c4a783          	lw	a5,364(s1)
    80006674:	2785                	addiw	a5,a5,1
    80006676:	16f4a623          	sw	a5,364(s1)
    uint64 before = p->vrt;
    8000667a:	1884b683          	ld	a3,392(s1)
    int tickets = nice_weight[p->nice + 20];
    8000667e:	1684a603          	lw	a2,360(s1)
    80006682:	0146071b          	addiw	a4,a2,20
    80006686:	070a                	slli	a4,a4,0x2
    80006688:	00003797          	auipc	a5,0x3
    8000668c:	4e878793          	addi	a5,a5,1256 # 80009b70 <nice_weight>
    80006690:	97ba                	add	a5,a5,a4
    if (tickets < stride_ticket_floor)
    80006692:	00007597          	auipc	a1,0x7
    80006696:	f8e5a583          	lw	a1,-114(a1) # 8000d620 <stride_ticket_floor>
    8000669a:	439c                	lw	a5,0(a5)
    8000669c:	873e                	mv	a4,a5
    8000669e:	2781                	sext.w	a5,a5
    800066a0:	00b7d363          	bge	a5,a1,800066a6 <policy_tick+0xbc>
    800066a4:	872e                	mv	a4,a1
    uint64 stride = STRIDE_SCALE / tickets;
    800066a6:	2701                	sext.w	a4,a4
    800066a8:	010007b7          	lui	a5,0x1000
    800066ac:	02e7d733          	divu	a4,a5,a4
    p->vrt += stride;
    800066b0:	00e687b3          	add	a5,a3,a4
    800066b4:	18f4b423          	sd	a5,392(s1)
    if (logging)
    800066b8:	00007597          	auipc	a1,0x7
    800066bc:	f545a583          	lw	a1,-172(a1) # 8000d60c <logging>
    800066c0:	e98d                	bnez	a1,800066f2 <policy_tick+0x108>
  uint64 minimum = 0;
    800066c2:	fc043423          	sd	zero,-56(s0)
  if (!stride_min_other(0, &minimum) || minimum < (1ULL << 60))
    800066c6:	fc840593          	addi	a1,s0,-56
    800066ca:	4501                	li	a0,0
    800066cc:	819ff0ef          	jal	80005ee4 <stride_min_other>
    800066d0:	cd29                	beqz	a0,8000672a <policy_tick+0x140>
    800066d2:	fc843583          	ld	a1,-56(s0)
    800066d6:	57fd                	li	a5,-1
    800066d8:	8391                	srli	a5,a5,0x4
    800066da:	04b7f863          	bgeu	a5,a1,8000672a <policy_tick+0x140>
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    800066de:	0000f797          	auipc	a5,0xf
    800066e2:	4d278793          	addi	a5,a5,1234 # 80015bb0 <proc>
      p->vrt = p->vrt >= minimum ? p->vrt - minimum : 0;
    800066e6:	4501                	li	a0,0
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    800066e8:	00016617          	auipc	a2,0x16
    800066ec:	ac860613          	addi	a2,a2,-1336 # 8001c1b0 <tickslock>
    800066f0:	a01d                	j	80006716 <policy_tick+0x12c>
      printk("stride charge pid %d nice %d before %lu step %lu after %lu at %d\n",
    800066f2:	00007817          	auipc	a6,0x7
    800066f6:	f2682803          	lw	a6,-218(a6) # 8000d618 <ticks>
    800066fa:	588c                	lw	a1,48(s1)
    800066fc:	00003517          	auipc	a0,0x3
    80006700:	1ac50513          	addi	a0,a0,428 # 800098a8 <etext+0x8a8>
    80006704:	e05f90ef          	jal	80000508 <printk>
    80006708:	bf6d                	j	800066c2 <policy_tick+0xd8>
      p->vrt = p->vrt >= minimum ? p->vrt - minimum : 0;
    8000670a:	18e7b423          	sd	a4,392(a5)
  for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8000670e:	19878793          	addi	a5,a5,408
    80006712:	00c78c63          	beq	a5,a2,8000672a <policy_tick+0x140>
    if (p->state != UNUSED)
    80006716:	4f98                	lw	a4,24(a5)
    80006718:	db7d                	beqz	a4,8000670e <policy_tick+0x124>
      p->vrt = p->vrt >= minimum ? p->vrt - minimum : 0;
    8000671a:	1887b683          	ld	a3,392(a5)
    8000671e:	872a                	mv	a4,a0
    80006720:	feb6e5e3          	bltu	a3,a1,8000670a <policy_tick+0x120>
    80006724:	40b68733          	sub	a4,a3,a1
    80006728:	b7cd                	j	8000670a <policy_tick+0x120>
    return p->qticks >= stride_quantum;
    8000672a:	16c4a903          	lw	s2,364(s1)
    8000672e:	00006797          	auipc	a5,0x6
    80006732:	7ba7a783          	lw	a5,1978(a5) # 8000cee8 <stride_quantum>
    80006736:	00f92933          	slt	s2,s2,a5
    8000673a:	00194913          	xori	s2,s2,1
    preempt = 1;
  for (struct proc *q = proc; q < &proc[NPROC]; q++)
    if (q->state == RUNNABLE && q->level > p->level)
      preempt = 1;
  return preempt;
}
    8000673e:	854a                	mv	a0,s2
    80006740:	70e2                	ld	ra,56(sp)
    80006742:	7442                	ld	s0,48(sp)
    80006744:	74a2                	ld	s1,40(sp)
    80006746:	7902                	ld	s2,32(sp)
    80006748:	69e2                	ld	s3,24(sp)
    8000674a:	6121                	addi	sp,sp,64
    8000674c:	8082                	ret
  p->used++;
    8000674e:	1784a783          	lw	a5,376(s1)
    80006752:	2785                	addiw	a5,a5,1
    80006754:	16f4ac23          	sw	a5,376(s1)
  p->qticks++;
    80006758:	16c4a783          	lw	a5,364(s1)
    8000675c:	2785                	addiw	a5,a5,1
    8000675e:	16f4a623          	sw	a5,364(s1)
  mlfq_boost();
    80006762:	877ff0ef          	jal	80005fd8 <mlfq_boost>
  if (p->level > 0 && p->used >= mlfq_allotment[p->level]) {
    80006766:	1704a583          	lw	a1,368(s1)
    8000676a:	00b05f63          	blez	a1,80006788 <policy_tick+0x19e>
    8000676e:	00259713          	slli	a4,a1,0x2
    80006772:	00003797          	auipc	a5,0x3
    80006776:	3fe78793          	addi	a5,a5,1022 # 80009b70 <nice_weight>
    8000677a:	97ba                	add	a5,a5,a4
    8000677c:	1784a703          	lw	a4,376(s1)
    80006780:	0a07a783          	lw	a5,160(a5)
    80006784:	02f75c63          	bge	a4,a5,800067bc <policy_tick+0x1d2>
  if (p->qticks >= mlfq_quantum[p->level])
    80006788:	1704a583          	lw	a1,368(s1)
    8000678c:	00259713          	slli	a4,a1,0x2
    80006790:	00006797          	auipc	a5,0x6
    80006794:	77078793          	addi	a5,a5,1904 # 8000cf00 <mlfq_quantum>
    80006798:	97ba                	add	a5,a5,a4
    8000679a:	16c4a703          	lw	a4,364(s1)
    8000679e:	439c                	lw	a5,0(a5)
    800067a0:	00f74363          	blt	a4,a5,800067a6 <policy_tick+0x1bc>
    preempt = 1;
    800067a4:	4905                	li	s2,1
    800067a6:	0000f797          	auipc	a5,0xf
    800067aa:	40a78793          	addi	a5,a5,1034 # 80015bb0 <proc>
    if (q->state == RUNNABLE && q->level > p->level)
    800067ae:	460d                	li	a2,3
      preempt = 1;
    800067b0:	4505                	li	a0,1
  for (struct proc *q = proc; q < &proc[NPROC]; q++)
    800067b2:	00016697          	auipc	a3,0x16
    800067b6:	9fe68693          	addi	a3,a3,-1538 # 8001c1b0 <tickslock>
    800067ba:	a829                	j	800067d4 <policy_tick+0x1ea>
    change_queue(p, p->level - 1);
    800067bc:	35fd                	addiw	a1,a1,-1
    800067be:	8526                	mv	a0,s1
    800067c0:	fd8ff0ef          	jal	80005f98 <change_queue>
    p->used = 0;
    800067c4:	1604ac23          	sw	zero,376(s1)
    preempt = 1;
    800067c8:	4905                	li	s2,1
    800067ca:	bf7d                	j	80006788 <policy_tick+0x19e>
  for (struct proc *q = proc; q < &proc[NPROC]; q++)
    800067cc:	19878793          	addi	a5,a5,408
    800067d0:	f6d787e3          	beq	a5,a3,8000673e <policy_tick+0x154>
    if (q->state == RUNNABLE && q->level > p->level)
    800067d4:	4f98                	lw	a4,24(a5)
    800067d6:	fec71be3          	bne	a4,a2,800067cc <policy_tick+0x1e2>
    800067da:	1707a703          	lw	a4,368(a5)
    800067de:	fee5d7e3          	bge	a1,a4,800067cc <policy_tick+0x1e2>
      preempt = 1;
    800067e2:	892a                	mv	s2,a0
    800067e4:	b7e5                	j	800067cc <policy_tick+0x1e2>

00000000800067e6 <policy_wakeup>:
// a waking process re-enters the policy; for example, a fair-share or
// stride policy may move a process that slept a long time up to the
// current minimum, so it cannot claim the CPU for the time it slept.
void
policy_wakeup(struct proc *p)
{
    800067e6:	1101                	addi	sp,sp,-32
    800067e8:	ec06                	sd	ra,24(sp)
    800067ea:	e822                	sd	s0,16(sp)
    800067ec:	e426                	sd	s1,8(sp)
    800067ee:	1000                	addi	s0,sp,32
    800067f0:	84aa                	mv	s1,a0
  p->wait_ticks = 0;
    800067f2:	18053023          	sd	zero,384(a0)
  if (is_stride(sched_current))
    800067f6:	00007517          	auipc	a0,0x7
    800067fa:	e1252503          	lw	a0,-494(a0) # 8000d608 <sched_current>
    800067fe:	eaaff0ef          	jal	80005ea8 <is_stride>
    80006802:	e511                	bnez	a0,8000680e <policy_wakeup+0x28>
    stride_place(p);
  // MLFQ retains level and used across sleeps; dispatch resets only qticks.
}
    80006804:	60e2                	ld	ra,24(sp)
    80006806:	6442                	ld	s0,16(sp)
    80006808:	64a2                	ld	s1,8(sp)
    8000680a:	6105                	addi	sp,sp,32
    8000680c:	8082                	ret
    stride_place(p);
    8000680e:	8526                	mv	a0,s1
    80006810:	f22ff0ef          	jal	80005f32 <stride_place>
}
    80006814:	bfc5                	j	80006804 <policy_wakeup+0x1e>

0000000080006816 <policy_nice>:

// Called whenever p's nice value changes.
void
policy_nice(struct proc *p)
{
    80006816:	711d                	addi	sp,sp,-96
    80006818:	ec86                	sd	ra,88(sp)
    8000681a:	e8a2                	sd	s0,80(sp)
    8000681c:	e4a6                	sd	s1,72(sp)
    8000681e:	1080                	addi	s0,sp,96
    80006820:	84aa                	mv	s1,a0
  // Stride derives its increment from the current nice; preserve its pass.
  if (!is_mlfq(sched_current))
    80006822:	00007517          	auipc	a0,0x7
    80006826:	de652503          	lw	a0,-538(a0) # 8000d608 <sched_current>
    8000682a:	e9eff0ef          	jal	80005ec8 <is_mlfq>
    8000682e:	c121                	beqz	a0,8000686e <policy_nice+0x58>
    80006830:	e0ca                	sd	s2,64(sp)
    80006832:	fc4e                	sd	s3,56(sp)
    80006834:	f852                	sd	s4,48(sp)
    80006836:	f456                	sd	s5,40(sp)
    return;
  int old_start = p->start_level;
    80006838:	1744a903          	lw	s2,372(s1)
  int old_level = p->level;
    8000683c:	1704a983          	lw	s3,368(s1)
  int old_used = p->used;
    80006840:	1784aa03          	lw	s4,376(s1)
  int old_qticks = p->qticks;
    80006844:	16c4aa83          	lw	s5,364(s1)
  int start = starting_queue(p->nice);
    80006848:	1684a783          	lw	a5,360(s1)
  if (nice <= -10)
    8000684c:	575d                	li	a4,-9
    return 2;
    8000684e:	4589                	li	a1,2
  if (nice <= -10)
    80006850:	00e7c463          	blt	a5,a4,80006858 <policy_nice+0x42>
  if (nice <= 10)
    80006854:	00b7a593          	slti	a1,a5,11
  if (start != p->start_level) {
    80006858:	02b91063          	bne	s2,a1,80006878 <policy_nice+0x62>
    p->start_level = start;
    change_queue(p, start);
    p->used = 0;
  }
  // Diagnostics observe Rule 6 without changing scheduling decisions.
  if (logging)
    8000685c:	00007797          	auipc	a5,0x7
    80006860:	db07a783          	lw	a5,-592(a5) # 8000d60c <logging>
    80006864:	e395                	bnez	a5,80006888 <policy_nice+0x72>
    80006866:	6906                	ld	s2,64(sp)
    80006868:	79e2                	ld	s3,56(sp)
    8000686a:	7a42                	ld	s4,48(sp)
    8000686c:	7aa2                	ld	s5,40(sp)
    printk("mlfq nicecheck pid %d nice %d start %d->%d level %d->%d used %d->%d qticks %d->%d at %d\n",
           p->pid, p->nice, old_start, p->start_level, old_level, p->level,
           old_used, p->used, old_qticks, p->qticks, ticks);
}
    8000686e:	60e6                	ld	ra,88(sp)
    80006870:	6446                	ld	s0,80(sp)
    80006872:	64a6                	ld	s1,72(sp)
    80006874:	6125                	addi	sp,sp,96
    80006876:	8082                	ret
    p->start_level = start;
    80006878:	16b4aa23          	sw	a1,372(s1)
    change_queue(p, start);
    8000687c:	8526                	mv	a0,s1
    8000687e:	f1aff0ef          	jal	80005f98 <change_queue>
    p->used = 0;
    80006882:	1604ac23          	sw	zero,376(s1)
    80006886:	bfd9                	j	8000685c <policy_nice+0x46>
    printk("mlfq nicecheck pid %d nice %d start %d->%d level %d->%d used %d->%d qticks %d->%d at %d\n",
    80006888:	00007797          	auipc	a5,0x7
    8000688c:	d907a783          	lw	a5,-624(a5) # 8000d618 <ticks>
    80006890:	ec3e                	sd	a5,24(sp)
    80006892:	16c4a783          	lw	a5,364(s1)
    80006896:	e83e                	sd	a5,16(sp)
    80006898:	e456                	sd	s5,8(sp)
    8000689a:	1784a783          	lw	a5,376(s1)
    8000689e:	e03e                	sd	a5,0(sp)
    800068a0:	88d2                	mv	a7,s4
    800068a2:	1704a803          	lw	a6,368(s1)
    800068a6:	87ce                	mv	a5,s3
    800068a8:	1744a703          	lw	a4,372(s1)
    800068ac:	86ca                	mv	a3,s2
    800068ae:	1684a603          	lw	a2,360(s1)
    800068b2:	588c                	lw	a1,48(s1)
    800068b4:	00003517          	auipc	a0,0x3
    800068b8:	03c50513          	addi	a0,a0,60 # 800098f0 <etext+0x8f0>
    800068bc:	c4df90ef          	jal	80000508 <printk>
    800068c0:	6906                	ld	s2,64(sp)
    800068c2:	79e2                	ld	s3,56(sp)
    800068c4:	7a42                	ld	s4,48(sp)
    800068c6:	7aa2                	ld	s5,40(sp)
    800068c8:	b75d                	j	8000686e <policy_nice+0x58>

00000000800068ca <clear>:
// Clear all workload state and release any workers.
// Caller holds wl_lock.
static void
clear(void)
{
  for (int i = 0; i < nslots; i++) {
    800068ca:	00007797          	auipc	a5,0x7
    800068ce:	d867a783          	lw	a5,-634(a5) # 8000d650 <nslots>
    800068d2:	08f05163          	blez	a5,80006954 <clear+0x8a>
{
    800068d6:	7139                	addi	sp,sp,-64
    800068d8:	fc06                	sd	ra,56(sp)
    800068da:	f822                	sd	s0,48(sp)
    800068dc:	f426                	sd	s1,40(sp)
    800068de:	f04a                	sd	s2,32(sp)
    800068e0:	ec4e                	sd	s3,24(sp)
    800068e2:	e852                	sd	s4,16(sp)
    800068e4:	e456                	sd	s5,8(sp)
    800068e6:	0080                	addi	s0,sp,64
    800068e8:	00021497          	auipc	s1,0x21
    800068ec:	cd048493          	addi	s1,s1,-816 # 800275b8 <ws>
  for (int i = 0; i < nslots; i++) {
    800068f0:	4901                	li	s2,0
    if (ws[i].p) {
      ws[i].p->wl_slot = -1;
    800068f2:	5afd                	li	s5,-1
  for (int i = 0; i < nslots; i++) {
    800068f4:	00007a17          	auipc	s4,0x7
    800068f8:	d5ca0a13          	addi	s4,s4,-676 # 8000d650 <nslots>
    800068fc:	a811                	j	80006910 <clear+0x46>
      wakeup(&ws[i]);
    }
    ws[i].p = 0;
    800068fe:	0009bc23          	sd	zero,24(s3)
  for (int i = 0; i < nslots; i++) {
    80006902:	2905                	addiw	s2,s2,1
    80006904:	0a048493          	addi	s1,s1,160
    80006908:	000a2783          	lw	a5,0(s4)
    8000690c:	00f95b63          	bge	s2,a5,80006922 <clear+0x58>
    if (ws[i].p) {
    80006910:	89a6                	mv	s3,s1
    80006912:	6c9c                	ld	a5,24(s1)
    80006914:	d7ed                	beqz	a5,800068fe <clear+0x34>
      ws[i].p->wl_slot = -1;
    80006916:	1957a823          	sw	s5,400(a5)
      wakeup(&ws[i]);
    8000691a:	8526                	mv	a0,s1
    8000691c:	e80fb0ef          	jal	80001f9c <wakeup>
    80006920:	bff9                	j	800068fe <clear+0x34>
  }
  loaded = 0;
    80006922:	00007797          	auipc	a5,0x7
    80006926:	d407a123          	sw	zero,-702(a5) # 8000d664 <loaded>
  started = 0;
    8000692a:	00007797          	auipc	a5,0x7
    8000692e:	d207ab23          	sw	zero,-714(a5) # 8000d660 <started>
  controller = 0;
    80006932:	00007797          	auipc	a5,0x7
    80006936:	d207b323          	sd	zero,-730(a5) # 8000d658 <controller>
  cur = 0;
  nslots = 0;
    8000693a:	00007797          	auipc	a5,0x7
    8000693e:	d007ab23          	sw	zero,-746(a5) # 8000d650 <nslots>
}
    80006942:	70e2                	ld	ra,56(sp)
    80006944:	7442                	ld	s0,48(sp)
    80006946:	74a2                	ld	s1,40(sp)
    80006948:	7902                	ld	s2,32(sp)
    8000694a:	69e2                	ld	s3,24(sp)
    8000694c:	6a42                	ld	s4,16(sp)
    8000694e:	6aa2                	ld	s5,8(sp)
    80006950:	6121                	addi	sp,sp,64
    80006952:	8082                	ret
  loaded = 0;
    80006954:	00007797          	auipc	a5,0x7
    80006958:	d007a823          	sw	zero,-752(a5) # 8000d664 <loaded>
  started = 0;
    8000695c:	00007797          	auipc	a5,0x7
    80006960:	d007a223          	sw	zero,-764(a5) # 8000d660 <started>
  controller = 0;
    80006964:	00007797          	auipc	a5,0x7
    80006968:	ce07ba23          	sd	zero,-780(a5) # 8000d658 <controller>
  nslots = 0;
    8000696c:	00007797          	auipc	a5,0x7
    80006970:	ce07a223          	sw	zero,-796(a5) # 8000d650 <nslots>
    80006974:	8082                	ret

0000000080006976 <events>:
  for (i = 0; i < nslots; i++) {
    80006976:	00007797          	auipc	a5,0x7
    8000697a:	cda7a783          	lw	a5,-806(a5) # 8000d650 <nslots>
    8000697e:	10f05f63          	blez	a5,80006a9c <events+0x126>
{
    80006982:	7159                	addi	sp,sp,-112
    80006984:	f486                	sd	ra,104(sp)
    80006986:	f0a2                	sd	s0,96(sp)
    80006988:	eca6                	sd	s1,88(sp)
    8000698a:	e8ca                	sd	s2,80(sp)
    8000698c:	e4ce                	sd	s3,72(sp)
    8000698e:	e0d2                	sd	s4,64(sp)
    80006990:	fc56                	sd	s5,56(sp)
    80006992:	f85a                	sd	s6,48(sp)
    80006994:	f45e                	sd	s7,40(sp)
    80006996:	f062                	sd	s8,32(sp)
    80006998:	ec66                	sd	s9,24(sp)
    8000699a:	e86a                	sd	s10,16(sp)
    8000699c:	e46e                	sd	s11,8(sp)
    8000699e:	1880                	addi	s0,sp,112
    800069a0:	8a2a                	mv	s4,a0
    800069a2:	00021917          	auipc	s2,0x21
    800069a6:	c1690913          	addi	s2,s2,-1002 # 800275b8 <ws>
  int i, nbatch = 0, arrived = 0, finished = 0;
    800069aa:	4d01                	li	s10,0
    800069ac:	4c01                	li	s8,0
    800069ae:	4a81                	li	s5,0
  for (i = 0; i < nslots; i++) {
    800069b0:	4981                	li	s3,0
    } else if (s->phase == WL_IO && now >= s->io_until) {
    800069b2:	4c89                	li	s9,2
  s->phase = WL_CPU;
    800069b4:	4b85                	li	s7,1
      if (s->phase == WL_DONE)
    800069b6:	4d8d                	li	s11,3
  for (i = 0; i < nslots; i++) {
    800069b8:	00007b17          	auipc	s6,0x7
    800069bc:	c98b0b13          	addi	s6,s6,-872 # 8000d650 <nslots>
    800069c0:	a885                	j	80006a30 <events+0xba>
      s->st.arrival = now - start_tick;
    800069c2:	00007797          	auipc	a5,0x7
    800069c6:	c8678793          	addi	a5,a5,-890 # 8000d648 <start_tick>
    800069ca:	439c                	lw	a5,0(a5)
    800069cc:	40fa07bb          	subw	a5,s4,a5
    800069d0:	04f92a23          	sw	a5,84(s2)
  s->phase = WL_CPU;
    800069d4:	03792023          	sw	s7,32(s2)
  s->remaining = s->def.cpu_burst * TICK_UNITS;
    800069d8:	00892783          	lw	a5,8(s2)
    800069dc:	06400713          	li	a4,100
    800069e0:	02f707bb          	mulw	a5,a4,a5
    800069e4:	02f92823          	sw	a5,48(s2)
  s->ready_at = now;
    800069e8:	03492e23          	sw	s4,60(s2)
  wakeup(s);
    800069ec:	854a                	mv	a0,s2
    800069ee:	daefb0ef          	jal	80001f9c <wakeup>
}
    800069f2:	a0b9                	j	80006a40 <events+0xca>
    } else if (s->phase == WL_IO && now >= s->io_until) {
    800069f4:	05979663          	bne	a5,s9,80006a40 <events+0xca>
    800069f8:	02892783          	lw	a5,40(s2)
    800069fc:	04fa4263          	blt	s4,a5,80006a40 <events+0xca>
  s->phase = WL_CPU;
    80006a00:	4785                	li	a5,1
    80006a02:	02f92023          	sw	a5,32(s2)
  s->remaining = s->def.cpu_burst * TICK_UNITS;
    80006a06:	00892703          	lw	a4,8(s2)
    80006a0a:	06400793          	li	a5,100
    80006a0e:	02e787bb          	mulw	a5,a5,a4
    80006a12:	02f92823          	sw	a5,48(s2)
  s->ready_at = now;
    80006a16:	03492e23          	sw	s4,60(s2)
  wakeup(s);
    80006a1a:	854a                	mv	a0,s2
    80006a1c:	d80fb0ef          	jal	80001f9c <wakeup>
}
    80006a20:	a005                	j	80006a40 <events+0xca>
  for (i = 0; i < nslots; i++) {
    80006a22:	2985                	addiw	s3,s3,1
    80006a24:	0a090913          	addi	s2,s2,160
    80006a28:	000b2783          	lw	a5,0(s6)
    80006a2c:	02f9d763          	bge	s3,a5,80006a5a <events+0xe4>
    struct wl_state *s = &ws[i];
    80006a30:	84ca                	mv	s1,s2
    if (s->phase == WL_WAIT && now >= s->arrive_at) {
    80006a32:	02092783          	lw	a5,32(s2)
    80006a36:	ffdd                	bnez	a5,800069f4 <events+0x7e>
    80006a38:	02492783          	lw	a5,36(s2)
    80006a3c:	f8fa53e3          	bge	s4,a5,800069c2 <events+0x4c>
  return s->def.io_burst == 0 && s->def.repeats == 1;
    80006a40:	44dc                	lw	a5,12(s1)
    80006a42:	f3e5                	bnez	a5,80006a22 <events+0xac>
    if (isbatch(s)) {
    80006a44:	489c                	lw	a5,16(s1)
    80006a46:	fd779ee3          	bne	a5,s7,80006a22 <events+0xac>
      nbatch++;
    80006a4a:	2a85                	addiw	s5,s5,1
      if (s->phase != WL_WAIT)
    80006a4c:	509c                	lw	a5,32(s1)
    80006a4e:	dbf1                	beqz	a5,80006a22 <events+0xac>
        arrived++;
    80006a50:	2c05                	addiw	s8,s8,1
      if (s->phase == WL_DONE)
    80006a52:	fdb798e3          	bne	a5,s11,80006a22 <events+0xac>
        finished++;
    80006a56:	2d05                	addiw	s10,s10,1
    80006a58:	b7e9                	j	80006a22 <events+0xac>
  if (fair_start < 0 && nbatch > 1 && arrived == nbatch && finished == 0)
    80006a5a:	00007797          	auipc	a5,0x7
    80006a5e:	bd27a783          	lw	a5,-1070(a5) # 8000d62c <fair_start>
    80006a62:	0207c163          	bltz	a5,80006a84 <events+0x10e>
}
    80006a66:	70a6                	ld	ra,104(sp)
    80006a68:	7406                	ld	s0,96(sp)
    80006a6a:	64e6                	ld	s1,88(sp)
    80006a6c:	6946                	ld	s2,80(sp)
    80006a6e:	69a6                	ld	s3,72(sp)
    80006a70:	6a06                	ld	s4,64(sp)
    80006a72:	7ae2                	ld	s5,56(sp)
    80006a74:	7b42                	ld	s6,48(sp)
    80006a76:	7ba2                	ld	s7,40(sp)
    80006a78:	7c02                	ld	s8,32(sp)
    80006a7a:	6ce2                	ld	s9,24(sp)
    80006a7c:	6d42                	ld	s10,16(sp)
    80006a7e:	6da2                	ld	s11,8(sp)
    80006a80:	6165                	addi	sp,sp,112
    80006a82:	8082                	ret
  if (fair_start < 0 && nbatch > 1 && arrived == nbatch && finished == 0)
    80006a84:	4785                	li	a5,1
    80006a86:	ff57d0e3          	bge	a5,s5,80006a66 <events+0xf0>
    80006a8a:	fd8a9ee3          	bne	s5,s8,80006a66 <events+0xf0>
    80006a8e:	fc0d1ce3          	bnez	s10,80006a66 <events+0xf0>
    fair_start = now;
    80006a92:	00007797          	auipc	a5,0x7
    80006a96:	b947ad23          	sw	s4,-1126(a5) # 8000d62c <fair_start>
}
    80006a9a:	b7f1                	j	80006a66 <events+0xf0>
    80006a9c:	8082                	ret

0000000080006a9e <wlinit>:
{
    80006a9e:	1141                	addi	sp,sp,-16
    80006aa0:	e406                	sd	ra,8(sp)
    80006aa2:	e022                	sd	s0,0(sp)
    80006aa4:	0800                	addi	s0,sp,16
  initlock(&wl_lock, "workload");
    80006aa6:	00003597          	auipc	a1,0x3
    80006aaa:	eaa58593          	addi	a1,a1,-342 # 80009950 <etext+0x950>
    80006aae:	00021517          	auipc	a0,0x21
    80006ab2:	af250513          	addi	a0,a0,-1294 # 800275a0 <wl_lock>
    80006ab6:	862fa0ef          	jal	80000b18 <initlock>
}
    80006aba:	60a2                	ld	ra,8(sp)
    80006abc:	6402                	ld	s0,0(sp)
    80006abe:	0141                	addi	sp,sp,16
    80006ac0:	8082                	ret

0000000080006ac2 <wl_clock>:
{
    80006ac2:	1101                	addi	sp,sp,-32
    80006ac4:	ec06                	sd	ra,24(sp)
    80006ac6:	e822                	sd	s0,16(sp)
    80006ac8:	e426                	sd	s1,8(sp)
    80006aca:	e04a                	sd	s2,0(sp)
    80006acc:	1000                	addi	s0,sp,32
    80006ace:	84aa                	mv	s1,a0
  int now = ticks;
    80006ad0:	00007917          	auipc	s2,0x7
    80006ad4:	b4892903          	lw	s2,-1208(s2) # 8000d618 <ticks>
  acquire(&wl_lock);
    80006ad8:	00021517          	auipc	a0,0x21
    80006adc:	ac850513          	addi	a0,a0,-1336 # 800275a0 <wl_lock>
    80006ae0:	8aefa0ef          	jal	80000b8e <acquire>
  if (!loaded || !started || end_tick >= 0) {
    80006ae4:	00007797          	auipc	a5,0x7
    80006ae8:	b807a783          	lw	a5,-1152(a5) # 8000d664 <loaded>
    80006aec:	12078363          	beqz	a5,80006c12 <wl_clock+0x150>
    80006af0:	00007797          	auipc	a5,0x7
    80006af4:	b707a783          	lw	a5,-1168(a5) # 8000d660 <started>
    80006af8:	10078d63          	beqz	a5,80006c12 <wl_clock+0x150>
    80006afc:	00007797          	auipc	a5,0x7
    80006b00:	b407a783          	lw	a5,-1216(a5) # 8000d63c <end_tick>
    80006b04:	1007d763          	bgez	a5,80006c12 <wl_clock+0x150>
  if (p == 0) {
    80006b08:	12048163          	beqz	s1,80006c2a <wl_clock+0x168>
  } else if (p->wl_slot < 0) {
    80006b0c:	1904a783          	lw	a5,400(s1)
    80006b10:	1207ce63          	bltz	a5,80006c4c <wl_clock+0x18a>
    busy++;
    80006b14:	00007697          	auipc	a3,0x7
    80006b18:	b2468693          	addi	a3,a3,-1244 # 8000d638 <busy>
    80006b1c:	4298                	lw	a4,0(a3)
    80006b1e:	2705                	addiw	a4,a4,1
    80006b20:	c298                	sw	a4,0(a3)
    if (s->phase == WL_CPU && !s->burst_done) {
    80006b22:	00279713          	slli	a4,a5,0x2
    80006b26:	973e                	add	a4,a4,a5
    80006b28:	0716                	slli	a4,a4,0x5
    80006b2a:	00021697          	auipc	a3,0x21
    80006b2e:	a8e68693          	addi	a3,a3,-1394 # 800275b8 <ws>
    80006b32:	9736                	add	a4,a4,a3
    80006b34:	5314                	lw	a3,32(a4)
    80006b36:	4705                	li	a4,1
    80006b38:	10e69063          	bne	a3,a4,80006c38 <wl_clock+0x176>
    80006b3c:	00279713          	slli	a4,a5,0x2
    80006b40:	973e                	add	a4,a4,a5
    80006b42:	0716                	slli	a4,a4,0x5
    80006b44:	00021697          	auipc	a3,0x21
    80006b48:	a7468693          	addi	a3,a3,-1420 # 800275b8 <ws>
    80006b4c:	9736                	add	a4,a4,a3
    80006b4e:	5f18                	lw	a4,56(a4)
    80006b50:	e765                	bnez	a4,80006c38 <wl_clock+0x176>
      int d = s->debt < units ? s->debt : units;
    80006b52:	00279713          	slli	a4,a5,0x2
    80006b56:	973e                	add	a4,a4,a5
    80006b58:	0716                	slli	a4,a4,0x5
    80006b5a:	9736                	add	a4,a4,a3
    80006b5c:	5b54                	lw	a3,52(a4)
    80006b5e:	85b6                	mv	a1,a3
    80006b60:	06400713          	li	a4,100
    80006b64:	00d75463          	bge	a4,a3,80006b6c <wl_clock+0xaa>
    80006b68:	06400593          	li	a1,100
      s->debt -= d;
    80006b6c:	00279613          	slli	a2,a5,0x2
    80006b70:	963e                	add	a2,a2,a5
    80006b72:	0616                	slli	a2,a2,0x5
    80006b74:	00021717          	auipc	a4,0x21
    80006b78:	a4470713          	addi	a4,a4,-1468 # 800275b8 <ws>
    80006b7c:	9732                	add	a4,a4,a2
    80006b7e:	9e8d                	subw	a3,a3,a1
    80006b80:	db54                	sw	a3,52(a4)
      s->st.ovh_units += d;
    80006b82:	5374                	lw	a3,100(a4)
    80006b84:	9ead                	addw	a3,a3,a1
    80006b86:	d374                	sw	a3,100(a4)
      if (units > s->remaining)
    80006b88:	5b14                	lw	a3,48(a4)
      units -= d;
    80006b8a:	06400713          	li	a4,100
    80006b8e:	9f0d                	subw	a4,a4,a1
      if (units > s->remaining)
    80006b90:	85ba                	mv	a1,a4
    80006b92:	2701                	sext.w	a4,a4
    80006b94:	00e6d363          	bge	a3,a4,80006b9a <wl_clock+0xd8>
    80006b98:	85b6                	mv	a1,a3
    80006b9a:	0005851b          	sext.w	a0,a1
      s->st.cpu_units += units;
    80006b9e:	00279613          	slli	a2,a5,0x2
    80006ba2:	963e                	add	a2,a2,a5
    80006ba4:	0616                	slli	a2,a2,0x5
    80006ba6:	00021717          	auipc	a4,0x21
    80006baa:	a1270713          	addi	a4,a4,-1518 # 800275b8 <ws>
    80006bae:	9732                	add	a4,a4,a2
    80006bb0:	5330                	lw	a2,96(a4)
    80006bb2:	9e2d                	addw	a2,a2,a1
    80006bb4:	d330                	sw	a2,96(a4)
      s->remaining -= units;
    80006bb6:	9e8d                	subw	a3,a3,a1
    80006bb8:	0006861b          	sext.w	a2,a3
    80006bbc:	db14                	sw	a3,48(a4)
  return s->def.io_burst == 0 && s->def.repeats == 1;
    80006bbe:	4758                	lw	a4,12(a4)
    80006bc0:	eb1d                	bnez	a4,80006bf6 <wl_clock+0x134>
    80006bc2:	00279713          	slli	a4,a5,0x2
    80006bc6:	973e                	add	a4,a4,a5
    80006bc8:	0716                	slli	a4,a4,0x5
    80006bca:	00021697          	auipc	a3,0x21
    80006bce:	9ee68693          	addi	a3,a3,-1554 # 800275b8 <ws>
    80006bd2:	9736                	add	a4,a4,a3
      if (isbatch(s) && fair_start >= 0 && fair_end < 0)
    80006bd4:	4b14                	lw	a3,16(a4)
    80006bd6:	4705                	li	a4,1
    80006bd8:	00e69f63          	bne	a3,a4,80006bf6 <wl_clock+0x134>
    80006bdc:	00007717          	auipc	a4,0x7
    80006be0:	a5072703          	lw	a4,-1456(a4) # 8000d62c <fair_start>
    80006be4:	fff74713          	not	a4,a4
    80006be8:	00007697          	auipc	a3,0x7
    80006bec:	a406a683          	lw	a3,-1472(a3) # 8000d628 <fair_end>
    80006bf0:	8f75                	and	a4,a4,a3
    80006bf2:	06074563          	bltz	a4,80006c5c <wl_clock+0x19a>
      if (s->remaining <= 0)
    80006bf6:	04c04163          	bgtz	a2,80006c38 <wl_clock+0x176>
        s->burst_done = 1;
    80006bfa:	00279713          	slli	a4,a5,0x2
    80006bfe:	97ba                	add	a5,a5,a4
    80006c00:	0796                	slli	a5,a5,0x5
    80006c02:	00021717          	auipc	a4,0x21
    80006c06:	9b670713          	addi	a4,a4,-1610 # 800275b8 <ws>
    80006c0a:	97ba                	add	a5,a5,a4
    80006c0c:	4705                	li	a4,1
    80006c0e:	df98                	sw	a4,56(a5)
    80006c10:	a025                	j	80006c38 <wl_clock+0x176>
    release(&wl_lock);
    80006c12:	00021517          	auipc	a0,0x21
    80006c16:	98e50513          	addi	a0,a0,-1650 # 800275a0 <wl_lock>
    80006c1a:	800fa0ef          	jal	80000c1a <release>
}
    80006c1e:	60e2                	ld	ra,24(sp)
    80006c20:	6442                	ld	s0,16(sp)
    80006c22:	64a2                	ld	s1,8(sp)
    80006c24:	6902                	ld	s2,0(sp)
    80006c26:	6105                	addi	sp,sp,32
    80006c28:	8082                	ret
    idle++;
    80006c2a:	00007717          	auipc	a4,0x7
    80006c2e:	a0a70713          	addi	a4,a4,-1526 # 8000d634 <idle>
    80006c32:	431c                	lw	a5,0(a4)
    80006c34:	2785                	addiw	a5,a5,1
    80006c36:	c31c                	sw	a5,0(a4)
  events(now);
    80006c38:	854a                	mv	a0,s2
    80006c3a:	d3dff0ef          	jal	80006976 <events>
  release(&wl_lock);
    80006c3e:	00021517          	auipc	a0,0x21
    80006c42:	96250513          	addi	a0,a0,-1694 # 800275a0 <wl_lock>
    80006c46:	fd5f90ef          	jal	80000c1a <release>
    80006c4a:	bfd1                	j	80006c1e <wl_clock+0x15c>
    other++;
    80006c4c:	00007717          	auipc	a4,0x7
    80006c50:	9e470713          	addi	a4,a4,-1564 # 8000d630 <other>
    80006c54:	431c                	lw	a5,0(a4)
    80006c56:	2785                	addiw	a5,a5,1
    80006c58:	c31c                	sw	a5,0(a4)
    80006c5a:	bff9                	j	80006c38 <wl_clock+0x176>
        s->st.fair_units += units;
    80006c5c:	00279713          	slli	a4,a5,0x2
    80006c60:	973e                	add	a4,a4,a5
    80006c62:	0716                	slli	a4,a4,0x5
    80006c64:	00021697          	auipc	a3,0x21
    80006c68:	95468693          	addi	a3,a3,-1708 # 800275b8 <ws>
    80006c6c:	9736                	add	a4,a4,a3
    80006c6e:	5734                	lw	a3,104(a4)
    80006c70:	9ea9                	addw	a3,a3,a0
    80006c72:	d734                	sw	a3,104(a4)
    80006c74:	b749                	j	80006bf6 <wl_clock+0x134>

0000000080006c76 <wl_dispatch>:
{
    80006c76:	1141                	addi	sp,sp,-16
    80006c78:	e422                	sd	s0,8(sp)
    80006c7a:	0800                	addi	s0,sp,16
  int switched = (p != last_proc);
    80006c7c:	00007797          	auipc	a5,0x7
    80006c80:	9c478793          	addi	a5,a5,-1596 # 8000d640 <last_proc>
    80006c84:	6390                	ld	a2,0(a5)
  last_proc = p;
    80006c86:	e388                	sd	a0,0(a5)
  if (!loaded || !started || p->wl_slot < 0)
    80006c88:	00007797          	auipc	a5,0x7
    80006c8c:	9dc7a783          	lw	a5,-1572(a5) # 8000d664 <loaded>
    80006c90:	cbe1                	beqz	a5,80006d60 <wl_dispatch+0xea>
    80006c92:	00007797          	auipc	a5,0x7
    80006c96:	9ce7a783          	lw	a5,-1586(a5) # 8000d660 <started>
    80006c9a:	c3f9                	beqz	a5,80006d60 <wl_dispatch+0xea>
    80006c9c:	19052783          	lw	a5,400(a0)
    80006ca0:	0c07c063          	bltz	a5,80006d60 <wl_dispatch+0xea>
  s->st.dispatches++;
    80006ca4:	00279713          	slli	a4,a5,0x2
    80006ca8:	973e                	add	a4,a4,a5
    80006caa:	0716                	slli	a4,a4,0x5
    80006cac:	00021697          	auipc	a3,0x21
    80006cb0:	90c68693          	addi	a3,a3,-1780 # 800275b8 <ws>
    80006cb4:	9736                	add	a4,a4,a3
    80006cb6:	5774                	lw	a3,108(a4)
    80006cb8:	2685                	addiw	a3,a3,1
    80006cba:	d774                	sw	a3,108(a4)
  if (switched && s->phase == WL_CPU)
    80006cbc:	00a60f63          	beq	a2,a0,80006cda <wl_dispatch+0x64>
    80006cc0:	00279713          	slli	a4,a5,0x2
    80006cc4:	973e                	add	a4,a4,a5
    80006cc6:	0716                	slli	a4,a4,0x5
    80006cc8:	00021697          	auipc	a3,0x21
    80006ccc:	8f068693          	addi	a3,a3,-1808 # 800275b8 <ws>
    80006cd0:	9736                	add	a4,a4,a3
    80006cd2:	5314                	lw	a3,32(a4)
    80006cd4:	4705                	li	a4,1
    80006cd6:	08e68863          	beq	a3,a4,80006d66 <wl_dispatch+0xf0>
  if (s->ready_at >= 0) {
    80006cda:	00279713          	slli	a4,a5,0x2
    80006cde:	973e                	add	a4,a4,a5
    80006ce0:	0716                	slli	a4,a4,0x5
    80006ce2:	00021697          	auipc	a3,0x21
    80006ce6:	8d668693          	addi	a3,a3,-1834 # 800275b8 <ws>
    80006cea:	9736                	add	a4,a4,a3
    80006cec:	5f58                	lw	a4,60(a4)
    80006cee:	06074963          	bltz	a4,80006d60 <wl_dispatch+0xea>
    int lat = ticks - s->ready_at;
    80006cf2:	00007597          	auipc	a1,0x7
    80006cf6:	9265a583          	lw	a1,-1754(a1) # 8000d618 <ticks>
    80006cfa:	40e5863b          	subw	a2,a1,a4
    80006cfe:	0006051b          	sext.w	a0,a2
    if (s->st.first_run < 0)
    80006d02:	00279713          	slli	a4,a5,0x2
    80006d06:	973e                	add	a4,a4,a5
    80006d08:	0716                	slli	a4,a4,0x5
    80006d0a:	9736                	add	a4,a4,a3
    80006d0c:	4f38                	lw	a4,88(a4)
    80006d0e:	06074963          	bltz	a4,80006d80 <wl_dispatch+0x10a>
    s->st.resp_count++;
    80006d12:	00279693          	slli	a3,a5,0x2
    80006d16:	96be                	add	a3,a3,a5
    80006d18:	0696                	slli	a3,a3,0x5
    80006d1a:	00021717          	auipc	a4,0x21
    80006d1e:	89e70713          	addi	a4,a4,-1890 # 800275b8 <ws>
    80006d22:	9736                	add	a4,a4,a3
    80006d24:	5b34                	lw	a3,112(a4)
    80006d26:	2685                	addiw	a3,a3,1
    80006d28:	db34                	sw	a3,112(a4)
    s->st.resp_sum += lat;
    80006d2a:	5b74                	lw	a3,116(a4)
    80006d2c:	9eb1                	addw	a3,a3,a2
    80006d2e:	db74                	sw	a3,116(a4)
    if (lat > s->st.resp_max)
    80006d30:	5f38                	lw	a4,120(a4)
    80006d32:	00a75c63          	bge	a4,a0,80006d4a <wl_dispatch+0xd4>
      s->st.resp_max = lat;
    80006d36:	00279713          	slli	a4,a5,0x2
    80006d3a:	973e                	add	a4,a4,a5
    80006d3c:	0716                	slli	a4,a4,0x5
    80006d3e:	00021697          	auipc	a3,0x21
    80006d42:	87a68693          	addi	a3,a3,-1926 # 800275b8 <ws>
    80006d46:	9736                	add	a4,a4,a3
    80006d48:	df30                	sw	a2,120(a4)
    s->ready_at = -1;
    80006d4a:	00279713          	slli	a4,a5,0x2
    80006d4e:	97ba                	add	a5,a5,a4
    80006d50:	0796                	slli	a5,a5,0x5
    80006d52:	00021717          	auipc	a4,0x21
    80006d56:	86670713          	addi	a4,a4,-1946 # 800275b8 <ws>
    80006d5a:	97ba                	add	a5,a5,a4
    80006d5c:	577d                	li	a4,-1
    80006d5e:	dfd8                	sw	a4,60(a5)
}
    80006d60:	6422                	ld	s0,8(sp)
    80006d62:	0141                	addi	sp,sp,16
    80006d64:	8082                	ret
    s->debt += SWITCH_COST;
    80006d66:	00279713          	slli	a4,a5,0x2
    80006d6a:	973e                	add	a4,a4,a5
    80006d6c:	0716                	slli	a4,a4,0x5
    80006d6e:	00021697          	auipc	a3,0x21
    80006d72:	84a68693          	addi	a3,a3,-1974 # 800275b8 <ws>
    80006d76:	9736                	add	a4,a4,a3
    80006d78:	5b54                	lw	a3,52(a4)
    80006d7a:	26d1                	addiw	a3,a3,20
    80006d7c:	db54                	sw	a3,52(a4)
    80006d7e:	bfb1                	j	80006cda <wl_dispatch+0x64>
      s->st.first_run = ticks - start_tick;
    80006d80:	00279713          	slli	a4,a5,0x2
    80006d84:	973e                	add	a4,a4,a5
    80006d86:	0716                	slli	a4,a4,0x5
    80006d88:	9736                	add	a4,a4,a3
    80006d8a:	00007697          	auipc	a3,0x7
    80006d8e:	8be6a683          	lw	a3,-1858(a3) # 8000d648 <start_tick>
    80006d92:	9d95                	subw	a1,a1,a3
    80006d94:	cf2c                	sw	a1,88(a4)
    80006d96:	bfb5                	j	80006d12 <wl_dispatch+0x9c>

0000000080006d98 <wl_burst_done>:
{
    80006d98:	1141                	addi	sp,sp,-16
    80006d9a:	e422                	sd	s0,8(sp)
    80006d9c:	0800                	addi	s0,sp,16
    80006d9e:	87aa                	mv	a5,a0
  return loaded && p->wl_slot >= 0 && ws[p->wl_slot].burst_done;
    80006da0:	00007517          	auipc	a0,0x7
    80006da4:	8c452503          	lw	a0,-1852(a0) # 8000d664 <loaded>
    80006da8:	c115                	beqz	a0,80006dcc <wl_burst_done+0x34>
    80006daa:	1907a703          	lw	a4,400(a5)
    80006dae:	4501                	li	a0,0
    80006db0:	00074e63          	bltz	a4,80006dcc <wl_burst_done+0x34>
    80006db4:	00271793          	slli	a5,a4,0x2
    80006db8:	97ba                	add	a5,a5,a4
    80006dba:	0796                	slli	a5,a5,0x5
    80006dbc:	00020717          	auipc	a4,0x20
    80006dc0:	7fc70713          	addi	a4,a4,2044 # 800275b8 <ws>
    80006dc4:	97ba                	add	a5,a5,a4
    80006dc6:	5f88                	lw	a0,56(a5)
    80006dc8:	00a03533          	snez	a0,a0
}
    80006dcc:	6422                	ld	s0,8(sp)
    80006dce:	0141                	addi	sp,sp,16
    80006dd0:	8082                	ret

0000000080006dd2 <wl_loaded>:
{
    80006dd2:	1141                	addi	sp,sp,-16
    80006dd4:	e422                	sd	s0,8(sp)
    80006dd6:	0800                	addi	s0,sp,16
}
    80006dd8:	00007517          	auipc	a0,0x7
    80006ddc:	88c52503          	lw	a0,-1908(a0) # 8000d664 <loaded>
    80006de0:	6422                	ld	s0,8(sp)
    80006de2:	0141                	addi	sp,sp,16
    80006de4:	8082                	ret

0000000080006de6 <wl_load>:

int
wl_load(int id)
{
    80006de6:	715d                	addi	sp,sp,-80
    80006de8:	e486                	sd	ra,72(sp)
    80006dea:	e0a2                	sd	s0,64(sp)
    80006dec:	e062                	sd	s8,0(sp)
    80006dee:	0880                	addi	s0,sp,80
  int i;
  struct wl_def *d = 0;

  for (i = 0; i < nworkloads; i++)
    80006df0:	00006697          	auipc	a3,0x6
    80006df4:	1086a683          	lw	a3,264(a3) # 8000cef8 <nworkloads>
    80006df8:	18d05763          	blez	a3,80006f86 <wl_load+0x1a0>
    80006dfc:	fc26                	sd	s1,56(sp)
    80006dfe:	f84a                	sd	s2,48(sp)
    80006e00:	00006797          	auipc	a5,0x6
    80006e04:	11078793          	addi	a5,a5,272 # 8000cf10 <workloads>
    80006e08:	15800713          	li	a4,344
    80006e0c:	02e686b3          	mul	a3,a3,a4
    80006e10:	96be                	add	a3,a3,a5
  struct wl_def *d = 0;
    80006e12:	4901                	li	s2,0
    80006e14:	a029                	j	80006e1e <wl_load+0x38>
  for (i = 0; i < nworkloads; i++)
    80006e16:	15878793          	addi	a5,a5,344
    80006e1a:	00d78763          	beq	a5,a3,80006e28 <wl_load+0x42>
    if (workloads[i].id == id)
    80006e1e:	4398                	lw	a4,0(a5)
    80006e20:	fea71be3          	bne	a4,a0,80006e16 <wl_load+0x30>
      d = &workloads[i];
    80006e24:	893e                	mv	s2,a5
    80006e26:	bfc5                	j	80006e16 <wl_load+0x30>

  acquire(&wl_lock);
    80006e28:	00020517          	auipc	a0,0x20
    80006e2c:	77850513          	addi	a0,a0,1912 # 800275a0 <wl_lock>
    80006e30:	d5ff90ef          	jal	80000b8e <acquire>
  if (d == 0 || loaded || d->nslots < 1 || d->nslots > WL_MAXSLOTS) {
    80006e34:	08090f63          	beqz	s2,80006ed2 <wl_load+0xec>
    80006e38:	00007c17          	auipc	s8,0x7
    80006e3c:	82cc2c03          	lw	s8,-2004(s8) # 8000d664 <loaded>
    80006e40:	080c1c63          	bnez	s8,80006ed8 <wl_load+0xf2>
    80006e44:	01092783          	lw	a5,16(s2)
    80006e48:	fff7869b          	addiw	a3,a5,-1
    80006e4c:	473d                	li	a4,15
    80006e4e:	06d76f63          	bltu	a4,a3,80006ecc <wl_load+0xe6>
    release(&wl_lock);
    return -1;
  }
  cur = d;
  nslots = d->nslots;
    80006e52:	00006497          	auipc	s1,0x6
    80006e56:	7fe48493          	addi	s1,s1,2046 # 8000d650 <nslots>
    80006e5a:	c09c                	sw	a5,0(s1)
  ndone = 0;
    80006e5c:	00006797          	auipc	a5,0x6
    80006e60:	7e07a823          	sw	zero,2032(a5) # 8000d64c <ndone>
  controller = myproc();
    80006e64:	a35fa0ef          	jal	80001898 <myproc>
    80006e68:	00006797          	auipc	a5,0x6
    80006e6c:	7ea7b823          	sd	a0,2032(a5) # 8000d658 <controller>
  end_tick = fair_start = fair_end = -1;
    80006e70:	57fd                	li	a5,-1
    80006e72:	00006717          	auipc	a4,0x6
    80006e76:	7af72b23          	sw	a5,1974(a4) # 8000d628 <fair_end>
    80006e7a:	00006717          	auipc	a4,0x6
    80006e7e:	7af72923          	sw	a5,1970(a4) # 8000d62c <fair_start>
    80006e82:	00006717          	auipc	a4,0x6
    80006e86:	7af72d23          	sw	a5,1978(a4) # 8000d63c <end_tick>
  busy = idle = other = 0;
    80006e8a:	00006797          	auipc	a5,0x6
    80006e8e:	7a07a323          	sw	zero,1958(a5) # 8000d630 <other>
    80006e92:	00006797          	auipc	a5,0x6
    80006e96:	7a07a123          	sw	zero,1954(a5) # 8000d634 <idle>
    80006e9a:	00006797          	auipc	a5,0x6
    80006e9e:	7807af23          	sw	zero,1950(a5) # 8000d638 <busy>
  for (i = 0; i < nslots; i++) {
    80006ea2:	409c                	lw	a5,0(s1)
    80006ea4:	0af05e63          	blez	a5,80006f60 <wl_load+0x17a>
    80006ea8:	f44e                	sd	s3,40(sp)
    80006eaa:	f052                	sd	s4,32(sp)
    80006eac:	ec56                	sd	s5,24(sp)
    80006eae:	e85a                	sd	s6,16(sp)
    80006eb0:	e45e                	sd	s7,8(sp)
    80006eb2:	00020497          	auipc	s1,0x20
    80006eb6:	70648493          	addi	s1,s1,1798 # 800275b8 <ws>
    80006eba:	0951                	addi	s2,s2,20
    80006ebc:	8ae2                	mv	s5,s8
    struct wl_state *s = &ws[i];
    memset(s, 0, sizeof(*s));
    s->def = d->slots[i];
    s->phase = WL_WAIT;
    s->bursts_left = s->def.repeats;
    s->ready_at = -1;
    80006ebe:	5a7d                	li	s4,-1
  return s->def.io_burst == 0 && s->def.repeats == 1;
    80006ec0:	8be2                	mv	s7,s8
  for (i = 0; i < nslots; i++) {
    80006ec2:	00006b17          	auipc	s6,0x6
    80006ec6:	78eb0b13          	addi	s6,s6,1934 # 8000d650 <nslots>
    80006eca:	a089                	j	80006f0c <wl_load+0x126>
    80006ecc:	74e2                	ld	s1,56(sp)
    80006ece:	7942                	ld	s2,48(sp)
    80006ed0:	a031                	j	80006edc <wl_load+0xf6>
    80006ed2:	74e2                	ld	s1,56(sp)
    80006ed4:	7942                	ld	s2,48(sp)
    80006ed6:	a019                	j	80006edc <wl_load+0xf6>
    80006ed8:	74e2                	ld	s1,56(sp)
    80006eda:	7942                	ld	s2,48(sp)
    release(&wl_lock);
    80006edc:	00020517          	auipc	a0,0x20
    80006ee0:	6c450513          	addi	a0,a0,1732 # 800275a0 <wl_lock>
    80006ee4:	d37f90ef          	jal	80000c1a <release>
    return -1;
    80006ee8:	5c7d                	li	s8,-1
    80006eea:	a841                	j	80006f7a <wl_load+0x194>
    s->st.nice = s->def.nice;
    s->st.cpu_burst = s->def.cpu_burst;
    s->st.io_burst = s->def.io_burst;
    s->st.repeats = s->def.repeats;
    s->st.batch = isbatch(s);
    80006eec:	04d9a823          	sw	a3,80(s3)
    s->st.arrival = s->st.first_run = s->st.completion = -1;
    80006ef0:	0549ae23          	sw	s4,92(s3)
    80006ef4:	0549ac23          	sw	s4,88(s3)
    80006ef8:	0549aa23          	sw	s4,84(s3)
  for (i = 0; i < nslots; i++) {
    80006efc:	2a85                	addiw	s5,s5,1
    80006efe:	0a048493          	addi	s1,s1,160
    80006f02:	0951                	addi	s2,s2,20
    80006f04:	000b2783          	lw	a5,0(s6)
    80006f08:	04fad763          	bge	s5,a5,80006f56 <wl_load+0x170>
    struct wl_state *s = &ws[i];
    80006f0c:	89a6                	mv	s3,s1
    memset(s, 0, sizeof(*s));
    80006f0e:	0a000613          	li	a2,160
    80006f12:	4581                	li	a1,0
    80006f14:	8526                	mv	a0,s1
    80006f16:	d3df90ef          	jal	80000c52 <memset>
    s->def = d->slots[i];
    80006f1a:	00092583          	lw	a1,0(s2)
    80006f1e:	00492603          	lw	a2,4(s2)
    80006f22:	00892683          	lw	a3,8(s2)
    80006f26:	00c92703          	lw	a4,12(s2)
    80006f2a:	01092783          	lw	a5,16(s2)
    80006f2e:	c08c                	sw	a1,0(s1)
    80006f30:	c0d0                	sw	a2,4(s1)
    80006f32:	c494                	sw	a3,8(s1)
    80006f34:	c4d8                	sw	a4,12(s1)
    80006f36:	c89c                	sw	a5,16(s1)
    s->phase = WL_WAIT;
    80006f38:	0204a023          	sw	zero,32(s1)
    s->bursts_left = s->def.repeats;
    80006f3c:	d4dc                	sw	a5,44(s1)
    s->ready_at = -1;
    80006f3e:	0344ae23          	sw	s4,60(s1)
    s->st.nice = s->def.nice;
    80006f42:	c0b0                	sw	a2,64(s1)
    s->st.cpu_burst = s->def.cpu_burst;
    80006f44:	c0f4                	sw	a3,68(s1)
    s->st.io_burst = s->def.io_burst;
    80006f46:	c4b8                	sw	a4,72(s1)
    s->st.repeats = s->def.repeats;
    80006f48:	c4fc                	sw	a5,76(s1)
  return s->def.io_burst == 0 && s->def.repeats == 1;
    80006f4a:	86de                	mv	a3,s7
    80006f4c:	f345                	bnez	a4,80006eec <wl_load+0x106>
    80006f4e:	17fd                	addi	a5,a5,-1
    80006f50:	0017b693          	seqz	a3,a5
    80006f54:	bf61                	j	80006eec <wl_load+0x106>
    80006f56:	79a2                	ld	s3,40(sp)
    80006f58:	7a02                	ld	s4,32(sp)
    80006f5a:	6ae2                	ld	s5,24(sp)
    80006f5c:	6b42                	ld	s6,16(sp)
    80006f5e:	6ba2                	ld	s7,8(sp)
  }
  loaded = 1;
    80006f60:	4785                	li	a5,1
    80006f62:	00006717          	auipc	a4,0x6
    80006f66:	70f72123          	sw	a5,1794(a4) # 8000d664 <loaded>
  release(&wl_lock);
    80006f6a:	00020517          	auipc	a0,0x20
    80006f6e:	63650513          	addi	a0,a0,1590 # 800275a0 <wl_lock>
    80006f72:	ca9f90ef          	jal	80000c1a <release>
  return 0;
    80006f76:	74e2                	ld	s1,56(sp)
    80006f78:	7942                	ld	s2,48(sp)
}
    80006f7a:	8562                	mv	a0,s8
    80006f7c:	60a6                	ld	ra,72(sp)
    80006f7e:	6406                	ld	s0,64(sp)
    80006f80:	6c02                	ld	s8,0(sp)
    80006f82:	6161                	addi	sp,sp,80
    80006f84:	8082                	ret
  acquire(&wl_lock);
    80006f86:	00020517          	auipc	a0,0x20
    80006f8a:	61a50513          	addi	a0,a0,1562 # 800275a0 <wl_lock>
    80006f8e:	c01f90ef          	jal	80000b8e <acquire>
  if (d == 0 || loaded || d->nslots < 1 || d->nslots > WL_MAXSLOTS) {
    80006f92:	b7a9                	j	80006edc <wl_load+0xf6>

0000000080006f94 <wl_count>:

int
wl_count(void)
{
    80006f94:	1101                	addi	sp,sp,-32
    80006f96:	ec06                	sd	ra,24(sp)
    80006f98:	e822                	sd	s0,16(sp)
    80006f9a:	e426                	sd	s1,8(sp)
    80006f9c:	1000                	addi	s0,sp,32
  int n;

  acquire(&wl_lock);
    80006f9e:	00020517          	auipc	a0,0x20
    80006fa2:	60250513          	addi	a0,a0,1538 # 800275a0 <wl_lock>
    80006fa6:	be9f90ef          	jal	80000b8e <acquire>
  n = (loaded && myproc() == controller) ? nslots : -1;
    80006faa:	00006797          	auipc	a5,0x6
    80006fae:	6ba7a783          	lw	a5,1722(a5) # 8000d664 <loaded>
    80006fb2:	cb8d                	beqz	a5,80006fe4 <wl_count+0x50>
    80006fb4:	8e5fa0ef          	jal	80001898 <myproc>
    80006fb8:	00006797          	auipc	a5,0x6
    80006fbc:	6a07b783          	ld	a5,1696(a5) # 8000d658 <controller>
    80006fc0:	02a79463          	bne	a5,a0,80006fe8 <wl_count+0x54>
    80006fc4:	00006497          	auipc	s1,0x6
    80006fc8:	68c4a483          	lw	s1,1676(s1) # 8000d650 <nslots>
  release(&wl_lock);
    80006fcc:	00020517          	auipc	a0,0x20
    80006fd0:	5d450513          	addi	a0,a0,1492 # 800275a0 <wl_lock>
    80006fd4:	c47f90ef          	jal	80000c1a <release>
  return n;
}
    80006fd8:	8526                	mv	a0,s1
    80006fda:	60e2                	ld	ra,24(sp)
    80006fdc:	6442                	ld	s0,16(sp)
    80006fde:	64a2                	ld	s1,8(sp)
    80006fe0:	6105                	addi	sp,sp,32
    80006fe2:	8082                	ret
  n = (loaded && myproc() == controller) ? nslots : -1;
    80006fe4:	54fd                	li	s1,-1
    80006fe6:	b7dd                	j	80006fcc <wl_count+0x38>
    80006fe8:	54fd                	li	s1,-1
    80006fea:	b7cd                	j	80006fcc <wl_count+0x38>

0000000080006fec <wl_attach>:

int
wl_attach(int index)
{
    80006fec:	7139                	addi	sp,sp,-64
    80006fee:	fc06                	sd	ra,56(sp)
    80006ff0:	f822                	sd	s0,48(sp)
    80006ff2:	f426                	sd	s1,40(sp)
    80006ff4:	f04a                	sd	s2,32(sp)
    80006ff6:	e852                	sd	s4,16(sp)
    80006ff8:	0080                	addi	s0,sp,64
    80006ffa:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80006ffc:	89dfa0ef          	jal	80001898 <myproc>
    80007000:	892a                	mv	s2,a0

  acquire(&wl_lock);
    80007002:	00020517          	auipc	a0,0x20
    80007006:	59e50513          	addi	a0,a0,1438 # 800275a0 <wl_lock>
    8000700a:	b85f90ef          	jal	80000b8e <acquire>
  if (!loaded || started || p == controller || p->wl_slot >= 0 ||
    8000700e:	00006797          	auipc	a5,0x6
    80007012:	6567a783          	lw	a5,1622(a5) # 8000d664 <loaded>
    80007016:	cfc9                	beqz	a5,800070b0 <wl_attach+0xc4>
    80007018:	00006a17          	auipc	s4,0x6
    8000701c:	648a2a03          	lw	s4,1608(s4) # 8000d660 <started>
    80007020:	080a1863          	bnez	s4,800070b0 <wl_attach+0xc4>
    80007024:	00006797          	auipc	a5,0x6
    80007028:	6347b783          	ld	a5,1588(a5) # 8000d658 <controller>
    8000702c:	09278263          	beq	a5,s2,800070b0 <wl_attach+0xc4>
    80007030:	fff4c713          	not	a4,s1
    80007034:	19092783          	lw	a5,400(s2)
    80007038:	8ff9                	and	a5,a5,a4
    8000703a:	0607db63          	bgez	a5,800070b0 <wl_attach+0xc4>
      index < 0 || index >= nslots || ws[index].p != 0) {
    8000703e:	00006797          	auipc	a5,0x6
    80007042:	6127a783          	lw	a5,1554(a5) # 8000d650 <nslots>
    80007046:	06f4d563          	bge	s1,a5,800070b0 <wl_attach+0xc4>
    8000704a:	00249793          	slli	a5,s1,0x2
    8000704e:	97a6                	add	a5,a5,s1
    80007050:	0796                	slli	a5,a5,0x5
    80007052:	00020717          	auipc	a4,0x20
    80007056:	56670713          	addi	a4,a4,1382 # 800275b8 <ws>
    8000705a:	97ba                	add	a5,a5,a4
    8000705c:	6f9c                	ld	a5,24(a5)
    8000705e:	eba9                	bnez	a5,800070b0 <wl_attach+0xc4>
    80007060:	ec4e                	sd	s3,24(sp)
    80007062:	e456                	sd	s5,8(sp)
    release(&wl_lock);
    return -1;
  }
  ws[index].p = p;
    80007064:	00020a97          	auipc	s5,0x20
    80007068:	554a8a93          	addi	s5,s5,1364 # 800275b8 <ws>
    8000706c:	00249993          	slli	s3,s1,0x2
    80007070:	009987b3          	add	a5,s3,s1
    80007074:	0796                	slli	a5,a5,0x5
    80007076:	97d6                	add	a5,a5,s5
    80007078:	0127bc23          	sd	s2,24(a5)
  p->wl_slot = index;
    8000707c:	18992823          	sw	s1,400(s2)
  release(&wl_lock);
    80007080:	00020517          	auipc	a0,0x20
    80007084:	52050513          	addi	a0,a0,1312 # 800275a0 <wl_lock>
    80007088:	b93f90ef          	jal	80000c1a <release>

  setnice(p, ws[index].def.nice);
    8000708c:	99a6                	add	s3,s3,s1
    8000708e:	0996                	slli	s3,s3,0x5
    80007090:	9ace                	add	s5,s5,s3
    80007092:	004aa583          	lw	a1,4(s5)
    80007096:	854a                	mv	a0,s2
    80007098:	b7afb0ef          	jal	80002412 <setnice>
    8000709c:	69e2                	ld	s3,24(sp)
    8000709e:	6aa2                	ld	s5,8(sp)
  return 0;
}
    800070a0:	8552                	mv	a0,s4
    800070a2:	70e2                	ld	ra,56(sp)
    800070a4:	7442                	ld	s0,48(sp)
    800070a6:	74a2                	ld	s1,40(sp)
    800070a8:	7902                	ld	s2,32(sp)
    800070aa:	6a42                	ld	s4,16(sp)
    800070ac:	6121                	addi	sp,sp,64
    800070ae:	8082                	ret
    release(&wl_lock);
    800070b0:	00020517          	auipc	a0,0x20
    800070b4:	4f050513          	addi	a0,a0,1264 # 800275a0 <wl_lock>
    800070b8:	b63f90ef          	jal	80000c1a <release>
    return -1;
    800070bc:	5a7d                	li	s4,-1
    800070be:	b7cd                	j	800070a0 <wl_attach+0xb4>

00000000800070c0 <wl_start>:

int
wl_start(void)
{
    800070c0:	715d                	addi	sp,sp,-80
    800070c2:	e486                	sd	ra,72(sp)
    800070c4:	e0a2                	sd	s0,64(sp)
    800070c6:	e45e                	sd	s7,8(sp)
    800070c8:	0880                	addi	s0,sp,80
  acquire(&wl_lock);
    800070ca:	00020517          	auipc	a0,0x20
    800070ce:	4d650513          	addi	a0,a0,1238 # 800275a0 <wl_lock>
    800070d2:	abdf90ef          	jal	80000b8e <acquire>
  if (!loaded || started || myproc() != controller) {
    800070d6:	00006797          	auipc	a5,0x6
    800070da:	58e7a783          	lw	a5,1422(a5) # 8000d664 <loaded>
    800070de:	0e078663          	beqz	a5,800071ca <wl_start+0x10a>
    800070e2:	00006b97          	auipc	s7,0x6
    800070e6:	57ebab83          	lw	s7,1406(s7) # 8000d660 <started>
    800070ea:	0e0b9063          	bnez	s7,800071ca <wl_start+0x10a>
    800070ee:	faafa0ef          	jal	80001898 <myproc>
    800070f2:	00006797          	auipc	a5,0x6
    800070f6:	5667b783          	ld	a5,1382(a5) # 8000d658 <controller>
    800070fa:	0ca79863          	bne	a5,a0,800071ca <wl_start+0x10a>
    800070fe:	f84a                	sd	s2,48(sp)
    80007100:	f44e                	sd	s3,40(sp)
    80007102:	ec56                	sd	s5,24(sp)
    80007104:	e85a                	sd	s6,16(sp)
    release(&wl_lock);
    return -1;
  }
  // Every worker must be attached and blocked in workload_checkpoint(),
  // so no worker is runnable before its arrival time.
  for (int i = 0; i < nslots; i++) {
    80007106:	00006797          	auipc	a5,0x6
    8000710a:	54a7a783          	lw	a5,1354(a5) # 8000d650 <nslots>
    8000710e:	00020917          	auipc	s2,0x20
    80007112:	4c290913          	addi	s2,s2,1218 # 800275d0 <ws+0x18>
    80007116:	89de                	mv	s3,s7
    if (p) {
      acquire(&p->lock);
      asleep = (p->state == SLEEPING);
      release(&p->lock);
    }
    if (!asleep) {
    80007118:	4a89                	li	s5,2
  for (int i = 0; i < nslots; i++) {
    8000711a:	00006b17          	auipc	s6,0x6
    8000711e:	536b0b13          	addi	s6,s6,1334 # 8000d650 <nslots>
    80007122:	02f05a63          	blez	a5,80007156 <wl_start+0x96>
    80007126:	fc26                	sd	s1,56(sp)
    80007128:	f052                	sd	s4,32(sp)
    struct proc *p = ws[i].p;
    8000712a:	00093483          	ld	s1,0(s2)
    if (p) {
    8000712e:	c4d5                	beqz	s1,800071da <wl_start+0x11a>
      acquire(&p->lock);
    80007130:	8526                	mv	a0,s1
    80007132:	a5df90ef          	jal	80000b8e <acquire>
      asleep = (p->state == SLEEPING);
    80007136:	0184aa03          	lw	s4,24(s1)
      release(&p->lock);
    8000713a:	8526                	mv	a0,s1
    8000713c:	adff90ef          	jal	80000c1a <release>
    if (!asleep) {
    80007140:	095a1d63          	bne	s4,s5,800071da <wl_start+0x11a>
  for (int i = 0; i < nslots; i++) {
    80007144:	2985                	addiw	s3,s3,1
    80007146:	0a090913          	addi	s2,s2,160
    8000714a:	000b2783          	lw	a5,0(s6)
    8000714e:	fcf9cee3          	blt	s3,a5,8000712a <wl_start+0x6a>
    80007152:	74e2                	ld	s1,56(sp)
    80007154:	7a02                	ld	s4,32(sp)
      return -1;
    }
  }
  // Policy state built up while the workers were forked and attached
  // depends on timing, so reset it; then every run starts the same.
  sched_reset(sched_current);
    80007156:	00006517          	auipc	a0,0x6
    8000715a:	4b252503          	lw	a0,1202(a0) # 8000d608 <sched_current>
    8000715e:	beefb0ef          	jal	8000254c <sched_reset>
  started = 1;
    80007162:	4785                	li	a5,1
    80007164:	00006717          	auipc	a4,0x6
    80007168:	4ef72e23          	sw	a5,1276(a4) # 8000d660 <started>
  start_tick = ticks;
    8000716c:	00006517          	auipc	a0,0x6
    80007170:	4ac52503          	lw	a0,1196(a0) # 8000d618 <ticks>
    80007174:	00006797          	auipc	a5,0x6
    80007178:	4ca7aa23          	sw	a0,1236(a5) # 8000d648 <start_tick>
  last_proc = 0;
    8000717c:	00006797          	auipc	a5,0x6
    80007180:	4c07b223          	sd	zero,1220(a5) # 8000d640 <last_proc>
  for (int i = 0; i < nslots; i++)
    80007184:	00006717          	auipc	a4,0x6
    80007188:	4cc72703          	lw	a4,1228(a4) # 8000d650 <nslots>
    8000718c:	02e05263          	blez	a4,800071b0 <wl_start+0xf0>
    80007190:	00020797          	auipc	a5,0x20
    80007194:	42878793          	addi	a5,a5,1064 # 800275b8 <ws>
    80007198:	00271693          	slli	a3,a4,0x2
    8000719c:	96ba                	add	a3,a3,a4
    8000719e:	0696                	slli	a3,a3,0x5
    800071a0:	96be                	add	a3,a3,a5
    ws[i].arrive_at = start_tick + ws[i].def.arrival;
    800071a2:	4398                	lw	a4,0(a5)
    800071a4:	9f29                	addw	a4,a4,a0
    800071a6:	d3d8                	sw	a4,36(a5)
  for (int i = 0; i < nslots; i++)
    800071a8:	0a078793          	addi	a5,a5,160
    800071ac:	fed79be3          	bne	a5,a3,800071a2 <wl_start+0xe2>
  events(start_tick);
    800071b0:	fc6ff0ef          	jal	80006976 <events>
  release(&wl_lock);
    800071b4:	00020517          	auipc	a0,0x20
    800071b8:	3ec50513          	addi	a0,a0,1004 # 800275a0 <wl_lock>
    800071bc:	a5ff90ef          	jal	80000c1a <release>
    800071c0:	7942                	ld	s2,48(sp)
    800071c2:	79a2                	ld	s3,40(sp)
    800071c4:	6ae2                	ld	s5,24(sp)
    800071c6:	6b42                	ld	s6,16(sp)
  return 0;
    800071c8:	a035                	j	800071f4 <wl_start+0x134>
    release(&wl_lock);
    800071ca:	00020517          	auipc	a0,0x20
    800071ce:	3d650513          	addi	a0,a0,982 # 800275a0 <wl_lock>
    800071d2:	a49f90ef          	jal	80000c1a <release>
    return -1;
    800071d6:	5bfd                	li	s7,-1
    800071d8:	a831                	j	800071f4 <wl_start+0x134>
      release(&wl_lock);
    800071da:	00020517          	auipc	a0,0x20
    800071de:	3c650513          	addi	a0,a0,966 # 800275a0 <wl_lock>
    800071e2:	a39f90ef          	jal	80000c1a <release>
      return -1;
    800071e6:	5bfd                	li	s7,-1
    800071e8:	74e2                	ld	s1,56(sp)
    800071ea:	7942                	ld	s2,48(sp)
    800071ec:	79a2                	ld	s3,40(sp)
    800071ee:	7a02                	ld	s4,32(sp)
    800071f0:	6ae2                	ld	s5,24(sp)
    800071f2:	6b42                	ld	s6,16(sp)
}
    800071f4:	855e                	mv	a0,s7
    800071f6:	60a6                	ld	ra,72(sp)
    800071f8:	6406                	ld	s0,64(sp)
    800071fa:	6ba2                	ld	s7,8(sp)
    800071fc:	6161                	addi	sp,sp,80
    800071fe:	8082                	ret

0000000080007200 <wl_checkpoint>:
// Called repeatedly by a worker. Blocks while the job has not arrived
// or is in simulated I/O. Returns 0 while the job needs the CPU,
// 1 when the job is finished, and -1 on error.
int
wl_checkpoint(void)
{
    80007200:	711d                	addi	sp,sp,-96
    80007202:	ec86                	sd	ra,88(sp)
    80007204:	e8a2                	sd	s0,80(sp)
    80007206:	e4a6                	sd	s1,72(sp)
    80007208:	fc4e                	sd	s3,56(sp)
    8000720a:	1080                	addi	s0,sp,96
  struct proc *p = myproc();
    8000720c:	e8cfa0ef          	jal	80001898 <myproc>
    80007210:	84aa                	mv	s1,a0

  acquire(&wl_lock);
    80007212:	00020517          	auipc	a0,0x20
    80007216:	38e50513          	addi	a0,a0,910 # 800275a0 <wl_lock>
    8000721a:	975f90ef          	jal	80000b8e <acquire>
  for (;;) {
    if (!loaded || p->wl_slot < 0 || killed(p)) {
    8000721e:	00006797          	auipc	a5,0x6
    80007222:	4467a783          	lw	a5,1094(a5) # 8000d664 <loaded>
    80007226:	cbb9                	beqz	a5,8000727c <wl_checkpoint+0x7c>
    80007228:	e0ca                	sd	s2,64(sp)
    8000722a:	f852                	sd	s4,48(sp)
    8000722c:	f456                	sd	s5,40(sp)
    8000722e:	f05a                	sd	s6,32(sp)
    80007230:	ec5e                	sd	s7,24(sp)
    80007232:	e862                	sd	s8,16(sp)
    80007234:	e466                	sd	s9,8(sp)
      release(&wl_lock);
      return -1;
    }
    struct wl_state *s = &ws[p->wl_slot];
    80007236:	00020917          	auipc	s2,0x20
    8000723a:	38290913          	addi	s2,s2,898 # 800275b8 <ws>
    if (s->burst_done)
      advance(s, ticks);
    if (s->phase == WL_DONE) {
    8000723e:	4b8d                	li	s7,3
      release(&wl_lock);
      return 1;
    }
    if (s->phase == WL_CPU) {
    80007240:	4b05                	li	s6,1
      advance(s, ticks);
    80007242:	00006c17          	auipc	s8,0x6
    80007246:	3d6c0c13          	addi	s8,s8,982 # 8000d618 <ticks>
    s->phase = WL_IO;
    8000724a:	4c89                	li	s9,2
      return 0;
    }
    // Not arrived yet, or in simulated I/O: block until the clock
    // wakes this slot.
    sleep_prepare(s);
    release(&wl_lock);
    8000724c:	00020a17          	auipc	s4,0x20
    80007250:	354a0a13          	addi	s4,s4,852 # 800275a0 <wl_lock>
    if (!loaded || p->wl_slot < 0 || killed(p)) {
    80007254:	00006a97          	auipc	s5,0x6
    80007258:	410a8a93          	addi	s5,s5,1040 # 8000d664 <loaded>
    8000725c:	a071                	j	800072e8 <wl_checkpoint+0xe8>
    8000725e:	6906                	ld	s2,64(sp)
    80007260:	7a42                	ld	s4,48(sp)
    80007262:	7aa2                	ld	s5,40(sp)
    80007264:	7b02                	ld	s6,32(sp)
    80007266:	6be2                	ld	s7,24(sp)
    80007268:	6c42                	ld	s8,16(sp)
    8000726a:	6ca2                	ld	s9,8(sp)
    8000726c:	a801                	j	8000727c <wl_checkpoint+0x7c>
    8000726e:	6906                	ld	s2,64(sp)
    80007270:	7a42                	ld	s4,48(sp)
    80007272:	7aa2                	ld	s5,40(sp)
    80007274:	7b02                	ld	s6,32(sp)
    80007276:	6be2                	ld	s7,24(sp)
    80007278:	6c42                	ld	s8,16(sp)
    8000727a:	6ca2                	ld	s9,8(sp)
      release(&wl_lock);
    8000727c:	00020517          	auipc	a0,0x20
    80007280:	32450513          	addi	a0,a0,804 # 800275a0 <wl_lock>
    80007284:	997f90ef          	jal	80000c1a <release>
      return -1;
    80007288:	59fd                	li	s3,-1
    sleep();
    acquire(&wl_lock);
  }
}
    8000728a:	854e                	mv	a0,s3
    8000728c:	60e6                	ld	ra,88(sp)
    8000728e:	6446                	ld	s0,80(sp)
    80007290:	64a6                	ld	s1,72(sp)
    80007292:	79e2                	ld	s3,56(sp)
    80007294:	6125                	addi	sp,sp,96
    80007296:	8082                	ret
    s->phase = WL_IO;
    80007298:	03952023          	sw	s9,32(a0)
    s->io_until = now + s->def.io_burst;
    8000729c:	455c                	lw	a5,12(a0)
    8000729e:	9fb1                	addw	a5,a5,a2
    800072a0:	d51c                	sw	a5,40(a0)
    if (s->phase == WL_DONE) {
    800072a2:	a02d                	j	800072cc <wl_checkpoint+0xcc>
    fair_end = now;
    800072a4:	00006797          	auipc	a5,0x6
    800072a8:	38c7a223          	sw	a2,900(a5) # 8000d628 <fair_end>
    800072ac:	a8e1                	j	80007384 <wl_checkpoint+0x184>
    end_tick = now;
    800072ae:	00006797          	auipc	a5,0x6
    800072b2:	38c7a723          	sw	a2,910(a5) # 8000d63c <end_tick>
    800072b6:	a0f5                	j	800073a2 <wl_checkpoint+0x1a2>
    if (s->phase == WL_DONE) {
    800072b8:	00271793          	slli	a5,a4,0x2
    800072bc:	97ba                	add	a5,a5,a4
    800072be:	0796                	slli	a5,a5,0x5
    800072c0:	97ca                	add	a5,a5,s2
    800072c2:	539c                	lw	a5,32(a5)
    800072c4:	0d778f63          	beq	a5,s7,800073a2 <wl_checkpoint+0x1a2>
    if (s->phase == WL_CPU) {
    800072c8:	0f678c63          	beq	a5,s6,800073c0 <wl_checkpoint+0x1c0>
    sleep_prepare(s);
    800072cc:	c65fa0ef          	jal	80001f30 <sleep_prepare>
    release(&wl_lock);
    800072d0:	8552                	mv	a0,s4
    800072d2:	949f90ef          	jal	80000c1a <release>
    sleep();
    800072d6:	c97fa0ef          	jal	80001f6c <sleep>
    acquire(&wl_lock);
    800072da:	8552                	mv	a0,s4
    800072dc:	8b3f90ef          	jal	80000b8e <acquire>
    if (!loaded || p->wl_slot < 0 || killed(p)) {
    800072e0:	000aa783          	lw	a5,0(s5)
    800072e4:	0e078c63          	beqz	a5,800073dc <wl_checkpoint+0x1dc>
    800072e8:	1904a783          	lw	a5,400(s1)
    800072ec:	f807c1e3          	bltz	a5,8000726e <wl_checkpoint+0x6e>
    800072f0:	8526                	mv	a0,s1
    800072f2:	eabfa0ef          	jal	8000219c <killed>
    800072f6:	f525                	bnez	a0,8000725e <wl_checkpoint+0x5e>
    struct wl_state *s = &ws[p->wl_slot];
    800072f8:	1904a703          	lw	a4,400(s1)
    800072fc:	00271513          	slli	a0,a4,0x2
    80007300:	953a                	add	a0,a0,a4
    80007302:	0516                	slli	a0,a0,0x5
    80007304:	954a                	add	a0,a0,s2
    if (s->burst_done)
    80007306:	03852983          	lw	s3,56(a0)
    8000730a:	fa0987e3          	beqz	s3,800072b8 <wl_checkpoint+0xb8>
      advance(s, ticks);
    8000730e:	000c2603          	lw	a2,0(s8)
  s->burst_done = 0;
    80007312:	02052c23          	sw	zero,56(a0)
  s->debt = 0;
    80007316:	02052a23          	sw	zero,52(a0)
  s->bursts_left--;
    8000731a:	5554                	lw	a3,44(a0)
    8000731c:	36fd                	addiw	a3,a3,-1
    8000731e:	0006859b          	sext.w	a1,a3
    80007322:	d554                	sw	a3,44(a0)
  if (s->bursts_left > 0) {
    80007324:	f6b04ae3          	bgtz	a1,80007298 <wl_checkpoint+0x98>
  s->phase = WL_DONE;
    80007328:	00271693          	slli	a3,a4,0x2
    8000732c:	96ba                	add	a3,a3,a4
    8000732e:	0696                	slli	a3,a3,0x5
    80007330:	00020797          	auipc	a5,0x20
    80007334:	28878793          	addi	a5,a5,648 # 800275b8 <ws>
    80007338:	97b6                	add	a5,a5,a3
    8000733a:	468d                	li	a3,3
    8000733c:	d394                	sw	a3,32(a5)
  s->st.completion = now - start_tick;
    8000733e:	00006697          	auipc	a3,0x6
    80007342:	30a6a683          	lw	a3,778(a3) # 8000d648 <start_tick>
    80007346:	40d606bb          	subw	a3,a2,a3
    8000734a:	cff4                	sw	a3,92(a5)
  return s->def.io_burst == 0 && s->def.repeats == 1;
    8000734c:	47dc                	lw	a5,12(a5)
    8000734e:	eb9d                	bnez	a5,80007384 <wl_checkpoint+0x184>
    80007350:	00271793          	slli	a5,a4,0x2
    80007354:	97ba                	add	a5,a5,a4
    80007356:	0796                	slli	a5,a5,0x5
    80007358:	00020717          	auipc	a4,0x20
    8000735c:	26070713          	addi	a4,a4,608 # 800275b8 <ws>
    80007360:	97ba                	add	a5,a5,a4
  if (isbatch(s) && fair_start >= 0 && fair_end < 0)
    80007362:	4b98                	lw	a4,16(a5)
    80007364:	4785                	li	a5,1
    80007366:	00f71f63          	bne	a4,a5,80007384 <wl_checkpoint+0x184>
    8000736a:	00006797          	auipc	a5,0x6
    8000736e:	2c27a783          	lw	a5,706(a5) # 8000d62c <fair_start>
    80007372:	fff7c793          	not	a5,a5
    80007376:	00006717          	auipc	a4,0x6
    8000737a:	2b272703          	lw	a4,690(a4) # 8000d628 <fair_end>
    8000737e:	8ff9                	and	a5,a5,a4
    80007380:	f207c2e3          	bltz	a5,800072a4 <wl_checkpoint+0xa4>
  if (++ndone == nslots)
    80007384:	00006717          	auipc	a4,0x6
    80007388:	2c870713          	addi	a4,a4,712 # 8000d64c <ndone>
    8000738c:	431c                	lw	a5,0(a4)
    8000738e:	2785                	addiw	a5,a5,1
    80007390:	0007869b          	sext.w	a3,a5
    80007394:	c31c                	sw	a5,0(a4)
    80007396:	00006797          	auipc	a5,0x6
    8000739a:	2ba7a783          	lw	a5,698(a5) # 8000d650 <nslots>
    8000739e:	f0d788e3          	beq	a5,a3,800072ae <wl_checkpoint+0xae>
      release(&wl_lock);
    800073a2:	00020517          	auipc	a0,0x20
    800073a6:	1fe50513          	addi	a0,a0,510 # 800275a0 <wl_lock>
    800073aa:	871f90ef          	jal	80000c1a <release>
      return 1;
    800073ae:	4985                	li	s3,1
    800073b0:	6906                	ld	s2,64(sp)
    800073b2:	7a42                	ld	s4,48(sp)
    800073b4:	7aa2                	ld	s5,40(sp)
    800073b6:	7b02                	ld	s6,32(sp)
    800073b8:	6be2                	ld	s7,24(sp)
    800073ba:	6c42                	ld	s8,16(sp)
    800073bc:	6ca2                	ld	s9,8(sp)
    800073be:	b5f1                	j	8000728a <wl_checkpoint+0x8a>
      release(&wl_lock);
    800073c0:	00020517          	auipc	a0,0x20
    800073c4:	1e050513          	addi	a0,a0,480 # 800275a0 <wl_lock>
    800073c8:	853f90ef          	jal	80000c1a <release>
      return 0;
    800073cc:	6906                	ld	s2,64(sp)
    800073ce:	7a42                	ld	s4,48(sp)
    800073d0:	7aa2                	ld	s5,40(sp)
    800073d2:	7b02                	ld	s6,32(sp)
    800073d4:	6be2                	ld	s7,24(sp)
    800073d6:	6c42                	ld	s8,16(sp)
    800073d8:	6ca2                	ld	s9,8(sp)
    800073da:	bd45                	j	8000728a <wl_checkpoint+0x8a>
    800073dc:	6906                	ld	s2,64(sp)
    800073de:	7a42                	ld	s4,48(sp)
    800073e0:	7aa2                	ld	s5,40(sp)
    800073e2:	7b02                	ld	s6,32(sp)
    800073e4:	6be2                	ld	s7,24(sp)
    800073e6:	6c42                	ld	s8,16(sp)
    800073e8:	6ca2                	ld	s9,8(sp)
    800073ea:	bd49                	j	8000727c <wl_checkpoint+0x7c>

00000000800073ec <wl_stop>:

int
wl_stop(void)
{
    800073ec:	1141                	addi	sp,sp,-16
    800073ee:	e406                	sd	ra,8(sp)
    800073f0:	e022                	sd	s0,0(sp)
    800073f2:	0800                	addi	s0,sp,16
  acquire(&wl_lock);
    800073f4:	00020517          	auipc	a0,0x20
    800073f8:	1ac50513          	addi	a0,a0,428 # 800275a0 <wl_lock>
    800073fc:	f92f90ef          	jal	80000b8e <acquire>
  if (!loaded || myproc() != controller) {
    80007400:	00006797          	auipc	a5,0x6
    80007404:	2647a783          	lw	a5,612(a5) # 8000d664 <loaded>
    80007408:	c795                	beqz	a5,80007434 <wl_stop+0x48>
    8000740a:	c8efa0ef          	jal	80001898 <myproc>
    8000740e:	00006797          	auipc	a5,0x6
    80007412:	24a7b783          	ld	a5,586(a5) # 8000d658 <controller>
    80007416:	00a79f63          	bne	a5,a0,80007434 <wl_stop+0x48>
    release(&wl_lock);
    return -1;
  }
  clear();
    8000741a:	cb0ff0ef          	jal	800068ca <clear>
  release(&wl_lock);
    8000741e:	00020517          	auipc	a0,0x20
    80007422:	18250513          	addi	a0,a0,386 # 800275a0 <wl_lock>
    80007426:	ff4f90ef          	jal	80000c1a <release>
  return 0;
    8000742a:	4501                	li	a0,0
}
    8000742c:	60a2                	ld	ra,8(sp)
    8000742e:	6402                	ld	s0,0(sp)
    80007430:	0141                	addi	sp,sp,16
    80007432:	8082                	ret
    release(&wl_lock);
    80007434:	00020517          	auipc	a0,0x20
    80007438:	16c50513          	addi	a0,a0,364 # 800275a0 <wl_lock>
    8000743c:	fdef90ef          	jal	80000c1a <release>
    return -1;
    80007440:	557d                	li	a0,-1
    80007442:	b7ed                	j	8000742c <wl_stop+0x40>

0000000080007444 <wl_stats>:

int
wl_stats(int index, uint64 addr)
{
    80007444:	7175                	addi	sp,sp,-144
    80007446:	e506                	sd	ra,136(sp)
    80007448:	e122                	sd	s0,128(sp)
    8000744a:	fca6                	sd	s1,120(sp)
    8000744c:	f8ca                	sd	s2,112(sp)
    8000744e:	f4ce                	sd	s3,104(sp)
    80007450:	0900                	addi	s0,sp,144
    80007452:	84aa                	mv	s1,a0
    80007454:	89ae                	mv	s3,a1
  struct wl_stats st;
  struct proc *p = myproc();
    80007456:	c42fa0ef          	jal	80001898 <myproc>
    8000745a:	892a                	mv	s2,a0

  acquire(&wl_lock);
    8000745c:	00020517          	auipc	a0,0x20
    80007460:	14450513          	addi	a0,a0,324 # 800275a0 <wl_lock>
    80007464:	f2af90ef          	jal	80000b8e <acquire>
  if (!loaded || p != controller || index < 0 || index >= nslots) {
    80007468:	00006797          	auipc	a5,0x6
    8000746c:	1fc7a783          	lw	a5,508(a5) # 8000d664 <loaded>
    80007470:	12078563          	beqz	a5,8000759a <wl_stats+0x156>
    80007474:	00006797          	auipc	a5,0x6
    80007478:	1e47b783          	ld	a5,484(a5) # 8000d658 <controller>
    8000747c:	11279f63          	bne	a5,s2,8000759a <wl_stats+0x156>
    80007480:	1004cd63          	bltz	s1,8000759a <wl_stats+0x156>
    80007484:	00006797          	auipc	a5,0x6
    80007488:	1cc7a783          	lw	a5,460(a5) # 8000d650 <nslots>
    8000748c:	10f4d763          	bge	s1,a5,8000759a <wl_stats+0x156>
    release(&wl_lock);
    return -1;
  }
  st = ws[index].st;
    80007490:	00249713          	slli	a4,s1,0x2
    80007494:	9726                	add	a4,a4,s1
    80007496:	0716                	slli	a4,a4,0x5
    80007498:	00020797          	auipc	a5,0x20
    8000749c:	12078793          	addi	a5,a5,288 # 800275b8 <ws>
    800074a0:	97ba                	add	a5,a5,a4
    800074a2:	0407b883          	ld	a7,64(a5)
    800074a6:	0487b803          	ld	a6,72(a5)
    800074aa:	6ba8                	ld	a0,80(a5)
    800074ac:	6fac                	ld	a1,88(a5)
    800074ae:	73b0                	ld	a2,96(a5)
    800074b0:	77b4                	ld	a3,104(a5)
    800074b2:	7bb8                	ld	a4,112(a5)
    800074b4:	7fbc                	ld	a5,120(a5)
    800074b6:	f7143823          	sd	a7,-144(s0)
    800074ba:	f7043c23          	sd	a6,-136(s0)
    800074be:	f8a43023          	sd	a0,-128(s0)
    800074c2:	f8b43423          	sd	a1,-120(s0)
    800074c6:	f8c43823          	sd	a2,-112(s0)
    800074ca:	f8d43c23          	sd	a3,-104(s0)
    800074ce:	fae43023          	sd	a4,-96(s0)
    800074d2:	faf43423          	sd	a5,-88(s0)
  st.sched_id = sched_current;
    800074d6:	00006797          	auipc	a5,0x6
    800074da:	1327a783          	lw	a5,306(a5) # 8000d608 <sched_current>
    800074de:	faf42623          	sw	a5,-84(s0)
  st.end = end_tick >= 0 ? end_tick - start_tick : -1;
    800074e2:	00006717          	auipc	a4,0x6
    800074e6:	15a72703          	lw	a4,346(a4) # 8000d63c <end_tick>
    800074ea:	57fd                	li	a5,-1
    800074ec:	00074863          	bltz	a4,800074fc <wl_stats+0xb8>
    800074f0:	00006797          	auipc	a5,0x6
    800074f4:	1587a783          	lw	a5,344(a5) # 8000d648 <start_tick>
    800074f8:	40f707bb          	subw	a5,a4,a5
    800074fc:	faf42823          	sw	a5,-80(s0)
  st.busy_ticks = busy;
    80007500:	00006797          	auipc	a5,0x6
    80007504:	1387a783          	lw	a5,312(a5) # 8000d638 <busy>
    80007508:	faf42a23          	sw	a5,-76(s0)
  st.idle_ticks = idle;
    8000750c:	00006797          	auipc	a5,0x6
    80007510:	1287a783          	lw	a5,296(a5) # 8000d634 <idle>
    80007514:	faf42c23          	sw	a5,-72(s0)
  st.other_ticks = other;
    80007518:	00006797          	auipc	a5,0x6
    8000751c:	1187a783          	lw	a5,280(a5) # 8000d630 <other>
    80007520:	faf42e23          	sw	a5,-68(s0)
  st.switch_cost = SWITCH_COST;
    80007524:	47d1                	li	a5,20
    80007526:	fcf42023          	sw	a5,-64(s0)
  st.fair_start = fair_start >= 0 ? fair_start - start_tick : -1;
    8000752a:	00006717          	auipc	a4,0x6
    8000752e:	10272703          	lw	a4,258(a4) # 8000d62c <fair_start>
    80007532:	57fd                	li	a5,-1
    80007534:	00074863          	bltz	a4,80007544 <wl_stats+0x100>
    80007538:	00006797          	auipc	a5,0x6
    8000753c:	1107a783          	lw	a5,272(a5) # 8000d648 <start_tick>
    80007540:	40f707bb          	subw	a5,a4,a5
    80007544:	fcf42223          	sw	a5,-60(s0)
  st.fair_end = fair_end >= 0 ? fair_end - start_tick : -1;
    80007548:	00006717          	auipc	a4,0x6
    8000754c:	0e072703          	lw	a4,224(a4) # 8000d628 <fair_end>
    80007550:	57fd                	li	a5,-1
    80007552:	00074863          	bltz	a4,80007562 <wl_stats+0x11e>
    80007556:	00006797          	auipc	a5,0x6
    8000755a:	0f27a783          	lw	a5,242(a5) # 8000d648 <start_tick>
    8000755e:	40f707bb          	subw	a5,a4,a5
    80007562:	fcf42423          	sw	a5,-56(s0)
  release(&wl_lock);
    80007566:	00020517          	auipc	a0,0x20
    8000756a:	03a50513          	addi	a0,a0,58 # 800275a0 <wl_lock>
    8000756e:	eacf90ef          	jal	80000c1a <release>

  if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    80007572:	05c00713          	li	a4,92
    80007576:	f7040693          	addi	a3,s0,-144
    8000757a:	864e                	mv	a2,s3
    8000757c:	04893583          	ld	a1,72(s2)
    80007580:	05093503          	ld	a0,80(s2)
    80007584:	f57f90ef          	jal	800014da <copyout>
    80007588:	41f5551b          	sraiw	a0,a0,0x1f
    return -1;
  return 0;
}
    8000758c:	60aa                	ld	ra,136(sp)
    8000758e:	640a                	ld	s0,128(sp)
    80007590:	74e6                	ld	s1,120(sp)
    80007592:	7946                	ld	s2,112(sp)
    80007594:	79a6                	ld	s3,104(sp)
    80007596:	6149                	addi	sp,sp,144
    80007598:	8082                	ret
    release(&wl_lock);
    8000759a:	00020517          	auipc	a0,0x20
    8000759e:	00650513          	addi	a0,a0,6 # 800275a0 <wl_lock>
    800075a2:	e78f90ef          	jal	80000c1a <release>
    return -1;
    800075a6:	557d                	li	a0,-1
    800075a8:	b7d5                	j	8000758c <wl_stats+0x148>

00000000800075aa <wl_exit>:

// Called by kexit(). A controller that exits stops its workload;
// a worker that exits is detached from its slot.
void
wl_exit(struct proc *p)
{
    800075aa:	1101                	addi	sp,sp,-32
    800075ac:	ec06                	sd	ra,24(sp)
    800075ae:	e822                	sd	s0,16(sp)
    800075b0:	e426                	sd	s1,8(sp)
    800075b2:	1000                	addi	s0,sp,32
    800075b4:	84aa                	mv	s1,a0
  acquire(&wl_lock);
    800075b6:	00020517          	auipc	a0,0x20
    800075ba:	fea50513          	addi	a0,a0,-22 # 800275a0 <wl_lock>
    800075be:	dd0f90ef          	jal	80000b8e <acquire>
  if (loaded && p == controller) {
    800075c2:	00006797          	auipc	a5,0x6
    800075c6:	0a27a783          	lw	a5,162(a5) # 8000d664 <loaded>
    800075ca:	c799                	beqz	a5,800075d8 <wl_exit+0x2e>
    800075cc:	00006797          	auipc	a5,0x6
    800075d0:	08c7b783          	ld	a5,140(a5) # 8000d658 <controller>
    800075d4:	02978f63          	beq	a5,s1,80007612 <wl_exit+0x68>
    clear();
  } else if (p->wl_slot >= 0) {
    800075d8:	1904a703          	lw	a4,400(s1)
    800075dc:	02074063          	bltz	a4,800075fc <wl_exit+0x52>
    ws[p->wl_slot].p = 0;
    800075e0:	00271793          	slli	a5,a4,0x2
    800075e4:	97ba                	add	a5,a5,a4
    800075e6:	0796                	slli	a5,a5,0x5
    800075e8:	00020717          	auipc	a4,0x20
    800075ec:	fd070713          	addi	a4,a4,-48 # 800275b8 <ws>
    800075f0:	97ba                	add	a5,a5,a4
    800075f2:	0007bc23          	sd	zero,24(a5)
    p->wl_slot = -1;
    800075f6:	57fd                	li	a5,-1
    800075f8:	18f4a823          	sw	a5,400(s1)
  }
  release(&wl_lock);
    800075fc:	00020517          	auipc	a0,0x20
    80007600:	fa450513          	addi	a0,a0,-92 # 800275a0 <wl_lock>
    80007604:	e16f90ef          	jal	80000c1a <release>
}
    80007608:	60e2                	ld	ra,24(sp)
    8000760a:	6442                	ld	s0,16(sp)
    8000760c:	64a2                	ld	s1,8(sp)
    8000760e:	6105                	addi	sp,sp,32
    80007610:	8082                	ret
    clear();
    80007612:	ab8ff0ef          	jal	800068ca <clear>
    80007616:	b7dd                	j	800075fc <wl_exit+0x52>
	...

0000000080008000 <_trampoline>:
    80008000:	14051073          	csrw	sscratch,a0
    80008004:	02000537          	lui	a0,0x2000
    80008008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000800a:	0536                	slli	a0,a0,0xd
    8000800c:	02153423          	sd	ra,40(a0)
    80008010:	02253823          	sd	sp,48(a0)
    80008014:	02353c23          	sd	gp,56(a0)
    80008018:	04453023          	sd	tp,64(a0)
    8000801c:	04553423          	sd	t0,72(a0)
    80008020:	04653823          	sd	t1,80(a0)
    80008024:	04753c23          	sd	t2,88(a0)
    80008028:	f120                	sd	s0,96(a0)
    8000802a:	f524                	sd	s1,104(a0)
    8000802c:	fd2c                	sd	a1,120(a0)
    8000802e:	e150                	sd	a2,128(a0)
    80008030:	e554                	sd	a3,136(a0)
    80008032:	e958                	sd	a4,144(a0)
    80008034:	ed5c                	sd	a5,152(a0)
    80008036:	0b053023          	sd	a6,160(a0)
    8000803a:	0b153423          	sd	a7,168(a0)
    8000803e:	0b253823          	sd	s2,176(a0)
    80008042:	0b353c23          	sd	s3,184(a0)
    80008046:	0d453023          	sd	s4,192(a0)
    8000804a:	0d553423          	sd	s5,200(a0)
    8000804e:	0d653823          	sd	s6,208(a0)
    80008052:	0d753c23          	sd	s7,216(a0)
    80008056:	0f853023          	sd	s8,224(a0)
    8000805a:	0f953423          	sd	s9,232(a0)
    8000805e:	0fa53823          	sd	s10,240(a0)
    80008062:	0fb53c23          	sd	s11,248(a0)
    80008066:	11c53023          	sd	t3,256(a0)
    8000806a:	11d53423          	sd	t4,264(a0)
    8000806e:	11e53823          	sd	t5,272(a0)
    80008072:	11f53c23          	sd	t6,280(a0)
    80008076:	140022f3          	csrr	t0,sscratch
    8000807a:	06553823          	sd	t0,112(a0)
    8000807e:	00853103          	ld	sp,8(a0)
    80008082:	02053203          	ld	tp,32(a0)
    80008086:	01053283          	ld	t0,16(a0)
    8000808a:	00053303          	ld	t1,0(a0)
    8000808e:	12000073          	sfence.vma
    80008092:	18031073          	csrw	satp,t1
    80008096:	12000073          	sfence.vma
    8000809a:	9282                	jalr	t0

000000008000809c <userret>:
    8000809c:	0000100f          	fence.i
    800080a0:	12000073          	sfence.vma
    800080a4:	18051073          	csrw	satp,a0
    800080a8:	12000073          	sfence.vma
    800080ac:	02000537          	lui	a0,0x2000
    800080b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800080b2:	0536                	slli	a0,a0,0xd
    800080b4:	02853083          	ld	ra,40(a0)
    800080b8:	03053103          	ld	sp,48(a0)
    800080bc:	03853183          	ld	gp,56(a0)
    800080c0:	04053203          	ld	tp,64(a0)
    800080c4:	04853283          	ld	t0,72(a0)
    800080c8:	05053303          	ld	t1,80(a0)
    800080cc:	05853383          	ld	t2,88(a0)
    800080d0:	7120                	ld	s0,96(a0)
    800080d2:	7524                	ld	s1,104(a0)
    800080d4:	7d2c                	ld	a1,120(a0)
    800080d6:	6150                	ld	a2,128(a0)
    800080d8:	6554                	ld	a3,136(a0)
    800080da:	6958                	ld	a4,144(a0)
    800080dc:	6d5c                	ld	a5,152(a0)
    800080de:	0a053803          	ld	a6,160(a0)
    800080e2:	0a853883          	ld	a7,168(a0)
    800080e6:	0b053903          	ld	s2,176(a0)
    800080ea:	0b853983          	ld	s3,184(a0)
    800080ee:	0c053a03          	ld	s4,192(a0)
    800080f2:	0c853a83          	ld	s5,200(a0)
    800080f6:	0d053b03          	ld	s6,208(a0)
    800080fa:	0d853b83          	ld	s7,216(a0)
    800080fe:	0e053c03          	ld	s8,224(a0)
    80008102:	0e853c83          	ld	s9,232(a0)
    80008106:	0f053d03          	ld	s10,240(a0)
    8000810a:	0f853d83          	ld	s11,248(a0)
    8000810e:	10053e03          	ld	t3,256(a0)
    80008112:	10853e83          	ld	t4,264(a0)
    80008116:	11053f03          	ld	t5,272(a0)
    8000811a:	11853f83          	ld	t6,280(a0)
    8000811e:	7928                	ld	a0,112(a0)
    80008120:	10200073          	sret
	...
