user/logwl.o: user/logwl.c kernel/types.h user/user.h
