#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Busy work spans timer ticks; sleeping would not charge the running process.
static void
spin_until(int start, int elapsed)
{
  while (uptime() - start < elapsed)
    ;
}

// Check syscall return values; kernel diagnostics expose the policy state.
static void
change_nice(char *label, int increment, int expected)
{
  printf("TEST %s\n", label);
  int got = nice(getpid(), increment);
  if (got != expected) {
    printf("FAIL nice return %d expected %d\n", got, expected);
    stopLogging();
    exit(1);
  }
}

// Rule 6 and a same-queue Rule 5 boost; all work is bounded.
int
main(void)
{
  if (set_scheduler(3) < 0)
    exit(1);
  int start = uptime();
  startLogging();
  printf("mlfqtest pid %d start %d\n", getpid(), start);
  spin_until(start, 12);
  change_nice("same value while demoted", 0, 0);
  change_nice("same starting band", 5, 5);
  change_nice("cross band while already Q0", 6, 11);
  change_nice("cross band into Q2", -21, -10);
  change_nice("prepare boost test in Q0", 21, 11);
  spin_until(start, 55);
  change_nice("enter Q1 before boost", -11, 0);
  spin_until(start, 65);
  stopLogging();
  printf("mlfqtest finished; inspect nicecheck and boostcheck state transitions\n");
  set_scheduler(0);
  exit(0);
}
