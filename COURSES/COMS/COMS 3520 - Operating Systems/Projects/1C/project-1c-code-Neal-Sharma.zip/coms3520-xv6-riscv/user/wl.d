user/wl.o: user/wl.c kernel/types.h kernel/stat.h kernel/param.h \
 kernel/workload.h user/user.h
