
user/_wl:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <printw>:
}

// Print v right-aligned in a field of w characters.
static void
printw(int v, int w)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e052                	sd	s4,0(sp)
   a:	1800                	addi	s0,sp,48
   c:	8a2a                	mv	s4,a0
  if (v < 0) {
   e:	87aa                	mv	a5,a0
  int n = 1;
  10:	4705                	li	a4,1
  if (v < 0) {
  12:	06054163          	bltz	a0,74 <printw+0x74>
  for (; v >= 10; v /= 10)
  16:	46a5                	li	a3,9
  18:	00f6db63          	bge	a3,a5,2e <printw+0x2e>
  1c:	4529                	li	a0,10
  1e:	06300613          	li	a2,99
    n++;
  22:	2705                	addiw	a4,a4,1
  for (; v >= 10; v /= 10)
  24:	86be                	mv	a3,a5
  26:	02a7c7bb          	divw	a5,a5,a0
  2a:	fed64ce3          	blt	a2,a3,22 <printw+0x22>
  spaces(w - ndigits(v));
  2e:	40e584bb          	subw	s1,a1,a4
  32:	0004879b          	sext.w	a5,s1
  while (n-- > 0)
  36:	34fd                	addiw	s1,s1,-1
  38:	02f05163          	blez	a5,5a <printw+0x5a>
  3c:	e84a                	sd	s2,16(sp)
  3e:	e44e                	sd	s3,8(sp)
    printf(" ");
  40:	00001997          	auipc	s3,0x1
  44:	fb098993          	addi	s3,s3,-80 # ff0 <malloc+0x106>
  while (n-- > 0)
  48:	597d                	li	s2,-1
    printf(" ");
  4a:	854e                	mv	a0,s3
  4c:	5eb000ef          	jal	e36 <printf>
  while (n-- > 0)
  50:	34fd                	addiw	s1,s1,-1
  52:	ff249ce3          	bne	s1,s2,4a <printw+0x4a>
  56:	6942                	ld	s2,16(sp)
  58:	69a2                	ld	s3,8(sp)
  printf("%d", v);
  5a:	85d2                	mv	a1,s4
  5c:	00001517          	auipc	a0,0x1
  60:	f9c50513          	addi	a0,a0,-100 # ff8 <malloc+0x10e>
  64:	5d3000ef          	jal	e36 <printf>
}
  68:	70a2                	ld	ra,40(sp)
  6a:	7402                	ld	s0,32(sp)
  6c:	64e2                	ld	s1,24(sp)
  6e:	6a02                	ld	s4,0(sp)
  70:	6145                	addi	sp,sp,48
  72:	8082                	ret
    v = -v;
  74:	40a007bb          	negw	a5,a0
    n++;
  78:	4709                	li	a4,2
  7a:	bf71                	j	16 <printw+0x16>

000000000000007c <print2>:
{
  7c:	1141                	addi	sp,sp,-16
  7e:	e406                	sd	ra,8(sp)
  80:	e022                	sd	s0,0(sp)
  82:	0800                	addi	s0,sp,16
  printf("%d.%d%d", (int)(v / 100), (int)(v / 10 % 10), (int)(v % 10));
  84:	47a9                	li	a5,10
  86:	02f55633          	divu	a2,a0,a5
  8a:	06400593          	li	a1,100
  8e:	02b555b3          	divu	a1,a0,a1
  92:	02f576b3          	remu	a3,a0,a5
  96:	02f67633          	remu	a2,a2,a5
  9a:	2581                	sext.w	a1,a1
  9c:	00001517          	auipc	a0,0x1
  a0:	f6450513          	addi	a0,a0,-156 # 1000 <malloc+0x116>
  a4:	593000ef          	jal	e36 <printf>
}
  a8:	60a2                	ld	ra,8(sp)
  aa:	6402                	ld	s0,0(sp)
  ac:	0141                	addi	sp,sp,16
  ae:	8082                	ret

00000000000000b0 <print2w>:

// Print v/100 with two decimal places, right-aligned in w characters.
static void
print2w(uint64 v, int w)
{
  b0:	7179                	addi	sp,sp,-48
  b2:	f406                	sd	ra,40(sp)
  b4:	f022                	sd	s0,32(sp)
  b6:	ec26                	sd	s1,24(sp)
  b8:	e44e                	sd	s3,8(sp)
  ba:	1800                	addi	s0,sp,48
  bc:	89aa                	mv	s3,a0
  spaces(w - ndigits((int)(v / 100)) - 3);
  be:	06400793          	li	a5,100
  c2:	02f557b3          	divu	a5,a0,a5
  c6:	2781                	sext.w	a5,a5
  int n = 1;
  c8:	4705                	li	a4,1
  if (v < 0) {
  ca:	0407ce63          	bltz	a5,126 <print2w+0x76>
  for (; v >= 10; v /= 10)
  ce:	46a5                	li	a3,9
  d0:	00f6db63          	bge	a3,a5,e6 <print2w+0x36>
  d4:	4529                	li	a0,10
  d6:	06300613          	li	a2,99
    n++;
  da:	2705                	addiw	a4,a4,1
  for (; v >= 10; v /= 10)
  dc:	86be                	mv	a3,a5
  de:	02a7c7bb          	divw	a5,a5,a0
  e2:	fed64ce3          	blt	a2,a3,da <print2w+0x2a>
  spaces(w - ndigits((int)(v / 100)) - 3);
  e6:	40e584bb          	subw	s1,a1,a4
  ea:	0004871b          	sext.w	a4,s1
  while (n-- > 0)
  ee:	34f1                	addiw	s1,s1,-4
  f0:	478d                	li	a5,3
  f2:	02e7d163          	bge	a5,a4,114 <print2w+0x64>
  f6:	e84a                	sd	s2,16(sp)
  f8:	e052                	sd	s4,0(sp)
    printf(" ");
  fa:	00001a17          	auipc	s4,0x1
  fe:	ef6a0a13          	addi	s4,s4,-266 # ff0 <malloc+0x106>
  while (n-- > 0)
 102:	597d                	li	s2,-1
    printf(" ");
 104:	8552                	mv	a0,s4
 106:	531000ef          	jal	e36 <printf>
  while (n-- > 0)
 10a:	34fd                	addiw	s1,s1,-1
 10c:	ff249ce3          	bne	s1,s2,104 <print2w+0x54>
 110:	6942                	ld	s2,16(sp)
 112:	6a02                	ld	s4,0(sp)
  print2(v);
 114:	854e                	mv	a0,s3
 116:	f67ff0ef          	jal	7c <print2>
}
 11a:	70a2                	ld	ra,40(sp)
 11c:	7402                	ld	s0,32(sp)
 11e:	64e2                	ld	s1,24(sp)
 120:	69a2                	ld	s3,8(sp)
 122:	6145                	addi	sp,sp,48
 124:	8082                	ret
    v = -v;
 126:	40f007bb          	negw	a5,a5
    n++;
 12a:	4709                	li	a4,2
 12c:	b74d                	j	ce <print2w+0x1e>

000000000000012e <main>:
  exit(r == 1 ? 0 : 1);
}

int
main(int argc, char *argv[])
{
 12e:	7171                	addi	sp,sp,-176
 130:	f506                	sd	ra,168(sp)
 132:	f122                	sd	s0,160(sp)
 134:	1900                	addi	s0,sp,176
  int id, n, i;

  if (argc < 2 || argc > 3) {
 136:	ffe5071b          	addiw	a4,a0,-2
 13a:	4785                	li	a5,1
 13c:	02e7f663          	bgeu	a5,a4,168 <main+0x3a>
 140:	ed26                	sd	s1,152(sp)
 142:	e94a                	sd	s2,144(sp)
 144:	e54e                	sd	s3,136(sp)
 146:	e152                	sd	s4,128(sp)
 148:	fcd6                	sd	s5,120(sp)
 14a:	f8da                	sd	s6,112(sp)
 14c:	f4de                	sd	s7,104(sp)
 14e:	f0e2                	sd	s8,96(sp)
 150:	ece6                	sd	s9,88(sp)
 152:	e8ea                	sd	s10,80(sp)
 154:	e4ee                	sd	s11,72(sp)
    printf("usage: wl workload-id [scheduler-id]\n");
 156:	00001517          	auipc	a0,0x1
 15a:	ec250513          	addi	a0,a0,-318 # 1018 <malloc+0x12e>
 15e:	4d9000ef          	jal	e36 <printf>
    exit(1);
 162:	4505                	li	a0,1
 164:	047000ef          	jal	9aa <exit>
 168:	ed26                	sd	s1,152(sp)
 16a:	e94a                	sd	s2,144(sp)
 16c:	f0e2                	sd	s8,96(sp)
 16e:	84aa                	mv	s1,a0
 170:	892e                	mv	s2,a1
  }
  id = atoi(argv[1]);
 172:	6588                	ld	a0,8(a1)
 174:	714000ef          	jal	888 <atoi>
 178:	8c2a                	mv	s8,a0
  if (argc == 3 && set_scheduler(atoi(argv[2])) < 0) {
 17a:	478d                	li	a5,3
 17c:	04f48063          	beq	s1,a5,1bc <main+0x8e>
    printf("wl: set_scheduler(%s) failed\n", argv[2]);
    exit(1);
  }
  if (workload_load(id) < 0) {
 180:	8562                	mv	a0,s8
 182:	0e9000ef          	jal	a6a <workload_load>
 186:	06054663          	bltz	a0,1f2 <main+0xc4>
 18a:	e54e                	sd	s3,136(sp)
    printf("wl: no workload %d\n", id);
    exit(1);
  }
  n = workload_process_count();
 18c:	0e7000ef          	jal	a72 <workload_process_count>
 190:	892a                	mv	s2,a0

  for (i = 0; i < n; i++) {
 192:	02a05263          	blez	a0,1b6 <main+0x88>
 196:	00002997          	auipc	s3,0x2
 19a:	e7a98993          	addi	s3,s3,-390 # 2010 <pids>
 19e:	4481                	li	s1,0
    int pid = fork();
 1a0:	003000ef          	jal	9a2 <fork>
    if (pid < 0) {
 1a4:	06054963          	bltz	a0,216 <main+0xe8>
      printf("wl: fork failed\n");
      workload_stop();
      exit(1);
    }
    if (pid == 0)
 1a8:	c949                	beqz	a0,23a <main+0x10c>
      worker(i);
    pids[i] = pid;
 1aa:	00a9a023          	sw	a0,0(s3)
  for (i = 0; i < n; i++) {
 1ae:	2485                	addiw	s1,s1,1
 1b0:	0991                	addi	s3,s3,4
 1b2:	fe9917e3          	bne	s2,s1,1a0 <main+0x72>
 1b6:	1f500493          	li	s1,501
 1ba:	a0ed                	j	2a4 <main+0x176>
  if (argc == 3 && set_scheduler(atoi(argv[2])) < 0) {
 1bc:	01093503          	ld	a0,16(s2)
 1c0:	6c8000ef          	jal	888 <atoi>
 1c4:	0e1000ef          	jal	aa4 <set_scheduler>
 1c8:	fa055ce3          	bgez	a0,180 <main+0x52>
 1cc:	e54e                	sd	s3,136(sp)
 1ce:	e152                	sd	s4,128(sp)
 1d0:	fcd6                	sd	s5,120(sp)
 1d2:	f8da                	sd	s6,112(sp)
 1d4:	f4de                	sd	s7,104(sp)
 1d6:	ece6                	sd	s9,88(sp)
 1d8:	e8ea                	sd	s10,80(sp)
 1da:	e4ee                	sd	s11,72(sp)
    printf("wl: set_scheduler(%s) failed\n", argv[2]);
 1dc:	01093583          	ld	a1,16(s2)
 1e0:	00001517          	auipc	a0,0x1
 1e4:	e6050513          	addi	a0,a0,-416 # 1040 <malloc+0x156>
 1e8:	44f000ef          	jal	e36 <printf>
    exit(1);
 1ec:	4505                	li	a0,1
 1ee:	7bc000ef          	jal	9aa <exit>
 1f2:	e54e                	sd	s3,136(sp)
 1f4:	e152                	sd	s4,128(sp)
 1f6:	fcd6                	sd	s5,120(sp)
 1f8:	f8da                	sd	s6,112(sp)
 1fa:	f4de                	sd	s7,104(sp)
 1fc:	ece6                	sd	s9,88(sp)
 1fe:	e8ea                	sd	s10,80(sp)
 200:	e4ee                	sd	s11,72(sp)
    printf("wl: no workload %d\n", id);
 202:	85e2                	mv	a1,s8
 204:	00001517          	auipc	a0,0x1
 208:	e5c50513          	addi	a0,a0,-420 # 1060 <malloc+0x176>
 20c:	42b000ef          	jal	e36 <printf>
    exit(1);
 210:	4505                	li	a0,1
 212:	798000ef          	jal	9aa <exit>
 216:	e152                	sd	s4,128(sp)
 218:	fcd6                	sd	s5,120(sp)
 21a:	f8da                	sd	s6,112(sp)
 21c:	f4de                	sd	s7,104(sp)
 21e:	ece6                	sd	s9,88(sp)
 220:	e8ea                	sd	s10,80(sp)
 222:	e4ee                	sd	s11,72(sp)
      printf("wl: fork failed\n");
 224:	00001517          	auipc	a0,0x1
 228:	e5450513          	addi	a0,a0,-428 # 1078 <malloc+0x18e>
 22c:	40b000ef          	jal	e36 <printf>
      workload_stop();
 230:	063000ef          	jal	a92 <workload_stop>
      exit(1);
 234:	4505                	li	a0,1
 236:	774000ef          	jal	9aa <exit>
 23a:	e152                	sd	s4,128(sp)
 23c:	fcd6                	sd	s5,120(sp)
 23e:	f8da                	sd	s6,112(sp)
 240:	f4de                	sd	s7,104(sp)
 242:	ece6                	sd	s9,88(sp)
 244:	e8ea                	sd	s10,80(sp)
 246:	e4ee                	sd	s11,72(sp)
  if (workload_attach(index) < 0) {
 248:	8526                	mv	a0,s1
 24a:	031000ef          	jal	a7a <workload_attach>
    for (volatile int k = 0; k < 1000; k++)
 24e:	3e700913          	li	s2,999
  if (workload_attach(index) < 0) {
 252:	02054763          	bltz	a0,280 <main+0x152>
  while ((r = workload_checkpoint()) == 0)
 256:	035000ef          	jal	a8a <workload_checkpoint>
 25a:	ed0d                	bnez	a0,294 <main+0x166>
    for (volatile int k = 0; k < 1000; k++)
 25c:	f8042623          	sw	zero,-116(s0)
 260:	f8c42783          	lw	a5,-116(s0)
 264:	2781                	sext.w	a5,a5
 266:	fef948e3          	blt	s2,a5,256 <main+0x128>
 26a:	f8c42783          	lw	a5,-116(s0)
 26e:	2785                	addiw	a5,a5,1
 270:	f8f42623          	sw	a5,-116(s0)
 274:	f8c42783          	lw	a5,-116(s0)
 278:	2781                	sext.w	a5,a5
 27a:	fef958e3          	bge	s2,a5,26a <main+0x13c>
 27e:	bfe1                	j	256 <main+0x128>
    printf("wl: worker %d: attach failed\n", index);
 280:	85a6                	mv	a1,s1
 282:	00001517          	auipc	a0,0x1
 286:	e0e50513          	addi	a0,a0,-498 # 1090 <malloc+0x1a6>
 28a:	3ad000ef          	jal	e36 <printf>
    exit(1);
 28e:	4505                	li	a0,1
 290:	71a000ef          	jal	9aa <exit>
  exit(r == 1 ? 0 : 1);
 294:	157d                	addi	a0,a0,-1
 296:	00a03533          	snez	a0,a0
 29a:	710000ef          	jal	9aa <exit>
    if (i == 500) {
      printf("wl: workers never became ready\n");
      workload_stop();
      exit(1);
    }
    pause(1);
 29e:	4505                	li	a0,1
 2a0:	79a000ef          	jal	a3a <pause>
  for (i = 0; workload_start() < 0; i++) {
 2a4:	7de000ef          	jal	a82 <workload_start>
 2a8:	02055663          	bgez	a0,2d4 <main+0x1a6>
    if (i == 500) {
 2ac:	34fd                	addiw	s1,s1,-1
 2ae:	f8e5                	bnez	s1,29e <main+0x170>
 2b0:	e152                	sd	s4,128(sp)
 2b2:	fcd6                	sd	s5,120(sp)
 2b4:	f8da                	sd	s6,112(sp)
 2b6:	f4de                	sd	s7,104(sp)
 2b8:	ece6                	sd	s9,88(sp)
 2ba:	e8ea                	sd	s10,80(sp)
 2bc:	e4ee                	sd	s11,72(sp)
      printf("wl: workers never became ready\n");
 2be:	00001517          	auipc	a0,0x1
 2c2:	df250513          	addi	a0,a0,-526 # 10b0 <malloc+0x1c6>
 2c6:	371000ef          	jal	e36 <printf>
      workload_stop();
 2ca:	7c8000ef          	jal	a92 <workload_stop>
      exit(1);
 2ce:	4505                	li	a0,1
 2d0:	6da000ef          	jal	9aa <exit>
 2d4:	e152                	sd	s4,128(sp)
 2d6:	fcd6                	sd	s5,120(sp)
 2d8:	f8da                	sd	s6,112(sp)
 2da:	f4de                	sd	s7,104(sp)
 2dc:	ece6                	sd	s9,88(sp)
 2de:	e8ea                	sd	s10,80(sp)
 2e0:	e4ee                	sd	s11,72(sp)
  }

  for (i = 0; i < n; i++)
 2e2:	4481                	li	s1,0
 2e4:	a029                	j	2ee <main+0x1c0>
    wait(0);
 2e6:	4501                	li	a0,0
 2e8:	6ca000ef          	jal	9b2 <wait>
  for (i = 0; i < n; i++)
 2ec:	2485                	addiw	s1,s1,1
 2ee:	ff24cce3          	blt	s1,s2,2e6 <main+0x1b8>
 2f2:	00002997          	auipc	s3,0x2
 2f6:	d5e98993          	addi	s3,s3,-674 # 2050 <st>
 2fa:	8a4e                	mv	s4,s3

  for (i = 0; i < n; i++)
 2fc:	4481                	li	s1,0
 2fe:	a801                	j	30e <main+0x1e0>
    workload_stats(i, &st[i]);
 300:	85d2                	mv	a1,s4
 302:	8526                	mv	a0,s1
 304:	796000ef          	jal	a9a <workload_stats>
  for (i = 0; i < n; i++)
 308:	2485                	addiw	s1,s1,1
 30a:	05ca0a13          	addi	s4,s4,92
 30e:	ff24c9e3          	blt	s1,s2,300 <main+0x1d2>
  workload_stop();
 312:	780000ef          	jal	a92 <workload_stop>

  // Per-process results.
  printf("workload %d, scheduler %d, switch cost %d units\n", id,
 316:	00002b97          	auipc	s7,0x2
 31a:	cfab8b93          	addi	s7,s7,-774 # 2010 <pids>
 31e:	090ba683          	lw	a3,144(s7)
 322:	07cba603          	lw	a2,124(s7)
 326:	85e2                	mv	a1,s8
 328:	00001517          	auipc	a0,0x1
 32c:	da850513          	addi	a0,a0,-600 # 10d0 <malloc+0x1e6>
 330:	307000ef          	jal	e36 <printf>
         st[0].sched_id, st[0].switch_cost);
  // cpu is in ticks; ovh and resp are in ticks with two decimals.
  printf("job  pid nice  kind arrive first  done  turn   cpu    ovh   resp  "
 334:	00001517          	auipc	a0,0x1
 338:	dd450513          	addi	a0,a0,-556 # 1108 <malloc+0x21e>
 33c:	2fb000ef          	jal	e36 <printf>
         "rmax\n");
  for (i = 0; i < n; i++) {
 340:	8b4e                	mv	s6,s3
 342:	4a01                	li	s4,0
    struct wl_stats *s = &st[i];
    int turn = s->completion >= 0 ? s->completion - s->arrival : -1;
    printw(i, 3);
    printw(pids[i], 5);
    printw(s->nice, 5);
    printf(" %s", s->batch ? "batch" : "inter");
 344:	00001d97          	auipc	s11,0x1
 348:	e0cd8d93          	addi	s11,s11,-500 # 1150 <malloc+0x266>
    printw(s->arrival, 7);
    printw(s->first_run, 6);
    printw(s->completion, 6);
    printw(turn, 6);
    printw(s->cpu_units / TICK_UNITS, 6);
 34c:	06400d13          	li	s10,100
    if (s->resp_count > 0)
      print2w((uint64)s->resp_sum * 100 / s->resp_count, 7);
    else
      printw(-1, 7);
    printw(s->resp_max, 6);
    printf("\n");
 350:	00001c97          	auipc	s9,0x1
 354:	e08c8c93          	addi	s9,s9,-504 # 1158 <malloc+0x26e>
  for (i = 0; i < n; i++) {
 358:	a871                	j	3f4 <main+0x2c6>
    printf(" %s", s->batch ? "batch" : "inter");
 35a:	856e                	mv	a0,s11
 35c:	2db000ef          	jal	e36 <printf>
    printw(s->arrival, 7);
 360:	459d                	li	a1,7
 362:	48c8                	lw	a0,20(s1)
 364:	c9dff0ef          	jal	0 <printw>
    printw(s->first_run, 6);
 368:	4599                	li	a1,6
 36a:	4c88                	lw	a0,24(s1)
 36c:	c95ff0ef          	jal	0 <printw>
    printw(s->completion, 6);
 370:	4599                	li	a1,6
 372:	4cc8                	lw	a0,28(s1)
 374:	c8dff0ef          	jal	0 <printw>
    printw(turn, 6);
 378:	4599                	li	a1,6
 37a:	8556                	mv	a0,s5
 37c:	c85ff0ef          	jal	0 <printw>
    printw(s->cpu_units / TICK_UNITS, 6);
 380:	5088                	lw	a0,32(s1)
 382:	4599                	li	a1,6
 384:	03a5453b          	divw	a0,a0,s10
 388:	c79ff0ef          	jal	0 <printw>
    print2w(s->ovh_units, 7);
 38c:	459d                	li	a1,7
 38e:	50c8                	lw	a0,36(s1)
 390:	d21ff0ef          	jal	b0 <print2w>
    if (s->resp_count > 0)
 394:	589c                	lw	a5,48(s1)
 396:	0af05463          	blez	a5,43e <main+0x310>
      print2w((uint64)s->resp_sum * 100 / s->resp_count, 7);
 39a:	58c8                	lw	a0,52(s1)
 39c:	06400713          	li	a4,100
 3a0:	02e50533          	mul	a0,a0,a4
 3a4:	459d                	li	a1,7
 3a6:	02f55533          	divu	a0,a0,a5
 3aa:	d07ff0ef          	jal	b0 <print2w>
    printw(s->resp_max, 6);
 3ae:	4599                	li	a1,6
 3b0:	5c88                	lw	a0,56(s1)
 3b2:	c4fff0ef          	jal	0 <printw>
    printf("\n");
 3b6:	8566                	mv	a0,s9
 3b8:	27f000ef          	jal	e36 <printf>
    printf("CSV,job,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", i, s->nice,
 3bc:	5c9c                	lw	a5,56(s1)
 3be:	f03e                	sd	a5,32(sp)
 3c0:	58dc                	lw	a5,52(s1)
 3c2:	ec3e                	sd	a5,24(sp)
 3c4:	589c                	lw	a5,48(s1)
 3c6:	e83e                	sd	a5,16(sp)
 3c8:	50dc                	lw	a5,36(s1)
 3ca:	e43e                	sd	a5,8(sp)
 3cc:	509c                	lw	a5,32(s1)
 3ce:	e03e                	sd	a5,0(sp)
 3d0:	88d6                	mv	a7,s5
 3d2:	01c4a803          	lw	a6,28(s1)
 3d6:	4c9c                	lw	a5,24(s1)
 3d8:	48d8                	lw	a4,20(s1)
 3da:	4894                	lw	a3,16(s1)
 3dc:	4090                	lw	a2,0(s1)
 3de:	85d2                	mv	a1,s4
 3e0:	00001517          	auipc	a0,0x1
 3e4:	d8050513          	addi	a0,a0,-640 # 1160 <malloc+0x276>
 3e8:	24f000ef          	jal	e36 <printf>
  for (i = 0; i < n; i++) {
 3ec:	2a05                	addiw	s4,s4,1
 3ee:	05cb0b13          	addi	s6,s6,92
 3f2:	0b91                	addi	s7,s7,4
 3f4:	052a5a63          	bge	s4,s2,448 <main+0x31a>
    int turn = s->completion >= 0 ? s->completion - s->arrival : -1;
 3f8:	84da                	mv	s1,s6
 3fa:	01cb2783          	lw	a5,28(s6)
 3fe:	5afd                	li	s5,-1
 400:	0007c663          	bltz	a5,40c <main+0x2de>
 404:	014b2a83          	lw	s5,20(s6)
 408:	41578abb          	subw	s5,a5,s5
    printw(i, 3);
 40c:	458d                	li	a1,3
 40e:	8552                	mv	a0,s4
 410:	bf1ff0ef          	jal	0 <printw>
    printw(pids[i], 5);
 414:	4595                	li	a1,5
 416:	000ba503          	lw	a0,0(s7)
 41a:	be7ff0ef          	jal	0 <printw>
    printw(s->nice, 5);
 41e:	4595                	li	a1,5
 420:	4088                	lw	a0,0(s1)
 422:	bdfff0ef          	jal	0 <printw>
    printf(" %s", s->batch ? "batch" : "inter");
 426:	489c                	lw	a5,16(s1)
 428:	00001597          	auipc	a1,0x1
 42c:	be858593          	addi	a1,a1,-1048 # 1010 <malloc+0x126>
 430:	f20785e3          	beqz	a5,35a <main+0x22c>
 434:	00001597          	auipc	a1,0x1
 438:	bd458593          	addi	a1,a1,-1068 # 1008 <malloc+0x11e>
 43c:	bf39                	j	35a <main+0x22c>
      printw(-1, 7);
 43e:	459d                	li	a1,7
 440:	557d                	li	a0,-1
 442:	bbfff0ef          	jal	0 <printw>
 446:	b7a5                	j	3ae <main+0x280>
  // job. A burst becomes ready at arrival or when its I/O finishes.
  uint64 rsum = 0, rn = 0, rmax = 0;
  // Fairness: Jain's index over batch jobs' CPU inside the window
  // when all batch jobs are present, each divided by its weight.
  uint64 xsum = 0, x2sum = 0, xn = 0;
  uint64 ovh = 0;
 448:	4581                	li	a1,0
  uint64 xsum = 0, x2sum = 0, xn = 0;
 44a:	4e01                	li	t3,0
 44c:	4301                	li	t1,0
 44e:	4801                	li	a6,0
  uint64 rsum = 0, rn = 0, rmax = 0;
 450:	4a01                	li	s4,0
 452:	4481                	li	s1,0
 454:	4501                	li	a0,0
  uint64 tsum = 0, tn = 0;
 456:	4a81                	li	s5,0
 458:	4881                	li	a7,0

  for (i = 0; i < n; i++) {
 45a:	4701                	li	a4,0
    if (s->resp_max > rmax)
      rmax = s->resp_max;
    if (s->batch) {
      tsum += s->completion - s->arrival;
      tn++;
      uint64 x = (uint64)s->fair_units * 1024 / weight[s->nice + 20];
 45c:	00001e97          	auipc	t4,0x1
 460:	e74e8e93          	addi	t4,t4,-396 # 12d0 <weight>
 464:	a021                	j	46c <main+0x33e>
  for (i = 0; i < n; i++) {
 466:	2705                	addiw	a4,a4,1
 468:	05c98993          	addi	s3,s3,92
 46c:	05275763          	bge	a4,s2,4ba <main+0x38c>
    ovh += s->ovh_units;
 470:	864e                	mv	a2,s3
 472:	0249a783          	lw	a5,36(s3)
 476:	95be                	add	a1,a1,a5
    rsum += s->resp_sum;
 478:	0349a783          	lw	a5,52(s3)
 47c:	953e                	add	a0,a0,a5
    rn += s->resp_count;
 47e:	0309a783          	lw	a5,48(s3)
 482:	94be                	add	s1,s1,a5
    if (s->resp_max > rmax)
 484:	0389a783          	lw	a5,56(s3)
 488:	00fa7363          	bgeu	s4,a5,48e <main+0x360>
 48c:	8a3e                	mv	s4,a5
    if (s->batch) {
 48e:	4a1c                	lw	a5,16(a2)
 490:	dbf9                	beqz	a5,466 <main+0x338>
      tsum += s->completion - s->arrival;
 492:	4e5c                	lw	a5,28(a2)
 494:	4a54                	lw	a3,20(a2)
 496:	9f95                	subw	a5,a5,a3
 498:	98be                	add	a7,a7,a5
      tn++;
 49a:	0a85                	addi	s5,s5,1
      uint64 x = (uint64)s->fair_units * 1024 / weight[s->nice + 20];
 49c:	5614                	lw	a3,40(a2)
 49e:	06aa                	slli	a3,a3,0xa
 4a0:	421c                	lw	a5,0(a2)
 4a2:	27d1                	addiw	a5,a5,20
 4a4:	078a                	slli	a5,a5,0x2
 4a6:	97f6                	add	a5,a5,t4
 4a8:	439c                	lw	a5,0(a5)
 4aa:	02f6d6b3          	divu	a3,a3,a5
      xsum += x;
 4ae:	9836                	add	a6,a6,a3
      x2sum += x * x;
 4b0:	02d686b3          	mul	a3,a3,a3
 4b4:	9336                	add	t1,t1,a3
      xn++;
 4b6:	0e05                	addi	t3,t3,1
 4b8:	b77d                	j	466 <main+0x338>
    }
  }

  uint64 turn = tn ? tsum * 100 / tn : 0;
 4ba:	000a8863          	beqz	s5,4ca <main+0x39c>
 4be:	06400793          	li	a5,100
 4c2:	02f888b3          	mul	a7,a7,a5
 4c6:	0358dab3          	divu	s5,a7,s5
  uint64 resp = rn ? rsum * 100 / rn : 0;
 4ca:	c499                	beqz	s1,4d8 <main+0x3aa>
 4cc:	06400793          	li	a5,100
 4d0:	02f507b3          	mul	a5,a0,a5
 4d4:	0297d4b3          	divu	s1,a5,s1
  int havefair = st[0].fair_start >= 0 && st[0].fair_end >= 0 && x2sum;
 4d8:	00002717          	auipc	a4,0x2
 4dc:	b3870713          	addi	a4,a4,-1224 # 2010 <pids>
 4e0:	09472783          	lw	a5,148(a4)
 4e4:	09872703          	lw	a4,152(a4)
 4e8:	8fd9                	or	a5,a5,a4
 4ea:	1007cb63          	bltz	a5,600 <main+0x4d2>
 4ee:	10030963          	beqz	t1,600 <main+0x4d2>
  uint64 fair = havefair ? xsum * xsum * 1000 / (xn * x2sum) : 0;
 4f2:	03080833          	mul	a6,a6,a6
 4f6:	3e800793          	li	a5,1000
 4fa:	02f809b3          	mul	s3,a6,a5
 4fe:	03c30333          	mul	t1,t1,t3
 502:	0269d9b3          	divu	s3,s3,t1
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 506:	00002797          	auipc	a5,0x2
 50a:	b8e7a783          	lw	a5,-1138(a5) # 2094 <st+0x44>
 50e:	1c079363          	bnez	a5,6d4 <main+0x5a6>

  printf("turnaround (mean, batch jobs): ");
 512:	00001517          	auipc	a0,0x1
 516:	d2e50513          	addi	a0,a0,-722 # 1240 <malloc+0x356>
 51a:	11d000ef          	jal	e36 <printf>
  print2(turn);
 51e:	8556                	mv	a0,s5
 520:	b5dff0ef          	jal	7c <print2>
  printf(" ticks\nresponse (mean, all CPU bursts): ");
 524:	00001517          	auipc	a0,0x1
 528:	d3c50513          	addi	a0,a0,-708 # 1260 <malloc+0x376>
 52c:	10b000ef          	jal	e36 <printf>
  print2(resp);
 530:	8526                	mv	a0,s1
 532:	b4bff0ef          	jal	7c <print2>
  printf(" ticks, worst %d\nfairness (nice-weighted Jain): ", (int)rmax);
 536:	2a01                	sext.w	s4,s4
 538:	85d2                	mv	a1,s4
 53a:	00001517          	auipc	a0,0x1
 53e:	d5650513          	addi	a0,a0,-682 # 1290 <malloc+0x3a6>
 542:	0f5000ef          	jal	e36 <printf>
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 546:	4901                	li	s2,0
         (int)(v / 10 % 10), (int)(v % 10));
 548:	47a9                	li	a5,10
 54a:	02f9d6b3          	divu	a3,s3,a5
  printf("%d.%d%d%d", (int)(v / 1000), (int)(v / 100 % 10),
 54e:	06400613          	li	a2,100
 552:	02c9d633          	divu	a2,s3,a2
 556:	3e800593          	li	a1,1000
 55a:	02b9d5b3          	divu	a1,s3,a1
 55e:	02f9f733          	remu	a4,s3,a5
 562:	02f6f6b3          	remu	a3,a3,a5
 566:	02f67633          	remu	a2,a2,a5
 56a:	2581                	sext.w	a1,a1
 56c:	00001517          	auipc	a0,0x1
 570:	c2450513          	addi	a0,a0,-988 # 1190 <malloc+0x2a6>
 574:	0c3000ef          	jal	e36 <printf>
  if (havefair) {
    print3(fair);
    printf(" over ticks %d-%d\n", st[0].fair_start, st[0].fair_end);
 578:	00002b17          	auipc	s6,0x2
 57c:	a98b0b13          	addi	s6,s6,-1384 # 2010 <pids>
 580:	098b2603          	lw	a2,152(s6)
 584:	094b2583          	lw	a1,148(s6)
 588:	00001517          	auipc	a0,0x1
 58c:	c1850513          	addi	a0,a0,-1000 # 11a0 <malloc+0x2b6>
 590:	0a7000ef          	jal	e36 <printf>
  } else {
    printf("n/a\n");
  }
  printf("switch overhead: ");
 594:	00001517          	auipc	a0,0x1
 598:	c2450513          	addi	a0,a0,-988 # 11b8 <malloc+0x2ce>
 59c:	09b000ef          	jal	e36 <printf>
  print2(ovhpct);
 5a0:	854a                	mv	a0,s2
 5a2:	adbff0ef          	jal	7c <print2>
  printf("%% of busy time; total %d ticks, idle %d, other %d\n", st[0].end,
 5a6:	08cb2683          	lw	a3,140(s6)
 5aa:	088b2603          	lw	a2,136(s6)
 5ae:	080b2583          	lw	a1,128(s6)
 5b2:	00001517          	auipc	a0,0x1
 5b6:	c1e50513          	addi	a0,a0,-994 # 11d0 <malloc+0x2e6>
 5ba:	07d000ef          	jal	e36 <printf>
         st[0].idle_ticks, st[0].other_ticks);
  printf("CSV,summary,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", id, st[0].sched_id,
 5be:	07cb2603          	lw	a2,124(s6)
 5c2:	090b2683          	lw	a3,144(s6)
 5c6:	000a871b          	sext.w	a4,s5
 5ca:	0004879b          	sext.w	a5,s1
 5ce:	0009889b          	sext.w	a7,s3
 5d2:	00002597          	auipc	a1,0x2
 5d6:	a3e58593          	addi	a1,a1,-1474 # 2010 <pids>
 5da:	08c5a503          	lw	a0,140(a1)
 5de:	e82a                	sd	a0,16(sp)
 5e0:	0805a583          	lw	a1,128(a1)
 5e4:	e42e                	sd	a1,8(sp)
 5e6:	2901                	sext.w	s2,s2
 5e8:	e04a                	sd	s2,0(sp)
 5ea:	8852                	mv	a6,s4
 5ec:	85e2                	mv	a1,s8
 5ee:	00001517          	auipc	a0,0x1
 5f2:	c2250513          	addi	a0,a0,-990 # 1210 <malloc+0x326>
 5f6:	041000ef          	jal	e36 <printf>
         st[0].switch_cost, (int)turn, (int)resp, (int)rmax,
         havefair ? (int)fair : -1, (int)ovhpct, st[0].end,
         st[0].other_ticks);
  exit(0);
 5fa:	4501                	li	a0,0
 5fc:	3ae000ef          	jal	9aa <exit>
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 600:	00002797          	auipc	a5,0x2
 604:	a947a783          	lw	a5,-1388(a5) # 2094 <st+0x44>
 608:	e7c9                	bnez	a5,692 <main+0x564>
  printf("turnaround (mean, batch jobs): ");
 60a:	00001517          	auipc	a0,0x1
 60e:	c3650513          	addi	a0,a0,-970 # 1240 <malloc+0x356>
 612:	025000ef          	jal	e36 <printf>
  print2(turn);
 616:	8556                	mv	a0,s5
 618:	a65ff0ef          	jal	7c <print2>
  printf(" ticks\nresponse (mean, all CPU bursts): ");
 61c:	00001517          	auipc	a0,0x1
 620:	c4450513          	addi	a0,a0,-956 # 1260 <malloc+0x376>
 624:	013000ef          	jal	e36 <printf>
  print2(resp);
 628:	8526                	mv	a0,s1
 62a:	a53ff0ef          	jal	7c <print2>
  printf(" ticks, worst %d\nfairness (nice-weighted Jain): ", (int)rmax);
 62e:	2a01                	sext.w	s4,s4
 630:	85d2                	mv	a1,s4
 632:	00001517          	auipc	a0,0x1
 636:	c5e50513          	addi	a0,a0,-930 # 1290 <malloc+0x3a6>
 63a:	7fc000ef          	jal	e36 <printf>
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 63e:	4901                	li	s2,0
    printf("n/a\n");
 640:	00001517          	auipc	a0,0x1
 644:	bc850513          	addi	a0,a0,-1080 # 1208 <malloc+0x31e>
 648:	7ee000ef          	jal	e36 <printf>
  printf("switch overhead: ");
 64c:	00001517          	auipc	a0,0x1
 650:	b6c50513          	addi	a0,a0,-1172 # 11b8 <malloc+0x2ce>
 654:	7e2000ef          	jal	e36 <printf>
  print2(ovhpct);
 658:	854a                	mv	a0,s2
 65a:	a23ff0ef          	jal	7c <print2>
  printf("%% of busy time; total %d ticks, idle %d, other %d\n", st[0].end,
 65e:	00002997          	auipc	s3,0x2
 662:	9b298993          	addi	s3,s3,-1614 # 2010 <pids>
 666:	08c9a683          	lw	a3,140(s3)
 66a:	0889a603          	lw	a2,136(s3)
 66e:	0809a583          	lw	a1,128(s3)
 672:	00001517          	auipc	a0,0x1
 676:	b5e50513          	addi	a0,a0,-1186 # 11d0 <malloc+0x2e6>
 67a:	7bc000ef          	jal	e36 <printf>
  printf("CSV,summary,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", id, st[0].sched_id,
 67e:	07c9a603          	lw	a2,124(s3)
 682:	0909a683          	lw	a3,144(s3)
 686:	000a871b          	sext.w	a4,s5
 68a:	0004879b          	sext.w	a5,s1
 68e:	58fd                	li	a7,-1
 690:	b789                	j	5d2 <main+0x4a4>
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 692:	06400713          	li	a4,100
 696:	02e58733          	mul	a4,a1,a4
 69a:	02f75933          	divu	s2,a4,a5
  printf("turnaround (mean, batch jobs): ");
 69e:	00001517          	auipc	a0,0x1
 6a2:	ba250513          	addi	a0,a0,-1118 # 1240 <malloc+0x356>
 6a6:	790000ef          	jal	e36 <printf>
  print2(turn);
 6aa:	8556                	mv	a0,s5
 6ac:	9d1ff0ef          	jal	7c <print2>
  printf(" ticks\nresponse (mean, all CPU bursts): ");
 6b0:	00001517          	auipc	a0,0x1
 6b4:	bb050513          	addi	a0,a0,-1104 # 1260 <malloc+0x376>
 6b8:	77e000ef          	jal	e36 <printf>
  print2(resp);
 6bc:	8526                	mv	a0,s1
 6be:	9bfff0ef          	jal	7c <print2>
  printf(" ticks, worst %d\nfairness (nice-weighted Jain): ", (int)rmax);
 6c2:	2a01                	sext.w	s4,s4
 6c4:	85d2                	mv	a1,s4
 6c6:	00001517          	auipc	a0,0x1
 6ca:	bca50513          	addi	a0,a0,-1078 # 1290 <malloc+0x3a6>
 6ce:	768000ef          	jal	e36 <printf>
  if (havefair) {
 6d2:	b7bd                	j	640 <main+0x512>
  uint64 ovhpct = st[0].busy_ticks ? ovh * 100 / st[0].busy_ticks : 0;
 6d4:	06400713          	li	a4,100
 6d8:	02e585b3          	mul	a1,a1,a4
 6dc:	02f5d933          	divu	s2,a1,a5
  printf("turnaround (mean, batch jobs): ");
 6e0:	00001517          	auipc	a0,0x1
 6e4:	b6050513          	addi	a0,a0,-1184 # 1240 <malloc+0x356>
 6e8:	74e000ef          	jal	e36 <printf>
  print2(turn);
 6ec:	8556                	mv	a0,s5
 6ee:	98fff0ef          	jal	7c <print2>
  printf(" ticks\nresponse (mean, all CPU bursts): ");
 6f2:	00001517          	auipc	a0,0x1
 6f6:	b6e50513          	addi	a0,a0,-1170 # 1260 <malloc+0x376>
 6fa:	73c000ef          	jal	e36 <printf>
  print2(resp);
 6fe:	8526                	mv	a0,s1
 700:	97dff0ef          	jal	7c <print2>
  printf(" ticks, worst %d\nfairness (nice-weighted Jain): ", (int)rmax);
 704:	2a01                	sext.w	s4,s4
 706:	85d2                	mv	a1,s4
 708:	00001517          	auipc	a0,0x1
 70c:	b8850513          	addi	a0,a0,-1144 # 1290 <malloc+0x3a6>
 710:	726000ef          	jal	e36 <printf>
  if (havefair) {
 714:	bd15                	j	548 <main+0x41a>

0000000000000716 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 716:	1141                	addi	sp,sp,-16
 718:	e406                	sd	ra,8(sp)
 71a:	e022                	sd	s0,0(sp)
 71c:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 71e:	a11ff0ef          	jal	12e <main>
  exit(r);
 722:	288000ef          	jal	9aa <exit>

0000000000000726 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 726:	1141                	addi	sp,sp,-16
 728:	e422                	sd	s0,8(sp)
 72a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 72c:	87aa                	mv	a5,a0
 72e:	0585                	addi	a1,a1,1
 730:	0785                	addi	a5,a5,1
 732:	fff5c703          	lbu	a4,-1(a1)
 736:	fee78fa3          	sb	a4,-1(a5)
 73a:	fb75                	bnez	a4,72e <strcpy+0x8>
    ;
  return os;
}
 73c:	6422                	ld	s0,8(sp)
 73e:	0141                	addi	sp,sp,16
 740:	8082                	ret

0000000000000742 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 742:	1141                	addi	sp,sp,-16
 744:	e422                	sd	s0,8(sp)
 746:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 748:	00054783          	lbu	a5,0(a0)
 74c:	cb91                	beqz	a5,760 <strcmp+0x1e>
 74e:	0005c703          	lbu	a4,0(a1)
 752:	00f71763          	bne	a4,a5,760 <strcmp+0x1e>
    p++, q++;
 756:	0505                	addi	a0,a0,1
 758:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 75a:	00054783          	lbu	a5,0(a0)
 75e:	fbe5                	bnez	a5,74e <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 760:	0005c503          	lbu	a0,0(a1)
}
 764:	40a7853b          	subw	a0,a5,a0
 768:	6422                	ld	s0,8(sp)
 76a:	0141                	addi	sp,sp,16
 76c:	8082                	ret

000000000000076e <strlen>:

uint
strlen(const char *s)
{
 76e:	1141                	addi	sp,sp,-16
 770:	e422                	sd	s0,8(sp)
 772:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 774:	00054783          	lbu	a5,0(a0)
 778:	cf91                	beqz	a5,794 <strlen+0x26>
 77a:	0505                	addi	a0,a0,1
 77c:	87aa                	mv	a5,a0
 77e:	86be                	mv	a3,a5
 780:	0785                	addi	a5,a5,1
 782:	fff7c703          	lbu	a4,-1(a5)
 786:	ff65                	bnez	a4,77e <strlen+0x10>
 788:	40a6853b          	subw	a0,a3,a0
 78c:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 78e:	6422                	ld	s0,8(sp)
 790:	0141                	addi	sp,sp,16
 792:	8082                	ret
  for (n = 0; s[n]; n++)
 794:	4501                	li	a0,0
 796:	bfe5                	j	78e <strlen+0x20>

0000000000000798 <memset>:

void *
memset(void *dst, int c, uint n)
{
 798:	1141                	addi	sp,sp,-16
 79a:	e422                	sd	s0,8(sp)
 79c:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 79e:	ca19                	beqz	a2,7b4 <memset+0x1c>
 7a0:	87aa                	mv	a5,a0
 7a2:	1602                	slli	a2,a2,0x20
 7a4:	9201                	srli	a2,a2,0x20
 7a6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 7aa:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 7ae:	0785                	addi	a5,a5,1
 7b0:	fee79de3          	bne	a5,a4,7aa <memset+0x12>
  }
  return dst;
}
 7b4:	6422                	ld	s0,8(sp)
 7b6:	0141                	addi	sp,sp,16
 7b8:	8082                	ret

00000000000007ba <strchr>:

char *
strchr(const char *s, char c)
{
 7ba:	1141                	addi	sp,sp,-16
 7bc:	e422                	sd	s0,8(sp)
 7be:	0800                	addi	s0,sp,16
  for (; *s; s++)
 7c0:	00054783          	lbu	a5,0(a0)
 7c4:	cb99                	beqz	a5,7da <strchr+0x20>
    if (*s == c)
 7c6:	00f58763          	beq	a1,a5,7d4 <strchr+0x1a>
  for (; *s; s++)
 7ca:	0505                	addi	a0,a0,1
 7cc:	00054783          	lbu	a5,0(a0)
 7d0:	fbfd                	bnez	a5,7c6 <strchr+0xc>
      return (char *)s;
  return 0;
 7d2:	4501                	li	a0,0
}
 7d4:	6422                	ld	s0,8(sp)
 7d6:	0141                	addi	sp,sp,16
 7d8:	8082                	ret
  return 0;
 7da:	4501                	li	a0,0
 7dc:	bfe5                	j	7d4 <strchr+0x1a>

00000000000007de <gets>:

char *
gets(char *buf, int max)
{
 7de:	711d                	addi	sp,sp,-96
 7e0:	ec86                	sd	ra,88(sp)
 7e2:	e8a2                	sd	s0,80(sp)
 7e4:	e4a6                	sd	s1,72(sp)
 7e6:	e0ca                	sd	s2,64(sp)
 7e8:	fc4e                	sd	s3,56(sp)
 7ea:	f852                	sd	s4,48(sp)
 7ec:	f456                	sd	s5,40(sp)
 7ee:	f05a                	sd	s6,32(sp)
 7f0:	ec5e                	sd	s7,24(sp)
 7f2:	1080                	addi	s0,sp,96
 7f4:	8baa                	mv	s7,a0
 7f6:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 7f8:	892a                	mv	s2,a0
 7fa:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
 7fc:	4aa9                	li	s5,10
 7fe:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
 800:	89a6                	mv	s3,s1
 802:	2485                	addiw	s1,s1,1
 804:	0344d663          	bge	s1,s4,830 <gets+0x52>
    cc = read(0, &c, 1);
 808:	4605                	li	a2,1
 80a:	faf40593          	addi	a1,s0,-81
 80e:	4501                	li	a0,0
 810:	1b2000ef          	jal	9c2 <read>
    if (cc < 1)
 814:	00a05e63          	blez	a0,830 <gets+0x52>
    buf[i++] = c;
 818:	faf44783          	lbu	a5,-81(s0)
 81c:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 820:	01578763          	beq	a5,s5,82e <gets+0x50>
 824:	0905                	addi	s2,s2,1
 826:	fd679de3          	bne	a5,s6,800 <gets+0x22>
    buf[i++] = c;
 82a:	89a6                	mv	s3,s1
 82c:	a011                	j	830 <gets+0x52>
 82e:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 830:	99de                	add	s3,s3,s7
 832:	00098023          	sb	zero,0(s3)
  return buf;
}
 836:	855e                	mv	a0,s7
 838:	60e6                	ld	ra,88(sp)
 83a:	6446                	ld	s0,80(sp)
 83c:	64a6                	ld	s1,72(sp)
 83e:	6906                	ld	s2,64(sp)
 840:	79e2                	ld	s3,56(sp)
 842:	7a42                	ld	s4,48(sp)
 844:	7aa2                	ld	s5,40(sp)
 846:	7b02                	ld	s6,32(sp)
 848:	6be2                	ld	s7,24(sp)
 84a:	6125                	addi	sp,sp,96
 84c:	8082                	ret

000000000000084e <stat>:

int
stat(const char *n, struct stat *st)
{
 84e:	1101                	addi	sp,sp,-32
 850:	ec06                	sd	ra,24(sp)
 852:	e822                	sd	s0,16(sp)
 854:	e04a                	sd	s2,0(sp)
 856:	1000                	addi	s0,sp,32
 858:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 85a:	4581                	li	a1,0
 85c:	18e000ef          	jal	9ea <open>
  if (fd < 0)
 860:	02054263          	bltz	a0,884 <stat+0x36>
 864:	e426                	sd	s1,8(sp)
 866:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 868:	85ca                	mv	a1,s2
 86a:	198000ef          	jal	a02 <fstat>
 86e:	892a                	mv	s2,a0
  close(fd);
 870:	8526                	mv	a0,s1
 872:	160000ef          	jal	9d2 <close>
  return r;
 876:	64a2                	ld	s1,8(sp)
}
 878:	854a                	mv	a0,s2
 87a:	60e2                	ld	ra,24(sp)
 87c:	6442                	ld	s0,16(sp)
 87e:	6902                	ld	s2,0(sp)
 880:	6105                	addi	sp,sp,32
 882:	8082                	ret
    return -1;
 884:	597d                	li	s2,-1
 886:	bfcd                	j	878 <stat+0x2a>

0000000000000888 <atoi>:

int
atoi(const char *s)
{
 888:	1141                	addi	sp,sp,-16
 88a:	e422                	sd	s0,8(sp)
 88c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 88e:	00054683          	lbu	a3,0(a0)
 892:	fd06879b          	addiw	a5,a3,-48
 896:	0ff7f793          	zext.b	a5,a5
 89a:	4625                	li	a2,9
 89c:	02f66863          	bltu	a2,a5,8cc <atoi+0x44>
 8a0:	872a                	mv	a4,a0
  n = 0;
 8a2:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 8a4:	0705                	addi	a4,a4,1
 8a6:	0025179b          	slliw	a5,a0,0x2
 8aa:	9fa9                	addw	a5,a5,a0
 8ac:	0017979b          	slliw	a5,a5,0x1
 8b0:	9fb5                	addw	a5,a5,a3
 8b2:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 8b6:	00074683          	lbu	a3,0(a4)
 8ba:	fd06879b          	addiw	a5,a3,-48
 8be:	0ff7f793          	zext.b	a5,a5
 8c2:	fef671e3          	bgeu	a2,a5,8a4 <atoi+0x1c>
  return n;
}
 8c6:	6422                	ld	s0,8(sp)
 8c8:	0141                	addi	sp,sp,16
 8ca:	8082                	ret
  n = 0;
 8cc:	4501                	li	a0,0
 8ce:	bfe5                	j	8c6 <atoi+0x3e>

00000000000008d0 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 8d0:	1141                	addi	sp,sp,-16
 8d2:	e422                	sd	s0,8(sp)
 8d4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 8d6:	02b57463          	bgeu	a0,a1,8fe <memmove+0x2e>
    while (n-- > 0)
 8da:	00c05f63          	blez	a2,8f8 <memmove+0x28>
 8de:	1602                	slli	a2,a2,0x20
 8e0:	9201                	srli	a2,a2,0x20
 8e2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 8e6:	872a                	mv	a4,a0
      *dst++ = *src++;
 8e8:	0585                	addi	a1,a1,1
 8ea:	0705                	addi	a4,a4,1
 8ec:	fff5c683          	lbu	a3,-1(a1)
 8f0:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 8f4:	fef71ae3          	bne	a4,a5,8e8 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 8f8:	6422                	ld	s0,8(sp)
 8fa:	0141                	addi	sp,sp,16
 8fc:	8082                	ret
    dst += n;
 8fe:	00c50733          	add	a4,a0,a2
    src += n;
 902:	95b2                	add	a1,a1,a2
    while (n-- > 0)
 904:	fec05ae3          	blez	a2,8f8 <memmove+0x28>
 908:	fff6079b          	addiw	a5,a2,-1
 90c:	1782                	slli	a5,a5,0x20
 90e:	9381                	srli	a5,a5,0x20
 910:	fff7c793          	not	a5,a5
 914:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 916:	15fd                	addi	a1,a1,-1
 918:	177d                	addi	a4,a4,-1
 91a:	0005c683          	lbu	a3,0(a1)
 91e:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 922:	fee79ae3          	bne	a5,a4,916 <memmove+0x46>
 926:	bfc9                	j	8f8 <memmove+0x28>

0000000000000928 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 928:	1141                	addi	sp,sp,-16
 92a:	e422                	sd	s0,8(sp)
 92c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 92e:	ca05                	beqz	a2,95e <memcmp+0x36>
 930:	fff6069b          	addiw	a3,a2,-1
 934:	1682                	slli	a3,a3,0x20
 936:	9281                	srli	a3,a3,0x20
 938:	0685                	addi	a3,a3,1
 93a:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 93c:	00054783          	lbu	a5,0(a0)
 940:	0005c703          	lbu	a4,0(a1)
 944:	00e79863          	bne	a5,a4,954 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 948:	0505                	addi	a0,a0,1
    p2++;
 94a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 94c:	fed518e3          	bne	a0,a3,93c <memcmp+0x14>
  }
  return 0;
 950:	4501                	li	a0,0
 952:	a019                	j	958 <memcmp+0x30>
      return *p1 - *p2;
 954:	40e7853b          	subw	a0,a5,a4
}
 958:	6422                	ld	s0,8(sp)
 95a:	0141                	addi	sp,sp,16
 95c:	8082                	ret
  return 0;
 95e:	4501                	li	a0,0
 960:	bfe5                	j	958 <memcmp+0x30>

0000000000000962 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 962:	1141                	addi	sp,sp,-16
 964:	e406                	sd	ra,8(sp)
 966:	e022                	sd	s0,0(sp)
 968:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 96a:	f67ff0ef          	jal	8d0 <memmove>
}
 96e:	60a2                	ld	ra,8(sp)
 970:	6402                	ld	s0,0(sp)
 972:	0141                	addi	sp,sp,16
 974:	8082                	ret

0000000000000976 <sbrk>:

char *
sbrk(int n)
{
 976:	1141                	addi	sp,sp,-16
 978:	e406                	sd	ra,8(sp)
 97a:	e022                	sd	s0,0(sp)
 97c:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 97e:	4585                	li	a1,1
 980:	0b2000ef          	jal	a32 <sys_sbrk>
}
 984:	60a2                	ld	ra,8(sp)
 986:	6402                	ld	s0,0(sp)
 988:	0141                	addi	sp,sp,16
 98a:	8082                	ret

000000000000098c <sbrklazy>:

char *
sbrklazy(int n)
{
 98c:	1141                	addi	sp,sp,-16
 98e:	e406                	sd	ra,8(sp)
 990:	e022                	sd	s0,0(sp)
 992:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 994:	4589                	li	a1,2
 996:	09c000ef          	jal	a32 <sys_sbrk>
}
 99a:	60a2                	ld	ra,8(sp)
 99c:	6402                	ld	s0,0(sp)
 99e:	0141                	addi	sp,sp,16
 9a0:	8082                	ret

00000000000009a2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 9a2:	4885                	li	a7,1
 ecall
 9a4:	00000073          	ecall
 ret
 9a8:	8082                	ret

00000000000009aa <exit>:
.global exit
exit:
 li a7, SYS_exit
 9aa:	4889                	li	a7,2
 ecall
 9ac:	00000073          	ecall
 ret
 9b0:	8082                	ret

00000000000009b2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 9b2:	488d                	li	a7,3
 ecall
 9b4:	00000073          	ecall
 ret
 9b8:	8082                	ret

00000000000009ba <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 9ba:	4891                	li	a7,4
 ecall
 9bc:	00000073          	ecall
 ret
 9c0:	8082                	ret

00000000000009c2 <read>:
.global read
read:
 li a7, SYS_read
 9c2:	4895                	li	a7,5
 ecall
 9c4:	00000073          	ecall
 ret
 9c8:	8082                	ret

00000000000009ca <write>:
.global write
write:
 li a7, SYS_write
 9ca:	48c1                	li	a7,16
 ecall
 9cc:	00000073          	ecall
 ret
 9d0:	8082                	ret

00000000000009d2 <close>:
.global close
close:
 li a7, SYS_close
 9d2:	48d5                	li	a7,21
 ecall
 9d4:	00000073          	ecall
 ret
 9d8:	8082                	ret

00000000000009da <kill>:
.global kill
kill:
 li a7, SYS_kill
 9da:	4899                	li	a7,6
 ecall
 9dc:	00000073          	ecall
 ret
 9e0:	8082                	ret

00000000000009e2 <exec>:
.global exec
exec:
 li a7, SYS_exec
 9e2:	489d                	li	a7,7
 ecall
 9e4:	00000073          	ecall
 ret
 9e8:	8082                	ret

00000000000009ea <open>:
.global open
open:
 li a7, SYS_open
 9ea:	48bd                	li	a7,15
 ecall
 9ec:	00000073          	ecall
 ret
 9f0:	8082                	ret

00000000000009f2 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 9f2:	48c5                	li	a7,17
 ecall
 9f4:	00000073          	ecall
 ret
 9f8:	8082                	ret

00000000000009fa <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 9fa:	48c9                	li	a7,18
 ecall
 9fc:	00000073          	ecall
 ret
 a00:	8082                	ret

0000000000000a02 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 a02:	48a1                	li	a7,8
 ecall
 a04:	00000073          	ecall
 ret
 a08:	8082                	ret

0000000000000a0a <link>:
.global link
link:
 li a7, SYS_link
 a0a:	48cd                	li	a7,19
 ecall
 a0c:	00000073          	ecall
 ret
 a10:	8082                	ret

0000000000000a12 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 a12:	48d1                	li	a7,20
 ecall
 a14:	00000073          	ecall
 ret
 a18:	8082                	ret

0000000000000a1a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 a1a:	48a5                	li	a7,9
 ecall
 a1c:	00000073          	ecall
 ret
 a20:	8082                	ret

0000000000000a22 <dup>:
.global dup
dup:
 li a7, SYS_dup
 a22:	48a9                	li	a7,10
 ecall
 a24:	00000073          	ecall
 ret
 a28:	8082                	ret

0000000000000a2a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 a2a:	48ad                	li	a7,11
 ecall
 a2c:	00000073          	ecall
 ret
 a30:	8082                	ret

0000000000000a32 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 a32:	48b1                	li	a7,12
 ecall
 a34:	00000073          	ecall
 ret
 a38:	8082                	ret

0000000000000a3a <pause>:
.global pause
pause:
 li a7, SYS_pause
 a3a:	48b5                	li	a7,13
 ecall
 a3c:	00000073          	ecall
 ret
 a40:	8082                	ret

0000000000000a42 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 a42:	48b9                	li	a7,14
 ecall
 a44:	00000073          	ecall
 ret
 a48:	8082                	ret

0000000000000a4a <sync>:
.global sync
sync:
 li a7, SYS_sync
 a4a:	48d9                	li	a7,22
 ecall
 a4c:	00000073          	ecall
 ret
 a50:	8082                	ret

0000000000000a52 <startLogging>:
.global startLogging
startLogging:
 li a7, SYS_startLogging
 a52:	48dd                	li	a7,23
 ecall
 a54:	00000073          	ecall
 ret
 a58:	8082                	ret

0000000000000a5a <stopLogging>:
.global stopLogging
stopLogging:
 li a7, SYS_stopLogging
 a5a:	48e1                	li	a7,24
 ecall
 a5c:	00000073          	ecall
 ret
 a60:	8082                	ret

0000000000000a62 <nice>:
.global nice
nice:
 li a7, SYS_nice
 a62:	48e5                	li	a7,25
 ecall
 a64:	00000073          	ecall
 ret
 a68:	8082                	ret

0000000000000a6a <workload_load>:
.global workload_load
workload_load:
 li a7, SYS_workload_load
 a6a:	48e9                	li	a7,26
 ecall
 a6c:	00000073          	ecall
 ret
 a70:	8082                	ret

0000000000000a72 <workload_process_count>:
.global workload_process_count
workload_process_count:
 li a7, SYS_workload_process_count
 a72:	48ed                	li	a7,27
 ecall
 a74:	00000073          	ecall
 ret
 a78:	8082                	ret

0000000000000a7a <workload_attach>:
.global workload_attach
workload_attach:
 li a7, SYS_workload_attach
 a7a:	48f1                	li	a7,28
 ecall
 a7c:	00000073          	ecall
 ret
 a80:	8082                	ret

0000000000000a82 <workload_start>:
.global workload_start
workload_start:
 li a7, SYS_workload_start
 a82:	48f5                	li	a7,29
 ecall
 a84:	00000073          	ecall
 ret
 a88:	8082                	ret

0000000000000a8a <workload_checkpoint>:
.global workload_checkpoint
workload_checkpoint:
 li a7, SYS_workload_checkpoint
 a8a:	48f9                	li	a7,30
 ecall
 a8c:	00000073          	ecall
 ret
 a90:	8082                	ret

0000000000000a92 <workload_stop>:
.global workload_stop
workload_stop:
 li a7, SYS_workload_stop
 a92:	48fd                	li	a7,31
 ecall
 a94:	00000073          	ecall
 ret
 a98:	8082                	ret

0000000000000a9a <workload_stats>:
.global workload_stats
workload_stats:
 li a7, SYS_workload_stats
 a9a:	02000893          	li	a7,32
 ecall
 a9e:	00000073          	ecall
 ret
 aa2:	8082                	ret

0000000000000aa4 <set_scheduler>:
.global set_scheduler
set_scheduler:
 li a7, SYS_set_scheduler
 aa4:	02100893          	li	a7,33
 ecall
 aa8:	00000073          	ecall
 ret
 aac:	8082                	ret

0000000000000aae <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 aae:	1101                	addi	sp,sp,-32
 ab0:	ec06                	sd	ra,24(sp)
 ab2:	e822                	sd	s0,16(sp)
 ab4:	1000                	addi	s0,sp,32
 ab6:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 aba:	4605                	li	a2,1
 abc:	fef40593          	addi	a1,s0,-17
 ac0:	f0bff0ef          	jal	9ca <write>
}
 ac4:	60e2                	ld	ra,24(sp)
 ac6:	6442                	ld	s0,16(sp)
 ac8:	6105                	addi	sp,sp,32
 aca:	8082                	ret

0000000000000acc <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 acc:	715d                	addi	sp,sp,-80
 ace:	e486                	sd	ra,72(sp)
 ad0:	e0a2                	sd	s0,64(sp)
 ad2:	f84a                	sd	s2,48(sp)
 ad4:	0880                	addi	s0,sp,80
 ad6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 ad8:	c299                	beqz	a3,ade <printint+0x12>
 ada:	0805c363          	bltz	a1,b60 <printint+0x94>
  neg = 0;
 ade:	4881                	li	a7,0
 ae0:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 ae4:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
 ae6:	00001517          	auipc	a0,0x1
 aea:	88a50513          	addi	a0,a0,-1910 # 1370 <digits>
 aee:	883e                	mv	a6,a5
 af0:	2785                	addiw	a5,a5,1
 af2:	02c5f733          	remu	a4,a1,a2
 af6:	972a                	add	a4,a4,a0
 af8:	00074703          	lbu	a4,0(a4)
 afc:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
 b00:	872e                	mv	a4,a1
 b02:	02c5d5b3          	divu	a1,a1,a2
 b06:	0685                	addi	a3,a3,1
 b08:	fec773e3          	bgeu	a4,a2,aee <printint+0x22>
  if (neg)
 b0c:	00088b63          	beqz	a7,b22 <printint+0x56>
    buf[i++] = '-';
 b10:	fd078793          	addi	a5,a5,-48
 b14:	97a2                	add	a5,a5,s0
 b16:	02d00713          	li	a4,45
 b1a:	fee78423          	sb	a4,-24(a5)
 b1e:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
 b22:	02f05a63          	blez	a5,b56 <printint+0x8a>
 b26:	fc26                	sd	s1,56(sp)
 b28:	f44e                	sd	s3,40(sp)
 b2a:	fb840713          	addi	a4,s0,-72
 b2e:	00f704b3          	add	s1,a4,a5
 b32:	fff70993          	addi	s3,a4,-1
 b36:	99be                	add	s3,s3,a5
 b38:	37fd                	addiw	a5,a5,-1
 b3a:	1782                	slli	a5,a5,0x20
 b3c:	9381                	srli	a5,a5,0x20
 b3e:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 b42:	fff4c583          	lbu	a1,-1(s1)
 b46:	854a                	mv	a0,s2
 b48:	f67ff0ef          	jal	aae <putc>
  while (--i >= 0)
 b4c:	14fd                	addi	s1,s1,-1
 b4e:	ff349ae3          	bne	s1,s3,b42 <printint+0x76>
 b52:	74e2                	ld	s1,56(sp)
 b54:	79a2                	ld	s3,40(sp)
}
 b56:	60a6                	ld	ra,72(sp)
 b58:	6406                	ld	s0,64(sp)
 b5a:	7942                	ld	s2,48(sp)
 b5c:	6161                	addi	sp,sp,80
 b5e:	8082                	ret
    x = -xx;
 b60:	40b005b3          	neg	a1,a1
    neg = 1;
 b64:	4885                	li	a7,1
    x = -xx;
 b66:	bfad                	j	ae0 <printint+0x14>

0000000000000b68 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 b68:	711d                	addi	sp,sp,-96
 b6a:	ec86                	sd	ra,88(sp)
 b6c:	e8a2                	sd	s0,80(sp)
 b6e:	e0ca                	sd	s2,64(sp)
 b70:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 b72:	0005c903          	lbu	s2,0(a1)
 b76:	28090663          	beqz	s2,e02 <vprintf+0x29a>
 b7a:	e4a6                	sd	s1,72(sp)
 b7c:	fc4e                	sd	s3,56(sp)
 b7e:	f852                	sd	s4,48(sp)
 b80:	f456                	sd	s5,40(sp)
 b82:	f05a                	sd	s6,32(sp)
 b84:	ec5e                	sd	s7,24(sp)
 b86:	e862                	sd	s8,16(sp)
 b88:	e466                	sd	s9,8(sp)
 b8a:	8b2a                	mv	s6,a0
 b8c:	8a2e                	mv	s4,a1
 b8e:	8bb2                	mv	s7,a2
  state = 0;
 b90:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 b92:	4481                	li	s1,0
 b94:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 b96:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 b9a:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 b9e:	06c00c93          	li	s9,108
 ba2:	a005                	j	bc2 <vprintf+0x5a>
        putc(fd, c0);
 ba4:	85ca                	mv	a1,s2
 ba6:	855a                	mv	a0,s6
 ba8:	f07ff0ef          	jal	aae <putc>
 bac:	a019                	j	bb2 <vprintf+0x4a>
    } else if (state == '%') {
 bae:	03598263          	beq	s3,s5,bd2 <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
 bb2:	2485                	addiw	s1,s1,1
 bb4:	8726                	mv	a4,s1
 bb6:	009a07b3          	add	a5,s4,s1
 bba:	0007c903          	lbu	s2,0(a5)
 bbe:	22090a63          	beqz	s2,df2 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 bc2:	0009079b          	sext.w	a5,s2
    if (state == 0) {
 bc6:	fe0994e3          	bnez	s3,bae <vprintf+0x46>
      if (c0 == '%') {
 bca:	fd579de3          	bne	a5,s5,ba4 <vprintf+0x3c>
        state = '%';
 bce:	89be                	mv	s3,a5
 bd0:	b7cd                	j	bb2 <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
 bd2:	00ea06b3          	add	a3,s4,a4
 bd6:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 bda:	8636                	mv	a2,a3
      if (c1)
 bdc:	c681                	beqz	a3,be4 <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
 bde:	9752                	add	a4,a4,s4
 be0:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
 be4:	05878363          	beq	a5,s8,c2a <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
 be8:	05978d63          	beq	a5,s9,c42 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 bec:	07500713          	li	a4,117
 bf0:	0ee78763          	beq	a5,a4,cde <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 bf4:	07800713          	li	a4,120
 bf8:	12e78963          	beq	a5,a4,d2a <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 bfc:	07000713          	li	a4,112
 c00:	14e78e63          	beq	a5,a4,d5c <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 c04:	06300713          	li	a4,99
 c08:	18e78e63          	beq	a5,a4,da4 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 c0c:	07300713          	li	a4,115
 c10:	1ae78463          	beq	a5,a4,db8 <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 c14:	02500713          	li	a4,37
 c18:	04e79563          	bne	a5,a4,c62 <vprintf+0xfa>
        putc(fd, '%');
 c1c:	02500593          	li	a1,37
 c20:	855a                	mv	a0,s6
 c22:	e8dff0ef          	jal	aae <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 c26:	4981                	li	s3,0
 c28:	b769                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 c2a:	008b8913          	addi	s2,s7,8
 c2e:	4685                	li	a3,1
 c30:	4629                	li	a2,10
 c32:	000ba583          	lw	a1,0(s7)
 c36:	855a                	mv	a0,s6
 c38:	e95ff0ef          	jal	acc <printint>
 c3c:	8bca                	mv	s7,s2
      state = 0;
 c3e:	4981                	li	s3,0
 c40:	bf8d                	j	bb2 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
 c42:	06400793          	li	a5,100
 c46:	02f68963          	beq	a3,a5,c78 <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 c4a:	06c00793          	li	a5,108
 c4e:	04f68263          	beq	a3,a5,c92 <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
 c52:	07500793          	li	a5,117
 c56:	0af68063          	beq	a3,a5,cf6 <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
 c5a:	07800793          	li	a5,120
 c5e:	0ef68263          	beq	a3,a5,d42 <vprintf+0x1da>
        putc(fd, '%');
 c62:	02500593          	li	a1,37
 c66:	855a                	mv	a0,s6
 c68:	e47ff0ef          	jal	aae <putc>
        putc(fd, c0);
 c6c:	85ca                	mv	a1,s2
 c6e:	855a                	mv	a0,s6
 c70:	e3fff0ef          	jal	aae <putc>
      state = 0;
 c74:	4981                	li	s3,0
 c76:	bf35                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 c78:	008b8913          	addi	s2,s7,8
 c7c:	4685                	li	a3,1
 c7e:	4629                	li	a2,10
 c80:	000bb583          	ld	a1,0(s7)
 c84:	855a                	mv	a0,s6
 c86:	e47ff0ef          	jal	acc <printint>
        i += 1;
 c8a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 c8c:	8bca                	mv	s7,s2
      state = 0;
 c8e:	4981                	li	s3,0
        i += 1;
 c90:	b70d                	j	bb2 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 c92:	06400793          	li	a5,100
 c96:	02f60763          	beq	a2,a5,cc4 <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 c9a:	07500793          	li	a5,117
 c9e:	06f60963          	beq	a2,a5,d10 <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 ca2:	07800793          	li	a5,120
 ca6:	faf61ee3          	bne	a2,a5,c62 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 caa:	008b8913          	addi	s2,s7,8
 cae:	4681                	li	a3,0
 cb0:	4641                	li	a2,16
 cb2:	000bb583          	ld	a1,0(s7)
 cb6:	855a                	mv	a0,s6
 cb8:	e15ff0ef          	jal	acc <printint>
        i += 2;
 cbc:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 cbe:	8bca                	mv	s7,s2
      state = 0;
 cc0:	4981                	li	s3,0
        i += 2;
 cc2:	bdc5                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 cc4:	008b8913          	addi	s2,s7,8
 cc8:	4685                	li	a3,1
 cca:	4629                	li	a2,10
 ccc:	000bb583          	ld	a1,0(s7)
 cd0:	855a                	mv	a0,s6
 cd2:	dfbff0ef          	jal	acc <printint>
        i += 2;
 cd6:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 cd8:	8bca                	mv	s7,s2
      state = 0;
 cda:	4981                	li	s3,0
        i += 2;
 cdc:	bdd9                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 cde:	008b8913          	addi	s2,s7,8
 ce2:	4681                	li	a3,0
 ce4:	4629                	li	a2,10
 ce6:	000be583          	lwu	a1,0(s7)
 cea:	855a                	mv	a0,s6
 cec:	de1ff0ef          	jal	acc <printint>
 cf0:	8bca                	mv	s7,s2
      state = 0;
 cf2:	4981                	li	s3,0
 cf4:	bd7d                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 cf6:	008b8913          	addi	s2,s7,8
 cfa:	4681                	li	a3,0
 cfc:	4629                	li	a2,10
 cfe:	000bb583          	ld	a1,0(s7)
 d02:	855a                	mv	a0,s6
 d04:	dc9ff0ef          	jal	acc <printint>
        i += 1;
 d08:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 d0a:	8bca                	mv	s7,s2
      state = 0;
 d0c:	4981                	li	s3,0
        i += 1;
 d0e:	b555                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 d10:	008b8913          	addi	s2,s7,8
 d14:	4681                	li	a3,0
 d16:	4629                	li	a2,10
 d18:	000bb583          	ld	a1,0(s7)
 d1c:	855a                	mv	a0,s6
 d1e:	dafff0ef          	jal	acc <printint>
        i += 2;
 d22:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 d24:	8bca                	mv	s7,s2
      state = 0;
 d26:	4981                	li	s3,0
        i += 2;
 d28:	b569                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 d2a:	008b8913          	addi	s2,s7,8
 d2e:	4681                	li	a3,0
 d30:	4641                	li	a2,16
 d32:	000be583          	lwu	a1,0(s7)
 d36:	855a                	mv	a0,s6
 d38:	d95ff0ef          	jal	acc <printint>
 d3c:	8bca                	mv	s7,s2
      state = 0;
 d3e:	4981                	li	s3,0
 d40:	bd8d                	j	bb2 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 d42:	008b8913          	addi	s2,s7,8
 d46:	4681                	li	a3,0
 d48:	4641                	li	a2,16
 d4a:	000bb583          	ld	a1,0(s7)
 d4e:	855a                	mv	a0,s6
 d50:	d7dff0ef          	jal	acc <printint>
        i += 1;
 d54:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 d56:	8bca                	mv	s7,s2
      state = 0;
 d58:	4981                	li	s3,0
        i += 1;
 d5a:	bda1                	j	bb2 <vprintf+0x4a>
 d5c:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 d5e:	008b8d13          	addi	s10,s7,8
 d62:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 d66:	03000593          	li	a1,48
 d6a:	855a                	mv	a0,s6
 d6c:	d43ff0ef          	jal	aae <putc>
  putc(fd, 'x');
 d70:	07800593          	li	a1,120
 d74:	855a                	mv	a0,s6
 d76:	d39ff0ef          	jal	aae <putc>
 d7a:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d7c:	00000b97          	auipc	s7,0x0
 d80:	5f4b8b93          	addi	s7,s7,1524 # 1370 <digits>
 d84:	03c9d793          	srli	a5,s3,0x3c
 d88:	97de                	add	a5,a5,s7
 d8a:	0007c583          	lbu	a1,0(a5)
 d8e:	855a                	mv	a0,s6
 d90:	d1fff0ef          	jal	aae <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d94:	0992                	slli	s3,s3,0x4
 d96:	397d                	addiw	s2,s2,-1
 d98:	fe0916e3          	bnez	s2,d84 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 d9c:	8bea                	mv	s7,s10
      state = 0;
 d9e:	4981                	li	s3,0
 da0:	6d02                	ld	s10,0(sp)
 da2:	bd01                	j	bb2 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 da4:	008b8913          	addi	s2,s7,8
 da8:	000bc583          	lbu	a1,0(s7)
 dac:	855a                	mv	a0,s6
 dae:	d01ff0ef          	jal	aae <putc>
 db2:	8bca                	mv	s7,s2
      state = 0;
 db4:	4981                	li	s3,0
 db6:	bbf5                	j	bb2 <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
 db8:	008b8993          	addi	s3,s7,8
 dbc:	000bb903          	ld	s2,0(s7)
 dc0:	00090f63          	beqz	s2,dde <vprintf+0x276>
        for (; *s; s++)
 dc4:	00094583          	lbu	a1,0(s2)
 dc8:	c195                	beqz	a1,dec <vprintf+0x284>
          putc(fd, *s);
 dca:	855a                	mv	a0,s6
 dcc:	ce3ff0ef          	jal	aae <putc>
        for (; *s; s++)
 dd0:	0905                	addi	s2,s2,1
 dd2:	00094583          	lbu	a1,0(s2)
 dd6:	f9f5                	bnez	a1,dca <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 dd8:	8bce                	mv	s7,s3
      state = 0;
 dda:	4981                	li	s3,0
 ddc:	bbd9                	j	bb2 <vprintf+0x4a>
          s = "(null)";
 dde:	00000917          	auipc	s2,0x0
 de2:	4ea90913          	addi	s2,s2,1258 # 12c8 <malloc+0x3de>
        for (; *s; s++)
 de6:	02800593          	li	a1,40
 dea:	b7c5                	j	dca <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 dec:	8bce                	mv	s7,s3
      state = 0;
 dee:	4981                	li	s3,0
 df0:	b3c9                	j	bb2 <vprintf+0x4a>
 df2:	64a6                	ld	s1,72(sp)
 df4:	79e2                	ld	s3,56(sp)
 df6:	7a42                	ld	s4,48(sp)
 df8:	7aa2                	ld	s5,40(sp)
 dfa:	7b02                	ld	s6,32(sp)
 dfc:	6be2                	ld	s7,24(sp)
 dfe:	6c42                	ld	s8,16(sp)
 e00:	6ca2                	ld	s9,8(sp)
    }
  }
}
 e02:	60e6                	ld	ra,88(sp)
 e04:	6446                	ld	s0,80(sp)
 e06:	6906                	ld	s2,64(sp)
 e08:	6125                	addi	sp,sp,96
 e0a:	8082                	ret

0000000000000e0c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 e0c:	715d                	addi	sp,sp,-80
 e0e:	ec06                	sd	ra,24(sp)
 e10:	e822                	sd	s0,16(sp)
 e12:	1000                	addi	s0,sp,32
 e14:	e010                	sd	a2,0(s0)
 e16:	e414                	sd	a3,8(s0)
 e18:	e818                	sd	a4,16(s0)
 e1a:	ec1c                	sd	a5,24(s0)
 e1c:	03043023          	sd	a6,32(s0)
 e20:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 e24:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 e28:	8622                	mv	a2,s0
 e2a:	d3fff0ef          	jal	b68 <vprintf>
}
 e2e:	60e2                	ld	ra,24(sp)
 e30:	6442                	ld	s0,16(sp)
 e32:	6161                	addi	sp,sp,80
 e34:	8082                	ret

0000000000000e36 <printf>:

void
printf(const char *fmt, ...)
{
 e36:	711d                	addi	sp,sp,-96
 e38:	ec06                	sd	ra,24(sp)
 e3a:	e822                	sd	s0,16(sp)
 e3c:	1000                	addi	s0,sp,32
 e3e:	e40c                	sd	a1,8(s0)
 e40:	e810                	sd	a2,16(s0)
 e42:	ec14                	sd	a3,24(s0)
 e44:	f018                	sd	a4,32(s0)
 e46:	f41c                	sd	a5,40(s0)
 e48:	03043823          	sd	a6,48(s0)
 e4c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 e50:	00840613          	addi	a2,s0,8
 e54:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 e58:	85aa                	mv	a1,a0
 e5a:	4505                	li	a0,1
 e5c:	d0dff0ef          	jal	b68 <vprintf>
}
 e60:	60e2                	ld	ra,24(sp)
 e62:	6442                	ld	s0,16(sp)
 e64:	6125                	addi	sp,sp,96
 e66:	8082                	ret

0000000000000e68 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 e68:	1141                	addi	sp,sp,-16
 e6a:	e422                	sd	s0,8(sp)
 e6c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 e6e:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 e72:	00001797          	auipc	a5,0x1
 e76:	18e7b783          	ld	a5,398(a5) # 2000 <freep>
 e7a:	a02d                	j	ea4 <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
 e7c:	4618                	lw	a4,8(a2)
 e7e:	9f2d                	addw	a4,a4,a1
 e80:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 e84:	6398                	ld	a4,0(a5)
 e86:	6310                	ld	a2,0(a4)
 e88:	a83d                	j	ec6 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
 e8a:	ff852703          	lw	a4,-8(a0)
 e8e:	9f31                	addw	a4,a4,a2
 e90:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 e92:	ff053683          	ld	a3,-16(a0)
 e96:	a091                	j	eda <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 e98:	6398                	ld	a4,0(a5)
 e9a:	00e7e463          	bltu	a5,a4,ea2 <free+0x3a>
 e9e:	00e6ea63          	bltu	a3,a4,eb2 <free+0x4a>
{
 ea2:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ea4:	fed7fae3          	bgeu	a5,a3,e98 <free+0x30>
 ea8:	6398                	ld	a4,0(a5)
 eaa:	00e6e463          	bltu	a3,a4,eb2 <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 eae:	fee7eae3          	bltu	a5,a4,ea2 <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
 eb2:	ff852583          	lw	a1,-8(a0)
 eb6:	6390                	ld	a2,0(a5)
 eb8:	02059813          	slli	a6,a1,0x20
 ebc:	01c85713          	srli	a4,a6,0x1c
 ec0:	9736                	add	a4,a4,a3
 ec2:	fae60de3          	beq	a2,a4,e7c <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 ec6:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
 eca:	4790                	lw	a2,8(a5)
 ecc:	02061593          	slli	a1,a2,0x20
 ed0:	01c5d713          	srli	a4,a1,0x1c
 ed4:	973e                	add	a4,a4,a5
 ed6:	fae68ae3          	beq	a3,a4,e8a <free+0x22>
    p->s.ptr = bp->s.ptr;
 eda:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 edc:	00001717          	auipc	a4,0x1
 ee0:	12f73223          	sd	a5,292(a4) # 2000 <freep>
}
 ee4:	6422                	ld	s0,8(sp)
 ee6:	0141                	addi	sp,sp,16
 ee8:	8082                	ret

0000000000000eea <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 eea:	7139                	addi	sp,sp,-64
 eec:	fc06                	sd	ra,56(sp)
 eee:	f822                	sd	s0,48(sp)
 ef0:	f426                	sd	s1,40(sp)
 ef2:	ec4e                	sd	s3,24(sp)
 ef4:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 ef6:	02051493          	slli	s1,a0,0x20
 efa:	9081                	srli	s1,s1,0x20
 efc:	04bd                	addi	s1,s1,15
 efe:	8091                	srli	s1,s1,0x4
 f00:	0014899b          	addiw	s3,s1,1
 f04:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
 f06:	00001517          	auipc	a0,0x1
 f0a:	0fa53503          	ld	a0,250(a0) # 2000 <freep>
 f0e:	c915                	beqz	a0,f42 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 f10:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 f12:	4798                	lw	a4,8(a5)
 f14:	08977a63          	bgeu	a4,s1,fa8 <malloc+0xbe>
 f18:	f04a                	sd	s2,32(sp)
 f1a:	e852                	sd	s4,16(sp)
 f1c:	e456                	sd	s5,8(sp)
 f1e:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 f20:	8a4e                	mv	s4,s3
 f22:	0009871b          	sext.w	a4,s3
 f26:	6685                	lui	a3,0x1
 f28:	00d77363          	bgeu	a4,a3,f2e <malloc+0x44>
 f2c:	6a05                	lui	s4,0x1
 f2e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 f32:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 f36:	00001917          	auipc	s2,0x1
 f3a:	0ca90913          	addi	s2,s2,202 # 2000 <freep>
  if (p == SBRK_ERROR)
 f3e:	5afd                	li	s5,-1
 f40:	a081                	j	f80 <malloc+0x96>
 f42:	f04a                	sd	s2,32(sp)
 f44:	e852                	sd	s4,16(sp)
 f46:	e456                	sd	s5,8(sp)
 f48:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 f4a:	00001797          	auipc	a5,0x1
 f4e:	6c678793          	addi	a5,a5,1734 # 2610 <base>
 f52:	00001717          	auipc	a4,0x1
 f56:	0af73723          	sd	a5,174(a4) # 2000 <freep>
 f5a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 f5c:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 f60:	b7c1                	j	f20 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 f62:	6398                	ld	a4,0(a5)
 f64:	e118                	sd	a4,0(a0)
 f66:	a8a9                	j	fc0 <malloc+0xd6>
  hp->s.size = nu;
 f68:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 f6c:	0541                	addi	a0,a0,16
 f6e:	efbff0ef          	jal	e68 <free>
  return freep;
 f72:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
 f76:	c12d                	beqz	a0,fd8 <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 f78:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 f7a:	4798                	lw	a4,8(a5)
 f7c:	02977263          	bgeu	a4,s1,fa0 <malloc+0xb6>
    if (p == freep)
 f80:	00093703          	ld	a4,0(s2)
 f84:	853e                	mv	a0,a5
 f86:	fef719e3          	bne	a4,a5,f78 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 f8a:	8552                	mv	a0,s4
 f8c:	9ebff0ef          	jal	976 <sbrk>
  if (p == SBRK_ERROR)
 f90:	fd551ce3          	bne	a0,s5,f68 <malloc+0x7e>
        return 0;
 f94:	4501                	li	a0,0
 f96:	7902                	ld	s2,32(sp)
 f98:	6a42                	ld	s4,16(sp)
 f9a:	6aa2                	ld	s5,8(sp)
 f9c:	6b02                	ld	s6,0(sp)
 f9e:	a03d                	j	fcc <malloc+0xe2>
 fa0:	7902                	ld	s2,32(sp)
 fa2:	6a42                	ld	s4,16(sp)
 fa4:	6aa2                	ld	s5,8(sp)
 fa6:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 fa8:	fae48de3          	beq	s1,a4,f62 <malloc+0x78>
        p->s.size -= nunits;
 fac:	4137073b          	subw	a4,a4,s3
 fb0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 fb2:	02071693          	slli	a3,a4,0x20
 fb6:	01c6d713          	srli	a4,a3,0x1c
 fba:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 fbc:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 fc0:	00001717          	auipc	a4,0x1
 fc4:	04a73023          	sd	a0,64(a4) # 2000 <freep>
      return (void *)(p + 1);
 fc8:	01078513          	addi	a0,a5,16
  }
}
 fcc:	70e2                	ld	ra,56(sp)
 fce:	7442                	ld	s0,48(sp)
 fd0:	74a2                	ld	s1,40(sp)
 fd2:	69e2                	ld	s3,24(sp)
 fd4:	6121                	addi	sp,sp,64
 fd6:	8082                	ret
 fd8:	7902                	ld	s2,32(sp)
 fda:	6a42                	ld	s4,16(sp)
 fdc:	6aa2                	ld	s5,8(sp)
 fde:	6b02                	ld	s6,0(sp)
 fe0:	b7f5                	j	fcc <malloc+0xe2>
